<?php
	class m_deliver_order extends CI_Model{
	
		function getAllMonitoringConfirm(){
			$this->db->from('kps_delivery_order_confirm');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_delivery_order_confirm.KPS_DO_ID_CONFIRM');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_vehicle','kps_outgoing_finished_good.KPS_VEHICLE_ID=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG','LEFT');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','LEFT');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->order_by('KPS_DELIVERY_ORDER_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getAll(){
			$this->db->from('kps_delivery_order');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_vehicle','kps_outgoing_finished_good.KPS_VEHICLE_ID=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG','left');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->order_by('KPS_DELIVERY_ORDER_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function updateStatusPrint($id){
			$this->db->set('KPS_DO_STATUS_PRINTED',date('Y-m-d H:i:s'));
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}	
		function confirmRefisiStatus($id){
			$this->db->set('KPS_DO_STATUS_REVISI',NULL);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function getAlls(){
			$this->db->from('kps_delivery_order');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_vehicle','kps_outgoing_finished_good.KPS_VEHICLE_ID=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->where('`KPS_DELIVERY_ORDER_ID` NOT IN (SELECT `delivery_order_id` FROM `kps_invoice_detail`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllId($id){
			$this->db->from('kps_delivery_order');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.KPS_OS_ID_OGFG','LEFT');
			$this->db->join('kps_vehicle','kps_outgoing_finished_good.KPS_VEHICLE_ID=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG','left');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->where('kps_delivery_order.KPS_DELIVERY_ORDER_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_delivery_order_');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order_.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_vehicle','kps_outgoing_finished_good.KPS_VEHICLE_ID=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->where('kps_delivery_order_.KPS_DELIVERY_ORDER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getConfirm($id){
			$this->db->from('kps_delivery_order_confirm');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_delivery_order_confirm.KPS_DO_ID_CONFIRM');
			$this->db->where("kps_delivery_order_confirm.KPS_DO_ID_CONFIRM",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllByCustomer($id){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->where("kps_bukti_pesanan.KPS_CUSTOMER_ID_BK",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByCustomerForDO($id){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG','left');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.KPS_OS_ID_OGFG','left');
			$where='(kps_bukti_pesanan.KPS_CUSTOMER_ID_BK='. $id .' OR kps_order_sheet.KPS_OS_CUSTOMER_ID='. $id .')';
			$this->db->where($where);
			$this->db->where('`KPS_OUTGOING_FINISHED_GOOD_ID` NOT IN (SELECT `KPS_OUTGOING_FINISHED_GOOD_ID_DO` FROM `kps_delivery_order`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllx($id){
			$this->db->from('kps_delivery_order');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.DELIVERY_DATE=kps_outgoing_finished_good.DELIVERY_DATE');
			
			$this->db->where("KPS_DELIVERY_ORDER_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_delivery_order');
			$this->db->where('year(DATE_DO) = '.$year);
			$this->db->where('NO_DO is not null');
			$this->db->order_by("KPS_DELIVERY_ORDER_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_delivery_order');
			// $this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			// $this->db->join('kps_delivery_schedule','kps_delivery_schedule.DELIVERY_DATE=kps_outgoing_finished_good.DELIVERY_DATE');
			// $this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_PLANT_ID=kps_delivery_order.KPS_CUSTOMER_PLANT_ID_DO');
			// $this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			// $this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			// $this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_delivery_order',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order',$data);
		}
		function updatetot($id,$total){
			$this->db->set('TOTAL_QTY',$total);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function delete($id){
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->delete('kps_delivery_order');
		}
		function getCode(){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$query = $this->db->get();
			return $query->result();
		}
		function getDetail($id){
			// $this->db->from("kps_delivery_order_detail");
			// $this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID=kps_delivery_order_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_DO');
			// $this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			// $this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			// $this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->from("kps_outgoing_finished_good");
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where("KPS_OUTGOING_FINISHED_GOOD_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailForDO($id){
			$this->db->from("kps_outgoing_finished_good");
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where("kps_delivery_order.KPS_DELIVERY_ORDER_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function getPlant($id){
			$this->db->from('kps_customer_plant');
			$this->db->join('kps_bukti_pesanan','kps_customer_plant.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID');
			$this->db->where("kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_do',$status);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function unlock($status,$id){
			$this->db->set('status_do',$status);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_do',$revno);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function del($status,$id){
			$this->db->set('DEL_DO',$status);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
		function undel($status,$id){
			$this->db->set('DEL_DO',$status);
			$this->db->where('KPS_DELIVERY_ORDER_ID',$id);
			$this->db->update('kps_delivery_order');
		}
	}

?>