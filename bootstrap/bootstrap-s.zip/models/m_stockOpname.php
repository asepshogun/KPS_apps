<?php
	class m_stockOpname extends CI_Model{
		
		function getAll(){
			$this->db->from('kps_stock_opname');
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->from('kps_stock_opname');
			$this->db->where('KPS_STOCK_OPNAME_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_stock_opname',$data);
		}
		function insertDetail($data){
			$this->db->insert('kps_stock_opname_detail',$data);
		}
		function cekBarcodeLabel($id){
			$this->db->from('kps_bsthp_detail_sub');
			$this->db->where('KPS_BARCODE_LABEL_ID_BSTHP_SUB',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function cekEksis($id,$idStockOpname){
			$this->db->from('kps_stock_opname_detail');
			$this->db->where('KPS_BARCODE_LABEL_ID_STOCK_OPNAME',$id);
			$this->db->where('KPS_STOCK_OPNAME_ID_SUB',$idStockOpname);
			$query = $this->db->get();
			return $query->first_row();
		}
		
	}

?>