<?php
	class m_section extends CI_Model{
		function getAll(){
			$this->db->from('kps_section_employee');
			$this->db->join('kps_department_employee','kps_department_employee.DEPT_EMPLOYEE_ID = kps_section_employee.DEPT_EMPLOYEE_ID_SEC');
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->where('SEC_EMPLOYEE_ID',$id);
			$query = $this->db->get('kps_section_employee');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_section_employee',$data);
		}
		function update($data,$id){
			$this->db->where('SEC_EMPLOYEE_ID',$id);
			$this->db->update('kps_section_employee',$data);
		}
		function delete($id){
			$this->db->where('SEC_EMPLOYEE_ID',$id);
			$this->db->delete('kps_section_employee');
		}

	}

?>