<?php
	class m_userdata extends CI_Model{
		private $tableName = 'kps_userdata';
		private $idTable = 'KPS_USERDATA_ID';
		
		function checkLogin($username,$password){
			$this->db->from($this->tableName);
			$this->db->join('kps_userdata_role','kps_userdata_role.user_data_id=kps_userdata.KPS_USERDATA_ID');
			$this->db->join('kps_roles','kps_roles.id=kps_userdata_role.roles_id');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_userdata.KPS_EMPLOYEE_ID');
			
			$this->db->where('USERNAME',$username);
			$this->db->where('PASSWORD',$password);
			$this->db->where('is_active',1);
			$query = $this->db->get();
			return $query->first_row();
		}
		

	}

?>