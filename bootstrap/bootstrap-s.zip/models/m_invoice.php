<?php
	class m_invoice extends CI_Model{
		
		function getaLLHistoryDeleteInvoice(){
			$this->db->from('kps_invoice_');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_.INVOICE_INDUK_ID_inv');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('KPS_INVOICE_APP_DELETE_CHANGE_NUMBER is not null');
			$this->db->where('KPS_INVOICE_NOMOR_PENGGANTI is not null');
			$this->db->where('KPS_INVOICE_STATUS_APP_DELETE_DIREKTUR is null');
			$query = $this->db->get();
			return $query->result();
		}
		function getaLLHistoryDeleteInvoiceDO(){
			$this->db->from('kps_invoice_detail_');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail_.INVOICE_INDUK_ID_DET');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail_.delivery_order_id');
			$this->db->where('KPS_INVOICE_DETAIL_STATUS_APP_DELETE is not null');
			$this->db->where('KPS_INVOICE_STATUS_APP_DELETE_DIREKTUR_DO_INVOICE is null');
			$query = $this->db->get();
			return $query->result();
		}
		function getTNoFaktur($id){
			$this->db->from('kps_invoice');
			$this->db->where('KPS_NO_INVOICE_FAKTUR_PAJAK',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getSelfDataInvoiceDO($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_delivery_order','kps_invoice_detail.delivery_order_id=kps_delivery_order.KPS_DELIVERY_ORDER_ID');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET');
			$this->db->where('KPS_INVOICE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getInvoiceDetailByIdForDelete($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET');
			$this->db->join('kps_invoice','kps_invoice.INVOICE_INDUK_ID_inv=kps_invoice_induk.INVOICE_INDUK_ID');
			$this->db->where('KPS_INVOICE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function deleteSubDetail($id,$table,$idColom){
			$this->db->where($idColom,$id);
			$this->db->delete($table);
		}
		//perubahan revisi invoice start
			function getLastIdNT(){
				$year = date('Y');
				$this->db->from('kps_invoice');
				$this->db->where('year(DATE_INVO) = '.$year);
				$this->db->where('NO_INVO is not null');
				$this->db->where('KPS_INV_NOMOR_URUT_NT_TX is not null');
				$this->db->where('REV_NO_INVO is null');
				$this->db->order_by("kps_invoice_ID","DESC");
				$query = $this->db->get();
				return $query->first_row();
			}
			function getLastId(){
				$year = date('Y');
				$this->db->from('kps_invoice');
				$this->db->where('year(DATE_INVO) = '.$year);
				$this->db->where('NO_INVO is not null');
				$this->db->where('REV_NO_INVO is not null');
				$this->db->where('KPS_INV_NOMOR_URUT_NT_TX is null');
				$this->db->order_by("kps_invoice_ID","DESC");
				$query = $this->db->get();
				return $query->first_row();
			}
		// perubahan revisi invoice end
		
		// backup revisi invoice start
				// function getLastId(){
					// $year = date('Y');
					// $this->db->from('kps_invoice');
					// $this->db->where('year(DATE_INVO) = '.$year);
					// $this->db->where('NO_INVO is not null');
					// $this->db->order_by("kps_invoice_ID","DESC");
					// $query = $this->db->get();
					// return $query->first_row();
				// }
		
		// backup revisi invoice end
		
		
		function getAll(){
			$this->db->from('kps_invoice');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice.BUKTI_PESANAN_ID');

			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			
			$query = $this->db->get();
			return $query->result();
		}
		function getType(){
			$this->db->from('kps_invoice_type');
			$query = $this->db->get();
			return $query->result();

		}
		function getTotal($id){
			$this->db->select('SUM(`QTY_DELIVERY_EXECUTION`*`KPS_BUKTI_PESANAN_DETAIL`.`price`) as `total`, SUM(`QTY_DELIVERY_EXECUTION`) as TotQTY');
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_invoice_detail','kps_invoice_detail.INVOICE_INDUK_ID_DET=kps_invoice_induk.INVOICE_INDUK_ID');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->where('kps_invoice_induk.INVOICE_INDUK_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}

		function get_induk($id){
			$this->db->from('kps_invoice');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice.INVOICE_INDUK_ID_inv');
			//perubahan untuk revisi tax invoice start
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			//perubahan untuk revisi tax invoice end
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO');
			// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->where('kps_invoice.INVOICE_INDUK_ID_inv',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function get_invoice_det($id){
			$this->db->from('kps_invoice');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice.INVOICE_INDUK_ID_inv');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO');
			// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->where('kps_invoice.KPS_INVOICE_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getInvoiceFordeleteFaktur($id){
			$this->db->from('kps_invoice');
			$this->db->where('kps_invoice.KPS_INVOICE_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function get_invoice_dets($id){
			$this->db->from('kps_invoice');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice.INVOICE_INDUK_ID_inv');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO');
			// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->where('kps_invoice.KPS_INVOICE_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function get_induks($id){
			$this->db->from('kps_invoice');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice.INVOICE_INDUK_ID_inv');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO');
			// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->where('kps_invoice.INVOICE_INDUK_ID_inv',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function get_induks_terms($id){
			$this->db->from('kps_invoice');
			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice.INVOICE_INDUK_ID_inv');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO');
			// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id');
			$this->db->where('kps_invoice.INVOICE_INDUK_ID_inv',$id);
			$this->db->order_by("KPS_INVOICE_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_invoice');
						$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_invoice.CHECKED_INVO','left');

			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice.customer_id','left');
			$this->db->where('kps_invoice.kps_invoice_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_invoice',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_invoice_ID',$id);
			$this->db->update('kps_invoice',$data);
		}
		function delete($id){
			$this->db->where('kps_invoice_ID',$id);
			$this->db->delete('kps_invoice');
		}
		function getCode(){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$query = $this->db->get();
			return $query->result();
		}
		function getDetail($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_invoice','kps_invoice_detail.KPS_INVOICE_ID=kps_invoice.KPS_INVOICE_ID');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->where('kps_invoice_detail.kps_invoice_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getTerm($id){
			$this->db->from('kps_invoice_term');
			$this->db->where('invoice_id',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function updateStatusPrint($id){
			$this->db->set('KPS_INVOICE_STATUS_PRINT',1);
			$this->db->where('KPS_INVOICE_ID',$id);
			$this->db->update('kps_invoice');
		}
	}

?>