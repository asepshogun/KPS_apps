<?php
	class m_delivery_status extends CI_Model{
		function getAll(){
			$this->db->select('LOI_CODE_ITEM, DATE_BP, REV_NO_BP, PO_OS_DATE_FROM_CUSTOMER, PO_OS_NO_FROM_CUSTOMER, COMPANY_NAME, LOI_PART_NAME, LOI_PART_NO, LOI_MODEL, QUANTITY, QTY_DELIVERY_EXECUTION, (QUANTITY - QTY_DELIVERY_EXECUTION) as REMAIN, kps_bukti_pesanan_detail.unit as UNITY, KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->from('kps_delivery_order_confirm');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID=kps_delivery_order_confirm.KPS_DO_ID_CONFIRM');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->where('kps_delivery_order_confirm.RECEIVED_DECISION','OK');
			$this->db->group_by('kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllx(){
			$this->db->select('*');
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.KPS_DO_ID_CONFIRM=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');
			$this->db->where('kps_delivery_order_confirm.RECEIVED_DECISION','OK');
			$this->db->group_by('LOI_CODE_ITEM');
			$query = $this->db->get();
			return $query->result();
		}
		function getId($id){
			$this->db->select('*');
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.KPS_DO_ID_CONFIRM=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDetail($id){
			$this->db->select('*');
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_delivery_schedule.KPS_OS_ID_DS','left');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.KPS_DO_ID_CONFIRM=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID','left');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID','left');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailpen($id){
			$this->db->select('SUM(QTY_DELIVERY_EXECUTION)-SUM(QUANTITY_DELIVERY) as pending');
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_delivery_schedule.KPS_OS_ID_DS','left');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.KPS_DO_ID_CONFIRM=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID','left');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID','left');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			//$this->db->group_by('KPS_DELIVERY_SCHEDULE_ID');
			//$this->db->or_where('kps_delivery_order_confirm.RECEIVED_DECISION','NG');
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_vehicle',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_VEHICLE_ID',$id);
			$this->db->update('kps_vehicle',$data);
		}
		function delete($id){
			$this->db->where('KPS_VEHICLE_ID',$id);
			$this->db->delete('kps_vehicle');
		}
		function getBP(){
			$query = $this->db->query('SELECT * FROM kps_bukti_pesanan_detail 
			JOIN kps_bukti_pesanan ON kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID
            JOIN kps_loi ON kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK 
			JOIN kps_customer ON kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK 
			JOIN kps_outgoing_finished_good ON kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID 
			GROUP BY kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			
			return $query->result();
		}
		function getDO($id){
			$query = $this->db->query("SELECT * FROM kps_outgoing_finished_good_detail JOIN kps_delivery_order_confirm ON kps_delivery_order_confirm.KPS_DO_ID_CONFIRM=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID	WHERE kps_delivery_order_confirm.RECEIVED_DECISION = 'OK' and KPS_OUTGOING_FINISHED_GOOD_ID_D = '".$id."'");
			
			return $query->result();
		}
		

	}

?>