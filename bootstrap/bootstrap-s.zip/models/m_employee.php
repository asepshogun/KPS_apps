<?php
	class m_employee extends CI_Model{
		function getAll(){
			$this->db->from('kps_employee');
			$this->db->join('kps_section_employee','kps_section_employee.SEC_EMPLOYEE_ID = kps_employee.SEC_EMPLOYEE_ID');
			$this->db->join('kps_department_employee','kps_department_employee.DEPT_EMPLOYEE_ID = kps_employee.DEPT_EMPLOYEE_ID');
			$this->db->join('kps_position_employee','kps_position_employee.POSITION_ID = kps_employee.POSITION_ID');
			$this->db->join('kps_group','kps_group.id = kps_employee.kps_group_id');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllx(){
			$this->db->from('kps_employee');
			$this->db->join('kps_section_employee','kps_section_employee.SEC_EMPLOYEE_ID = kps_employee.SEC_EMPLOYEE_ID');
			$this->db->join('kps_department_employee','kps_department_employee.DEPT_EMPLOYEE_ID = kps_employee.DEPT_EMPLOYEE_ID');
			$this->db->join('kps_position_employee','kps_position_employee.POSITION_ID = kps_employee.POSITION_ID');
			$this->db->join('kps_group','kps_group.id = kps_employee.kps_group_id');
			$this->db->where('`KPS_EMPLOYEE_ID` NOT IN (SELECT `KPS_EMPLOYEE_ID` FROM `kps_userdata`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->from('kps_employee');
			$this->db->join('kps_section_employee','kps_section_employee.SEC_EMPLOYEE_ID = kps_employee.SEC_EMPLOYEE_ID');
			$this->db->join('kps_department_employee','kps_department_employee.DEPT_EMPLOYEE_ID = kps_employee.DEPT_EMPLOYEE_ID');
			$this->db->join('kps_position_employee','kps_position_employee.POSITION_ID = kps_employee.POSITION_ID');
			$this->db->join('kps_group','kps_group.id = kps_employee.kps_group_id');
			$this->db->where('kps_employee.KPS_EMPLOYEE_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function gets($id){
			$this->db->from('kps_employee');
			$this->db->join('kps_section_employee','kps_section_employee.SEC_EMPLOYEE_ID = kps_employee.SEC_EMPLOYEE_ID');
			$this->db->join('kps_department_employee','kps_department_employee.DEPT_EMPLOYEE_ID = kps_employee.DEPT_EMPLOYEE_ID');
			$this->db->join('kps_position_employee','kps_position_employee.POSITION_ID = kps_employee.POSITION_ID');
			$this->db->join('kps_group','kps_group.id = kps_employee.kps_group_id');
			$this->db->where('kps_employee.KPS_EMPLOYEE_ID',$id);
			$this->db->where('`KPS_EMPLOYEE_ID` NOT IN (SELECT `KPS_EMPLOYEE_ID` FROM `kps_userdata`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_employee',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_EMPLOYEE_ID',$id);
			$this->db->update('kps_employee',$data);
		}
		function delete($id){
			$this->db->where('KPS_EMPLOYEE_ID',$id);
			$this->db->delete('kps_employee');
		}
		function getChild($table,$field,$id){
			$this->db->from($table);
			$this->db->where($field,$id);
			return $this->db->get()->result();
		}
	}

?>