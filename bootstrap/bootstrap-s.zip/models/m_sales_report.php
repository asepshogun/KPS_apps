<?php
class m_sales_report extends CI_Model{
	
		function getAll(){
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_invoice_detail','kps_invoice_detail.INVOICE_INDUK_ID_DET=kps_invoice_induk.INVOICE_INDUK_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id','left');

			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_bukti_pesanan_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_loi','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');

			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->group_by('kps_invoice_induk.INVOICE_INDUK_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getId($id){
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_invoice_detail','kps_invoice_detail.INVOICE_INDUK_ID_DET=kps_invoice_induk.INVOICE_INDUK_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id','left');

			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_bukti_pesanan_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_loi','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');

			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');

			$this->db->where('kps_invoice_induk.INVOICE_INDUK_ID',$id);

			$query = $this->db->get();
			return $query->result();
		}
	
	
	
}
?>