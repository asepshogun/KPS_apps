<?php
	class m_bsthp_detail_sub extends CI_Model{
		 private $tableName = 'kps_bsthp_detail_sub';

		private $idTable = 'KPS_BSTHP_DETAIL_SUB_ID';
		function getAll($id){
			$this->db->from($this->tableName);
			// $this->db->join('kps_bsthp_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->join('kps_barcode_label','kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
			$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_BSTHP_DETAIL_ID_SUB',$id);
			$this->db->order_by('kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_SUB_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_bsthp_detail_sub_');
			$this->db->join('kps_barcode_label','kps_bsthp_detail_sub_.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
			$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_BSTHP_DETAIL_ID_SUB',$id);
			$this->db->order_by('kps_bsthp_detail_sub_.KPS_BSTHP_DETAIL_SUB_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getSelfData($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_bsthp_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->join('kps_bsthp','kps_bsthp_detail.KPS_BSTHP_ID_det=kps_bsthp.KPS_BSTHP_ID');
			$this->db->join('kps_barcode_label','kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
			$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_BSTHP_DETAIL_SUB_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllForSub($id){
			$this->db->from($this->tableName);
			// $this->db->join('kps_bsthp_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->join('kps_barcode_label','kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
			$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_BSTHP_ID_det',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function get_no($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_bsthp_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->join('kps_bsthp','kps_bsthp_detail.KPS_BSTHP_ID_det=kps_bsthp.KPS_BSTHP_ID');
			$this->db->where('kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB',$id);
			$query = $this->db->get();
			return $query->result();
		}	
		function getVerBsthpBySub($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_bsthp_verification_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_verification_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->where('kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_SUB_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		// function getIdsub($id){
			// $this->db->from($this->tableName);
		//	($this->db->join('kps_bsthp_detail','kps_bsthp_detail_sub.KPS_BSTHP_DETAIL_ID_SUB=kps_bsthp_detail.KPS_BSTHP_DETAIL_ID');
			// $this->db->join('kps_barcode_label','kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			// $this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
			// $this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			// $this->db->where('kps_barcode.BARCODE_NO',$id);
			// $query = $this->db->get();
			// return $query->result();
		// }
		function getIdsub($barcode, $orderby){
			$this->db->from('kps_barcode_label');
			$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_bsthp_detail_sub','kps_barcode_label.kps_barcode_label_id=kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB');
			$this->db->where('code_label',$barcode);
			$this->db->where('order_label',$orderby);
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where($this->idTable,$id);
			$query = $this->db->get($this->tableName);
			return $query->first_row();
		}
		function get($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_label','kps_bsthp_detail.no_barcode_bsthp=kps_label.barcode');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_BSTHP_ID_det',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from($this->tableName);
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("kps_label_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert($this->tableName,$data);
		}
		function insertVeri($data){
			$this->db->insert('kps_bsthp_verification_detail',$data);
		}
		function insertDetail($data){
			$this->db->insert($this->tableName,$data);
		}
		function update($data,$id){
			$this->db->where($this->idTable,$id);
			$this->db->update($this->tableName,$data);
		}
		function delete($id){
			$this->db->where($this->idTable,$id);
			$this->db->delete($this->tableName);
		}
		function getVeri(){
			$this->db->from('kps_bsthp_verification_detail');
			$this->db->join('kps_bsthp','kps_bsthp_verification_detail.KPS_BSTHP_ID=kps_bsthp.KPS_BSTHP_ID');
			$this->db->join('kps_bsthp_detail','kps_bsthp_verification_detail.KPS_BSTHP_DETAIL_ID=kps_bsthp_detail.KPS_BSTHP_ID_det');
			$this->db->join('kps_label','kps_bsthp_detail.KPS_LABEL_ID=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			
			$query = $this->db->get();
			return $query->result();

		}
		function getVeriAll($code){
			$this->db->from('kps_bsthp');
			$this->db->join('kps_bsthp_detail','kps_bsthp.KPS_BSTHP_ID=kps_bsthp_detail.KPS_BSTHP_ID_det');
			$this->db->join('kps_label','kps_bsthp_detail.KPS_LABEL_ID=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('bsthp_barcode_code',$code);
			$query = $this->db->get();
			return $query->first_row();
		}
		function updateVeri($data,$id){
			$this->db->where("KPS_BSTHP_VERIFICATION_DETAIL_ID",$id);
			$this->db->update("kps_bsthp_verification_detail",$data);
		}
		function updateSubByOut($id){
			$data=array('BSTHP_DETAIL_SUB_VER_BY_OUTGOING'=>'1');
			$this->db->where('KPS_BSTHP_DETAIL_SUB_ID',$id);
			$this->db->update('kps_bsthp_detail_sub',$data);
		}
		function getIDOutBySub($id){
			$this->db->from('kps_outgoing_finished_good_detail_verification');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail_verification.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->where('KPS_BSTHP_DETAIL_SUB_ID_VER',$id);
			$query = $this->db->get();
			return $query->first_row();
		}

	}

?>