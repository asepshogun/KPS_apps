<?php
	class m_quotation extends CI_Model{
		
		//revisi quotation start
		
		function getAllBcByRfq($cisId,$RfqCus){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$cisId);
			$this->db->where('kps_rfq.RFQ_CUSTOMER_NO',$RfqCus);
			$this->db->where('`KPS_BREAKDOWN_COST_ID` NOT IN (SELECT `breakdown_cost_id` FROM `kps_quotation_detail`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAll(){
			$this->db->select('*,kps_customer_is_person_in_charge.EMAIL AS Email_PIC');
			$this->db->from('kps_quotation');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_customer_is_person_in_charge','kps_quotation.kps_customer_is_person_in_charge_quo=kps_customer_is_person_in_charge.KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('DEL_QUO','0');
			$this->db->group_by('KPS_QUOTATION_ID');
			$this->db->order_by('KPS_QUOTATION_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}	
	
		function getAllPrint($id){
			$this->db->select('*,kps_customer_is_person_in_charge.EMAIL AS Email_PIC');
			$this->db->from('kps_quotation');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->join('kps_customer_is_person_in_charge','kps_quotation.kps_customer_is_person_in_charge_quo=kps_customer_is_person_in_charge.KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('kps_quotation.kps_quotation_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		//revisi quotation end
		
		
		//back up revisi start
				// function getAll(){
					// $this->db->from('kps_quotation');
					// $this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
					// $this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
					// $this->db->join('kps_customer_is_person_in_charge','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC','left');
					// $this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
					// $this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
					// $this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
					// $this->db->where('DEL_QUO','0');
					// $this->db->group_by('KPS_QUOTATION_ID');
					// $query = $this->db->get();
					// return $query->result();
				// }
		
				// function getAllPrint($id){
					// $this->db->from('kps_quotation');
					// $this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
					// $this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
					// $this->db->join('kps_quotation_detail','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
					// $this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
					// $this->db->join('kps_customer_is_person_in_charge','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC','left');
					// $this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
					// $this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
					// $this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
					// $this->db->where('kps_quotation.kps_quotation_ID',$id);
					// $query = $this->db->get();
					// return $query->first_row();
				// }
		//back up revisi end
		function getAllMon(){
			$this->db->from('kps_quotation');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->join('kps_customer_is_person_in_charge','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->group_by('NO_QUO');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllMonh(){
			$this->db->from('kps_quotation_detail');
			$this->db->join('kps_quotation','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_loi','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');		
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$query1 = $this->db->get()->result();

			$this->db->from('kps_quotation_detail_');
			$this->db->join('kps_quotation','kps_quotation_detail_.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_loi','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');		
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$query2 = $this->db->get()->result();

			$query = array_merge($query1, $query2);

			return $query;
		}

		function gethpu($id){
			$this->db->select('NO_QUO,DATE_QUO,price,unit,VALID_DATE_FROM,VALID_DATE_UNTIL');
			$this->db->from('kps_quotation_detail');
			$this->db->join('kps_quotation','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_loi','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');		
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('kps_quotation_detail.KPS_QUOTATION_ID',$id);
			$this->db->group_by('kps_quotation_detail.price');
			$query1 = $this->db->get()->result();

			$this->db->select('NO_QUO,DATE_QUO,price,unit,VALID_DATE_FROM,VALID_DATE_UNTIL');
			$this->db->from('kps_quotation_detail_');
			$this->db->join('kps_quotation','kps_quotation_detail_.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID','left');
			
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_loi','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');		
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('kps_quotation_detail_.KPS_QUOTATION_ID',$id);
			$this->db->group_by('kps_quotation_detail_.price');
			$query2 = $this->db->get()->result();

			$query = array_merge($query1, $query2);


			return $query;
		}

		function getAllRFQForHistoryPrice(){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_production_plan','kps_rfq_production_plan.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.breakdown_cost_id=kps_breakdown_cost.KPS_BREAKDOWN_COST_ID','left');
			// $this->db->where('`KPS_RFQ_ID` NOT IN (SELECT `KPS_RFQ_ID_QUO` FROM `kps_quotation`)', NULL, FALSE);
			$this->db->order_by('kps_rfq.KPS_RFQ_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_quotation');
			$this->db->where('year(DATE_QUO) = '.$year);
			$this->db->where('NO_QUO is not null');
			$this->db->order_by("KPS_QUOTATION_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		
		function get($id){
			$this->db->from('kps_quotation');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_customer_is_person_in_charge','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('kps_quotation.kps_quotation_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function del($status,$id){
			$this->db->set('DEL_QUO',$status);
			$this->db->where('KPS_QUOTATION_ID',$id);
			$this->db->update('kps_quotation');
		}
		function undel($status,$id){
			$this->db->set('DEL_QUO',$status);
			$this->db->where('KPS_QUOTATION_ID',$id);
			$this->db->update('kps_quotation');
		}
		function geth($id){
			$this->db->from('kps_quotation_');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_CURENCY_ID=kps_quotation_.KPS_RFQ_CURENCY_ID_QUO','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_quotation_.KPS_RFQ_ID_QUO','left');
			$this->db->join('kps_customer_is_person_in_charge','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id','left');
			$this->db->where('kps_quotation_.kps_quotation_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_quotation',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_quotation_ID',$id);
			$this->db->update('kps_quotation',$data);
		}
		function delete($id){
			$this->db->where('kps_quotation_ID',$id);
			$this->db->delete('kps_quotation');
		}
		
		function getDetail($id){
			$this->db->from('kps_quotation_detail');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_BREAKDOWN_COST_ID = kps_quotation_detail.breakdown_cost_id');
			$this->db->where("kps_quotation_detail.KPS_QUOTATION_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllDetail(){
			$this->db->from('kps_quotation_detail');
			$query = $this->db->get();
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getPic($id){
			$this->db->from('kps_customer_is_person_in_charge');
			$this->db->join('kps_rfq','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function excelexport($id){
			$query = $this->db->query('SELECT a.KPS_RFQ_ID, DATE_RFQ, TOOLING_COST_RFQ, PART_STATUS, NO_RFQ, PERIODE, RFQ_CUSTOMER_NO, RFQ_CUSTOMER_DATE, COMPANY_NAME, RECEIVING_RFQ_DATE, RFQ_CUSTOMER_DATE, DUE_DATE_QUOTATION, ESTIMATION_LOI_DATE, KPS_RFQ_PART_NO, KPS_RFQ_PART_NAME, KPS_RFQ_PART_QTY, KPS_RFQ_PART_UNIT, CURRENCY_NAME, TO_IDR, e.MODEL, QTY_UNIT, QTY_MONTH, PP1, SAMPLE_MASSPRO, MASSPRO, COMPETITIOR_NAME, COMPETITIOR_PRICE, TARGET_PRICE, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = employee_checked_by) as employee_checked, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = employee_approved_by) as employee_approved, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = a.user_made_by_id) as user_made, DATE_QUO, NO_QUO, VALID_DATE_FROM, VALID_DATE_UNTIL, TELP, FAX, NO_BREAK, TOTAL_BREAKDOWN

			FROM kps_rfq a, kps_customer b, kps_rfq_drawing c, kps_rfq_currency d,kps_rfq_production_plan e, kps_rfq_schedule f, kps_rfq_target_price g, kps_quotation h, kps_customer_plant i, kps_breakdown_cost j
			where 
			b.KPS_CUSTOMER_ID = a.KPS_CUSTOMER_ID_RFQ and
			a.KPS_RFQ_ID = c.KPS_RFQ_ID and
			a.KPS_RFQ_ID = d.KPS_RFQ_ID and
			a.KPS_RFQ_ID = e.KPS_RFQ_ID and
			a.KPS_RFQ_ID = f.KPS_RFQ_ID and
			a.KPS_RFQ_ID = g.KPS_RFQ_ID and
			a.KPS_RFQ_ID = h.rfq_id and
			b.KPS_CUSTOMER_ID = i.KPS_CUSTOMER_ID and
			a.KPS_RFQ_ID = j.KPS_RFQ_ID_BREAK and
			a.KPS_RFQ_ID = '.$id.'');

			return $query->result();
		}
		function getAllRFQ(){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->where('`KPS_RFQ_ID` NOT IN (SELECT `KPS_RFQ_ID_QUO` FROM `kps_quotation`)', NULL, FALSE);
			$this->db->order_by('KPS_RFQ_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getRFQ($id){
			$query = $this->db->query('SELECT * FROM kps_breakdown_cost a, kps_rfq b, kps_rfq_production_plan c, kps_rfq_drawing d where b.KPS_RFQ_ID=a.KPS_RFQ_ID_BREAK and b.KPS_RFQ_ID = c.KPS_RFQ_ID and b.KPS_RFQ_ID=d.KPS_RFQ_ID and b.KPS_RFQ_ID ='.$id.'');

			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_quo',$status);
			$this->db->where('kps_quotation_ID',$id);
			$this->db->update('kps_quotation');
		}
		function unlock($status,$id){
			$this->db->set('status_quo',$status);
			$this->db->where('kps_quotation_ID',$id);
			$this->db->update('kps_quotation');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_quo',$revno);
			$this->db->where('kps_quotation_ID',$id);
			$this->db->update('kps_quotation');
		}
	}

?>