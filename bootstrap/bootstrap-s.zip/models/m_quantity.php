<?php
	class m_quantity extends CI_Model{
		function getAll(){
			$this->db->from('kps_marketing_quantity');
			$this->db->join('kps_loi','kps_marketing_quantity.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where('KPS_MARKETING_QUANTITY_ID',$id);
			$query = $this->db->get('kps_marketing_quantity');
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_marketing_quantity');
			$this->db->join('kps_loi','kps_marketing_quantity.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_marketing_quantity.KPS_MARKETING_QUANTITY_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getdet($loi){
			$this->db->select("sum(QTY_DELIVERY_EXECUTION) as delivery_exe, CONCAT(MONTH(INVOICE_INDUK_DATE), ' - ' ,YEAR(INVOICE_INDUK_DATE)) as yearmonth", FALSE);
			$this->db->from('kps_loi');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');

			$this->db->join('kps_invoice_detail','kps_invoice_detail.delivery_order_id=kps_delivery_order.KPS_DELIVERY_ORDER_ID','left');

			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET','left');

			$this->db->where('kps_loi.KPS_LOI_ID',$loi);

			$this->db->group_by('yearmonth');
			$query = $this->db->get();
			return $query->result();
		}
		function getdetLast($loi){
			$this->db->select("sum(QTY_DELIVERY_EXECUTION) as delivery_exe, CONCAT(MONTH(INVOICE_INDUK_DATE), ' - ' ,YEAR(INVOICE_INDUK_DATE)) as yearmonth", FALSE);
			$this->db->from('kps_loi');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');

			$this->db->join('kps_invoice_detail','kps_invoice_detail.delivery_order_id=kps_delivery_order.KPS_DELIVERY_ORDER_ID','left');

			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET','left');

			$this->db->where('kps_loi.KPS_LOI_ID',$loi);

			$this->db->group_by('yearmonth');
			$this->db->order_by('yearmonth','DESC');
			$query = $this->db->get();
			return $query->first_row();
		}
		function getdets($loi){
			$query ="SELECT CONCAT(MONTH(INVOICE_INDUK_DATE),' - ',YEAR(INVOICE_INDUK_DATE)) as yearmonth, sum(QTY_DELIVERY_EXECUTION) as delivery_exe FROM (`kps_loi`) 
				LEFT JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK`=`kps_loi`.`KPS_LOI_ID` 
				LEFT JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`=`kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID` 
				LEFT JOIN `kps_outgoing_finished_good_detail` ON `kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD`=`kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID` 
				LEFT JOIN `kps_delivery_order` ON `kps_delivery_order`.`KPS_OUTGOING_FINISHED_GOOD_ID_DO`=`kps_outgoing_finished_good_detail`.`KPS_OUTGOING_FINISHED_GOOD_ID_D` 
				LEFT JOIN `kps_invoice_detail` ON `kps_invoice_detail`.`delivery_order_id`=`kps_delivery_order`.`KPS_DELIVERY_ORDER_ID` 
				LEFT JOIN `kps_invoice_induk` ON `kps_invoice_induk`.`INVOICE_INDUK_ID`=`kps_invoice_detail`.`INVOICE_INDUK_ID_DET` 
				WHERE `kps_loi`.`KPS_LOI_ID` = '3'
				GROUP BY yearmonth";
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_marketing_quantity');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO_MQ is not null');
			$this->db->order_by("KPS_MARKETING_QUANTITY_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_marketing_quantity',$data);
		}
		function insertDet($data){
			$this->db->insert('kps_marketing_quantity_detail',$data);
		}
		function insertDetail($data){
			$this->db->insert('kps_marketing_quantity_detail',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_MARKETING_QUANTITY_ID',$id);
			$this->db->update('kps_marketing_quantity',$data);
		}
		function updatedet($data,$id){
			$this->db->where('KPS_MARKETING_QUANTITY_ID',$id);
			$this->db->update('kps_marketing_quantity_detail',$data);
		}
		function delete($id){
			$this->db->where('KPS_MARKETING_QUANTITY_ID',$id);
			$this->db->delete('kps_marketing_quantity');
		}
		function cekID($id){
			$this->db->from('kps_marketing_quantity_detail');
			$this->db->where('KPS_MARKETING_QUANTITY_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}

	}

?>