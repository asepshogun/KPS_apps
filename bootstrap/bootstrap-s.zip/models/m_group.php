<?php
	class m_group extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_group');
			return $query->result();
		}
		function get($id){
			$this->db->where('id',$id);
			$query = $this->db->get('kps_group');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_group',$data);
		}
		function update($data,$id){
			$this->db->where('id',$id);
			$this->db->update('kps_group',$data);
		}
		function delete($id){
			$this->db->where('id',$id);
			$this->db->delete('kps_group');
		}

	}

?>