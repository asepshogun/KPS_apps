<?php
	class m_delivery_quota extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_vehicle');
			return $query->result();
		}
		function getbyid($id){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D');
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join('kps_bukti_pesanan_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_loi','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->where('kps_outgoing_finished_good.KPS_VEHICLE_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		
	}
?>
		