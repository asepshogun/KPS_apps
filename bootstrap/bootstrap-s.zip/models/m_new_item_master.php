<?php
	class m_new_item_master extends CI_Model{
	function getAll(){
			$this->db->from('kps_item_master');
			$this->db->where('ITEM_MASTER_STATUS_DELETE',0);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_item_master_');
			$this->db->where('KPS_ITEM_MASTER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->from('kps_item_master');
			$this->db->where('KPS_ITEM_MASTER_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_item_master',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_ITEM_MASTER_ID',$id);
			$this->db->update('kps_item_master',$data);
		}
		function getForLoi($id){
		$query = $this->db->query('select * 
				from kps_item_master  
				where KPS_ITEM_MASTER_ID= '.$id.'');
			return $query->result();
		}
	}
	?>