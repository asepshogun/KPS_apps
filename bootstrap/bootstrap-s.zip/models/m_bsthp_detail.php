<?php
	class m_bsthp_detail extends CI_Model{
		 private $tableName = 'kps_bsthp_detail';

		private $idTable = 'KPS_BSTHP_DETAIL_ID';
		function getAll($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_loi','kps_bsthp_detail.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->order_by('kps_bsthp_detail.KPS_BSTHP_DETAIL_ID','desc');
			$this->db->where('KPS_BSTHP_ID_det',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_bsthp_detail_');
			$this->db->join('kps_loi','kps_bsthp_detail_.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->order_by('kps_bsthp_detail_.ID_BSTHP_DETAIL_','desc');
			$this->db->where('KPS_BSTHP_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDet($id){
		$this->db->from($this->tableName);
		$this->db->where('KPS_BSTHP_DETAIL_ID',$id);
		$query = $this->db->get();
		return $query->first_row();
		}
		function updatelock($id){
			$data=array('BSTHP_DETAIL_LOCK'=>'1');
			$this->db->where('KPS_BSTHP_DETAIL_ID',$id);
			$this->db->update('kps_bsthp_detail',$data);
		}
		function getOnly($id){
			$this->db->where($this->idTable,$id);
			$query = $this->db->get($this->tableName);
			return $query->first_row();
		}
		function get($id){
			$this->db->from($this->tableName);
			$this->db->join('kps_bsthp','kps_bsthp_detail.KPS_BSTHP_ID_det=kps_bsthp.KPS_BSTHP_ID');
			$this->db->join('kps_loi','kps_bsthp_detail.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID');
			$this->db->where('KPS_BSTHP_ID_det',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from($this->tableName);
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("kps_label_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert($this->tableName,$data);
		}
		function insertVeri($data){
			$this->db->insert('kps_bsthp_verification_detail',$data);
		}
		function insertDetail($data){
			$this->db->insert($this->tableName,$data);
		}
		function update($data,$id){
			$this->db->where($this->idTable,$id);
			$this->db->update($this->tableName,$data);
		}
		function delete($id){
			$this->db->where($this->idTable,$id);
			$this->db->delete($this->tableName);
		}
		function getVeri($id){
			$this->db->from('kps_bsthp_verification_detail');
			$this->db->join('kps_bsthp','kps_bsthp_verification_detail.KPS_BSTHP_ID=kps_bsthp.KPS_BSTHP_ID','left');
			$this->db->join('kps_bsthp_detail','kps_bsthp_verification_detail.KPS_BSTHP_DETAIL_ID=kps_bsthp_detail.KPS_BSTHP_ID_det','left');
			// $this->db->join('kps_label','kps_bsthp_detail.KPS_LABEL_ID=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_bsthp_detail.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID','left');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID','left');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID','left');
			$this->db->where('kps_bsthp_verification_detail.KPS_BSTHP_ID',$id);
			$this->db->group_by('KPS_BSTHP_VERIFICATION_DETAIL_ID');
			$query = $this->db->get();
			return $query->result();

		}
		function getIdBsthpByIdVer($id){
			$this->db->from('kps_bsthp_verification_detail');
			$this->db->where('KPS_BSTHP_VERIFICATION_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getBarLabelByIdVer($id){
			$this->db->from('kps_bsthp_detail_sub');
			$this->db->join('kps_barcode_label','kps_bsthp_detail_sub.KPS_BARCODE_LABEL_ID_BSTHP_SUB=kps_barcode_label.kps_barcode_label_id');
			$this->db->where('KPS_BSTHP_DETAIL_ID_SUB',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getVeriAll($code){
			$this->db->from('kps_bsthp');
			$this->db->join('kps_bsthp_detail','kps_bsthp.KPS_BSTHP_ID=kps_bsthp_detail.KPS_BSTHP_ID_det');
			// $this->db->join('kps_label','kps_bsthp_detail.KPS_LABEL_ID=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_bsthp_detail.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('bsthp_barcode_code',$code);
			$query = $this->db->get();
			return $query->first_row();
		}
		function updateVeri($data,$id){
			$this->db->where("KPS_BSTHP_VERIFICATION_DETAIL_ID",$id);
			$this->db->update("kps_bsthp_verification_detail",$data);
		}
		function updateStatusLabelDes($id){
			$data=array('BARCODE_LABEL_DESTINATION'=>'1');
			$this->db->where('kps_barcode_label_id',$id);
			$this->db->update('kps_barcode_label',$data);
		}
		function updateStatusSubDes($id){
			$data=array('BSTHP_DETAIL_SUB_VER'=>'1');
			$this->db->where('KPS_BSTHP_DETAIL_SUB_ID',$id);
			$this->db->update('kps_bsthp_detail_sub',$data);
		}

	}

?>