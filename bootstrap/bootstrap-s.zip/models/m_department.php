<?php
	class m_department extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_department_employee');
			return $query->result();
		}
		function get($id){
			$this->db->where('DEPT_EMPLOYEE_ID',$id);
			$query = $this->db->get('kps_department_employee');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_department_employee',$data);
		}
		function update($data,$id){
			$this->db->where('DEPT_EMPLOYEE_ID',$id);
			$this->db->update('kps_department_employee',$data);
		}
		function delete($id){
			$this->db->where('DEPT_EMPLOYEE_ID',$id);
			$this->db->delete('kps_department_employee');
		}

	}

?>