<?php
	class m_order_sheet extends CI_Model{
		function getAll(){
			$this->db->from('kps_order_sheet');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_order_sheet');
			$this->db->where('year(DELIVERY_DATE) = '.$year);
			$this->db->where('NO_REV_NO is not null');
			$this->db->order_by("kps_order_sheet_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_order_sheet');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet.KPS_BUKTI_PESANAN_ID_DS');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_order_sheet.kps_order_sheet_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_order_sheet',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_order_sheet_ID',$id);
			$this->db->update('kps_order_sheet',$data);
		}
		function delete($id){
			$this->db->where('kps_order_sheet_ID',$id);
			$this->db->delete('kps_order_sheet');
		}
		function getDetail($id){
			$this->db->from("kps_order_sheet_detail");
			$this->db->join('kps_order_sheet','kps_order_sheet_detail.kps_order_sheet_ID=kps_order_sheet_detail.kps_order_sheet_ID');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_order_sheet_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID');

			$this->db->where("kps_order_sheet_detail.kps_order_sheet_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDelivSetup(){
			return $this->db->get('kps_customer_delivery_setup')->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
	}

?>