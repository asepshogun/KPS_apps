<?php
	class m_schedule extends CI_Model{
		function cekOutgoing($id){
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D');
			$this->db->where('KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDsForDelete($idBpdet){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where('KPS_BUKTI_PESANAN_DETAIL_ID_SD',$idBpdet);
			$query = $this->db->get();
			return $query->result();
		}
		function getBpDetForDel($idBpdet){
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->where('KPS_BUKTI_PESANAN_DETAIL_ID',$idBpdet);
			$query = $this->db->get();
			return $query->first_row();
		}
		function updateFordelete($data,$id){
			$this->db->where('KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$this->db->update('kps_delivery_schedule_detail',$data);
		}
		function deleteDsDet($id){
			$this->db->where('KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$this->db->delete('kps_delivery_schedule_detail');
		}
		//for Return Pending
		function getForPending($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where('KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function checkBuktiDetailForRePending($id,$idDsd){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID_SD",$id);
			$this->db->where("KPS_DSD_R_PENDING",$idDsd);
			$query = $this->db->get();
			return $query->result();
		}
		function getRemainingReturnPending($id,$idDsd){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID_SD",$id);
			$this->db->where("KPS_DSD_R_PENDING",$idDsd);
			$this->db->order_by("KPS_DELIVERY_SCHEDULE_DETAIL_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		//for Return Pending
		
		function getAll(){
			$this->db->from('kps_delivery_schedule');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_delivery_schedule.employee_checked_id');
			$this->db->order_by("KPS_DELIVERY_SCHEDULE_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getDelivSetupForOs($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			return $this->db->get('kps_customer_delivery_setup')->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_delivery_schedule');
			$this->db->where('year(DELIVERY_DATE) = '.$year);
			$this->db->where('NO_REV_NO is not null');
			$this->db->order_by("kps_delivery_schedule_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_delivery_schedule');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_delivery_schedule.kps_delivery_schedule_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByDsDet($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_delivery_schedule_');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_delivery_schedule_.KPS_BUKTI_PESANAN_ID_DS');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_delivery_schedule_.kps_delivery_schedule_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getTotSchedule($date){
			$this->db->select('kps_delivery_schedule.TOTAL as TOTAL');
			$this->db->from('kps_delivery_schedule');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->where('kps_delivery_schedule_detail.DELIVERY_PLAN',$date);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getOnly($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where('kps_delivery_schedule_id',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_delivery_schedule',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule',$data);
		}
		function updatetot($total,$id){
			$this->db->set('TOTAL',$total);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
		function delete($id){
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->delete('kps_delivery_schedule');
		}
		function getDetail($id){
			$this->db->from("kps_delivery_schedule_detail");
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');

			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');	
			$this->db->where('kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDate($id){
			$this->db->from("kps_delivery_schedule_detail");
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->where('kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function cekDP($dp,$bpd){
			$this->db->select('DELIVERY_PLAN','KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where('DELIVERY_PLAN',$dp);
			$this->db->where('KPS_BUKTI_PESANAN_DETAIL_ID_SD',$bpd);
			$query = $this->db->get();
			return $query->first_row();

		}
		function getDetailPesanan($id){
			$this->db->from("kps_delivery_schedule_detail");
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');	
			$this->db->order_by('KPS_DELIVERY_SCHEDULE_DETAIL_ID','desc');
			$this->db->where('kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDetailDP($id){
			$this->db->from("kps_delivery_schedule");
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');	
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDelivSetup($id){
			$this->db->from("kps_bukti_pesanan");
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->from($table);
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');	
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID');
			$this->db->where($tableId,$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getDeliveryPlan($id){
			$query = $this->db->query("SELECT `DELIVERY_PLAN`
			FROM (`kps_delivery_schedule_detail`)
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			WHERE `KPS_BUKTI_PESANAN_ID` =  '.$id.' and DELIVERY_PLAN not in(
				select DELIVERY_DATE from kps_outgoing_finished_good
			)
			GROUP BY `kps_delivery_schedule_detail`.`DELIVERY_PLAN`");
			// echo $this->db->last_query();
			return $query->result();
		}
		function getDeliveryPlanForOs($id){
			$query = $this->db->query("SELECT `KPS_OS_SCHEDULE_DELIVERY_DATE`
			FROM (`kps_order_sheet`)
			WHERE `KPS_OS_ID` =".$id);
			// echo $this->db->last_query();
			return $query->first_row();
		}
		// count pending Item start
		function getAllPendingGroupBP(){
			$query = $this->db->query('SELECT *,(SUM(kps_outgoing_finished_good_detail.QTY_PENDING_OFGD)) AS TOTAL_PENDING_BP FROM `kps_outgoing_finished_good_detail` 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID`=`kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD` 
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_outgoing_finished_good_detail.QTY_PENDING_OFGD IS NOT NULL
			and kps_outgoing_finished_good_detail.QTY_PENDING_OFGD != 0
			and kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		function getAllReturnPendingGroupBP(){
			$query = $this->db->query('SELECT *,(SUM(kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD)) AS TOTAL_RETURN_PENDING_BP FROM `kps_outgoing_finished_good_detail` 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID`=`kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD` 
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD IS NOT NULL
			and kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD != 0
			and kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		function getAllPendingGroupBpNotExe(){
			$query = $this->db->query('SELECT *,(SUM(kps_delivery_schedule_detail.QUANTITY_DELIVERY)) AS TOTAL_PENDING_BP_DSD FROM `kps_delivery_schedule_detail`  
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_delivery_schedule_detail.DELIVERY_PLAN < CURDATE()
			AND kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID NOT IN (SELECT KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD FROM kps_outgoing_finished_good_detail)
			AND kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		function getAllPendingGroupBPDetailByIdBp($id){
			$query = $this->db->query('SELECT *,(SUM(kps_outgoing_finished_good_detail.QTY_PENDING_OFGD)) AS TOTAL_PENDING_BP FROM `kps_outgoing_finished_good_detail` 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID`=`kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD` 
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_outgoing_finished_good_detail.QTY_PENDING_OFGD IS NOT NULL
			and kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID = '. $id .'
			and kps_outgoing_finished_good_detail.QTY_PENDING_OFGD != 0
			and kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		function getAllReturnPendingGroupBPDetailByIdBp($id){
			$query = $this->db->query('SELECT *,(SUM(kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD)) AS TOTAL_RETURN_PENDING_BP FROM `kps_outgoing_finished_good_detail` 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID`=`kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD` 
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD IS NOT NULL
			and kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID = '. $id .'
			and kps_outgoing_finished_good_detail.QTY_RETURN_PENDING_OFGD != 0
			and kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		function getAllPendingGroupBpNotExeDetailByIdBp($id){
			$query = $this->db->query('SELECT *,(SUM(kps_delivery_schedule_detail.QUANTITY_DELIVERY)) AS TOTAL_PENDING_BP_DSD FROM `kps_delivery_schedule_detail`  
			JOIN kps_delivery_schedule ON kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD`
			where kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID = '. $id .'
			AND kps_delivery_schedule_detail.DELIVERY_PLAN < CURDATE()
			AND kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID NOT IN (SELECT KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD FROM kps_outgoing_finished_good_detail)
			AND kps_delivery_schedule.KPS_OS_ID_DS IS NULL
			GROUP BY kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			return $query->result();
		}
		// count pending Item end
		function getDeliveryPlans($id){
			$this->db->select('DELIVERY_PLAN');
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->where('kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID',$id);
			$this->db->where('kps_delivery_schedule.KPS_OS_ID_DS',NULL);
			$this->db->where('`DELIVERY_PLAN` NOT IN (SELECT `DELIVERY_DATE` FROM `kps_outgoing_finished_good` WHERE KPS_BUKTI_PESANAN_ID_OGFG IS NOT NULL AND KPS_BUKTI_PESANAN_ID_OGFG ='. $id .')', NULL, FALSE);
			$this->db->where('`kps_delivery_schedule_detail`.`DELIVERY_PLAN` >=',date('Y-m-d'));
			$this->db->group_by('`kps_delivery_schedule_detail`.`DELIVERY_PLAN`');
			$query = $this->db->get();
			return $query->result();
		}

		function getDeliveryPlanx($id){
			$this->db->select('DELIVERY_DATE');
			$this->db->from('kps_delivery_schedule');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID = kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS');
			$this->db->where('kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID',$id);
			$this->db->where('kps_delivery_schedule.KPS_OS_ID_DS',NULL);
			$query = $this->db->get();
			return $query->result();
		}
		function getCustom($id){
			$this->db->from('kps_delivery_schedule');
			$this->db->where($field,$id);
			$query = $this->db->get();
			return $query->result();
		}
		function checkBuktiDetail($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID_SD",$id);
			$this->db->where("KPS_DSD_R_PENDING",NULL,True);
			$query = $this->db->get();
			return $query->result();
		}
		function getRemaining($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID_SD",$id);
			$this->db->where("KPS_DSD_R_PENDING",NULL,True);
			$this->db->order_by("KPS_DELIVERY_SCHEDULE_DETAIL_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function lock($status,$id){
			$this->db->set('status_ds',$status);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
		function unlock($status,$id){
			$this->db->set('status_ds',$status);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_ds',$revno);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
		function del($status,$id){
			$this->db->set('DEL_DS',$status);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
		function undel($status,$id){
			$this->db->set('DEL_DS',$status);
			$this->db->where('kps_delivery_schedule_ID',$id);
			$this->db->update('kps_delivery_schedule');
		}
	}

?>