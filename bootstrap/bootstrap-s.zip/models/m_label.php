<?php
	class m_label extends CI_Model{
		function getAll(){
			$this->db->from('kps_label');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->order_by('kps_label.KPS_LABEL_ID','desc');
			// $this->db->join('kps_employee','kps_label.INSPECTOR=kps_employee.KPS_EMPLOYEE_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_label_');
			$this->db->join('kps_loi','kps_label_.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->order_by('kps_label_.ID_KPS_LABEL_','desc');
			$this->db->where('kps_label_.KPS_LABEL_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where('kps_label_ID',$id);
			$query = $this->db->get('kps_label');
			return $query->first_row();
		}
		// Barcode Setting start
		function updateBarcodeSetting($data,$id){
			$this->db->where('KPS_BARCODE_SETTING_ID',$id);
			$this->db->update('kps_barcode_setting',$data);
		}
		function getBarcodeSetting($id){
			$this->db->where('KPS_BARCODE_SETTING_ID',$id);
			$query = $this->db->get('kps_barcode_setting');
			return $query->first_row();
		}
		function getAllHistoryBarcodeSetting($id){
			$this->db->from('kps_barcode_setting_');
			$this->db->where('KPS_BARCODE_SETTING_ID',$id);
			$this->db->order_by('kps_barcode_setting_.KPS_BARCODE_SETTING_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function insertBarcodeLabelSetting(){
			$data=array(
					'KPS_BARCODE_PADDING'=>'5',
					'KPS_BARCODE_FONT_SIZE'=>'17',
					'KPS_BARCODE_SIZE_BARCODE'=>'20',
					'KPS_BARCODE_SETTING_MADE_BY'=>'0'
					);
			$this->db->insert('kps_barcode_setting',$data);
		}
		function setDefaultBarcodeLabelSetting($id,$idMadeBy){
			$data=array(
					'KPS_BARCODE_PADDING'=>'5',
					'KPS_BARCODE_FONT_SIZE'=>'17',
					'KPS_BARCODE_SIZE_BARCODE'=>'20',
					'KPS_BARCODE_SETTING_MADE_BY'=>$idMadeBy
					);
			$this->db->where('KPS_BARCODE_SETTING_ID',$id);
			$this->db->update('kps_barcode_setting',$data);
		}
		// Barcode Setting end
		function get($id){
			$this->db->from('kps_label');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_label.kps_label_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getForUpdate($id){
			$this->db->from('kps_label');
			$this->db->where('kps_label.kps_label_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_label');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO_LABEL is not null');
			$this->db->order_by("kps_label_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function getLabelByBarcode($barcode){
			$this->db->from('kps_barcode_label');
			$this->db->join('kps_label','kps_label.KPS_LABEL_ID=kps_barcode_label.label_id');
			$this->db->join('kps_barcode','kps_barcode.KPS_BARCODE_ID=kps_barcode_label.barcode_id');
			$this->db->where('code_label',$barcode);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getIdbarcode($barcode, $orderby){
			$this->db->from('kps_barcode_label');
			$this->db->where('code_label',$barcode);
			$this->db->where('order_label',$orderby);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiCode($id){
			$this->db->from('kps_barcode_label');
			$this->db->join('kps_label','kps_label.KPS_LABEL_ID=kps_barcode_label.label_id');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->where('kps_barcode_label_id',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function updateStatusOTW($id){
			$data=array('BARCODE_LABEL_OTW'=>'1');
			$this->db->where('kps_barcode_label_id',$id);
			$this->db->update('kps_barcode_label',$data);
		}
		function updateStatusOTWToNol($id){
			$data=array('BARCODE_LABEL_OTW'=>'NULL');
			$this->db->where('kps_barcode_label_id',$id);
			$this->db->update('kps_barcode_label',$data);
		}
		function getDataBrcode(){
		$this->db->from('kps_barcode_label');
		$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
		$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
		$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
		$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
		$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
		$this->db->order_by("label_id","DESC");
		$this->db->group_by('label_id');
		$query = $this->db->get();
		return $query->result();
		}
		function getDataBrcode_group(){
		$this->db->select('* , sum(kps_label.QUANTITY) as QTYTOT , sum(kps_label.qty_barcode) as QTYTOTBar','LEFT');
		$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID','LEFT');
		$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID','LEFT');
		$this->db->join('kps_item_master','kps_loi.KPS_LOI_ITEM_MASTER_ID=kps_item_master.KPS_ITEM_MASTER_ID','LEFT');
		$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID','LEFT');
		$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID','LEFT');
		$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','LEFT');
		$this->db->group_by('kps_item_master.KPS_ITEM_MASTER_ID');
		$query = $this->db->get('kps_barcode_label');
		return $query->result();
		}
		function getData_barcode_byID($id){
		$this->db->from('kps_barcode_label');
		$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
		$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
		$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
		$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
		$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
		$this->db->group_by('label_id');
		$this->db->where('kps_barcode_label.label_id',$id);
		$query = $this->db->get();
		return $query->first_row();
		}
		function getDataBarcodeDetail($id){
		$this->db->from('kps_barcode_label');
		$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID');
		$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
		$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
		$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID');
		$this->db->where('kps_barcode_label.label_id',$id);
		$query = $this->db->get();
		return $query->result();
		}
		function getDataBarcodeDetailAll(){
		$this->db->from('kps_barcode_label');
		$this->db->join('kps_label','kps_barcode_label.label_id=kps_label.KPS_LABEL_ID','LEFT');
		$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID','LEFT');
		$this->db->join('kps_item_master','kps_loi.KPS_LOI_ITEM_MASTER_ID=kps_item_master.KPS_ITEM_MASTER_ID','LEFT');
		$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID','LEFT');
		$this->db->join('kps_barcode','kps_barcode_label.barcode_id=kps_barcode.KPS_BARCODE_ID','LEFT');
		$query = $this->db->get();
		return $query->result();
		}
		function getDataBarcode($labelId){
			$this->db->from('kps_barcode_label');
			$this->db->join('kps_label','kps_label.KPS_LABEL_ID=kps_barcode_label.label_id');
			$this->db->join('kps_barcode','kps_barcode.KPS_BARCODE_ID=kps_barcode_label.barcode_id');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('label_id',$labelId);
			$query = $this->db->get();
			return $query->result();
		}	
		function getDataBarcodeByMutation($labelId){
			$this->db->from('kps_barcode_label');
			$this->db->join('kps_label','kps_label.KPS_LABEL_ID=kps_barcode_label.label_id');
			$this->db->join('kps_barcode','kps_barcode.KPS_BARCODE_ID=kps_barcode_label.barcode_id');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('KPS_LABEL_ID_MUTATION',$labelId);
			$query = $this->db->get();
			return $query->result();
		}
		function getInventory(){
			$this->db->from('');
			
		}
		function checkLabelBarcode($codeLabel){

			$this->db->from('kps_barcode_label');
			$this->db->where('code_label',$codeLabel);
			$this->db->order_by('order_label','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getBarcodeForUpdate($id){

			$this->db->from('kps_barcode_label');
			$this->db->where('label_id',$id);
			$this->db->order_by('order_label','DESC');
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_label',$data);
			return $this->db->insert_id();

		}
		function insertBarcodeLabel($data){
			$this->db->insert('kps_barcode_label',$data);
				return $this->db->insert_id();

		}

		function insertDetail($data){
			$this->db->insert('kps_label',$data);
		}
		function insertBarcode($data){
			$this->db->insert('kps_barcode',$data);
			return $this->db->insert_id();
		}
		function update($data,$id){
			$this->db->where('kps_label_ID',$id);
			$this->db->update('kps_label',$data);
		}
		function delete($id){
			$this->db->where('kps_label_ID',$id);
			$this->db->delete('kps_label');
		}

	}

?>