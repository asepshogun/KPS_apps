<?php
	class m_marketing extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_marketing');
			return $query->result();
		}
		function get($id){
			$this->db->where('KPS_MARKETING_ID',$id);
			$query = $this->db->get('kps_marketing');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_marketing',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_MARKETING_ID',$id);
			$this->db->insert('kps_marketing',$data);
		}
		function delete($id){
			$this->db->where('KPS_MARKETING_ID',$id);
			$this->db->delete('kps_marketing');
		}

	}

?>