<?php
	class m_project extends CI_Model{
		function getAll(){
			$this->db->from('kps_failed_project');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_failed_project.KPS_RFQ_ID_FAILED');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_failed_project');
			$this->db->where('year(DATE_FAILED) = '.$year);
			$this->db->where('NO_FAILED is not null');
			$this->db->order_by("kps_failed_project_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_failed_project');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_failed_project.KPS_RFQ_ID_FAILED');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_failed_project.employee_approved_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->where('kps_failed_project.kps_failed_project_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_failed_project_');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_failed_project_.KPS_RFQ_ID_FAILED');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_failed_project_.employee_approved_id=kps_employee.KPS_EMPLOYEE_ID');
			$this->db->where('kps_failed_project_.kps_failed_project_ID',$id);
			$this->db->group_by('kps_failed_project_.revisi_no_project');
			$query = $this->db->get();
			return $query->result();

		}
		function del($status,$id){
			$this->db->set('DEL_PROJECT',$status);
			$this->db->where('kps_failed_project_ID',$id);
			$this->db->update('kps_failed_project');
		}
		function undel($status,$id){
			$this->db->set('DEL_PROJECT',$status);
			$this->db->where('kps_failed_project_ID',$id);
			$this->db->update('kps_failed_project');
		}
		function lock($status,$id){
			$this->db->set('status_project',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_failed_project');
		}
		function unlock($status,$id){
			$this->db->set('status_project',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_failed_project');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_project',$revno);
			$this->db->where('kps_failed_project_ID',$id);
			$this->db->update('kps_failed_project');
		}
		function insert($data){
			$this->db->insert('kps_failed_project',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_failed_project_ID',$id);
			$this->db->update('kps_failed_project',$data);
		}
		function delete($id){
			$this->db->where('kps_failed_project_ID',$id);
			$this->db->delete('kps_failed_project');
		}
		function getDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
	}

?>