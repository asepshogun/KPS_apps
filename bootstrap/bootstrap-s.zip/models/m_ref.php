<?php
	class m_ref extends CI_Model{
		public function getKabkota(){
			$query = $this->db->get('tref_kabkota');
			return $query->result();
		}
	}
?>