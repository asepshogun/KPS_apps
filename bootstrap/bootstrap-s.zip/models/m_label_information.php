<?php
	class m_label_information extends CI_Model{
		function getAll(){
			$this->db->from('kps_label_information');
			$this->db->join('kps_item_master','kps_label_information.KPS_ITEM_MASTER_ID_LF=kps_item_master.KPS_ITEM_MASTER_ID');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_label_information.CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_barcode','kps_barcode.KPS_BARCODE_ID=kps_label_information.KPS_BARCODE_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function updateQtyBarcode($id){
			$data = $this->db->get_where('kps_label_information', array('kps_label_information_ID' => $id))->first_row();
			$qty = $data->QTY_BARCODE_LF + 1;
			$data = array(
				'QTY_BARCODE_LF' => $qty
			);
			$this->db->where('kps_label_information_ID',$id);
			$this->db->update('kps_label_information',$data);
		}
		function getOnly($id){
			$this->db->where('kps_label_information_ID',$id);
			$query = $this->db->get('kps_label_information');
			return $query->first_row();
		}
		function getAllProses(){
			$query = $this->db->get('kps_proses');
			return $query->result();
		}
		function getAllTooling(){
			$query = $this->db->get('kps_item_master_tooling');
			return $query->result();
		}
function getAllMachine(){
			$query = $this->db->get('kps_machine');
			return $query->result();
		}

		function get($id){
			$this->db->from('kps_label_information');
			$this->db->join('kps_item_master','kps_label_information.KPS_ITEM_MASTER_ID_LF=kps_item_master.KPS_ITEM_MASTER_ID');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_label_information.CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_barcode','kps_barcode.KPS_BARCODE_ID=kps_label_information.KPS_BARCODE_ID');
			$this->db->where('kps_label_information.kps_label_information_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_label_information');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO_REV_NO is not null');
			$this->db->order_by("kps_label_information_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_label_information',$data);
		}
		function insertSub($data){
			$this->db->insert('kps_label_information_detail',$data);
		}
		function insertBarcode($data){
			$this->db->insert('kps_barcode',$data);
			return $this->db->insert_id();
		}
		function insertDetail($data){
			$this->db->insert('kps_label_information',$data);
		}
		function update($data,$id){
			$this->db->where('kps_label_information_ID',$id);
			$this->db->update('kps_label_information',$data);
		}
		function delete($id){
			$this->db->where('kps_label_information_ID',$id);
			$this->db->delete('kps_label_information');
		}

	}

?>