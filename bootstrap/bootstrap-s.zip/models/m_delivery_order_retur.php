<?php
	class m_delivery_order_retur extends CI_Model{
		function getAllOutForDOR(){
			$this->db->from('kps_outgoing_retur_product');
			$this->db->join('kps_retur_barang','kps_outgoing_retur_product.KPS_RETUR_BARANG_ID_OUT=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_vehicle','kps_outgoing_retur_product.KPS_VEHICLE_ID_OG_RTR=kps_vehicle.KPS_VEHICLE_ID');
			// $this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_retur_barang.KPS_DELIVERY_ORDER_ID_RETUR');
			$this->db->where('`OUTGOING_RETUR_PRODUCT_ID` NOT IN (SELECT `OUTGOING_RETUR_PRODUCT_ID_DO` FROM `kps_delivery_order_retur`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAll(){
			$this->db->from('kps_delivery_order_retur');
			$this->db->join('kps_outgoing_retur_product','kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID=kps_delivery_order_retur.OUTGOING_RETUR_PRODUCT_ID_DO');
			$this->db->join('kps_outgoing_retur_product_detail','kps_outgoing_retur_product_detail.OUTGOING_RETUR_PRODUCT_ID_DETAIL=kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID');
			$this->db->join('kps_retur_barang','kps_retur_barang.KPS_RETUR_BARANG_ID=kps_outgoing_retur_product.KPS_RETUR_BARANG_ID_OUT');
			// $this->db->join('kps_retur_barang_detail','kps_retur_barang_detail.KPS_RETUR_BARANG_ID_DET=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_retur_barang.KPS_CUSTOMER_ID_RETUR');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_retur_product.KPS_VEHICLE_ID_OG_RTR');
			$query = $this->db->get();
			return $query->result();
		}
		function get_Detail_DO_retur($id){
			$this->db->from('kps_delivery_order_retur');
			$this->db->join('kps_outgoing_retur_product','kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID=kps_delivery_order_retur.OUTGOING_RETUR_PRODUCT_ID_DO');
			$this->db->join('kps_outgoing_retur_product_detail','kps_outgoing_retur_product_detail.OUTGOING_RETUR_PRODUCT_ID_DETAIL=kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID');
			$this->db->join('kps_retur_barang','kps_retur_barang.KPS_RETUR_BARANG_ID=kps_outgoing_retur_product.KPS_RETUR_BARANG_ID_OUT');
			$this->db->join('kps_retur_barang_detail','kps_retur_barang_detail.KPS_RETUR_BARANG_ID_DET=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_retur_barang.KPS_CUSTOMER_ID_RETUR');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_retur_product.KPS_VEHICLE_ID_OG_RTR');
			$this->db->where('kps_delivery_order_retur.KPS_DELIVERY_ORDER_RETUR_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByCust($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);

			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_delivery_order_retur');
			$this->db->where('year(KPS_DO_RETUR_DATE) = '.$year);
			$this->db->where('KPS_DO_REV_NO is not null');
			$this->db->order_by("KPS_DELIVERY_ORDER_RETUR_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			$this->db->join('kps_customer_divisi','kps_customer_divisi.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_bukti_pesanan.kps_bukti_pesanan_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByCust($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_bukti_pesanan.KPS_CUSTOMER_ID_BK',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getCurr($id){
			$this->db->from('kps_customer_finance_bank');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAccount($id){
			$this->db->from('kps_customer_finance_bank');
			$this->db->join('kps_bank','kps_bank.KPS_BANK_ID=kps_customer_finance_bank.KPS_BANK_ID');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_delivery_order_retur',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_bukti_pesanan_ID',$id);
			$this->db->update('kps_bukti_pesanan',$data);
		}
		function delete($id){
			$this->db->where('kps_bukti_pesanan_ID',$id);
			$this->db->delete('kps_bukti_pesanan');
		}
		function getDetailPesanan($id){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where("KPS_BUKTI_PESANAN_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailPesananQty($id){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDetailPesananAll(){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$query = $this->db->get();
			return $query->result();
		}
		
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}

		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getModelPrice($id){
			$this->db->from("kps_loi");
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost',' kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation_detail',' kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->where("kps_loi.KPS_LOI_ID",$id);
			return $this->db->get()->first_row();
		}
	}

?>