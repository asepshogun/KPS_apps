<?php
	class m_customer_information extends CI_Model{
		//revisi for pesanan TX non TX start
		
		function getAllNT(){
			$this->db->from('kps_customer');
			$this->db->where('SALES_TAX',"Non Tax");
			$this->db->order_by("KPS_CUSTOMER_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getAllTX(){
			$this->db->from('kps_customer');
			$this->db->where('SALES_TAX',"Tax");
			$this->db->order_by("KPS_CUSTOMER_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		
		//revisi for pesanan TX non TX end
		
		function getAll(){
			$this->db->order_by("KPS_CUSTOMER_ID","DESC");
			$query = $this->db->get('kps_customer');
			
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_customer');
			$this->db->where('year(DATE_CIS) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("KPS_CUSTOMER_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}

		function get($id){
			$this->db->from('kps_customer');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function get_Pap($id){
			$this->db->from('kps_customer');
			$this->db->join('kps_customer_personal_payment','kps_customer_personal_payment.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		
		function getAllMarketing(){
			$this->db->from('kps_customer');
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_customer.marketing_id');
			$this->db->join('kps_customer_is_person_in_charge','kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->group_by('kps_customer.COMPANY_NAME');
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_customer',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->update('kps_customer',$data);
		}
		
		function delete($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->delete('kps_customer');
		}

		function getCustomerCp($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_company');
			return $query->result();
		}
		function getPlant($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_plant');
			return $query->result();
		}
		function getPlantAll(){
			$query = $this->db->get('kps_customer_plant');
			return $query->result();
		}
		function getDivisi($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_divisi');
			return $query->result();
		}
		function getPic($id){
			$this->db->where('KPS_CUSTOMER_ID_PIC',$id);
			$query = $this->db->get('kps_customer_is_person_in_charge');
			return $query->result();
		}
		function getPicRfq($id){
			$this->db->from('kps_customer_is_person_in_charge');
			$this->db->join('kps_rfq','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer_is_person_in_charge.KPS_CUSTOMER_ID_PIC');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getMain($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_main_customer');
			return $query->result();
		}
		function getSupplier($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_is_supplier');
			return $query->result();
		}
		function getFinance($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_finance');
			return $query->result();
		}
		function getAcc($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->join('kps_bank','kps_bank.KPS_BANK_ID=kps_customer_finance_bank.KPS_BANK_ID');
			$query = $this->db->get('kps_customer_finance_bank');
			return $query->result();
		}
		function getAccount($id){
			$this->db->from('kps_customer_finance_bank');
			$this->db->join('kps_bank','kps_bank.KPS_BANK_ID=kps_customer_finance_bank.KPS_BANK_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getDeliv($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_delivery_setup');
			return $query->result();
		}
		function getIso($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_iso');
			return $query->result();
		}
		//perubahan untuk revisi personal payment start
		function getPap($id){
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get('kps_customer_personal_payment');
			return $query->result();
		}
		//perubahan untuk revisi personal payment end


		function getDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function lock($status,$id){
			$this->db->set('status',$status);
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->update('kps_customer');
		}
		function unlock($status,$id){
			$this->db->set('status',$status);
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->update('kps_customer');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no',$revno);
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$this->db->update('kps_customer');
		}
	}

?>