<?php
	class m_order_sheet extends CI_Model{
		
		function deleteOsDet($id){
			$this->db->where('KPS_ORDER_SHEET_DETAIL_ID',$id);
			$this->db->delete('kps_order_sheet_detail');
		}
		function deleteDs($id){
			$this->db->where('KPS_OS_ID_DS',$id);
			$this->db->delete('kps_delivery_schedule');
		}
		function getDetForDelete($id){
			$this->db->from("kps_order_sheet_detail");
			$this->db->join("kps_order_sheet",'kps_order_sheet.KPS_OS_ID=kps_order_sheet_detail.KPS_OS_ID_DETAIL');
			$this->db->join("kps_bukti_pesanan",'kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS');
			$this->db->join("kps_delivery_schedule",'kps_order_sheet_detail.KPS_ORDER_SHEET_DETAIL_ID=kps_delivery_schedule.KPS_OS_ID_DS');
			$this->db->where("kps_order_sheet_detail.KPS_ORDER_SHEET_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		// revisi os 23-5-2016 start
		function getDelivSetupForOs($id){
			$this->db->from("kps_customer_delivery_setup");
			$this->db->where("kps_customer_delivery_setup.KPS_CUSTOMER_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function cekOsFromCus($id){
			$this->db->from("kps_order_sheet");
			$this->db->where("kps_order_sheet.KPS_OS_DN_NO",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDsByOs($id){
			$this->db->from("kps_delivery_schedule");
			$this->db->where("kps_delivery_schedule.KPS_OS_ID_DS",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function cekPoOs($id){
			$this->db->from("kps_delivery_schedule_detail");
			$this->db->join("kps_bukti_pesanan_detail",'kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join("kps_loi",'kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where("kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		// revisi os 23-5-2016 end
		
		
		//for OS
		function getDet($id){
			$this->db->from("kps_order_sheet_detail");
			$this->db->join("kps_order_sheet",'kps_order_sheet.KPS_OS_ID=kps_order_sheet_detail.KPS_OS_ID_DETAIL');
			$this->db->join("kps_bukti_pesanan",'kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS');
			$this->db->join("kps_delivery_schedule",'kps_order_sheet_detail.KPS_ORDER_SHEET_DETAIL_ID=kps_delivery_schedule.KPS_OS_ID_DS');
			$this->db->where("kps_order_sheet_detail.KPS_ORDER_SHEET_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		//for Os
		function getDataForReturnPending($id){
		$this->db->from('kps_order_sheet');
		$this->db->where('KPS_OS_ID',$id);
		$query = $this->db->get();
		return $query->first_row();
		}
		function getAll(){
			$this->db->from('kps_order_sheet');
			$this->db->join("kps_customer_delivery_setup",'kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_order_sheet.KPS_CUSTOMER_DELIVERY_SETUP_ID');
			$this->db->join("kps_customer_divisi",'kps_customer_divisi.KPS_CUSTOMER_DIVISI_ID=kps_order_sheet.KPS_OS_CUSTOMER_DIVISI_ID');
			$this->db->join("kps_customer",'kps_customer.KPS_CUSTOMER_ID=kps_order_sheet.KPS_OS_CUSTOMER_ID');
			$this->db->where('KPS_OS_FLAG_DELETE',null,true);
			$this->db->where('KPS_OS_STATUS_R_PENDING',null,true);
			$this->db->order_by("kps_order_sheet.KPS_OS_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_order_sheet_');
			$this->db->join("kps_customer_delivery_setup",'kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_order_sheet_.KPS_CUSTOMER_DELIVERY_SETUP_ID');
			$this->db->join("kps_customer_divisi",'kps_customer_divisi.KPS_CUSTOMER_DIVISI_ID=kps_order_sheet_.KPS_OS_CUSTOMER_DIVISI_ID');
			$this->db->join("kps_customer",'kps_customer.KPS_CUSTOMER_ID=kps_order_sheet_.KPS_OS_CUSTOMER_ID');
			$this->db->order_by("kps_order_sheet_.ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		//for Return Pending OS
		function getAllForReturnPending($id,$idDS){
			// $this->db->from('ps_delivery_schedule');
			// $this->db->join("kps_delivery_schedule_detail",'kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID');
			// $this->db->join("kps_order_sheet_detail",'kps_order_sheet_detail.KPS_ORDER_SHEET_DETAIL_ID=kps_delivery_schedule.KPS_OS_ID_DS');
			// $this->db->join("kps_order_sheet",'kps_order_sheet.KPS_OS_ID=kps_order_sheet_detail.KPS_OS_ID_DETAIL');
			// $this->db->join("kps_bukti_pesanan_detail",'kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			// $this->db->join("kps_loi",'kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			// $this->db->where('kps_delivery_schedule.KPS_OS_ID_DS',$id);
			// $query = $this->db->get();
			$query = $this->db->query("
			SELECT * FROM (`kps_delivery_schedule`) 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_ID`=`kps_delivery_schedule`.`KPS_DELIVERY_SCHEDULE_ID` 
			JOIN `kps_order_sheet_detail` ON `kps_order_sheet_detail`.`KPS_ORDER_SHEET_DETAIL_ID`=`kps_delivery_schedule`.`KPS_OS_ID_DS` 
			JOIN `kps_order_sheet` ON `kps_order_sheet`.`KPS_OS_ID`=`kps_order_sheet_detail`.`KPS_OS_ID_DETAIL` 
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD` 
			JOIN `kps_loi` ON `kps_loi`.`KPS_LOI_ID`=`kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK` 
			WHERE `kps_delivery_schedule`.`KPS_OS_ID_DS` = $id AND KPS_BUKTI_PESANAN_DETAIL_ID_SD NOT IN (SELECT KPS_BUKTI_PESANAN_DETAIL_ID_SD FROM  kps_delivery_schedule_detail WHERE KPS_DELIVERY_SCHEDULE_ID = $idDS )
			");
			return $query->result();
		}
		function getDataOsDetailForReturn($id){
			$this->db->select('KPS_OSD_ID_RETURN');
			$this->db->where('KPS_ORDER_SHEET_DETAIL_ID',$id);
			$query = $this->db->get('kps_order_sheet_detail');
			return $query->result();
		}
		function getIdFromOsdet($id){
			$this->db->select('KPS_DELIVERY_SCHEDULE_ID');
			$this->db->where('KPS_OS_ID_DS',$id);
			$query = $this->db->get('Kps_delivery_schedule');
			return $query->result();
		}
		function getPendingFromOutForRpending($id){
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->where('KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		//for Return Pending OS
		function getAllPending(){
			$query = $this->db->query("
			SELECT * , SUM(QTY_PENDING_OFGD) AS TotalPending FROM (`kps_order_sheet`)  
			JOIN `kps_outgoing_finished_good` ON `kps_outgoing_finished_good`.`KPS_OS_ID_OGFG`=`kps_order_sheet`.`KPS_OS_ID`
			JOIN `kps_outgoing_finished_good_detail` ON `kps_outgoing_finished_good_detail`.`KPS_OUTGOING_FINISHED_GOOD_ID_D`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID` 
			JOIN `kps_customer_delivery_setup` ON `kps_customer_delivery_setup`.`KPS_CUSTOMER_DELIVERY_SETUP`=`kps_order_sheet`.`KPS_CUSTOMER_DELIVERY_SETUP_ID` 
			JOIN `kps_customer_divisi` ON `kps_customer_divisi`.`KPS_CUSTOMER_DIVISI_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_DIVISI_ID` 
			JOIN `kps_customer` ON `kps_customer`.`KPS_CUSTOMER_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_ID` 
			WHERE `KPS_OS_FLAG_DELETE` IS NULL 
			GROUP BY `KPS_OS_ID` , kps_outgoing_finished_good_detail.KPS_OFGD_STAT_R_OS_PENDING
			");
			return $query->result();
		}
		function getAllPendingPerItem(){
			$query = $this->db->query("
			SELECT * FROM (`kps_order_sheet`)  
			JOIN `kps_outgoing_finished_good` ON `kps_outgoing_finished_good`.`KPS_OS_ID_OGFG`=`kps_order_sheet`.`KPS_OS_ID`
			JOIN `kps_delivery_order` ON `kps_delivery_order`.`KPS_OUTGOING_FINISHED_GOOD_ID_DO`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID`
			JOIN `kps_outgoing_finished_good_detail` ON `kps_outgoing_finished_good_detail`.`KPS_OUTGOING_FINISHED_GOOD_ID_D`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID` 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID`=`kps_outgoing_finished_good_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD` 
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD` 
			JOIN `kps_loi` ON `kps_loi`.`KPS_LOI_ID`=`kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK` 
			JOIN `kps_bukti_pesanan` ON `kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID`=`kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_ID` 
			JOIN `kps_customer_delivery_setup` ON `kps_customer_delivery_setup`.`KPS_CUSTOMER_DELIVERY_SETUP`=`kps_order_sheet`.`KPS_CUSTOMER_DELIVERY_SETUP_ID` 
			JOIN `kps_customer_divisi` ON `kps_customer_divisi`.`KPS_CUSTOMER_DIVISI_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_DIVISI_ID` 
			JOIN `kps_customer` ON `kps_customer`.`KPS_CUSTOMER_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_ID` 
			WHERE `KPS_OS_FLAG_DELETE` IS NULL 
			");
			return $query->result();
		}
		function getAllRtnPending(){
			$query = $this->db->query("
			SELECT *  FROM (`kps_order_sheet`)  
			JOIN `kps_customer_delivery_setup` ON `kps_customer_delivery_setup`.`KPS_CUSTOMER_DELIVERY_SETUP`=`kps_order_sheet`.`KPS_CUSTOMER_DELIVERY_SETUP_ID` 
			JOIN `kps_customer_divisi` ON `kps_customer_divisi`.`KPS_CUSTOMER_DIVISI_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_DIVISI_ID` 
			JOIN `kps_customer` ON `kps_customer`.`KPS_CUSTOMER_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_ID` 
			WHERE `KPS_OS_FLAG_DELETE` IS NULL 	AND KPS_OS_STATUS_R_PENDING IS NOT NULL 
			");
			return $query->result();
		}
		
		function detDetailPending($id){
			$query = $this->db->query("
			SELECT * , SUM(QTY_PENDING_OFGD) AS TotalPending FROM (`kps_order_sheet`)  
			JOIN `kps_outgoing_finished_good` ON `kps_outgoing_finished_good`.`KPS_OS_ID_OGFG`=`kps_order_sheet`.`KPS_OS_ID`
			JOIN `kps_outgoing_finished_good_detail` ON `kps_outgoing_finished_good_detail`.`KPS_OUTGOING_FINISHED_GOOD_ID_D`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID` 
			JOIN `kps_customer_delivery_setup` ON `kps_customer_delivery_setup`.`KPS_CUSTOMER_DELIVERY_SETUP`=`kps_order_sheet`.`KPS_CUSTOMER_DELIVERY_SETUP_ID` 
			JOIN `kps_customer_divisi` ON `kps_customer_divisi`.`KPS_CUSTOMER_DIVISI_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_DIVISI_ID` 
			JOIN `kps_customer` ON `kps_customer`.`KPS_CUSTOMER_ID`=`kps_order_sheet`.`KPS_OS_CUSTOMER_ID` 
			WHERE `KPS_OS_FLAG_DELETE` IS NULL AND
			kps_order_sheet.KPS_OS_ID = $id
			GROUP BY `KPS_OS_ID` , kps_outgoing_finished_good_detail.KPS_OFGD_STAT_R_OS_PENDING
			");
			return $query->result();
		}
		//For Outgoing
		function getOsForOutGoing(){
			$this->db->from('kps_order_sheet');
			$this->db->where('STATUS_OS_BY_OUTGOING',null,true);
			$query = $this->db->get();
			return $query->result();
		}	
		function getOsByCusForOut($id){
			$query = $this->db->query("SELECT *
			FROM (`kps_order_sheet`)
			WHERE `kps_order_sheet`.`KPS_OS_CUSTOMER_ID` =".$id." and KPS_OS_ID not in( select KPS_OS_ID_OGFG from kps_outgoing_finished_good where KPS_OS_ID_OGFG is not null)");
			return $query->result();
		}
		//For Outgoing
		// For OS return pending
		function getBpidForOsReturn($id){
			$this->db->from('kps_order_sheet_detail');
			$this->db->where('KPS_ORDER_SHEET_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		// For OS return pending
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_order_sheet');
			$this->db->where('year(KPS_OS_CREATION_DATE) = '.$year);
			$this->db->where('KPS_OS_NO is not null');
			$this->db->order_by("KPS_OS_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_order_sheet');
			$this->db->join("kps_customer_delivery_setup",'kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_order_sheet.KPS_CUSTOMER_DELIVERY_SETUP_ID');
			$this->db->join("kps_customer",'kps_order_sheet.KPS_OS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join("kps_customer_divisi",'kps_order_sheet.KPS_OS_CUSTOMER_DIVISI_ID=kps_customer_divisi.KPS_CUSTOMER_DIVISI_ID');
			$this->db->where('kps_order_sheet.KPS_OS_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getRevNo($id){
			$this->db->from('kps_order_sheet');
			$this->db->where('kps_order_sheet.KPS_OS_ID',$id);
			$this->db->select('KPS_OS_REV_NO');
			return $this->db->get()->result();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDelivSetup($id){
			$this->db->from('kps_customer_delivery_setup');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_order_sheet',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
			return $this->db->insert_id();
		}
		function update($data,$id){
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet',$data);
		}
		function delete($id){
			$data=array('KPS_OS_FLAG_DELETE'=>'1');
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet',$data);
		}
		function lockUpdate($id){
			$data=array('KPS_OS_LOCK_UPDATE'=>'1');
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet',$data);
		}
		function lockDetail($id){
			$data=array('KPS_OS_LOCK_DETAIL'=>'1');
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet',$data);
		}
		function getDetail($id){
			$this->db->from("kps_order_sheet_detail");
			$this->db->join("kps_order_sheet",'kps_order_sheet.KPS_OS_ID=kps_order_sheet_detail.KPS_OS_ID_DETAIL');
			$this->db->join("kps_bukti_pesanan",'kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS');
			$this->db->join("kps_bukti_pesanan_detail",'kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->where("kps_order_sheet_detail.KPS_OS_ID_DETAIL",$id);
			$this->db->group_by('kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getCode(){
			$this->db->from("kps_bukti_pesanan");
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailAttach($id){
			$this->db->from("kps_order_sheet_attachment");
			$this->db->where("kps_order_sheet_attachment.KPS_OS_ID_ATTACHMENT",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function lock($status,$id){
			$this->db->set('status_os',$status);
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet');
		}
		function unlock($status,$id){
			$this->db->set('status_os',$status);
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_os',$revno);
			$this->db->where('KPS_OS_ID',$id);
			$this->db->update('kps_order_sheet');
		}
	}

?>