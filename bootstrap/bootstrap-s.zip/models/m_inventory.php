<?php
	class m_inventory extends CI_Model{
		
		function getAll(){
			$this->db->select('LOI_CODE_ITEM, DATE_BP, REV_NO_BP, DISCONTINUE_DATE, QTY_MONTH, LOI_PART_NAME, LOI_PART_NO, LOI_MODEL, QUANTITY, QUANTITY_DELIVERY, QTY_DELIVERY_EXECUTION, MIN_STOK, MAX_STOCK, SUM(QTY_DELIVERY_EXECUTION) as TOTEX, unit,  ');
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_production_plan','kps_rfq_production_plan.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.OUTGOING_DETAIL=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');
			
			$this->db->group_by('LOI_CODE_ITEM');
			$query = $this->db->get();
			return $query->result();
		}
		
		

	}

?>