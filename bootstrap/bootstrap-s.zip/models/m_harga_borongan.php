<?php
	class m_harga_borongan extends CI_Model{
		function getAll(){
			$this->db->from('kps_harga_borongan');
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where('kps_harga_borongan_ID',$id);
			$query = $this->db->get('kps_harga_borongan');
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_harga_borongan');
			$this->db->join('kps_loi','kps_harga_borongan.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_harga_borongan.kps_harga_borongan_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_harga_borongan');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("kps_harga_borongan_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_harga_borongan',$data);
		}
		function update($data,$id){
			$this->db->where('kps_harga_borongan_ID',$id);
			$this->db->update('kps_harga_borongan',$data);
		}
		function delete($id){
			$this->db->where('kps_harga_borongan_ID',$id);
			$this->db->delete('kps_harga_borongan');
		}

	}

?>