<?php
	class m_vehicle extends CI_Model{
		function getAll(){

			$this->db->from('kps_vehicle');
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->where('KPS_VEHICLE_ID',$id);
			$query = $this->db->get('kps_vehicle');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_vehicle',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_VEHICLE_ID',$id);
			$this->db->update('kps_vehicle',$data);
		}
		function delete($id){
			$this->db->where('KPS_VEHICLE_ID',$id);
			$this->db->delete('kps_vehicle');
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_vehicle');
			$this->db->where('year(VEHICLE_DATE) = '.$year);
			$this->db->where('VEHICLE_NO_SURAT is not null');
			$this->db->order_by("KPS_VEHICLE_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getdate($id){
			$this->db->select('DELIVERY_DATE, sum(QTY_DELIVERY_EXECUTION*kps_quotation_detail.price) as TOTALS, KPS_OUTGOING_FINISHED_GOOD_ID_D, PLANT1_LOCAL_JABOTABEK, COD_LOCAL, COD_JABODETABEK');
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_order.KPS_CUSTOMER_PLANT_ID_DO');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.part_name=kps_loi.LOI_PART_NAME');
			$this->db->where('kps_outgoing_finished_good.KPS_VEHICLE_ID',$id);
			//$this->db->group_by('DELIVERY_DATE');
			$query = $this->db->get();
			return $query->result();

		}
		function getqty($id){
			$this->db->select('QTY_DELIVERY_EXECUTION*price as QTYDATE, DELIVERY_DATE, PLANT1_LOCAL_JABOTABEK,COD_LOCAL,COD_JABOTABEK');
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.part_name=kps_loi.LOI_PART_NAME');
			$this->db->join('kps_customer_delivery_setup','kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->where('kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D',$id);
			$query = $this->db->get();
			return $query->result();

		}

	}

?>