<?php
	class m_retur_product extends CI_Model{
		//revisi retur 23-5-2016 start
			function getDetailPesananRetur($id){
				$this->db->from('kps_retur_barang_bukti_pesan');
				$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_retur_barang_bukti_pesan.KPS_BUKTI_PESANAN_ID_BUKTIPESAN_RETUR');
				$this->db->where('KPS_RETUR_BARANG_ID_BUKTIPESAN_RETUR',$id);
				$this->db->order_by('KPS_RETUR_BUKTIPESAN_ID','desc');
				$query = $this->db->get();
				return $query->result();
			}
			function getPesananForAdd($id,$idCust){
				$this->db->from('kps_bukti_pesanan');
				$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');		
				$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
				$this->db->where('`KPS_BUKTI_PESANAN_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_ID_BUKTIPESAN_RETUR` FROM `kps_retur_barang_bukti_pesan` WHERE KPS_RETUR_BARANG_ID_BUKTIPESAN_RETUR='. $id. ')', NULL, FALSE);
				$query = $this->db->get();
				return $query->result();
			}
		//revisi retur 23-5-2016 end
		
		//revisi retur 22-15-2016 start
		
		function getHistoryInduk($id){
			$this->db->from('kps_retur_barang_');
			$this->db->join('kps_customer','kps_retur_barang_.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_retur_barang_.KPS_DELIVERY_ORDER_ID_RETUR');
			$this->db->where('KPS_RETUR_BARANG_ID',$id);
			$this->db->order_by("UPDATE_TIME","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getHistoryDetail($id){
			$this->db->from('kps_retur_barang_detail_');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail_.KPS_LOI_ID_RETUR');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_DRAWING_ID=kps_rfq.KPS_RFQ_ID','left');
			$this->db->where('KPS_RETUR_BARANG_ID_DET',$id);
			$this->db->order_by("UPDATE_TIME","DESC");
			$query = $this->db->get();
			return $query->result();
		}	
			
		//revisi retur 22-15-2016 End
		
		function getAll(){
			$this->db->from('kps_retur_barang');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('KPS_RETUR_FLAG_DELETE is  null');
			$this->db->order_by('KPS_RETUR_BARANG_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_retur_barang');
			$this->db->where('year(DATE_RTR) = '.$year);
			$this->db->where('REV_NO_RTR is not null');
			$this->db->order_by("KPS_RETUR_BARANG_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_retur_barang');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_retur_barang.KPS_RETUR_BARANG_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllLoiForRetur($id,$idCust){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');		
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$this->db->where('`KPS_LOI_ID` NOT IN (SELECT `KPS_LOI_ID_RETUR` FROM `kps_retur_barang_detail` WHERE KPS_RETUR_BARANG_ID_DET='. $id. ')', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function get_retur_detail($id){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->join('kps_retur_barang','kps_retur_barang_detail.KPS_RETUR_BARANG_ID_DET=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->where("KPS_RETUR_BARANG_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByCust($id){
			$this->db->from('kps_retur_barang');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_retur_barang.KPS_CUSTOMER_ID_BK',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_retur_barang',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang',$data);
		}
		function delete($id){
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->delete('kps_retur_barang');
		}
		function getDetailPesanan($id){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_outgoing_retur_product_detail','kps_retur_barang_detail.KPS_RETUR_BARANG_DETAIL_ID=kps_outgoing_retur_product_detail.KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL','left');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_DRAWING_ID=kps_rfq.KPS_RFQ_ID','left');
			$this->db->where("KPS_RETUR_BARANG_ID_DET",$id);
			$this->db->group_by('kps_retur_barang_detail.KPS_RETUR_BARANG_DETAIL_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailPesananForOut($id,$idOut){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_DRAWING_ID=kps_rfq.KPS_RFQ_ID','left');
			$this->db->where("KPS_RETUR_BARANG_ID_DET",$id);
			$this->db->where('`KPS_RETUR_BARANG_DETAIL_ID` NOT IN (SELECT `KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL` FROM `kps_outgoing_retur_product_detail` WHERE OUTGOING_RETUR_PRODUCT_ID_DETAIL='. $idOut. ')', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		// function getReturForExe($id){
			// $this->db->from("kps_retur_barang_detail");
			// $this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			// $this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			// $this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_DRAWING_ID=kps_rfq.KPS_RFQ_ID','left');
			// $this->db->where("KPS_RETUR_BARANG_DETAIL_ID",$id);
			// $query = $this->db->get();
			// return $query->result();
		// }
		function getDetailPesananAll(){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_BK');
			$query = $this->db->get();
			return $query->result();
		}
		
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}

		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function deleteDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$this->db->delete($table);
		}
		function getModelPrice($id){
			$this->db->from("kps_loi");
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost',' kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation_detail',' kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->where("kps_loi.KPS_LOI_ID",$id);
			return $this->db->get()->first_row();
		}
		function lock($status,$id){
			$this->db->set('status_retur',$status);
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang');
		}
		function unlock($status,$id){
			$this->db->set('status_retur',$status);
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang');
		}
		
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_retur',$revno);
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang');
		}
		function del($status,$id){
			$this->db->set('DEL_RETUR',$status);
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang');
		}
		function undel($status,$id){
			$this->db->set('DEL_RETUR',$status);
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang');
		}
	}

?>