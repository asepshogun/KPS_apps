<?php
	class m_bank_reference extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_bank');
			return $query->result();
		}
		function get($id){
			$this->db->where('KPS_BANK_ID',$id);
			$query = $this->db->get('kps_bank');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_bank',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_BANK_ID',$id);
			$this->db->update('kps_bank',$data);
		}
		function delete($id){
			$this->db->where('KPS_BANK_ID',$id);
			$this->db->delete('kps_bank');
		}

	}

?>