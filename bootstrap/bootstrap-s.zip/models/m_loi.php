<?php
	class m_loi extends CI_Model{
		//for OS
			function getAllByBuktiForOs($id,$idDs){
			$query = $this->db->query('SELECT * FROM (`kps_bukti_pesanan_detail`) 
			JOIN `kps_loi` ON `kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK`=`kps_loi`.`KPS_LOI_ID` 
			WHERE `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_ID` ='.$id.'
			AND `KPS_BUKTI_PESANAN_DETAIL_ID` not in (select `KPS_BUKTI_PESANAN_DETAIL_ID_SD` from `kps_delivery_schedule_detail` where `KPS_DELIVERY_SCHEDULE_ID`='. $idDs .')');
			return $query->result();
		}
		//For OS
		function getAll(){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi.MADE_BY_LOI');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllId($id){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi.MADE_BY_LOI');
			$this->db->where('KPS_LOI_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllByBukti($id){
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_loi','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}	
		function getAllByBuktiForDs($id,$idDs){
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_loi','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID',$id);
			// $this->db->where('`KPS_BUKTI_PESANAN_DETAIL_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_DETAIL_ID_SD` FROM `kps_delivery_schedule_detail` WHERE KPS_DELIVERY_SCHEDULE_ID='. $idDs. ')', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByCust($id){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi.MADE_BY_LOI');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_loi');
			$this->db->where('year(DATE_LOI) = '.$year);
			$this->db->where('NO_LOI is not null');
			$this->db->order_by("KPS_LOI_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->where('kps_loi.kps_loi_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_loi_');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi_.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi_.MADE_BY_LOI');
			$query = $this->db->get();
			return $query->result();
		}
		function del($status,$id){
			$this->db->set('DEL_LOI',$status);
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi');
		}
		function undel($status,$id){
			$this->db->set('DEL_LOI',$status);
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi');
		}
		function insert($data){
			$this->db->insert('kps_loi',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi',$data);
		}
		function delete($id){
			$this->db->where('kps_loi_ID',$id);
			$this->db->delete('kps_loi');
		}
		function getAllDetail(){
			$query = $this->db->get('kps_loi_detail');
			return $query->result();
		}
		function getDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->result();
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		
		function getLoiRFQ($id){
			$query = $this->db->query('select * 
				from kps_rfq a, kps_rfq_drawing b, kps_rfq_production_plan c 
				where a.KPS_RFQ_ID=b.KPS_RFQ_ID and a.KPS_RFQ_ID=c.KPS_RFQ_ID and a.KPS_RFQ_ID= '.$id.'');

			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_loi',$status);
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi');
		}
		function unlock($status,$id){
			$this->db->set('status_loi',$status);
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_loi',$revno);
			$this->db->where('kps_loi_ID',$id);
			$this->db->update('kps_loi');
		}
	}

?>