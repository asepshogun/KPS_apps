<?php
	class m_outgoing_retur_product extends CI_Model{
		function getAll(){
			$this->db->from('kps_outgoing_retur_product');
			$this->db->join('kps_retur_barang','kps_outgoing_retur_product.KPS_RETUR_BARANG_ID_OUT=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_vehicle','kps_outgoing_retur_product.KPS_VEHICLE_ID_OG_RTR=kps_vehicle.KPS_VEHICLE_ID');
			// $this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_retur_barang.KPS_DELIVERY_ORDER_ID_RETUR');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_outgoing_retur_product');
			$this->db->where('year(OUTGOING_RETUR_PRODUCT_DATE) = '.$year);
			$this->db->where('OUTGOING_RETUR_PRODUCT_NO_REV is not null');
			$this->db->order_by("OUTGOING_RETUR_PRODUCT_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_outgoing_retur_product');
			$this->db->join('kps_retur_barang','kps_outgoing_retur_product.KPS_RETUR_BARANG_ID_OUT=kps_retur_barang.KPS_RETUR_BARANG_ID');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_RETUR=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_vehicle','kps_outgoing_retur_product.KPS_VEHICLE_ID_OG_RTR=kps_vehicle.KPS_VEHICLE_ID');
			$this->db->where('kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getOutGoingForAdd($id){
			$this->db->from('kps_outgoing_retur_product_detail');
			$this->db->where('kps_outgoing_retur_product_detail.KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL',$id);
			$this->db->order_by("kps_outgoing_retur_product_detail.OUTGOING_RETUR_PRODUCT_DETAIL_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByCust($id){
			$this->db->from('kps_retur_barang');
			$this->db->join('kps_customer','kps_retur_barang.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_retur_barang.KPS_CUSTOMER_ID_BK',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_outgoing_retur_product',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->update('kps_retur_barang',$data);
		}
		function delete($id){
			$this->db->where('kps_retur_barang_ID',$id);
			$this->db->delete('kps_retur_barang');
		}
		function insert_out($data){
			$this->db->insert('kps_outgoing_retur_product_detail',$data);
		}
		function getDetail($id){
			$this->db->from("kps_outgoing_retur_product_detail");
			$this->db->join('kps_retur_barang_detail','kps_retur_barang_detail.KPS_RETUR_BARANG_DETAIL_ID=kps_outgoing_retur_product_detail.KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_DRAWING_ID=kps_rfq.KPS_RFQ_ID','left');
			$this->db->where("OUTGOING_RETUR_PRODUCT_ID_DETAIL",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailPesanan($id){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_RETUR');
			$this->db->where("KPS_RETUR_BARANG_ID_DET",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailPesananAll(){
			$this->db->from("kps_retur_barang_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_retur_barang_detail.KPS_LOI_ID_BK');
			$query = $this->db->get();
			return $query->result();
		}
		
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}

		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getModelPrice($id){
			$this->db->from("kps_loi");
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost',' kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation_detail',' kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->where("kps_loi.KPS_LOI_ID",$id);
			return $this->db->get()->first_row();
		}
	}

?>