<?php
	class m_userdata extends CI_Model{
		private $tableName = 'kps_userdata';
		private $idTable = 'KPS_USERDATA_ID';
		
		function checkLogin($username,$password){
			$this->db->from($this->tableName);
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_userdata.KPS_EMPLOYEE_ID');
			$this->db->join('kps_userdata_role','kps_userdata_role.user_data_id=kps_userdata.KPS_USERDATA_ID');
			$this->db->join('kps_roles','kps_userdata_role.roles_id=kps_roles.id');
			$this->db->where('USERNAME',$username);
			$this->db->where('PASSWORD',$password);
			$this->db->where('is_active',1);
			$query = $this->db->get();
			return $query->first_row();
		}

		function get($id){
			$this->db->where('KPS_USERDATA_ID',$id);
			$query = $this->db->get('kps_userdata');
			return $query->first_row();
		}

		function update($data,$id){
			$this->db->where('KPS_USERDATA_ID',$id);
			$this->db->update('kps_userdata',$data);
		}
		

	}

?>