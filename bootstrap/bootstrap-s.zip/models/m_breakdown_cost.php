<?php
	class m_breakdown_cost extends CI_Model{
		function getAll(){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_customer','kps_breakdown_cost.CUSTOMER_RESPOND = kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->where('DEL_BREAK','0');
			$this->db->order_by('KPS_BREAKDOWN_COST_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getAll_J(){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI = kps_rfq.KPS_RFQ_ID','');
			$this->db->join('kps_breakdown_cost','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK ');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID = kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ = kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_rfq_currency','kps_rfq_currency.KPS_RFQ_ID = kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation','kps_quotation.KPS_RFQ_CURENCY_ID_QUO = kps_rfq_currency.KPS_RFQ_CURENCY_ID','left');
			$query = $this->db->get();
			return $query->result();
		}
		function del($status,$id){
			$this->db->set('DEL_BREAK',$status);
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost');
		}
		function undel($status,$id){
			$this->db->set('DEL_BREAK',$status);
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost');
		}
		function getAllByCis($idcis){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idcis);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_breakdown_cost');
			$this->db->where('year(DATE_BREAK) = '.$year);
			$this->db->where('NO_BREAK is not null');
			$this->db->order_by("KPS_BREAKDOWN_COST_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		
		function get($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost');
			return $query->first_row();
		}
		function geth($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_');
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_breakdown_cost',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost',$data);
		}
		function delete($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->delete('kps_breakdown_cost');
		}
		function getDetail($id){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function getDepre($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_depreciation');
			return $query->result();
		}
		function getDeprex($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_depreciation');
			return $query->first_row();
		}
		function getDepreByCust($id){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_breakdown_cost_depreciation','kps_breakdown_cost_depreciation.KPS_BREAKDOWN_COST_ID=kps_breakdown_cost.KPS_BREAKDOWN_COST_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getManu($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_manufacturing');
			return $query->result();
		}
		function getMaterial($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_material');
			return $query->result();
		}
		function getPart($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_part');
			return $query->result();
		}
		function getTool($id){
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get('kps_breakdown_cost_tooling');
			return $query->result();
		}
		function getToolByRfq($id){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_breakdown_cost_tooling','kps_breakdown_cost_tooling.KPS_BREAKDOWN_COST_ID=kps_breakdown_cost.KPS_BREAKDOWN_COST_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getProduct(){
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getPartPart(){
			$query = $this->db->get('kps_breakdown_cost_part');
			return $query->result();
		}
		function getProd($id){
			$this->db->where('MODEL',$id);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_break',$status);
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost');
		}
		function unlock($status,$id){
			$this->db->set('status_break',$status);
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_break',$revno);
			$this->db->where('KPS_BREAKDOWN_COST_ID',$id);
			$this->db->update('kps_breakdown_cost');
		}

	}

?>