<?php
	class m_bsthp extends CI_Model{
		 private $tableName = 'kps_bsthp';
		private $idTable = 'KPS_BSTHP_ID';
		
		function getAll(){
			$this->db->from($this->tableName);
			$this->db->order_by('kps_bsthp.KPS_BSTHP_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllHistory($id){
			$this->db->from('kps_bsthp_');
			$this->db->order_by('kps_bsthp_.ID_BSTHP_','desc');
			$this->db->where('kps_bsthp_.KPS_BSTHP_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDataPrint($id){
			$this->db->from($this->tableName);
			$this->db->where('KPS_BSTHP_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDataPrintDetail($id){
		$this->db->from('kps_bsthp');
			$this->db->join('kps_bsthp_detail','kps_bsthp.KPS_BSTHP_ID=kps_bsthp_detail.KPS_BSTHP_ID_det');
			$this->db->join('kps_loi','kps_bsthp_detail.KPS_LOI_ID_BSTHP_Detail=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->where('kps_bsthp.KPS_BSTHP_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDataNullForLockAdd(){
			$this->db->from('kps_bsthp');
			$this->db->join('kps_bsthp_detail','kps_bsthp.KPS_BSTHP_ID=kps_bsthp_detail.KPS_BSTHP_ID_det','left');
			$this->db->where('kps_bsthp_detail.KPS_BSTHP_DETAIL_ID',NULL,TRUE);
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where($this->idTable,$id);
			$query = $this->db->get($this->tableName);
			return $query->first_row();
		}
		function updatelock($id){
			$data=array('BSTHP_LOCK'=>'1');
			$this->db->where('KPS_BSTHP_ID',$id);
			$this->db->update('kps_bsthp',$data);
		}
		function updateStatVer($id){
			$data=array('BSTHP_STATUS_VER'=>'1');
			$this->db->where('KPS_BSTHP_ID',$id);
			$this->db->update('kps_bsthp',$data);
		}
		function get($id){
			$this->db->from($this->tableName);
			$this->db->where($this->idTable,$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from($this->tableName);
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("KPS_BSTHP_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert($this->tableName,$data);
		}
		function insertDetail($data){
			$this->db->insert($this->tableName,$data);
		}
		function update($data,$id){
			$this->db->where($this->idTable,$id);
			$this->db->update($this->tableName,$data);
		}
		function updateDetail($data,$id){
			$this->db->where('KPS_BSTHP_DETAIL_ID',$id);
			$this->db->update('kps_bsthp_detail',$data);
		}
		function delete($id){
			$this->db->where($this->idTable,$id);
			$this->db->delete($this->tableName);
		}

	}

?>