<?php
	class m_pesanan extends CI_Model{
	
		function cekPesananDet($id){
			$this->db->from('kps_delivery_schedule_detail');
			$this->db->join('kps_delivery_schedule','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where('kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function cekPesananDetForDel($id){
			$this->db->from('kps_bukti_pesanan_detail');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where('kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllloiByCust($id,$idCus){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi.MADE_BY_LOI');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCus);
			$this->db->where('`KPS_LOI_ID` NOT IN (SELECT `KPS_LOI_ID_BK` FROM `kps_bukti_pesanan_detail` WHERE KPS_BUKTI_PESANAN_ID='. $id. ')', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAll(){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$query = $this->db->get();
			return $query->result();
		}
		//revisi for pesanan TX non TX start
		
		function getAllNT(){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_customer.SALES_TAX',"Non Tax");
			$this->db->order_by("kps_bukti_pesanan.kps_bukti_pesanan_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getAllTX(){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_customer.SALES_TAX',"Tax");
			$this->db->order_by("kps_bukti_pesanan.kps_bukti_pesanan_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getLastIdNT(){
			$year = date('Y');
			$this->db->from('kps_bukti_pesanan');
			$this->db->where('year(DATE_BP) = '.$year);
			$this->db->where('REV_NO_BP is not null');
			$this->db->where('KPS_BP_NO_URUT_BP_NT is not null');
			$this->db->order_by("kps_bukti_pesanan_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getAllByCustForInv($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			//$this->db->where('`kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_ID_DS` FROM `kps_delivery_schedule`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		//revisi for pesanan TX non TX end
		//model for OS
		function getByCusForOs($id,$idOs){
			$query = $this->db->query('SELECT * FROM (`kps_bukti_pesanan`) 
			WHERE `kps_bukti_pesanan`.`KPS_CUSTOMER_ID_BK` = '.$id.' AND `kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID` not in (select `KPS_BUKTI_PESANAN_ID_OS` from `kps_order_sheet_detail` where `KPS_OS_ID_DETAIL`='.$idOs.')');
			
			return $query->result();;
		}	
		function getByCusForReturnOs($idOs,$idROs){
			$query = $this->db->query('SELECT * FROM (`kps_order_sheet_detail`) 
			JOIN `kps_bukti_pesanan` ON `kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID`=`kps_order_sheet_detail`.`KPS_BUKTI_PESANAN_ID_OS`
			WHERE `kps_order_sheet_detail`.`KPS_OS_ID_DETAIL` = '.$idROs.' 
			AND `kps_order_sheet_detail`.`KPS_BUKTI_PESANAN_ID_OS` not in (select `KPS_BUKTI_PESANAN_ID_OS` from `kps_order_sheet_detail` where `KPS_OS_ID_DETAIL`='.$idOs.')');
			
			return $query->result();;
		}
		//model for os end
		function getAllByCust($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			//$this->db->where('`kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_ID_DS` FROM `kps_delivery_schedule`)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByCustForSchedule($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$this->db->where('`KPS_BUKTI_PESANAN_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_ID_DS` FROM `kps_delivery_schedule` WHERE KPS_BUKTI_PESANAN_ID_DS IS NOT NULL)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}	
		function getAllByCustForScheduleRev($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$this->db->where('`KPS_BUKTI_PESANAN_ID` NOT IN (SELECT `KPS_BUKTI_PESANAN_ID_DS` FROM `kps_delivery_schedule` WHERE KPS_BUKTI_PESANAN_ID_DS IS NOT NULL)', NULL, FALSE);
			$query = $this->db->get();
			return $query->result();
		}
		function cekNO($no){
			$this->db->from('kps_bukti_pesanan');
			$this->db->where('kps_bukti_pesanan.PO_OS_NO_FROM_CUSTOMER',$no);
			$query = $this->db->get();
			return $query->result();
		}
		function getForDropOut($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->where('kps_bukti_pesanan.KPS_CUSTOMER_ID_BK',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_bukti_pesanan');
			$this->db->where('year(DATE_BP) = '.$year);
			$this->db->where('REV_NO_BP is not null');
			$this->db->where('NO_REV_BP is not null');
			$this->db->order_by("kps_bukti_pesanan_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->join('kps_customer_divisi','kps_customer_divisi.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->where('kps_bukti_pesanan.kps_bukti_pesanan_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_bukti_pesanan_');
			$this->db->join('kps_customer','kps_bukti_pesanan_.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan_.CURRENCY_BP','left');
			$this->db->join('kps_customer_divisi','kps_customer_divisi.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->where('kps_bukti_pesanan_.kps_bukti_pesanan_ID',$id);
			$this->db->order_by('ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getTotPO($id){
			$this->db->select('SUM(QUANTITY) as TOTAL');
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID');
			$this->db->where('kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByCust($id){
			$this->db->from('kps_bukti_pesanan');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_bukti_pesanan.KPS_CUSTOMER_ID_BK',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getCurr($id){
			$this->db->from('kps_customer_finance_bank');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getAccount($id){
			$this->db->from('kps_customer_finance_bank');
			$this->db->join('kps_bank','kps_bank.KPS_BANK_ID=kps_customer_finance_bank.KPS_BANK_ID');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_bukti_pesanan',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan',$data);
		}
		function delete($id){
			$this->db->where('kps_bukti_pesanan_ID',$id);
			$this->db->delete('kps_bukti_pesanan');
		}
		function updateDetailFix($data,$id){
			$this->db->where('KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			$this->db->update('kps_bukti_pesanan_detail',$data);
		}
		function deleteDetail($id){
			$this->db->where('KPS_BUKTI_PESANAN_DETAIL_ID',$id);
			$this->db->delete('kps_bukti_pesanan_detail');
		}
		function getDetailPesanan($id){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->where("KPS_BUKTI_PESANAN_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetailPesananQty($id){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->where("KPS_BUKTI_PESANAN_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDetailPesananAll(){
			$this->db->from("kps_bukti_pesanan_detail");
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$query = $this->db->get();
			return $query->result();
		}
		
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}

		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getModelPrice($id){
			$this->db->from("kps_loi");
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost',' kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_quotation_detail',' kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_quotation_detail.breakdown_cost_id');
			$this->db->where("kps_loi.KPS_LOI_ID",$id);
			return $this->db->get()->first_row();
		}
		function lock($status,$id){
			$this->db->set('status_bp',$status);
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan');
		}
		function unlock($status,$id){
			$this->db->set('status_bp',$status);
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_bp',$revno);
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan');
		}
		function del($status,$id){
			$this->db->set('DEL_PESANAN',$status);
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan');
		}
		function undel($status,$id){
			$this->db->set('DEL_PESANAN',$status);
			$this->db->where('KPS_BUKTI_PESANAN_ID',$id);
			$this->db->update('kps_bukti_pesanan');
		}
	}

?>