<?php
	class m_user_data extends CI_Model{
		function getAll(){
			$this->db->select('USERNAME,NIK,EMPLOYEE_NAME,DEPARTMENT,kps_userdata.SECTION as SECTIONUSER,POSITION,KPS_USERDATA_ID,kps_userdata.KPS_EMPLOYEE_ID as KPS_EMPLOYEE_ID');
			$this->db->from('kps_userdata');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID = kps_userdata.KPS_EMPLOYEE_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->where('KPS_USERDATA_ID',$id);
			
			$query = $this->db->get('kps_userdata');

			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_userdata',$data);
			return $this->db->insert_id();
		}
		function update($data,$id){
			$this->db->where('KPS_USERDATA_ID',$id);
			$this->db->update('kps_userdata',$data);
		}
		function delete($id){
			$this->db->where('KPS_USERDATA_ID',$id);
			$this->db->delete('kps_userdata');
		}

	}

?>