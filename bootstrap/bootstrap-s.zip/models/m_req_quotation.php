<?php
	class m_req_quotation extends CI_Model{
		function getAll(){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->where('DEL_RFQ','0');
			$this->db->order_by('KPS_RFQ_ID','desc');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllh(){
			$this->db->from('kps_rfq_');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq_.KPS_CUSTOMER_ID_RFQ');
			$this->db->order_by('KPS_RFQ_ID','desc');

			$query = $this->db->get();
			return $query->result();
		}
		// revisi new Item Start
		function getAllByCust($id){
			// $query =$this->db->query('select * from `kps_rfq` join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ) where `KPS_RFQ_ID` not in(select KPS_RFQ_ID_FAILED from kps_failed_project) and KPS_CUSTOMER_ID='.$id);
			// return $query->result();
			
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->where('`KPS_RFQ_ID` NOT IN (SELECT `KPS_RFQ_ID_FAILED` FROM `kps_failed_project`)', NULL, FALSE);
			$this->db->where('`KPS_BREAKDOWN_COST_ID` IN (SELECT `breakdown_cost_id` FROM `kps_quotation_detail`)', NULL, FALSE);
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}

		function getAllByCustFailed($id){
			// $query =$this->db->query('select * from `kps_rfq` join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ) where `KPS_RFQ_ID` not in(select KPS_RFQ_ID_LOI from kps_loi) and KPS_CUSTOMER_ID='.$id);
			// return $query->result();
			
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->where('`KPS_RFQ_ID` NOT IN (SELECT `KPS_RFQ_ID_LOI` FROM `kps_loi`)', NULL, FALSE);
			$this->db->where('`KPS_BREAKDOWN_COST_ID` IN (SELECT `breakdown_cost_id` FROM `kps_quotation_detail`)', NULL, FALSE);
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
// revisi new Item End	
			
			
		//backup revisi from new item start
				// function getAllByCust($id){
					// $query =$this->db->query('select * from `kps_rfq` join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ) where `KPS_RFQ_ID` not in(select KPS_RFQ_ID_FAILED from kps_failed_project) and KPS_CUSTOMER_ID='.$id);
					// return $query->result();
				// }
			// function getAllByCustFailed($id){
				// $query =$this->db->query('select * from `kps_rfq` join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ) where `KPS_RFQ_ID` not in(select KPS_RFQ_ID_LOI from kps_loi) and KPS_CUSTOMER_ID='.$id);
				// return $query->result();
			// }
		//backup revisi from new item end

		function getAllOne(){
			$query =$this->db->query('select * from `kps_rfq` join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ) where `KPS_RFQ_ID` not in(select KPS_RFQ_ID_BREAK from kps_breakdown_cost)');
			
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_rfq');
			$this->db->where('year(DATE_RFQ) = '.$year);
			$this->db->where('NO_RFQ is not null');
			$this->db->order_by("KPS_RFQ_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastIdDrawing(){
			$year = date('Y');
			$this->db->from('kps_rfq_drawing');
			$this->db->where('year(DRAWING_DATE) = '.$year);
			$this->db->where('DRAWING_NO is not null');
			$this->db->order_by("KPS_RFQ_DRAWING_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function geth($id){
			$this->db->from('kps_rfq_');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq_.KPS_CUSTOMER_ID_RFQ');
			$this->db->where('kps_rfq_.KPS_RFQ_ID',$id);
			$this->db->group_by("revisi_no_rfq");
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_rfq',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq',$data);
		}
		
		function delete($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->delete('kps_rfq');
		}
		function getAttach($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_attachment');
			return $query->result();
		}
		function getCurr($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_currency');
			return $query->result();
		}
		function getPrice($id){
			$this->db->from('kps_rfq_target_price');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_rfq_target_price.KPS_RFQ_ID');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getSchedule($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_schedule');
			return $query->result();
		}
		function getDrawings($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_drawing');
			return $query->result();
		}
		function getDrawingsx($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_drawing');
			return $query->first_row();
		}
		function getDrawingsh($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_drawing_');
			return $query->result();
		}
		function getPP($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->where('`KPS_RFQ_PRODUCTION_PLAN_ID` NOT IN (SELECT `KPS_RFQ_SCHEDULE_ID` FROM `kps_rfq_schedule`)', NULL, FALSE);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getPPs($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->where('`KPS_RFQ_PRODUCTION_PLAN_ID` NOT IN (SELECT `KPS_RFQ_SCHEDULE_ID` FROM `kps_rfq_schedule`)', NULL, FALSE);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getPPsx($id){
			$this->db->where('KPS_RFQ_ID',$id);
			//$this->db->where('`KPS_RFQ_PRODUCTION_PLAN_ID` NOT IN (SELECT `KPS_RFQ_SCHEDULE_ID` FROM `kps_rfq_schedule`)', NULL, FALSE);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->first_row();
		}
		function getPPAll(){
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getPPAllx($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getLastPP($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->order_by('KPS_RFQ_PRODUCTION_PLAN_ID','desc');
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->first_row();
		}
		function getPart($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_part');
			return $query->result();
		}
		function getDrawing($id){
			$this->db->from('kps_breakdown_cost');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_rfq_production_plan','kps_rfq_production_plan.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->where('kps_breakdown_cost.KPS_BREAKDOWN_COST_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastDrawing($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->order_by('KPS_RFQ_DRAWING_ID','desc');
			$query = $this->db->get('kps_rfq_drawing');
			return $query->first_row();
		}
		function getDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function excelexport($id){
			$query = $this->db->query('SELECT a.KPS_RFQ_ID, DATE_RFQ, TOOLING_COST_RFQ, PART_STATUS, NO_RFQ, PERIODE, RFQ_CUSTOMER_NO, RFQ_CUSTOMER_DATE, COMPANY_NAME, RECEIVING_RFQ_DATE, RFQ_CUSTOMER_DATE, DUE_DATE_QUOTATION, ESTIMATION_LOI_DATE, KPS_RFQ_PART_NO, KPS_RFQ_PART_NAME, KPS_RFQ_PART_QTY, KPS_RFQ_PART_UNIT, CURRENCY_NAME, TO_IDR, e.MODEL, QTY_UNIT, QTY_MONTH, PP1, SAMPLE_MASSPRO, MASSPRO, COMPETITIOR_NAME, COMPETITIOR_PRICE, TARGET_PRICE, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = employee_checked_by) as employee_checked, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = employee_approved_by) as employee_approved, (select employee_name from kps_employee where KPS_EMPLOYEE_ID = a.user_made_by_id) as user_made

			FROM kps_rfq a, kps_customer b, kps_rfq_drawing c, kps_rfq_currency d,kps_rfq_production_plan e, kps_rfq_schedule f, kps_rfq_target_price g
			where 
			b.KPS_CUSTOMER_ID = a.KPS_CUSTOMER_ID_RFQ and
			a.KPS_RFQ_ID = c.KPS_RFQ_ID and
			a.KPS_RFQ_ID = d.KPS_RFQ_ID and
			a.KPS_RFQ_ID = e.KPS_RFQ_ID and
			a.KPS_RFQ_ID = f.KPS_RFQ_ID and
			a.KPS_RFQ_ID = g.KPS_RFQ_ID and
			a.KPS_RFQ_ID = '.$id.'');

			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_rfq',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq');
		}
		function unlock($status,$id){
			$this->db->set('status_rfq',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq');
		}
		
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_rfq',$revno);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq');
		}
		function del($status,$id){
			$this->db->set('DEL_RFQ',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq');
		}
		function undel($status,$id){
			$this->db->set('DEL_RFQ',$status);
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq');
		}
	}

?>