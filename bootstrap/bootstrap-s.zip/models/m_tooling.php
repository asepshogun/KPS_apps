<?php
	class m_tooling extends CI_Model{
		function getbyYM($year,$month){
			$this->db->select("AMORTIZE_COST_PURCHASE_PERIODE, INVOICE_INDUK_NO, INVOICE_INDUK_DATE, TOTAL_TERBAYAR, COMPANY_NAME, NO_LOI, kps_bukti_pesanan_detail.unit as unit, AMORTIZE_COST_BREAKDOWN, AMORTIZE_COST_PURCHASE, TOOLINGS_PRICE_BASED_ON_BREAKDOWN, TOOLINGS_PRICE_BASED_ON_PURCHASE, DATE_LOI, LOI_PART_NAME, LOI_MODEL, LOI_PART_NO, FIRST_PO_DATE, QTY_BASED_ON_BREAKDOWN, sum(QTY_DELIVERY_EXECUTION) as delivery_exe", FALSE);
			$this->db->from('kps_loi');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');

			$this->db->join('kps_invoice_detail','kps_invoice_detail.delivery_order_id=kps_delivery_order.KPS_DELIVERY_ORDER_ID','left');

			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET','left');

			$this->db->join('kps_marketing_quantity','kps_marketing_quantity.KPS_LOI_ID=kps_loi.KPS_LOI_ID','left');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');

			$this->db->where('YEAR(kps_invoice_induk.INVOICE_INDUK_DATE)',$year);
			$this->db->where('MONTH(kps_invoice_induk.INVOICE_INDUK_DATE)',$month);
			
			$this->db->group_by('kps_loi.KPS_LOI_ID');
			$this->db->order_by('kps_loi.KPS_LOI_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getbyYMX($year,$month){
			$this->db->select("*");
			$this->db->from('kps_loi');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_LOI_ID_BK=kps_loi.KPS_LOI_ID','left');

			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID','left');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID','left');

			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D','left');

			$this->db->join('kps_invoice_detail','kps_invoice_detail.delivery_order_id=kps_delivery_order.KPS_DELIVERY_ORDER_ID','left');

			$this->db->join('kps_invoice_induk','kps_invoice_induk.INVOICE_INDUK_ID=kps_invoice_detail.INVOICE_INDUK_ID_DET','left');

			$this->db->join('kps_marketing_quantity','kps_marketing_quantity.KPS_LOI_ID=kps_loi.KPS_LOI_ID','left');
			$this->db->join('kps_marketing_quantity_detail','kps_marketing_quantity_detail.KPS_MARKETING_QUANTITY_ID=kps_marketing_quantity.KPS_MARKETING_QUANTITY_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');

			$this->db->where('YEAR(kps_marketing_quantity.LOI_DATE)',$year);
			$this->db->where('MONTH(kps_marketing_quantity.LOI_DATE)',$month);
			
			$this->db->group_by('kps_loi.KPS_LOI_ID');
			//$this->db->order_by('kps_loi.KPS_LOI_ID','DESC');
			$query = $this->db->get();
			return $query->result();
		}
		function getAll(){
			$this->db->from('kps_marketing_toolings');
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->where('kps_marketing_toolings_ID',$id);
			$query = $this->db->get('kps_marketing_toolings');
			return $query->first_row();
		}
		function getDetail(){
			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','left');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID','left');
			$this->db->group_by('kps_loi.KPS_LOI_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->from('kps_marketing_toolings');
			$this->db->where('kps_marketing_toolings.kps_marketing_toolings_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_marketing_toolings');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("KPS_MARKETING_TOOLINGS_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_marketing_toolings',$data);
		}
		function update($data,$id){
			$this->db->where('kps_marketing_toolings_ID',$id);
			$this->db->update('kps_marketing_toolings',$data);
		}
		function delete($id){
			$this->db->where('kps_marketing_toolings_ID',$id);
			$this->db->delete('kps_marketing_toolings');
		}

	}

?>