<?php
	class m_rfqmon extends CI_Model{
		function getAll(){
			$this->db->from('kps_rfq');
			$this->db->join('kps_loi','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI','LEFT');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID','LEFT');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID','LEFT');
			$this->db->join('kps_rfq_schedule','kps_rfq.KPS_RFQ_ID=kps_rfq_schedule.KPS_RFQ_ID','LEFT');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ','LEFT');
			$this->db->join('kps_employee','kps_employee.KPS_EMPLOYEE_ID=kps_loi.MADE_BY_LOI','LEFT');
			$this->db->join('kps_breakdown_cost','kps_rfq.KPS_RFQ_ID=kps_breakdown_cost.KPS_RFQ_ID_BREAK','LEFT');
			$this->db->join('kps_breakdown_cost_tooling','kps_breakdown_cost.KPS_BREAKDOWN_COST_ID=kps_breakdown_cost_tooling.KPS_BREAKDOWN_COST_ID','LEFT');
			$this->db->join('kps_quotation_detail','kps_quotation_detail.breakdown_cost_id=kps_breakdown_cost.KPS_BREAKDOWN_COST_ID','LEFT');
			//$this->db->join('kps_quotation_detail','kps_quotation_detail.KPS_QUOTATION_ID=kps_quotation.KPS_QUOTATION_ID');
			$this->db->order_by('kps_rfq.KPS_RFQ_ID');
			
			$query = $this->db->get();
			return $query->result();
		}
		
	}

?>