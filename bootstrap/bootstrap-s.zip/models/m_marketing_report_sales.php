<?php
	class m_marketing_report_sales extends CI_Model{
		function getAll(){
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_marketing_sales_report.MARKETING_ID_MSR');
			$query = $this->db->get('kps_marketing_sales_report');
			return $query->result();
		}
		function get($id){
			$this->db->where('KPS_MSR_ID',$id);
			$this->db->join('kps_marketing','kps_marketing.KPS_MARKETING_ID=kps_marketing_sales_report.MARKETING_ID_MSR');
			$query = $this->db->get('kps_marketing_sales_report');
			return $query->first_row();
		}
		function getDetail($id,$year){
			$this->db->select('COMPANY_NAME, SUM(TOTAL_TERBAYAR) as total, MONTH(kps_invoice_induk.INVOICE_INDUK_DATE) as bulan');
			$this->db->from('kps_invoice_induk');
			
			$this->db->join('kps_customer','kps_invoice_induk.KPS_CUSTOMER_ID_INDK=kps_customer.KPS_CUSTOMER_ID');

			$this->db->where('YEAR(kps_invoice_induk.INVOICE_INDUK_DATE)',$year);
			$this->db->where('kps_customer.marketing_id',$id);
			$this->db->group_by('MONTH(kps_invoice_induk.INVOICE_INDUK_DATE)');
			$query = $this->db->get();
			return $query->result();

		}
		function insert($data){
			$this->db->insert('kps_marketing_sales_report',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_MARKETING_ID',$id);
			$this->db->insert('kps_marketing_sales_report',$data);
		}
		function delete($id){
			$this->db->where('KPS_MARKETING_ID',$id);
			$this->db->delete('kps_marketing_sales_report');
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_marketing_sales_report');
			$this->db->where('year(DATE_MSR) = '.$year);
			$this->db->where('NO_MSR is not null');
			$this->db->order_by("KPS_MSR_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}

	}

?>