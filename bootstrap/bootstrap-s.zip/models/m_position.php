<?php
	class m_position extends CI_Model{
		function getAll(){
			$this->db->from('kps_position_employee');
			$this->db->join('kps_section_employee','kps_position_employee.SEC_EMPLOYEE_ID_POS = kps_section_employee.SEC_EMPLOYEE_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function get($id){
			$this->db->where('POSITION_ID',$id);
			$query = $this->db->get('kps_position_employee');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_position_employee',$data);
		}
		function update($data,$id){
			$this->db->where('POSITION_ID',$id);
			$this->db->update('kps_position_employee',$data);
		}
		function delete($id){
			$this->db->where('POSITION_ID',$id);
			$this->db->delete('kps_position_employee');
		}

	}

?>