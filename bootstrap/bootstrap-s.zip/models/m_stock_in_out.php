<?php
	class m_stock_in_out extends CI_Model{
		function getAll(){
			$this->db->from('kps_bsthp_detail');
			$this->db->join('kps_bsthp_verification_detail','kps_bsthp_detail.KPS_BSTHP_DETAIL_ID=kps_bsthp_verification_detail.KPS_BSTHP_DETAIL_ID');
			$this->db->join('kps_label','kps_bsthp_detail.KPS_LABEL_ID=kps_label.KPS_LABEL_ID');
			$this->db->join('kps_loi','kps_label.KPS_LOI_ID_label=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_breakdown_cost','kps_breakdown_cost.KPS_RFQ_ID_BREAK=kps_rfq.KPS_RFQ_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');
			$this->db->join('kps_rfq_production_plan','kps_rfq.KPS_RFQ_ID=kps_rfq_production_plan.KPS_RFQ_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllx(){
			$this->db->select('*');
			$this->db->from('kps_bukti_pesanan_detail');

			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID');

			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK');

			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');

			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');

			$this->db->join('kps_rfq_production_plan','kps_rfq_production_plan.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');

			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID');

			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');

			$this->db->join('kps_delivery_order_confirm','kps_delivery_order_confirm.OUTGOING_DETAIL=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID');

			$this->db->where('kps_delivery_order_confirm.RECEIVED_DECISION','OK');

			$this->db->group_by('LOI_CODE_ITEM');
			$query = $this->db->get();
			return $query->result();
		}		

	}

?>