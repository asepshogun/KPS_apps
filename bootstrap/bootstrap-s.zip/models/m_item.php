<?php
	class m_loi extends CI_Model{
		function getAll(){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_rfq');
			$this->db->where('year(DATE_RFQ) = '.$year);
			$this->db->where('NO_RFQ is not null');
			$this->db->order_by("KPS_RFQ_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastIdDrawing(){
			$year = date('Y');
			$this->db->from('kps_rfq_drawing');
			$this->db->where('year(DRAWING_DATE) = '.$year);
			$this->db->where('DRAWING_NO is not null');
			$this->db->order_by("KPS_RFQ_DRAWING_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_rfq');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_rfq.KPS_CUSTOMER_ID_RFQ');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_rfq',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->update('kps_rfq',$data);
		}
		function delete($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$this->db->delete('kps_rfq');
		}
		function getAttach($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_attachment');
			return $query->result();
		}
		function getCurr($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_currency');
			return $query->result();
		}
		function getPrice($id){
			$this->db->from('kps_rfq_target_price');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_rfq_target_price.KPS_RFQ_ID');
			$this->db->where('kps_rfq.KPS_RFQ_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getSchedule($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_schedule');
			return $query->result();
		}
		function getPP($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_production_plan');
			return $query->result();
		}
		function getPart($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_part');
			return $query->result();
		}
		function getDrawing($id){
			$this->db->where('KPS_RFQ_ID',$id);
			$query = $this->db->get('kps_rfq_drawing');
			return $query->result();
		}
		function getDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
	}

?>