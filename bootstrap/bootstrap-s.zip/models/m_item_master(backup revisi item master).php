<?php
	class m_item_master extends CI_Model{
		function getAll(){
			$this->db->from('kps_item_master');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByCust($id){
			$this->db->from('kps_item_master');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getOnly($id){
			$this->db->from('kps_item_master');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_item_master_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_item_master_detail');
			$this->db->join('kps_item_master','kps_item_master.KPS_ITEM_MASTER_ID=kps_item_master_detail.KPS_ITEM_MASTER_ID');
			$this->db->join('kps_loi','kps_item_master.KPS_LOI_ID=kps_loi.KPS_LOI_ID');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_proses','kps_proses.KPS_PROSES_ID=kps_item_master_detail.KPS_PROSES_ID');
			$this->db->where('kps_item_master_detail.kps_item_master_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_item_master');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("kps_item_master_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_item_master',$data);
		}
		function insertDetail($data){
			$this->db->insert('kps_item_master_detail',$data);
		}
		function update($data,$id){
			$this->db->where('kps_item_master_ID',$id);
			$this->db->update('kps_item_master',$data);
		}
		function delete($id){
			$this->db->where('kps_item_master_ID',$id);
			$this->db->delete('kps_item_master');
		}

	}

?>