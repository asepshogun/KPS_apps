<?php
	class m_roles extends CI_Model{
		function getAll(){
			$this->db->from('kps_roles');
			$query = $this->db->get();
			return $query->result();
		}
		function getListRoles($idUser){
			$this->db->where('user_data_id',$idUser);
			$query = $this->db->get('kps_userdata_role');
			return $query->result();
		}
		function getRolesName($idRole){
			$this->db->where('id',$idRole);
			$query = $this->db->get('kps_roles');
			return $query->first_row();	
		}
		function insertUserRoles($idUser,$idRoles){
			$data = array(
				'user_data_id' => $idUser,
				'roles_id' => $idRoles
			);
			$this->db->insert('kps_userdata_role',$data);
		}
		function deleteUserRoles($idUser){
			$this->db->where('user_data_id',$idUser);
			$this->db->delete('kps_userdata_role');
		}

	}

?>