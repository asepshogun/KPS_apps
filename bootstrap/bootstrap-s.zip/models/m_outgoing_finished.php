<?php
	class m_outgoing_finished extends CI_Model{
		function getAll(){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->order_by("KPS_OUTGOING_FINISHED_GOOD_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getAllByOsForOut(){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.KPS_OS_ID_OGFG');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_order_sheet.KPS_OS_CUSTOMER_ID');
			$this->db->join('kps_customer_divisi','kps_customer_divisi.KPS_CUSTOMER_DIVISI_ID=kps_order_sheet.KPS_OS_CUSTOMER_DIVISI_ID');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_outgoing_finished_good');
			$this->db->where('year(DATE_OUTGOING) = '.$year);
			$this->db->where('NO_OUTGOING is not null');
			$this->db->order_by("KPS_OUTGOING_FINISHED_GOOD_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.kps_employee_id');
			$this->db->where('kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getByOs($id){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.KPS_OS_ID_OGFG');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_order_sheet.KPS_OS_CUSTOMER_ID');
			$this->db->join('kps_customer_divisi','kps_customer_divisi.KPS_CUSTOMER_DIVISI_ID=kps_order_sheet.KPS_OS_CUSTOMER_DIVISI_ID');
			$this->db->join('kps_employee','kps_outgoing_finished_good.employee_driver_id=kps_employee.kps_employee_id');
			$this->db->where('kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getDivisi($id){
			$this->db->from('kps_customer_divisi');
			$this->db->where('KPS_CUSTOMER_ID',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function insert($data){
			$this->db->insert('kps_outgoing_finished_good',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){

			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good',$data);
		}
		function updatetotalexc($id,$total){
			$this->db->set('TOTAL_DELIVERY_EXECUTION',$total);
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good');
		}
		function delete($id){
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->delete('kps_outgoing_finished_good');
		}
		function getDetail($id){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->join("kps_delivery_schedule_detail","kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD");
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');		
			$this->db->where("kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getQtyDet($id){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->where("KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getDetail_var($id){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->join("kps_delivery_schedule_detail","kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD");
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');		
			$this->db->join('kps_rfq','kps_loi.KPS_RFQ_ID_LOI=kps_rfq.KPS_RFQ_ID');		
			$this->db->join('kps_rfq_drawing','kps_rfq.KPS_RFQ_ID=kps_rfq_drawing.KPS_RFQ_ID');		
			$this->db->where("kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID",$id);
			$query = $this->db->get();
			return $query->result();
		}
		function getCode(){
			$this->db->from("kps_delivery_schedule_detail");
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$query = $this->db->get();
			return $query->result();
		}
		function getDelivSetup(){
			return $this->db->get('kps_customer_delivery_setup')->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function updateQtyVer($data,$id){
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID',$id);
			$this->db->update('kps_outgoing_finished_good_detail',$data);
		}
		function getOs(){
			$this->db->from('kps_outgoing_finished_good');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG');
			$this->db->join('kps_vehicle','kps_vehicle.KPS_VEHICLE_ID=kps_outgoing_finished_good.KPS_VEHICLE_ID');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.order_sheet_id');
			$query = $this->db->get();
			return $query->result();
		}
		function updateOs($data,$id){
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good',$data);
		}
		function getTableDetail($table,$tableId,$id){
			$this->db->where($tableId,$id);
			$query = $this->db->get($table);
			return $query->first_row();
		}
		function getDS($date,$buktiId){
			// $this->db->from('kps_delivery_schedule');
			// $this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID');
			// $this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			// $this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');		
			// $this->db->where("kps_delivery_schedule_detail.DELIVERY_PLAN",$date);
			// $this->db->where("kps_delivery_schedule.KPS_BUKTI_PESANAN_ID_DS",$buktiId);
			// $this->db->where("kps_delivery_schedule.KPS_OS_ID_DS is  NULL");
			//AND `kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_DETAIL_ID` NOT IN (	SELECT KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD FROM kps_outgoing_finished_good_detail)

			$query = $this->db->query("SELECT * FROM (`kps_delivery_schedule`) 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule`.`KPS_DELIVERY_SCHEDULE_ID`=`kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_ID` 
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD` 
			JOIN `kps_loi` ON `kps_loi`.`KPS_LOI_ID`=`kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK` WHERE 
			`kps_delivery_schedule_detail`.`DELIVERY_PLAN` = '$date' 
			AND `kps_delivery_schedule`.`KPS_BUKTI_PESANAN_ID_DS` = '$buktiId' 
			AND `kps_delivery_schedule`.`KPS_OS_ID_DS` is NULL 
			AND KPS_DELIVERY_SCHEDULE_DETAIL_ID NOT IN (SELECT KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD FROM kps_outgoing_finished_good_detail where KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD is not null)
			");
			return $query->result();	
		}
		function getDSByOs($idOS){
			$query = $this->db->query("SELECT * FROM (`kps_delivery_schedule`) 
			JOIN `kps_delivery_schedule_detail` ON `kps_delivery_schedule`.`KPS_DELIVERY_SCHEDULE_ID`=`kps_delivery_schedule_detail`.`KPS_DELIVERY_SCHEDULE_ID` 
			JOIN `kps_order_sheet_detail` ON `kps_order_sheet_detail`.`KPS_ORDER_SHEET_DETAIL_ID`=`kps_delivery_schedule`.`KPS_OS_ID_DS` 
			JOIN `kps_order_sheet` ON `kps_order_sheet`.`KPS_OS_ID`=`kps_order_sheet_detail`.`KPS_OS_ID_DETAIL` 
			JOIN `kps_bukti_pesanan_detail` ON `kps_bukti_pesanan_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID`=`kps_delivery_schedule_detail`.`KPS_BUKTI_PESANAN_DETAIL_ID_SD` 
			JOIN `kps_loi` ON `kps_loi`.`KPS_LOI_ID`=`kps_bukti_pesanan_detail`.`KPS_LOI_ID_BK` 
			WHERE `kps_order_sheet`.`KPS_OS_ID` = '$idOS' 
			AND KPS_DELIVERY_SCHEDULE_DETAIL_ID NOT IN (SELECT KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD FROM kps_outgoing_finished_good_detail)
			");
			return $query->result();	
		}
		function getDSX($date){
			$this->db->from('kps_delivery_schedule');
			$this->db->where("kps_delivery_schedule.DELIVERY_DATE",$date);

			return $this->db->get()->result();	
		}
		function getDetailProduct($Id){
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');		
			$this->db->where("kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D",$Id);
			
			$query = $this->db->get();
			return $query->result();
		}
		function checkDetail($id){
			$this->db->from('kps_outgoing_finished_good_detail');
			$this->db->where("KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD",$id);
			$this->db->order_by("KPS_OUTGOING_FINISHED_GOOD_ID_D","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function lock($status,$id){
			$this->db->set('status_ogfg',$status);
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good');
		}
		function unlock($status,$id){
			$this->db->set('status_ogfg',$status);
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_ogfg',$revno);
			$this->db->where('KPS_OUTGOING_FINISHED_GOOD_ID',$id);
			$this->db->update('kps_outgoing_finished_good');
		}

	}

?>	