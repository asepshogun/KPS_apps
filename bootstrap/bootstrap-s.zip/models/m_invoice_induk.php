<?php
	class m_invoice_induk extends CI_Model{
		//revisi rekap invoice 22-5-2016 start
		function get_do_detailForRekap($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_outgoing_finished_good.KPS_OS_ID_OGFG','LEFT');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.kps_bukti_pesanan_ID=kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG','left');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->where('kps_invoice_detail.INVOICE_INDUK_ID_DET',$id);
			$query = $this->db->get();
			return $query->result();
		}
		//revisi rekap invoice 22-5-2016 end
		// revisi Invoice TX non TX Start
		
		function getAllNT(){
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK','left');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK','left');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_customer.SALES_TAX',"Non Tax");
			$this->db->group_by('kps_invoice_induk.INVOICE_INDUK_ID');
			$this->db->order_by("INVOICE_INDUK_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getAllTX(){
			$this->db->from('kps_invoice_induk');
			// $this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			// $this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_customer.SALES_TAX',"Tax");
			$this->db->group_by('kps_invoice_induk.INVOICE_INDUK_ID');
			$this->db->order_by("INVOICE_INDUK_ID","DESC");
			$query = $this->db->get();
			return $query->result();
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_invoice_induk');
			$this->db->where('year(INVOICE_INDUK_DATE) = '.$year);
			$this->db->where('INVOICE_INDUK_NO is not null');
			$this->db->where('KPS_INVOICE_INDUK_NO_URUT_TX is not null');
			$this->db->order_by("INVOICE_INDUK_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLastIdNT(){
			$year = date('Y');
			$this->db->from('kps_invoice_induk');
			$this->db->where('year(INVOICE_INDUK_DATE) = '.$year);
			$this->db->where('INVOICE_INDUK_NO is not null');
			$this->db->where('KPS_INVOICE_INDUK_NO_URUT_NT is not null');
			$this->db->order_by("INVOICE_INDUK_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		
		function get($id){
			$this->db->from('kps_invoice_induk');
			// $this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			$this->db->join('kps_customer_finance','kps_customer_finance.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID','left');
			// $this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP','left');
			$this->db->where('kps_invoice_induk.INVOICE_INDUK_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function getTXFromIND($id){
			$this->db->select('kps_customer.SALES_TAX');
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->where('kps_invoice_induk.INVOICE_INDUK_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		// revisi Invoice TX non TX END
		
		//backup perubahan revisi untk tx non tx start
		
			// function getLastId(){
				// $year = date('Y');
				// $this->db->from('kps_invoice_induk');
				// $this->db->where('year(INVOICE_INDUK_DATE) = '.$year);
				// $this->db->where('INVOICE_INDUK_NO is not null');
				// $this->db->order_by("INVOICE_INDUK_ID","DESC");
				// $query = $this->db->get();
				// return $query->first_row();
			// }
			
			// function get($id){
				// $this->db->from('kps_invoice_induk');
				// $this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');

				// $this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
				// $this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
				// $this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');

				// $this->db->where('kps_invoice_induk.INVOICE_INDUK_ID',$id);
				// $query = $this->db->get();
				// return $query->first_row();
			// }
		//backup perubahan revisi untk tx non tx start
		function getAll(){
			$this->db->from('kps_invoice_induk');
			$this->db->join('kps_bukti_pesanan','kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_invoice_induk.BUKTI_PESANAN_ID_INDK');
			$this->db->join('kps_customer','kps_customer.KPS_CUSTOMER_ID=kps_invoice_induk.KPS_CUSTOMER_ID_INDK');
			$this->db->join('kps_customer_plant','kps_customer_plant.KPS_CUSTOMER_ID=kps_customer.KPS_CUSTOMER_ID');
			$this->db->join('kps_customer_finance_bank','kps_customer_finance_bank.KPS_CUSTOMER_FINANCE_BANK_ID=kps_bukti_pesanan.CURRENCY_BP');
			$this->db->group_by('kps_invoice_induk.INVOICE_INDUK_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getType(){
			$this->db->from('kps_invoice_type');
			$query = $this->db->get();
			return $query->result();

		}
		
		//Perubahan Untuk revisi invoice Start
		
		function get_do($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->join('kps_outgoing_finished_good','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_bukti_pesanan','kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID','left');
			$this->db->join('kps_order_sheet','kps_outgoing_finished_good.KPS_OS_ID_OGFG=kps_order_sheet.KPS_OS_ID','left');
			$this->db->where('kps_invoice_detail.INVOICE_INDUK_ID_DET',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function get_do_detail($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID=kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_delivery_schedule_detail','kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD');
			$this->db->join('kps_bukti_pesanan_detail','kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD');
			$this->db->join('kps_loi','kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_rfq_drawing','kps_rfq_drawing.KPS_RFQ_ID=kps_rfq.KPS_RFQ_ID');
			$this->db->where('kps_invoice_detail.INVOICE_INDUK_ID_DET',$id);
			$query = $this->db->get();
			return $query->result();
		}
		//Perubahan Untuk revisi invoice End
		function insert($data){
			$this->db->insert('kps_invoice_induk',$data);
		}
		function insertData($table,$data){
			$this->db->insert($table,$data);
		}
		function update($data,$id){
			$this->db->where('kps_invoice_ID',$id);
			$this->db->update('kps_invoice',$data);
		}
		function updateInvoiceInduk($data,$id){
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk',$data);
		}
		function updateInvoiceDetailDo($data,$id){
			$this->db->where('KPS_INVOICE_DETAIL_ID',$id);
			$this->db->update('kps_invoice_detail',$data);
		}
		function delete($id){
			$this->db->where('kps_invoice_ID',$id);
			$this->db->delete('kps_invoice');
		}
		function getCode(){
			$this->db->from("kps_outgoing_finished_good_detail");
			$this->db->join('kps_delivery_schedule_detail','kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID');
			$this->db->join("kps_bukti_pesanan_detail","kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD");
			$query = $this->db->get();
			return $query->result();
		}
		function getDetail($id){
			$this->db->from('kps_invoice_detail');
			$this->db->join('kps_invoice_induk','kps_invoice_detail.INVOICE_INDUK_ID_DET=kps_invoice_induk.INVOICE_INDUK_ID');
			$this->db->join('kps_delivery_order','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_invoice_detail.delivery_order_id');
			$this->db->where('kps_invoice_detail.INVOICE_INDUK_ID_DET',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function updateDetail($table,$tableId,$data,$id){
			$this->db->where($tableId,$id);
			$this->db->update($table,$data);
		}
		function getAllsForInvoice($id){
			$this->db->from('kps_delivery_order');
			$this->db->join('kps_order_sheet','kps_order_sheet.KPS_OS_ID=kps_order_sheet.KPS_OS_ID','left');
			$this->db->join('kps_delivery_order_confirm','kps_delivery_order.KPS_DELIVERY_ORDER_ID=kps_delivery_order_confirm.KPS_DO_ID_CONFIRM','left');
			$this->db->join('kps_outgoing_finished_good','kps_delivery_order.KPS_OUTGOING_FINISHED_GOOD_ID_DO=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$this->db->join('kps_bukti_pesanan','kps_outgoing_finished_good.KPS_BUKTI_PESANAN_ID_OGFG=kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID','left');
			$this->db->join('kps_customer','kps_bukti_pesanan.KPS_CUSTOMER_ID_BK=kps_customer.KPS_CUSTOMER_ID','left');
			$where='(kps_bukti_pesanan.KPS_CUSTOMER_ID_BK='. $id .' OR kps_order_sheet.KPS_OS_CUSTOMER_ID='. $id .')';
			$this->db->where($where);
			// $this->db->where('kps_customer.KPS_CUSTOMER_ID',$id);
			$this->db->where('kps_delivery_order_confirm.RECEIVED_DECISION',"OK");
			$this->db->where('`KPS_DELIVERY_ORDER_ID` NOT IN (SELECT `delivery_order_id` FROM `kps_invoice_detail`)', NULL, FALSE);
			$this->db->group_by('kps_delivery_order.KPS_DELIVERY_ORDER_ID');
			$query = $this->db->get();
			return $query->result();
		}
		function getTerm($id){
			$this->db->from('kps_invoice_term');
			$this->db->where('invoice_id',$id);
			$query = $this->db->get();
			return $query->result();
		}
		function lockdo($status,$id){
			$this->db->set('status_inv_do',$status);
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk');
		}
		function unlockdo($status,$id){
			$this->db->set('status_inv_do',$status);
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk');
		}
		function updateTotPem($get_Tot,$id){
			$this->db->set('TOTAL_PEMBAYARAN',$get_Tot);
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk');
		}
		function updateInvDet($Tot,$TotQTY,$id){
			$this->db->set('total_qty',$TotQTY);
			$this->db->set('total_amount',$Tot);
			$this->db->where('INVOICE_INDUK_ID_inv',$id);
			$this->db->update('kps_invoice');
		}
		function updateTerTerm($Tot,$TotQTY,$id){
			$this->db->set('TOTAL_TERBAYAR',$Tot);
			$this->db->set('TOTAL_TERM',$TotQTY);
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk');
		}
		function updaterevno($revno,$id){
			$this->db->set('revisi_no_inv',$revno);
			$this->db->where('INVOICE_INDUK_ID',$id);
			$this->db->update('kps_invoice_induk');
		}
	}

?>