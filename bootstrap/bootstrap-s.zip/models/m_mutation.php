<?php
	class m_mutation extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_mutation_item');
			return $query->result();
		}
		function getAllMutationByOfg($id){
			$this->db->from('kps_mutation_item');
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_MUTATION_ID_OGFG=kps_mutation_item.KPS_MUTATION_ITEM_ID');
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$query = $this->db->get();
			return $query->first_row();
		}
		function get($id){
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_MUTATION_ID_OGFG=kps_mutation_item.KPS_MUTATION_ITEM_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$query = $this->db->get('kps_mutation_item');
			return $query->first_row();
		}
		function getMutationByOgdet($id){
			$this->db->where('kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID',$id);
			$this->db->join('kps_outgoing_finished_good','kps_outgoing_finished_good.KPS_MUTATION_ID_OGFG=kps_mutation_item.KPS_MUTATION_ITEM_ID');
			$this->db->join('kps_outgoing_finished_good_detail','kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_ID_D=kps_outgoing_finished_good.KPS_OUTGOING_FINISHED_GOOD_ID');
			$query = $this->db->get('kps_mutation_item');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_mutation_item',$data);
		}
		function update($data,$id){
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->update('kps_mutation_item',$data);
		}
		function updatelock($id){
			$data=array('KPS_STATUS_LOCK'=>'1');
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->update('kps_mutation_item',$data);
		}
		function delete($id){
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->delete('kps_mutation_item');
		}
		function getLastId(){
			$year = date('Y');
			$this->db->from('kps_mutation_item');
			$this->db->where('year(DATE) = '.$year);
			$this->db->where('NO is not null');
			$this->db->order_by("KPS_MUTATION_ITEM_ID","DESC");
			$query = $this->db->get();
			return $query->first_row();
		}
		function getLoiByCust($idCust){

			$this->db->from('kps_loi');
			$this->db->join('kps_rfq','kps_rfq.KPS_RFQ_ID=kps_loi.KPS_RFQ_ID_LOI');
			$this->db->join('kps_customer','kps_rfq.KPS_CUSTOMER_ID_RFQ=kps_customer.KPS_CUSTOMER_ID');
			$this->db->where('kps_customer.KPS_CUSTOMER_ID',$idCust);
			$query = $this->db->get();
			return $query->result();
		}
		function updateStatusOfg($id){
			$data=array('STATUS_MT_OFG'=>'1');
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->update('kps_mutation_item',$data);
		}	
		function updateStatusOfgDet($id){
			$data=array('STATUS_MT_OFGDET'=>'1');
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->update('kps_mutation_item',$data);
		}	
		function updateStatusOfgVer($id){
			$data=array('STATUS_MT_OFG_VER'=>'1');
			$this->db->where('KPS_MUTATION_ITEM_ID',$id);
			$this->db->update('kps_mutation_item',$data);
		}

	}

?>