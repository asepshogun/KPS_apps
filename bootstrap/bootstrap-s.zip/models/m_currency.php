<?php
	class m_currency extends CI_Model{
		function getAll(){
			$query = $this->db->get('kps_currency');
			return $query->result();
		}
		function get($id){
			$this->db->where('kps_currency_ID',$id);
			$query = $this->db->get('kps_currency');
			return $query->first_row();
		}
		function insert($data){
			$this->db->insert('kps_currency',$data);
		}
		function update($data,$id){
			$this->db->where('kps_currency_ID',$id);
			$this->db->update('kps_currency',$data);
		}
		function delete($id){
			$this->db->where('kps_currency_ID',$id);
			$this->db->delete('kps_currency');
		}

	}

?>