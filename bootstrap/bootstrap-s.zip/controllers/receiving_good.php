<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Receiving_Good extends CI_Controller {

	public function index()
	{
		$data['content'] = 'warehouse/v_receiving_good';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

	public function detail(){
		$data['content'] = 'warehouse/detail/receiving_good';
		$this->load->view('template/template',$data);
	}

}
