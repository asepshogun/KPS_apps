<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(E_ALL);

class Item extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_loi');
		$this->load->model('m_req_quotation');
		$this->load->model('m_employee');
		$this->load->model('m_customer_information');
		// perubahan untuk revisi Item master Start
		$this->load->model('m_new_item_master');
		// perubahan untuk revisi Item master End
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_loi->getAll();
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['content'] = 'sales_data/v_item';
		$this->load->view('template/template',$data);
	}
	public function pre_print($id){
		$data['detail'] = $this->m_loi->getAllId($id);		
		$this->load->view('sales_data/print/v_pre_print_loi',$data);
	}
	// perubahan untuk revisi Item master Start
	public function loadProd2(){
		$id = $this->input->post('id');
		$data = $this->m_loi->getLoiRFQ($id);
	    header('Content-Type: application/json');
    	echo json_encode( $data );
	}
	public function loadProd(){
		$id = $this->input->post('id');
		$data = $this->m_new_item_master->getForLoi($id);
	    header('Content-Type: application/json');
    	echo json_encode( $data );
	}
	// perubahan untuk revisi Item master End
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_loi->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO_LOI+1;

		}
		$no = $year."/NI-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_LOI'] = $no;
		$data['REV_NO_LOI'] = $revNoNew;
		unset($data['KPS_CUSTOMER_ID_BK']);
		$this->m_loi->insert($data);
		redirect('item');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_loi_attachment"){
			$data['FILENAME'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['upload_path'] = './uploads/loi/';
			$config['allowed_types'] = $ext.'|'.$fileType;

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
		}
		
		$this->m_loi->insertData($table,$data);
		redirect('item/detail/'.$data['KPS_LOI_ID']);
	}
	public function detail($id)
	{;
		$datas = $this->m_loi->get($id);
		$idRfq = $datas->KPS_RFQ_ID_LOI;
		$data['data'] = $this->m_loi->get($id);
		$data['attach'] = $this->m_loi->getDetail("kps_loi_attachment","KPS_LOI_ID",$id);
		
		$data['content'] = 'sales_data/detail/item';
		$this->load->view('template/template',$data);
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_loi->geth($id);
		$data['content'] = 'sales_data/history/history_loi';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_loi->del($status,$id);
		redirect('item');
	}
	public function undel($id){
		$status = "0";
		$this->m_loi->undel($status,$id);
		redirect('item');
	}
	public function edit($id){
		
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['data'] = $this->m_loi->get($id);
		$this->load->view('sales_data/v_edit_item',$data);
	}
	// perubahan untuk revisi Item master Start
	public function preAdd(){
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['itemMaster'] = $this->m_new_item_master->getAll();
		$this->load->view('sales_data/add/pop_up_add_loi',$data);
	}
	// perubahan untuk revisi Item master End
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_loi->update($data,$id);
		$status = $data['revisi_no_loi']+1;
		$this->m_loi->updaterevno($status,$id);
		redirect('item');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		
		$data['data'] = $this->m_loi->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_LOI_ID'];
		if($table=="kps_loi_attachment"){
			$data['FILENAME'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['upload_path'] = './uploads/loi/';
			$config['allowed_types'] = $ext.'|'.$fileType;

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
		}
		unset($data['id']);
		unset($data['KPS_LOI_ID']);
		$this->m_loi->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_loi->get($idRef);
		$status = $data->revisi_no_loi+1;
		$this->m_loi->updaterevno($status,$idRef);
		redirect('item/detail/'.$idRef);
	}
	public function loadRFQs(){
		$id = $this->input->get('id');
		$datas = $this->m_req_quotation->getAllByCust($id);
		?>
		<option>-- Select RFQ --</option>								
		<?php
		foreach ($datas as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_RFQ_ID;?>"><?php echo $value->NO_RFQ;?></option>	
			<?php
		}
	}
	public function loadRFQsFailed(){
		$id = $this->input->get('id');
		$datas = $this->m_req_quotation->getAllByCustFailed($id);
		?>
		<option>-- Select RFQ --</option>								
		<?php
		foreach ($datas as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_RFQ_ID;?>"><?php echo $value->NO_RFQ;?></option>	
			<?php
		}
	}
	public function lock($id){
		$status = "1";
		$this->m_loi->lock($status,$id);
		redirect('item');
	}
	public function unlock($id){
		$status = "0";
		$this->m_loi->unlock($status,$id);
		redirect('item');
	}

}
