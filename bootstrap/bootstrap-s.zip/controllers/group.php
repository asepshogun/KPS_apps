<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Group extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_group');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_group->getAll();
		$data['content'] = 'module/v_group';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_group->insert($data);
		redirect('group');
	}
	public function edit($id){
		$data['data'] = $this->m_group->get($id);
		$this->load->view('module/v_edit_group',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_group->update($data,$id);
		redirect('group');
	}
}
