<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Monthly_Marketing_Sales_Report extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_marketing_report_sales');
		$this->load->model('m_marketing');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_marketing_report_sales->getAll();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['content'] = 'report_management/v_monthly_marketing_sales_report';
		$this->load->view('template/template',$data);
	}

	public function detail($id)
	{	
		$datax = $this->m_marketing_report_sales->get($id);
		$data['data'] = $this->m_marketing_report_sales->getDetail($datax->MARKETING_ID_MSR,$datax->YEAR_MSR);
		$data['dataOnly']= $this->m_marketing_report_sales->get($id);
		$data['content'] = 'report_management/detail/monthly_marketing_sales_report';
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_marketing_report_sales->getLastId();
		if(!empty($lastNo)){
			$revSplit = explode("/", $lastNo->NO_MSR);
			$revNoNew = $revSplit[3]+1;
		}else{
			$revNoNew = 1;
		}

		$no = $year."/MSR-MRK/".$this->KonDecRomawi($month)."/".$revNoNew; 

		$data['NO_MSR'] = $no;
		

		$this->m_marketing_report_sales->insert($data);
		redirect('Monthly_Marketing_Sales_Report');
	}
	public function edit($id){
		$data['data'] = $this->m_report_monthly->get($id);
		$this->load->view('marketing/v_edit_report_monthly',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_report_monthly->update($data,$id);
		redirect('report_monthly');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
		}
		function tampil_bulan ($x) {
	    if ($x == 1 ) {
	        $bulan = "Januari"; }
	    if ($x == 2 ) {
	        $bulan = "Februari"; }
	    if ($x == 3 ) {
	        $bulan = "Maret"; }
	    if ($x == 4 ) {
	        $bulan = "April"; }
	    if ($x == 5 ) {
	        $bulan = "Mei"; }
	    if ($x == 6 ) {
	        $bulan = "Juni"; }
	    if ($x == 7 ) {
	        $bulan = "Juli"; }
	    if ($x == 8 ) {
	        $bulan = "Agustus"; }
	    if ($x == 9 ) {
	        $bulan = "September"; }
	    if ($x == 10) {
	        $bulan = "Oktober"; }
	    if ($x == 11) {
	        $bulan = "November"; }
	    if ($x == 12) {
	        $bulan = "Desember"; }
	    return $bulan;
	}
}
