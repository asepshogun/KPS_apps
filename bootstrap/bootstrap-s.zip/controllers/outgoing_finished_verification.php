<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Outgoing_finished_verification extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_outgoing_finished');
		$this->load->model('m_outgoing_finished_verification');
		$this->load->model('m_bsthp_detail_sub');
		$this->load->model('m_employee');
		$this->load->model('m_pesanan');
		$this->load->model('m_quotation');
		$this->load->model('m_pesanan');
		$this->load->model('m_vehicle');
		$this->load->model('m_schedule');
	}
	public function index()
	{
		$data['data'] = $this->m_outgoing_finished->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataBukti'] = $this->m_pesanan->getAll();
		$data['dataVeh'] = $this->m_vehicle->getAll();
		$data['content'] = 'sales_data/v_outgoing_finished_verification';
		$this->load->view('template/template',$data);
	}
	
	public function add($id){
		$data = $this->input->post();
		// $barcode = $data['no_barcode_item'];
		$barcode = substr($data['no_barcode_item'], 0, -3);
		$orderby = abs(substr($data['no_barcode_item'], -3));
		$dataLabel = $this->m_bsthp_detail_sub->getIdsub($barcode,$orderby);
		if($dataLabel){
			$labelId = $dataLabel[0]->KPS_BSTHP_DETAIL_SUB_ID;
			// $getVerBsthpBySub = $this->m_bsthp_detail_sub->getVerBsthpBySub($labelId);
			unset($data['no_barcode_item']);
			$pesan="0";
				if($data['LOI_idByVER']==$dataLabel[0]->KPS_LOI_ID_label){
					if($dataLabel[0]->BSTHP_DETAIL_SUB_VER){
						if(empty($dataLabel[0]->BSTHP_DETAIL_SUB_VER_BY_OUTGOING)){
							$getOUTDet = $this->m_outgoing_finished->getQtyDet($data['KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER']);
							$data['KPS_BSTHP_DETAIL_SUB_ID_VER'] = $labelId;
							$qtyTotalExe=$getOUTDet[0]->QTY_DELIVERY_EXECUTION;
							$qtyTotalVer=$getOUTDet[0]->OUTGOING_DETAIL_QTY_VERIFICATION;
							$qtyTotalExVer=$dataLabel[0]->QUANTITY;
							$qtyTotalVer=$qtyTotalVer+$qtyTotalExVer;
							if($qtyTotalVer<=$qtyTotalExe){
								$qtyTotalVerUpdate['OUTGOING_DETAIL_QTY_VERIFICATION']=$qtyTotalVer;
								unset($data['LOI_idByVER']);
								$this->m_outgoing_finished_verification->insert($data);
								$this->m_bsthp_detail_sub->updateSubByOut($labelId);
								$this->m_outgoing_finished->updateQtyVer($qtyTotalVerUpdate,$data['KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER']);
							}else{
								$pesan="4";
							}
						}else{
							$pesan=$labelId;
							// print_r($pesan);
						}
					}else{
						$pesan="2";
					}
				}else{
					$pesan="1";
				}
			}else{
				$pesan="3";
			}
			redirect('Outgoing_finished_verification/detail_ver/'.$this->input->post('KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER') ."/". $id ."/" . $pesan);
	}
	// public function addSub($table){
		// $data=$this->input->post();
		
		// $datas = array(
			// 'TOTAL_WAREHOUSE' => $data['TOTAL_WAREHOUSE'],
			// 'TOTAL_PO' => $data['TOTAL_PO'],
			// 'TOTAL_DELIVERY_SHCEDULE' => $data['TOTAL_DELIVERY_SHCEDULE'],
			// 'TOTAL_DELIVERY_PENDING' => $data['TOTAL_DELIVERY_PENDING'],
			// 'TOTAL_OUTSTANDING_PO_OS' => $data['QTY_OUTSTANDING_PO_OS'],
			// 'TOTAL_DELIVERY_EXECUTION' => $data['QTY_DELIVERY_EXECUTION']
		// );
		// unset($data['TOTAL_WAREHOUSE']);
		// unset($data['TOTAL_DELIVERY_SHCEDULE']);
		// unset($data['TOTAL_DELIVERY_PENDING']);
		// unset($data['TOTAL_PO']);
		// $this->m_outgoing_finished->insertData($table,$data);
		// $str = $this->db->last_query();

		// $this->m_outgoing_finished->update($datas,$data['KPS_OUTGOING_FINISHED_GOOD_ID_D']);

		// redirect('outgoing_finished/detail/'.$data['KPS_OUTGOING_FINISHED_GOOD_ID_D']);
	// }
	public function detail($id)
	{;
		$data['data'] = $this->m_outgoing_finished->get($id);
		$dataDetail = $this->m_outgoing_finished->get($id);
		$data['detail'] = $this->m_outgoing_finished->getDetail($id);
		$detail = $this->m_outgoing_finished->getDetail($id);

		$total = 0;
		for ($i=0; $i < count($detail); $i++) { 
			$total += $detail[$i]->QTY_DELIVERY_EXECUTION;	
		}
		
		$data['total'] = $total;
		$data['schedule'] = $this->m_outgoing_finished->getDS($dataDetail->DELIVERY_DATE,$dataDetail->KPS_BUKTI_PESANAN_ID);
		$data['content'] = 'sales_data/detail/outgoing_finished_verification';
		$this->load->view('template/template',$data);
	}
	public function detail_ver($id,$idOG,$pesan="0")
	{
		$data['data'] = $this->m_outgoing_finished->get($idOG);
		$dataDetail = $this->m_outgoing_finished->get($idOG);
		$data['detail'] = $this->m_outgoing_finished->getDetail_var($id);
		$data['detail_ver'] = $this->m_outgoing_finished_verification->getAll($id);
		$detail = $this->m_outgoing_finished->getDetail($idOG);

		$total = 0;
		for ($i=0; $i < count($detail); $i++) { 
			$total += $detail[$i]->QTY_DELIVERY_EXECUTION;	
		}
		if($pesan){
			if($pesan==1){
				$dataSub="Code item tidak sesuai dengan yang terdaftar pada Mutasi";
			}elseif($pesan==2){
				$dataSub="Ini adalah Barang NG";
			}elseif($pesan==3){
				$dataSub="Barang belum terdaftar di BSTHP";
			}elseif($pesan==4){
				$dataSub="QTY Barang Melebihi Quota Execution";
			}else{
			$dataout=$this->m_bsthp_detail_sub->getIDOutBySub($pesan);
			$dataSub="Barang Sudah terdaftar pada Outgoing No :".$dataout->NO_OUTGOING ." Tanggal Outgoing : ".$dataout->DATE_OUTGOING;
			}
		}else{
		$dataSub="0";
		}
		$data['pesan'] = $dataSub;
		$data['total'] = $total;
		$data['content'] = 'sales_data/detail/detail/outgoing_finished_verification';
		$this->load->view('template/template',$data);
	}
	// public function edit($id){
		// $data['dataEmployee'] = $this->m_employee->getAll();
		// $data['dataBukti'] = $this->m_pesanan->getAll();
		// $data['dataVeh'] = $this->m_vehicle->getAll();
		
		// $data['data'] = $this->m_outgoing_finished->get($id);
		// $this->load->view('sales_data/v_edit_outgoing_finished',$data);
	// }
	// public function update(){
		// $id=$this->input->post('id');
		// $data=$this->input->post();
		
		// unset($data['id']);
		 // $this->m_outgoing_finished->update($data,$id);
		// redirect('outgoing_finished');
	// }
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	// public function editDetail($id,$view,$table,$tableId){
		// $data['code'] = $this->m_outgoing_finished->getCode();
		
		// $data['data'] = $this->m_outgoing_finished->getTableDetail($table,$tableId,$id);
		// $this->load->view('sales_data/detail/'.$view,$data);
	// }
	// public function updateDetail($table,$tableId){
		// $id=$this->input->post('id');
		// $data=$this->input->post();
		// $idRef = $data['idRef'];
		// unset($data['id']);
		// unset($data['idRef']);
		 // $this->m_outgoing_finished->updateDetail($table,$tableId,$data,$id);
		// redirect('outgoing_finished/detail/'.$idRef);
	// }
	public function loadDate(){
		$id = $this->input->get('id');
		$data = $this->m_schedule->getDeliveryPlan($id);
		?>
		<option>-- Select Delivery Schedule --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->DELIVERY_PLAN;?>"><?php echo $value->DELIVERY_PLAN;?></option>	
			<?php
		}
	}
	// public function loadPo(){
		// $id = $this->input->get('id');
		// $idout = $this->input->get('idout');
		// $q = 0;
		
		// if(count($this->m_outgoing_finished->checkDetail($id))==0){
			// $data = $this->m_schedule->getDetailPesanan($id);
			// $q = $data->QUANTITY;
		// }else{
			// $datacount = $this->m_outgoing_finished->checkDetail($id);
			// $q = $datacount[0]->QTY_OUTSTANDING_PO_OS - $datacount[0]->QTY_DELIVERY_EXECUTION;
		// }
		// $dataPo = $this->m_schedule->getDetailPesanan($id);
		// $po = $dataPo->QUANTITY;
		// $ds = $dataPo->QUANTITY_DELIVERY;
		// $outstanding = trim($q);
		// $dataRespon = array(
			// 'outstanding' => $outstanding,
			// 'po' => $po,
			// 'ds' => $ds
		// );
		// header('Content-Type: application/json');
		// echo json_encode( $dataRespon );
	// }

}