<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Outgoing_Finished_Good_Other extends CI_Controller {

	public function index()
	{
		$data['content'] = 'warehouse/v_outgoing_finished_good_other';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail(){
		$data['content'] = 'warehouse/detail/outgoing_finished_good_other';
		$this->load->view('template/template',$data);
	}

	public function report(){
		$data['content'] = 'warehouse/v_outgoing_finished_good_other_report';
		$this->load->view('template/template',$data);
	}

}
