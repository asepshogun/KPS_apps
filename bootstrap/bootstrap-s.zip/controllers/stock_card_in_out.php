<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock_Card_In_Out extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_stock_in_out');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_stock_in_out->getAllx();
		$data['content'] = 'warehouse/v_stock_card_in_out';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail(){
		$data['content'] = 'warehouse/detail/stock_card_in_out';
		$this->load->view('template/template',$data);
	}

}
