<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Outgoing_retur_product extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_retur_product');
		$this->load->model('m_customer_information');
		$this->load->model('m_deliver_order');
		$this->load->model('m_employee');
		$this->load->model('m_outgoing_retur_product');
		$this->load->model('m_vehicle');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_outgoing_retur_product->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataVeh'] = $this->m_vehicle->getAll();
		$data['dataRetur'] = $this->m_retur_product->getAll();
		$data['content'] = 'sales_data/v_outgoing_retur_product';
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_outgoing_retur_product->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->OUTGOING_RETUR_PRODUCT_NO_REV+1;

		}
		$no = $year."/OGRTR-PPIC/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['OUTGOING_RETUR_PRODUCT_NO'] = $no;
		$data['OUTGOING_RETUR_PRODUCT_NO_REV'] = $revNoNew;

		$this->m_outgoing_retur_product->insert($data);
		redirect('outgoing_retur_product');
	}
	public function add_out($id){
		$data=$this->input->post();
		$this->m_outgoing_retur_product->insert_out($data);
		redirect('outgoing_retur_product/detail/'.$data['OUTGOING_RETUR_PRODUCT_ID_DETAIL']."/".$id);
	}
	public function addSub($table){
		$data=$this->input->post();
		$this->m_retur_product->insertData($table,$data);
		redirect('retur_product/detail/'.$data['KPS_RETUR_BARANG_ID_DET']);
	}
	public function add_exe($id_retur,$id_out,$id){
		$data['detail'] = $this->m_retur_product->get_retur_detail($id_retur);
		$data['id_retur_det'] = $id_retur;
		$data['id_outgoing'] = $id_out;
		$data['id_retur_induk'] = $id;
		$returDetail=$this->m_retur_product->get_retur_detail($id_retur); // Tujuan untuk mengambil data retur produk dan outgoing
		$getOutGoing=$this->m_outgoing_retur_product->getOutGoingForAdd($id_retur); // tujuan untuk count apakah retur sudah ada di outgoing
		$data['returDetail']=$returDetail;
		if(empty($getOutGoing)){
		$data['QTY_REMAINIG_EXECUTION_OUT']=$returDetail->QTY_RTR;
		}else{
		$data['QTY_REMAINIG_EXECUTION_OUT']=$getOutGoing->QTY_REMAINIG_EXECUTION_OUT;
		}
		$this->load->view('sales_data/add/pop_up_add_exe_out_going_retur',$data);
	}
	public function insertExe(){
		$data=$this->input->post();
		$remaining=$data['QTY_REMAINIG_EXECUTION_OUT'];
		$idReturBarang=$data['KPS_RETUR_BARANG_ID_DET'];
		$loi=$data['loi'];
		unset($data['KPS_RETUR_BARANG_ID_DET']);
		unset($data['loi']);
		if($remaining-$data['QTY_EXECUTION_OUT']>0){
			$data['QTY_REMAINIG_EXECUTION_OUT']=$remaining-$data['QTY_EXECUTION_OUT'];
			$this->m_outgoing_retur_product->insertData("kps_outgoing_retur_product_detail",$data);
			redirect('Outgoing_retur_product/detail/'.$data['OUTGOING_RETUR_PRODUCT_ID_DETAIL'] ."/". $idReturBarang);
		}else{
			redirect('Outgoing_retur_product/detail/'.$data['OUTGOING_RETUR_PRODUCT_ID_DETAIL'] ."/". $idReturBarang ."/". $loi );
		}
	}
	public function detail($id,$id_retur,$pesan="0")
	{;
		$data['datas'] = $this->m_outgoing_retur_product->get($id);
		$data['detail'] = $this->m_retur_product->getDetailPesananForOut($id_retur,$id);
		$data['detail_out'] = $this->m_outgoing_retur_product->getDetail($id);
		$data['pesan']=$pesan;
		$data['content'] = 'sales_data/detail/out_retur';
		$this->load->view('template/template',$data);
	}
	public function edit($id,$idCust){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataCurr'] = $this->m_currency->getAll();
		$data['dataDivisi'] = $this->m_pesanan->getDivisi($idCust);
		
		$data['data'] = $this->m_pesanan->get($id);
		$this->load->view('sales_data/v_edit_pesanan',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_pesanan->update($data,$id);
		redirect('pesanan');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$data['name'] = $this->m_quotation->getAllDetail();
		$data['number'] = $this->m_quotation->getAllDetail();
		$data['code'] = $this->m_loi->getAllDetail();
		
		$data['data'] = $this->m_pesanan->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_pesanan->updateDetail($table,$tableId,$data,$id);
		redirect('pesanan/detail/'.$idRef);
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_pesanan->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadModelPrice(){
		$id = $this->input->post('id');
		$data = $this->m_pesanan->getModelPrice($id);
		echo json_encode($data);
	}

}
