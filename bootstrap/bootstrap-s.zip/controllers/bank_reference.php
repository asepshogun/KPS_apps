<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bank_Reference extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_bank_reference');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_bank_reference->getAll();
		$data['content'] = 'module/v_bank_reference';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_bank_reference->insert($data);
		redirect('bank_reference');
	}
	public function edit($id){
		$data['data'] = $this->m_bank_reference->get($id);
		$this->load->view('module/v_edit_bank_reference',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_bank_reference->update($data,$id);
		redirect('bank_reference');
	}
	

}
