<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_order_retur extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_delivery_order_retur');
		$this->load->model('m_outgoing_retur_product');
		$this->load->model('m_customer_information');
		// $this->load->model('m_outgoing_finished');
		$this->load->model('m_employee');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_delivery_order_retur->getAll();
		$data['data_out'] = $this->m_delivery_order_retur->getAllOutForDOR();
		$data['dataCust'] = $this->m_customer_information->getAll();
		// $data['dataPlant'] = $this->m_customer_information->getPlantAll();
		// $data['dataOut'] = $this->m_outgoing_finished->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		// $data['dataCust'] = $this->m_customer_information->getAll();

		$data['content'] = 'sales_data/v_delivery_order_retur';
		$this->load->view('template/template',$data);
	}
	public function preprint($id){
		$data['detail'] = $this->m_delivery_order_retur->get_Detail_DO_retur($id);
		$this->load->view('sales_data/print/v_pre_print_DO_retur',$data);
	}
	public function preprint2($id){
		$data['detail'] = $this->m_delivery_order_retur->get_Detail_DO_retur($id);
		$this->load->view('sales_data/print/v_pre_print_DO_retur',$data);
	}
	public function confirmation($id)
	{
		$data['id'] = $id;
		$data['data'] = $this->m_deliver_order->getConfirm($id);
		$data['content'] = 'sales_data/v_delivery_order_confirmation';
		$this->load->view('template/template',$data);
	}
	
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_delivery_order_retur->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->KPS_DO_REV_NO+1;

		}
		$no = $year."/DO-RTR-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['KPS_DO_RETUR_NO'] = $no;
		$data['KPS_DO_REV_NO'] = $revNoNew;
		// $data['TOTAL_QTY'] = 0;
		// unset($data['KPS_CUSTOMER_ID_BK']);
		$this->m_delivery_order_retur->insert($data);
		redirect('delivery_order_retur');
	}
	public function addSub($table){
		$data=$this->input->post();
		$this->m_deliver_order->insertData($table,$data);
		echo $str = $this->db->last_query();
		
		redirect('delivery_order/confirmation/'.$data['OUTGOING']);
	}
	public function detail($id)
	{
		$data['code'] = $this->m_deliver_order->getCode();
		$datas = $this->m_deliver_order->get($id);
		$data['data'] = $this->m_deliver_order->get($id);
		$data['outgoing'] = $this->m_outgoing_finished->getAll();
		$data['detail'] = $this->m_deliver_order->getDetail($datas->KPS_OUTGOING_FINISHED_GOOD_ID_DO);
		$detail = $this->m_deliver_order->getDetail($id);
		$total=0;
		foreach($detail as $value){
			$total += $value->QTY_DELIVERY_EXECUTION;
		}
		$data['total'] = $total;
		$data['content'] = 'sales_data/detail/delivery_order';
		$this->load->view('template/template',$data);
	}
	public function edit($id){
		$data['dataPlant'] = $this->m_customer_information->getPlantAll();
		$data['dataOut'] = $this->m_outgoing_finished->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		
		$data['data'] = $this->m_deliver_order->get($id);
		$this->load->view('sales_data/v_edit_delivery_order',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		
		unset($data['id']);
		 $this->m_deliver_order->update($data,$id);
		redirect('delivery_order');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$data['code'] = $this->m_deliver_order->getCode();

		$data['data'] = $this->m_deliver_order->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_deliver_order->updateDetail($table,$tableId,$data,$id);
		redirect('delivery_order/detail/'.$idRef);
	}
	public function loadOutgoing(){
		$id = $this->input->post('id');
		$data = $this->m_deliver_order->getAllByCustomer($id);
		?>
		<option>-- Select Delivery Schedule --</option>								
		  <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_ID;?>"><?php echo $value->NO_OUTGOING;?></option>
	<?php } 

	}
	public function loadPlant(){
		$id = $this->input->get('id');
		$data = $this->m_deliver_order->getPlant($id);
		?>
		<option>-- Select Plant --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_PLANT_ID;?>">
			 	<?php echo $value->PLANT;?></option>	
			<?php
		}
	}
	public function loadProduct(){
		$id = $this->input->post('id');
		$data = $this->m_outgoing_finished->getDetailProduct($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO." - ".$value->LOI_PART_NAME." - ".$value->DELIVERY_PLAN?></option>
		    <?php 
		} 
	}

}