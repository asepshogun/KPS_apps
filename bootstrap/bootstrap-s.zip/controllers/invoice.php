<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Invoice extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_invoice');
		$this->load->model('m_customer_information');
		$this->load->model('m_outgoing_finished');
		$this->load->model('m_deliver_order');
		$this->load->model('m_invoice_induk');
		$this->load->model('m_employee');
		$this->load->model('m_pesanan');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function monitoringDeleteInvoice(){
		$data['data'] = $this->m_invoice->getaLLHistoryDeleteInvoice();
		$data['content'] = 'sales_data/v_invoice_historyDeleteInvoice';
		$this->load->view('template/template',$data);
	}
	public function monitoringDeleteInvoiceDetailDO(){
		$data['data'] = $this->m_invoice->getaLLHistoryDeleteInvoiceDO();
		$data['content'] = 'sales_data/v_invoice_historyDeleteInvoiceDo';
		$this->load->view('template/template',$data);
	}
	public function confirm_view($id){
		$data['KPS_INVOICE_STATUS_APP_DELETE_DIREKTUR']=1;
		$table="kps_invoice_";
		$tableId="KPS_INVOICE_ID_";
		$this->m_invoice->updateDetail($table,$tableId,$data,$id);
		redirect('invoice/monitoringDeleteInvoice');
	}
	public function confirm_view_Do($id){
		$data['KPS_INVOICE_STATUS_APP_DELETE_DIREKTUR_DO_INVOICE']=1;
		$table="kps_invoice_detail_";
		$tableId="ID";
		$this->m_invoice->updateDetail($table,$tableId,$data,$id);
		redirect('invoice/monitoringDeleteInvoiceDetailDO');
	}
	public function unlockDelChangeNumberInvoice(){
		$data=$this->input->post();
		$id=$data['KPS_INVOICE_ID'];
		$idInduk=$data['INVOICE_INDUK_ID_inv'];
		unset($data['KPS_INVOICE_ID']);
		unset($data['INVOICE_INDUK_ID_inv']);
		$this->m_invoice->update($data,$id);
		redirect('invoice/index_detail_do/'.$idInduk);
	}
	//revisi delete nomor faktur start
		public function deleteNomorFaktur($id,$role){
			$getInvoiceNo=$this->m_invoice->getInvoiceFordeleteFaktur($id);
			$data['data']=$getInvoiceNo;
			$data['dataEmployee'] = $this->m_employee->getAll();
			
				if($role=="Administrator" && empty($getInvoiceNo->KPS_INVOICE_APP_DELETE_CHANGE_NUMBER)){
					$this->load->view('sales_data/detail/pre_del_faktur_invoice_no_unlock_del',$data);
				}else if($role=="Administrator" && $getInvoiceNo->KPS_INVOICE_APP_DELETE_CHANGE_NUMBER){
					$this->load->view('sales_data/detail/pre_del_faktur_invoice_no_unlock_del_warning',$data);
				}else{
					if($getInvoiceNo->KPS_INVOICE_STATUS_PRINT && empty($getInvoiceNo->KPS_INVOICE_APP_DELETE_CHANGE_NUMBER)){
						$this->load->view('sales_data/detail/pre_del_faktur_invoice_no_warning',$data);
					}else{
						$this->load->view('sales_data/detail/pre_del_faktur_invoice_no',$data);
					}
				}
		}	
		public function deleteInvoice($id){
			$getInvoiceNo=$this->m_invoice->getInvoiceFordeleteFaktur($id);
				if($getInvoiceNo->KPS_INVOICE_STATUS_PRINT){
				$data['data']=$getInvoiceNo;
				$this->load->view('sales_data/detail/pre_del_faktur_invoice_no_warning',$data);
				}else{
				
				}
		}
	//revisi delte nomro faktur end
	// revisi Invoice TX non TX Start
	public function indexNT()
	{
		$data['data'] = $this->m_invoice_induk->getAllNT();
		$data['dataType'] = $this->m_invoice->getType();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCom'] = $this->m_customer_information->getAllNT();
		$data['statusTx']="NT";
		$data['content'] = 'sales_data/v_invoice_induk';
		$this->load->view('template/template',$data);
	}
	public function index()
	{
		$data['data'] = $this->m_invoice_induk->getAllTX();
		$data['dataType'] = $this->m_invoice->getType();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCom'] = $this->m_customer_information->getAllTX();
		$data['statusTx']="TX";
		$data['content'] = 'sales_data/v_invoice_induk';
		$this->load->view('template/template',$data);
	}
	public function loadBuktiPesanan(){
		$id = $this->input->get('id');
		$datas = $this->m_pesanan->getAllByCustForInv($id);
	 	?>	
	 		<option>-- Select Product --</option>
	 	<?php
	 	foreach ($datas as $value) { ?>
			<option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>"><?php echo "Nomor  Bukti Pesanan : &nbsp;&nbsp;" . $value->REV_NO_BP . " &nbsp;&nbsp; - Nomor PO : &nbsp;&nbsp;" . $value->PO_OS_NO_FROM_CUSTOMER . " &nbsp;&nbsp;- Date PO : &nbsp;&nbsp;" . $value->PO_OS_DATE_FROM_CUSTOMER;?></option>
			<?php
		}
	}
	public function add_invoice_induk($status){
		if($status=="TX"){
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_invoice_induk->getLastId();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->KPS_INVOICE_INDUK_NO_URUT_TX+1;

			}
			$no = $year."/INV-INDK-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data['INVOICE_INDUK_NO'] = $no;
			$data['KPS_INVOICE_INDUK_NO_URUT_TX'] = $revNoNew;

			$this->m_invoice_induk->insert($data);
			redirect('invoice');
		}else{
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_invoice_induk->getLastIdNT();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->KPS_INVOICE_INDUK_NO_URUT_NT+1;

			}
			$no = $year."/INV-INDK-SLSR/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data['INVOICE_INDUK_NO'] = $no;
			$data['KPS_INVOICE_INDUK_NO_URUT_NT'] = $revNoNew;

			$this->m_invoice_induk->insert($data);
			redirect('invoice/indexNT');
		}
	}
	public function add(){
		$data=$this->input->post();
		$cekNoFaktur=$this->m_invoice->getTNoFaktur($data['KPS_NO_INVOICE_FAKTUR_PAJAK']);
		$idcek=$this->input->post('INVOICE_INDUK_ID_inv');
		$StatusTX=$this->m_invoice_induk->getTXFromIND($idcek);
		if($cekNoFaktur){
				$this->session->set_flashdata('errorNOFAktur', 'Terdapat duplikasi NO Invoice Faktur');
				redirect('invoice/index_detail_do/'.$idcek);
		}else{
			if($StatusTX=="Tax"){
				$year = date('y');
				$month = date('m');
				$lastNo = $this->m_invoice->getLastId();
				if(empty($lastNo)){
					$revNoNew = 1;
				}else{
					$revNoNew = $lastNo->REV_NO_INVO+1;

				}
				$no = $year."/INV-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
				
				$data['NO_INVO'] = $no;
				$data['REV_NO_INVO'] = $revNoNew;
				$data['total_qty'] = 0;
				$data['total_amount'] = 0;
				$data['total_dp_or_vat'] = 0;
				$data['total_ppn_or_tax'] = 0;
				$data['total_all'] = 0;
				$datax = $this->m_invoice->get_induks($idcek);
				$tot = 0;
				foreach ($datax as $value) {
					$tot += $value->KPS_INVOICE_DP;
				}
				$hasil = $tot + $data['KPS_INVOICE_DP'];
				if($hasil > 100){
					$this->session->set_flashdata('errorDP', 'Down Payment tidak boleh lebih dari 100%');
					redirect('invoice/index_detail_do/'.$idcek);
				}else{
					$this->m_invoice->insert($data);
					redirect('invoice/index_detail_do/'.$idcek);
				}
			}else{
				$year = date('y');
				$month = date('m');
				$lastNo = $this->m_invoice->getLastIdNT();
				if(empty($lastNo)){
					$revNoNew = 1;
				}else{
					$revNoNew = $lastNo->KPS_INV_NOMOR_URUT_NT_TX+1;

				}
				$no = $year."/INV-SLSR/".$this->KonDecRomawi($month)."/".$revNoNew; 
				
				$data['NO_INVO'] = $no;
				$data['KPS_INV_NOMOR_URUT_NT_TX'] = $revNoNew;
				$data['total_qty'] = 0;
				$data['total_amount'] = 0;
				$data['total_dp_or_vat'] = 0;
				$data['total_ppn_or_tax'] = 0;
				$data['total_all'] = 0;
				$datax = $this->m_invoice->get_induks($idcek);
				$tot = 0;
				foreach ($datax as $value) {
					//revisi nomor faktur pajak start
					if(empty($value->KPS_INVOICE_NOMOR_PENGGANTI)){
						$tot += $value->KPS_INVOICE_DP;
						}
					//revisi nomor faktur pajak end
				}
				$hasil = $tot + $data['KPS_INVOICE_DP'];
				if($hasil > 100){
					$this->session->set_flashdata('errorDP', 'Down Payment tidak boleh lebih dari 100%');
					redirect('invoice/index_detail_do/'.$idcek);
				}else{
					$this->m_invoice->insert($data);
					redirect('invoice/index_detail_do/'.$idcek);
				}
			}
		
		}
	}public function addFromDelete(){
		$data=$this->input->post();
		$cekNoFaktur=$this->m_invoice->getTNoFaktur($data['KPS_NO_INVOICE_FAKTUR_PAJAK']);
		$idcek=$this->input->post('INVOICE_INDUK_ID_inv');
		$StatusTX=$this->m_invoice_induk->getTXFromIND($idcek);
		if($cekNoFaktur){
				$this->session->set_flashdata('errorNOFAktur', 'Terdapat duplikasi NO Invoice Faktur');
				redirect('invoice/index_detail_do/'.$idcek);
		}else{
			$datasUpdate['KPS_INVOICE_NOMOR_PENGGANTI']=$data['KPS_NO_INVOICE_FAKTUR_PAJAK'];
			$datasUpdate['PREPARED_INVO']=$data['PREPARED_INVO'];
			$data['KPS_NO_INVOICE_FAKTUR_PAJAK']=$data['KPS_NO_INVOICE_FAKTUR_PAJAK'];
			$idInvoiceForUpdate=$data['KPS_INVOICE_ID'];
			unset($data['KPS_INVOICE_ID']);
			$datax = $this->m_invoice->get_induks($idcek);
			$tot="";
			foreach ($datax as $value) {
					//revisi nomor faktur pajak start
					if(empty($value->KPS_INVOICE_NOMOR_PENGGANTI)){
							if($value->KPS_INVOICE_ID!=$idInvoiceForUpdate){
								$tot += $value->KPS_INVOICE_DP;
							}
						}
					//revisi nomor faktur pajak end
				}
			$hasil = $tot + $data['KPS_INVOICE_DP'];
			if($hasil > 100){
					$this->session->set_flashdata('errorDP', 'Down Payment tidak boleh lebih dari 100%');
					redirect('invoice/index_detail_do/'.$idcek);
			}else{
				$this->m_invoice->update($datasUpdate,$idInvoiceForUpdate);
				if($StatusTX=="Tax"){
					$year = date('y');
					$month = date('m');
					$lastNo = $this->m_invoice->getLastId();
					if(empty($lastNo)){
						$revNoNew = 1;
					}else{
						$revNoNew = $lastNo->REV_NO_INVO+1;

					}
					$no = $year."/INV-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
					
					$data['NO_INVO'] = $no;
					$data['REV_NO_INVO'] = $revNoNew;
					$data['total_qty'] = 0;
					$data['total_amount'] = 0;
					$data['total_dp_or_vat'] = 0;
					$data['total_ppn_or_tax'] = 0;
					$data['total_all'] = 0;
					$tot = 0;
						$this->m_invoice->insert($data);
						redirect('invoice/index_detail_do/'.$idcek);
				}else{
					$year = date('y');
					$month = date('m');
					$lastNo = $this->m_invoice->getLastIdNT();
					if(empty($lastNo)){
						$revNoNew = 1;
					}else{
						$revNoNew = $lastNo->KPS_INV_NOMOR_URUT_NT_TX+1;

					}
					$no = $year."/INV-SLSR/".$this->KonDecRomawi($month)."/".$revNoNew; 
					
					$data['NO_INVO'] = $no;
					$data['KPS_INV_NOMOR_URUT_NT_TX'] = $revNoNew;
					$data['total_qty'] = 0;
					$data['total_amount'] = 0;
					$data['total_dp_or_vat'] = 0;
					$data['total_ppn_or_tax'] = 0;
					$data['total_all'] = 0;
					$tot = 0;
				
					$this->m_invoice->insert($data);
					redirect('invoice/index_detail_do/'.$idcek);
				}
			}
		}
	}
	public function preDelete_detail_DO($id, $idcus, $role){
		$dataInvoice= $this->m_invoice->getInvoiceDetailByIdForDelete($id);
		if($dataInvoice){
			if($role=="Administrator" && empty($dataInvoice->KPS_INVOICE_DETAIL_STATUS_APP_DELETE)){
				$data['data'] = $this->m_invoice->getSelfDataInvoiceDO($id);
				$data['idCus'] = $idcus;
				$this->load->view('sales_data/v_delete_invoiceDo_detail_app',$data);
			}else if($role=="Administrator" && $dataInvoice->KPS_INVOICE_DETAIL_STATUS_APP_DELETE){
				$this->load->view('sales_data/v_delete_invoiceDo_detail_done_app',$dataInvoice);
			}else{
				if($dataInvoice->KPS_INVOICE_DETAIL_STATUS_APP_DELETE){
					$data['data'] = $this->m_invoice->getSelfDataInvoiceDO($id);
					$data['idCus'] = $idcus;
					$this->load->view('sales_data/v_delete_invoiceDo_detail',$data);
				}else{
					$data['dataInvoice']=$dataInvoice;
					$this->load->view('sales_data/v_delete_invoiceDo_detail_warning',$data);
				}
			}
		}else{
			$data['data'] = $this->m_invoice->getSelfDataInvoiceDO($id);
			$data['idCus'] = $idcus;
			$this->load->view('sales_data/v_delete_invoiceDo_detail',$data);
		}
	}
	public function unlockDelete(){
		$data=$this->input->post();
		$id=$data['INVOICE_INDUK_ID_DET'];
		$idCus=$data['idCus'];
		$KPS_INVOICE_DETAIL_ID=$data['KPS_INVOICE_DETAIL_ID'];
		$datas['KPS_INVOICE_DETAIL_STATUS_APP_DELETE']=$data['KPS_INVOICE_DETAIL_DELETE'];
		$this->m_invoice_induk->updateInvoiceDetailDo($datas,$KPS_INVOICE_DETAIL_ID);
		redirect('invoice/detail/'.$id."/".$idCus);
	}
	// revisi Invoice TX non TX END
	
	//back up revisi tx non tx start
		// public function index()
		// {
			// $data['data'] = $this->m_invoice_induk->getAll();
			// $data['dataType'] = $this->m_invoice->getType();
			// $data['dataEmployee'] = $this->m_employee->getAll();
			// $data['dataCom'] = $this->m_customer_information->getAll();
			// $data['content'] = 'sales_data/v_invoice_induk';
			// $this->load->view('template/template',$data);
		// }
		// public function add_invoice_induk(){
			// $data=$this->input->post();
			// $year = date('y');
			// $month = date('m');
			// $lastNo = $this->m_invoice_induk->getLastId();
			// if(empty($lastNo)){
				// $revNoNew = 1;
			// }else{
				// $revNoNew = $lastNo->REV_NO_INVO+1;

			// }
			// $no = $year."/INV-INDK-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			// $data['INVOICE_INDUK_NO'] = $no;
			// $data['KPS_INVOICE_INDUK_REV_NO'] = $revNoNew;

			// $this->m_invoice_induk->insert($data);
			// redirect('invoice');
		// }
		
		// public function add(){
			// $data=$this->input->post();
			// $idcek=$this->input->post('INVOICE_INDUK_ID_inv');
			// $year = date('y');
			// $month = date('m');
			// $lastNo = $this->m_invoice->getLastId();
			// if(empty($lastNo)){
				// $revNoNew = 1;
			// }else{
				// $revNoNew = $lastNo->REV_NO_INVO+1;

			// }
			// $no = $year."/INV-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			// $data['NO_INVO'] = $no;
			// $data['REV_NO_INVO'] = $revNoNew;
			// $data['total_qty'] = 0;
			// $data['total_amount'] = 0;
			// $data['total_dp_or_vat'] = 0;
			// $data['total_ppn_or_tax'] = 0;
			// $data['total_all'] = 0;
			// $datax = $this->m_invoice->get_induks($idcek);
			// $tot = 0;
			// foreach ($datax as $value) {
				// $tot += $value->KPS_INVOICE_DP;
			// }
			// $hasil = $tot + $data['KPS_INVOICE_DP'];
			// if($hasil > 100){
				// $this->session->set_flashdata('errorDP', 'Down Payment tidak boleh lebih dari 100%');
				// redirect('invoice/index_detail_do/'.$idcek);
			// }else{
				// $this->m_invoice->insert($data);
				// redirect('invoice/index_detail_do/'.$idcek);
			// }
		// }
	//back up revisi tx non tx end
	public function pre_print($id){
		$this->m_invoice->updateStatusPrint($id);
		$data['detail'] = $this->m_invoice->get_invoice_det($id);
		$datas = $this->m_invoice->get_invoice_dets($id);
		$data['datas']=$datas;
		$data['data'] = $this->m_invoice_induk->get($datas->INVOICE_INDUK_ID_inv);
		//Perubahan Untuk revisi invoice Start
		$data['do'] = $this->m_invoice_induk->get_do($datas->INVOICE_INDUK_ID_inv);
		$data['do_detail'] = $this->m_invoice_induk->get_do_detail($datas->INVOICE_INDUK_ID_inv);
		$data['invoice'] = $this->m_invoice->get($id);
		//Perubahan Untuk revisi invoice end
		
		//$detail = $this->m_invoice->get_induk($id);
		//$data['data'] = $this->m_invoice_induk->get($detail->INVOICE_INDUK_ID_inv);
		$this->load->view('sales_data/print/v_pre_print_invoice',$data);
	}
	public function pre_print_rekap($id){
		$data['detail'] = $this->m_invoice->get_invoice_det($id);
		$datas = $this->m_invoice->get_invoice_dets($id);
		$data['datas']=$datas;
		$data['data'] = $this->m_invoice_induk->get($datas->INVOICE_INDUK_ID_inv);
		//Perubahan Untuk revisi invoice Start
		$data['do'] = $this->m_invoice_induk->get_do($datas->INVOICE_INDUK_ID_inv);
		$data['do_detail'] = $this->m_invoice_induk->get_do_detailForRekap($datas->INVOICE_INDUK_ID_inv);
		$data['invoice'] = $this->m_invoice->get($id);
		//Perubahan Untuk revisi invoice end
		
		//$detail = $this->m_invoice->get_induk($id);
		//$data['data'] = $this->m_invoice_induk->get($detail->INVOICE_INDUK_ID_inv);
		$this->load->view('sales_data/print/v_pre_print_invoice_rekap',$data);
	}
	public function index_detail_do($id)
	{
		$data['detail'] = $this->m_invoice->get_induk($id);
		$data['data'] = $this->m_invoice_induk->get($id);
		$data['dataType'] = $this->m_invoice->getType();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCom'] = $this->m_customer_information->getAll();
		//$get_Tot = $this->m_invoice->getTotal($id);
		//$this->m_invoice_induk->updateTotPem($get_Tot->total,$id);
		$datax = $this->m_invoice->get_induks($id);
		$dataTerm = $this->m_invoice->get_induks_terms($id);
		$get_Tot = $this->m_invoice->getTotal($id);
		if($dataTerm){
			$tot_term = $dataTerm->term;
		}else{
		$tot_term = 0;
		}
		$data['tot_term'] = $tot_term;
		$tot_terbayar = 0;
		$tot = 0;
		foreach ($datax as $value) {
			$tot += $value->KPS_INVOICE_DP;
		}
		$tot_terbayar = ($tot/100)*$get_Tot->total;
		$get_Tot = $this->m_invoice->getTotal($id);
		$this->m_invoice_induk->updateInvDet($get_Tot->total,$get_Tot->TotQTY,$id);
		$this->m_invoice_induk->updateTerTerm($tot_terbayar,$tot,$id);
		//$status = $data['revisi_no_inv']+1;
		//$this->m_invoice_induk->updaterevno($status,$id);
		$data['content'] = 'sales_data/detail/invoice_get_no';
		$this->load->view('template/template',$data);
	}
	public function index_detail_get_number()
	{
		$data['data'] = $this->m_invoice->getAll();
		$data['dataType'] = $this->m_invoice->getType();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCom'] = $this->m_customer_information->getAll();
		$data['content'] = 'sales_data/v_invoice';
		$this->load->view('template/template',$data);
	}

	public function deleteDetailSub($table){
		$data=$this->input->post();
		$id=$data['INVOICE_INDUK_ID_DET'];
		$idTable=$data['KPS_INVOICE_DETAIL_ID'];
		$idColom="KPS_INVOICE_DETAIL_ID";
		$idCus = $data['idCus'];
		$INVOICE_INDUK_ID = $data['INVOICE_INDUK_ID'];
		// $KPS_INVOICE_ID = $data['KPS_INVOICE_ID'];
		$datas['revisi_no_inv']=$data['revisi_no_inv'];
		$dataInvo['MADE_BY']=$data['KPS_INVOICE_DETAIL_DELETE'];
		$datadetail['KPS_INVOICE_DETAIL_DELETE']=$data['KPS_INVOICE_DETAIL_DELETE'];
		$this->m_invoice_induk->updateInvoiceInduk($datas,$INVOICE_INDUK_ID);
		$this->m_invoice_induk->updateInvoiceDetailDo($datadetail,$idTable);
		// $this->m_invoice->update($dataInvo,$KPS_INVOICE_ID);
		$this->m_invoice->deleteSubDetail($idTable,$table,$idColom);
		redirect('invoice/detail/'.$id."/".$idCus);
	}
	
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_invoice_detail"){
			$idCus=$data['idCus'];
			unset($data['idCus']);
			foreach ($data['delivery_order_id'] as $datax) {
			$data['delivery_order_id'] = $datax;
			$this->m_invoice_induk->insertData($table,$data);
			}
		}else{
			$idCus=$data['idCus'];
			unset($data['idCus']);
			$this->m_invoice_induk->insertData($table,$data);
		}
		redirect('invoice/detail/'.$data['INVOICE_INDUK_ID_DET'] ."/". $idCus);
	}
	public function detail($id,$idCus)
	{
		$data['delivery'] = $this->m_invoice_induk->getAllsForInvoice($idCus);
		$get_Tot = $this->m_invoice->getTotal($id);
		$this->m_invoice_induk->updateTotPem($get_Tot->total,$id);
		$this->m_invoice_induk->updateInvDet($get_Tot->total,$get_Tot->TotQTY,$id);
		$data['data'] = $this->m_invoice_induk->get($id);
		$data['detail'] = $this->m_invoice_induk->getDetail($id);
		$data['idCus'] = $idCus;
		$data['content'] = 'sales_data/detail/invoice';
		$this->load->view('template/template',$data);
	}
	public function edit($id){
		$data['dataType'] = $this->m_invoice->getType();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCom'] = $this->m_customer_information->getAll();
		
		$data['data'] = $this->m_invoice->get($id);
		$this->load->view('sales_data/v_edit_invoice',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		
		unset($data['id']);
		 $this->m_invoice->update($data,$id);
		redirect('invoice');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		
		$data['data'] = $this->m_invoice->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_RFQ_ID'];
		unset($data['id']);
		unset($data['KPS_RFQ_ID']);
		 $this->m_invoice->updateDetail($table,$tableId,$data,$id);
		redirect('outgoing_finished/detail/'.$idRef);
	}
	public function term(){
		$data = $this->input->post();
		// print_r($data);
		unset($data['termtotal']);
		$this->m_invoice->insertData("kps_invoice_term",$data);
		redirect('invoice');
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_invoice->getDivisi($id);
		?>
		<option selected="">-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadterm($id,$count,$term){
		$data['data'] = $this->m_invoice->getTerm($id);
		$data['invoiceId'] = $id;
		$data['count'] = $count;
		$data['termtotal'] = $term;
		$this->load->view('sales_data/detail/v_term',$data);
	}
	public function lockdo($id,$idCus){
		$status = "1";
		$this->m_invoice_induk->lockdo($status,$id);
		redirect('invoice/detail/'.$id ."/". $idCus);
	}
	public function unlockdo($id,$idCus){
		$status = "0";
		$this->m_invoice_induk->unlockdo($status,$id);
		redirect('invoice/detail/'.$id ."/". $idCus);
	}

}