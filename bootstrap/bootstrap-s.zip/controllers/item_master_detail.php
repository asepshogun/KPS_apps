<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Item_Master_Detail extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/detail/item_master';
		$this->load->view('template/template',$data);
		
	}

	public function detail()
	{
		$data['content'] = 'production/detail/item_master2';
		$this->load->view('template/template',$data);
	}

}
