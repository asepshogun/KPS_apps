<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_Information extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_customer_information');
		$this->load->model('m_marketing');
		$this->load->model('m_employee');
		$this->load->model('m_bank_reference');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	//revisi sales 24-5-2016 start
		public function prePrintAll(){
			$data['data'] = $this->m_customer_information->getAll();
			$this->load->view('sales_data/print/v_pre_print_all_customer',$data);
		}
		public function pre_print_Single($id){
				$data['datas'] = $this->m_customer_information->get($id);
				$data['cp'] = $this->m_customer_information->getCustomerCp($id);
				$data['plant'] = $this->m_customer_information->getPlant($id);
				$data['divisi'] = $this->m_customer_information->getDivisi($id);
				$data['pic'] = $this->m_customer_information->getPic($id);
				$data['main'] = $this->m_customer_information->getMain($id);
				$data['sup'] = $this->m_customer_information->getSupplier($id);
				$data['finance'] = $this->m_customer_information->getFinance($id);
				$data['account'] = $this->m_customer_information->getAcc($id);
				$data['deliv'] = $this->m_customer_information->getDeliv($id);
				$data['iso'] = $this->m_customer_information->getIso($id);
				//perubahan untuk revisi pap start
				$data['pap'] = $this->m_customer_information->getPap($id);
				//perubahan untuk revisi PAP end
				$data['databank'] = $this->m_bank_reference->getAll();
			$this->load->view('sales_data/print/v_pre_print_customer_single',$data);
		}
	//revisi sales 24-5-2016 end
	
	public function index()
	{
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['data'] = $this->m_customer_information->getAll();
		$data['content'] = 'sales_data/v_customer';
		$this->load->view('template/template',$data);
	}
	//perubahan untuk revisi PAP start
	public function preAdd(){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$this->load->view('sales_data/add/pop_up_add_cis',$data);
	}
	//perubahan untuk revisi PAP end
	public function detail($id)
	{
		$data['datas'] = $this->m_customer_information->get($id);
		$data['cp'] = $this->m_customer_information->getCustomerCp($id);
		$data['plant'] = $this->m_customer_information->getPlant($id);
		$data['divisi'] = $this->m_customer_information->getDivisi($id);
		$data['pic'] = $this->m_customer_information->getPic($id);
		$data['main'] = $this->m_customer_information->getMain($id);
		$data['sup'] = $this->m_customer_information->getSupplier($id);
		$data['finance'] = $this->m_customer_information->getFinance($id);
		$data['account'] = $this->m_customer_information->getAcc($id);
		$data['deliv'] = $this->m_customer_information->getDeliv($id);
		$data['iso'] = $this->m_customer_information->getIso($id);
		//perubahan untuk revisi pap start
		$data['pap'] = $this->m_customer_information->getPap($id);
		//perubahan untuk revisi PAP end
		$data['databank'] = $this->m_bank_reference->getAll();
		$data['content'] = 'sales_data/detail/customer_information';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_customer_information->getLastId();
		$revNoNew = $lastNo->REV_NO+1;
		$no = $year."/CIS-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO'] = $no;
		$data['REV_NO'] = $revNoNew;
		// $revNo = 
		$this->m_customer_information->insert($data);
		redirect('customer_information');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_customer_company"){
			$typeOfCompany = "";
			for($i=0;$i<count($data['TYPE_OF_COMPANY']);$i++){
				$typeOfCompany .= $data['TYPE_OF_COMPANY'][$i].",";
			}
			$typeOfCompany = substr($typeOfCompany, 0, -1);
			$data['TYPE_OF_COMPANY'] = $typeOfCompany;
		}
		$this->m_customer_information->insertData($table,$data);
		//perubahan untuk revisi pap start
		if($table == "kps_customer_personal_payment"){
			$data['KPS_CUSTOMER_ID']= $data['KPS_CUSTOMER_ID'];
		}else if($data['KPS_CUSTOMER_ID']==""){
			$data['KPS_CUSTOMER_ID'] = $data['KPS_CUSTOMER_ID_PIC'];
		}
		//perubahan untuk revisi pap end
		redirect('customer_information/detail/'.$data['KPS_CUSTOMER_ID']);
	}

	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['data'] = $this->m_customer_information->get($id);
		$this->load->view('sales_data/v_edit_customer',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_customer_information->update($data,$id);
		$status = $data['revisi_no']+1;
		$this->m_customer_information->updaterevno($status,$id);
		redirect('customer_information');
	}
	public function lock($id){
		$status = "1";
		$this->m_customer_information->lock($status,$id);
		redirect('customer_information');
	}
	public function unlock($id){
		$status = "0";
		$this->m_customer_information->unlock($status,$id);
		redirect('customer_information');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}

	public function editDetail($id,$view,$table,$tableId){
		$data['databank'] = $this->m_bank_reference->getAll();
		$data['data'] = $this->m_customer_information->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		if($table=="kps_customer_company"){
			$typeOfCompany = "";
			for($i=0;$i<count($data['TYPE_OF_COMPANY']);$i++){
				$typeOfCompany .= $data['TYPE_OF_COMPANY'][$i].",";
			}
			$typeOfCompany = substr($typeOfCompany, 0, -1);
			$data['TYPE_OF_COMPANY'] = $typeOfCompany;
		}
		$idRef = $data['KPS_CUSTOMER_ID'];
		unset($data['id']);
		unset($data['KPS_CUSTOMER_ID']);
		
		$this->m_customer_information->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_customer_information->get($idRef);
		$status = $data->revisi_no+1;
		$this->m_customer_information->updaterevno($status,$idRef);
		redirect('customer_information/detail/'.$idRef);
	}

}
