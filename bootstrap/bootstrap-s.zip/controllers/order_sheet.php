<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Order_Sheet extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_order_sheet');
		$this->load->model('m_employee');
		$this->load->model('m_pesanan');
		$this->load->model('m_quotation');
		$this->load->model('m_pesanan');
		$this->load->model('m_loi');
		$this->load->model('m_deliver_order');
		$this->load->model('m_schedule');
		$this->load->model('m_customer_information');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function preDelDetailPo($id){
		$getIdDs=$this->m_order_sheet->getDsByOs($id);
		$cekPoOs=$this->m_order_sheet->cekPoOs($getIdDs->KPS_DELIVERY_SCHEDULE_ID);
		if($cekPoOs){
		// print_r($cekPoOs);
		$data['data']=$cekPoOs;
		$this->load->view('sales_data/detail/pre_del_os_po_warning',$data);
		}else{
		$data['detail'] = $this->m_order_sheet->getDetForDelete($id);
		$this->load->view('sales_data/detail/pre_del_os_po',$data);
		
		}
	}
	public function deletePoOs(){
		$data=$this->input->post();
		$idOs=$data['KPS_OS_ID']; 
		$idOsDet=$data['KPS_ORDER_SHEET_DETAIL_ID']; 
		$this->m_order_sheet->deleteDs($idOsDet);
		$this->m_order_sheet->deleteOsDet($idOsDet);
		redirect('order_sheet/detail/'. $idOs);
	}
	public function index()
	{
		$data['data'] = $this->m_order_sheet->getAll();
		$data['dataPending'] = $this->m_order_sheet->getAllPending();
		$data['dataRtnPending'] = $this->m_order_sheet->getAllRtnPending();
		$data['dataEmployee'] = $this->m_employee->getAll();
		// $data['deliv'] = $this->m_schedule->getDelivSetupForOs($id);
		$data['dataCust'] = $this->m_customer_information->getAll();

		$data['content'] = 'sales_data/v_order_sheet';
		$this->load->view('template/template',$data);
	}
	public function monitoringSales()
	{
		$data['data'] = $this->m_order_sheet->getAll();
		$data['dataPending'] = $this->m_order_sheet->getAllPending();
		$data['dataRtnPending'] = $this->m_order_sheet->getAllRtnPending();
		$data['dataEmployee'] = $this->m_employee->getAll();
		// $data['deliv'] = $this->m_schedule->getDelivSetupForOs($id);
		$data['dataCust'] = $this->m_customer_information->getAll();

		$data['content'] = 'sales_data/v_order_sheet_monitoring';
		$this->load->view('template/template',$data);
	}
	public function monitoringSalesPerItem()
	{
		$data['data'] = $this->m_order_sheet->getAll();
		$data['dataPending'] = $this->m_order_sheet->getAllPendingPerItem();
		$data['dataRtnPending'] = $this->m_order_sheet->getAllRtnPending();
		$data['dataEmployee'] = $this->m_employee->getAll();
		// $data['deliv'] = $this->m_schedule->getDelivSetupForOs($id);
		$data['dataCust'] = $this->m_customer_information->getAll();

		$data['content'] = 'sales_data/v_order_sheet_monitoring_perItem';
		$this->load->view('template/template',$data);
	}
	public function detailMonitoring($id)
	{
		$datas = $this->m_order_sheet->get($id);
		$data['data'] = $this->m_order_sheet->get($id);

		$data['detail'] = $this->m_order_sheet->getDetail($id);
		// $data['detailPesanan'] = $this->m_order_sheet->getDetail($id);
		$id_cus=$data['data']->KPS_OS_CUSTOMER_ID;
		$data['bukti'] = $this->m_pesanan->getByCusForOs($id_cus,$id);
		$data['attach'] = $this->m_order_sheet->getDetailAttach($id);
		$data['code'] = $this->m_order_sheet->getCode();
		// $data['deliv'] = $this->m_order_sheet->getDelivSetup();
		$data['content'] = 'sales_data/detail/order_sheet_monitoring';
		$this->load->view('template/template',$data);
	}
	public function detailPoMonitoring($idOsDet)
	{
		$dataOsDet=$this->m_order_sheet->getDet($idOsDet);
		$data['data']=$dataOsDet;
		$idBp=$dataOsDet[0]->KPS_BUKTI_PESANAN_ID;
		$idOs=$dataOsDet[0]->KPS_OS_ID;
		$idDs=$dataOsDet[0]->KPS_DELIVERY_SCHEDULE_ID;
		$data['Bpdet']=$this->m_loi->getAllByBuktiForOs($idBp,$idDs);
		$data['detail'] = $this->m_schedule->getDetail($idDs);
		// $datas = $this->m_order_sheet->get($idorder);
		// $bukti = $this->m_pesanan->get($id);
		// $data['bukti'] = $this->m_pesanan->get($id);
		// $data['data'] = $this->m_order_sheet->get($idorder);

		// $data['code'] = $this->m_loi->getAllByBukti($bukti->KPS_BUKTI_PESANAN_ID);

		$data['content'] = 'sales_data/detail/order_sheet_po_monitoring';
		$this->load->view('template/template',$data);
	}
	public function history($id){
		$data['data'] = $this->m_order_sheet->getAllHistory($id);
		$data['content'] = 'sales_data/v_order_sheet_history';
		$this->load->view('template/template',$data);
	}
	public function add(){
		if($data=$this->input->post()){
			$data=$this->input->post();
			$cekOSFromCustomer=$this->m_order_sheet->cekOsFromCus($data['KPS_OS_DN_NO']);
			if($cekOSFromCustomer){
				$this->session->set_flashdata('errorNoOs', 'Terdapat duplikasi NO OS From Customer');
				redirect('order_sheet');
			}else{
				$year = date('y');
				$month = date('m');
				$lastNo = $this->m_order_sheet->getLastId();
				if(empty($lastNo)){
					$revNoNew = 1;
				}else{
					$revNoNew = $lastNo->KPS_OS_NO_URUT+1;

				}
				$no = $year."/OSR-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
				
				$data['KPS_OS_NO'] = $no;
				$data['KPS_OS_NO_URUT'] = $revNoNew;

				$this->m_order_sheet->insert($data);
				redirect('order_sheet');
			}
		}else{
			$data['dataCust'] = $this->m_customer_information->getAll();
			$data['dataEmployee'] = $this->m_employee->getAll();
			// $data['deliv'] = $this->m_schedule->getDelivSetupForOs();
			$this->load->view('sales_data/add/pop_up_add_os',$data);
		}
	}
	public function addSub($table, $id="0", $idOsL="0", $idROs="0"){
		$data=$this->input->post();
		if($table=="kps_order_sheet_attachment"){
			$data['KPS_OS_ATTACHMENT_FILE'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['upload_path'] = './uploads/os/';
			$config['allowed_types'] = $ext.'|'.$fileType;

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
		}
		$data['KPS_OS_ID_DETAIL'] = $data['KPS_OS_ID'];
		unset($data['KPS_OS_ID']);
		$idOs = $this->m_order_sheet->insertData($table,$data);
		if($table!="kps_order_sheet_attachment"){

			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_schedule->getLastId();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->REV_NO+1;

			}
			$no = $year."/DS-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$dataSchedule['NO_REV_NO'] = $no;
			$dataSchedule['REV_NO'] = $revNoNew;
			$dataSchedule['TOTAL'] = 0;
			unset ($data['KPS_BUKTI_PESANAN_ID_OS']);
			$dataSchedule['KPS_OS_ID_DS'] = $idOs;

			$this->m_schedule->insert($dataSchedule);
		}
		if($id){
		print_r($id);
		redirect('order_sheet/'.$id.'/'.$idOsL.'/'.$idROs);
		}else{
		redirect('order_sheet/detail/'.$data['KPS_OS_ID_DETAIL']);
		}
	}
	public function detail($id)
	{
		$datas = $this->m_order_sheet->get($id);
		$data['data'] = $this->m_order_sheet->get($id);

		$data['detail'] = $this->m_order_sheet->getDetail($id);
		// $data['detailPesanan'] = $this->m_order_sheet->getDetail($id);
		$id_cus=$data['data']->KPS_OS_CUSTOMER_ID;
		$data['bukti'] = $this->m_pesanan->getByCusForOs($id_cus,$id);
		$data['attach'] = $this->m_order_sheet->getDetailAttach($id);
		$data['code'] = $this->m_order_sheet->getCode();
		// $data['deliv'] = $this->m_order_sheet->getDelivSetup();
		$data['content'] = 'sales_data/detail/order_sheet';
		$this->load->view('template/template',$data);
	}
	public function detailPending($id)
	{
		// $datas = $this->m_order_sheet->get($id);
		$data['data'] = $this->m_order_sheet->detDetailPending($id);

		$data['detail'] = $this->m_order_sheet->getDetail($id);
		// $data['detailPesanan'] = $this->m_order_sheet->getDetail($id);
		$id_cus=$data['data'][0]->KPS_OS_CUSTOMER_ID;
		$data['bukti'] = $this->m_pesanan->getByCusForOs($id_cus,$id);
		$data['attach'] = $this->m_order_sheet->getDetailAttach($id);
		$data['code'] = $this->m_order_sheet->getCode();
		// $data['deliv'] = $this->m_order_sheet->getDelivSetup();
		$data['content'] = 'sales_data/detail/order_sheet_pending';
		$this->load->view('template/template',$data);
	}
	public function detailReturnPending($idOs,$idROs)
	{
		$data['data'] = $this->m_order_sheet->detDetailPending($idROs);
		$data['detail'] = $this->m_order_sheet->getDetail($idOs);
		$id_cus=$data['data'][0]->KPS_OS_CUSTOMER_ID;
		$data['bukti'] = $this->m_pesanan->getByCusForReturnOs($idOs,$idROs);
		$data['attach'] = $this->m_order_sheet->getDetailAttach($idROs);
		$data['code'] = $this->m_order_sheet->getCode();
		$data['idOs'] = $idOs;
		$data['idROs'] = $idROs;
		$data['content'] = 'sales_data/detail/order_sheet_Return_pending';
		$this->load->view('template/template',$data);
	}
	public function returnPending($id){
		
		if($data=$this->input->post()){
		$dataForInput=$this->m_order_sheet->getDataForReturnPending($id);
		print_r($dataForInput->KPS_OS_ID);
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_order_sheet->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->KPS_OS_ID+1;

		}
		$no = $year."/OSR-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['KPS_OS_NO'] = $no;
		$data['KPS_OS_PRINTED_DATE'] = $dataForInput->KPS_OS_PRINTED_DATE;
		$data['KPS_OS_TOTAL_KANBAN'] = $dataForInput->KPS_OS_TOTAL_KANBAN;
		$data['KPS_OS_PRINT_COUNT'] = $dataForInput->KPS_OS_PRINT_COUNT;
		$data['KPS_CUSTOMER_DELIVERY_SETUP_ID'] = $dataForInput->KPS_CUSTOMER_DELIVERY_SETUP_ID;
		$data['KPS_OS_CUSTOMER_ID'] = $dataForInput->KPS_OS_CUSTOMER_ID;
		$data['KPS_OS_CUSTOMER_DIVISI_ID'] = $dataForInput->KPS_OS_CUSTOMER_DIVISI_ID;
		$data['KPS_OS_DN_NO'] = $dataForInput->KPS_OS_DN_NO;
		$data['KPS_OS_DN_DATE'] = $dataForInput->KPS_OS_DN_DATE;
		$data['KPS_OS_STATUS_R_PENDING'] =  $dataForInput->KPS_OS_ID;


		$this->m_order_sheet->insert($data);
		redirect('order_sheet');
		}else{
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['idOs']=$id;
		$this->load->view('sales_data/add/pop_up_add_return_pending',$data);
		}
	}
	public function detailPo($idOsDet)
	{
		$dataOsDet=$this->m_order_sheet->getDet($idOsDet);
		$data['data']=$dataOsDet;
		$idBp=$dataOsDet[0]->KPS_BUKTI_PESANAN_ID;
		$idOs=$dataOsDet[0]->KPS_OS_ID;
		$idDs=$dataOsDet[0]->KPS_DELIVERY_SCHEDULE_ID;
		$data['Bpdet']=$this->m_loi->getAllByBuktiForOs($idBp,$idDs);
		$data['detail'] = $this->m_schedule->getDetail($idDs);
		// $datas = $this->m_order_sheet->get($idorder);
		// $bukti = $this->m_pesanan->get($id);
		// $data['bukti'] = $this->m_pesanan->get($id);
		// $data['data'] = $this->m_order_sheet->get($idorder);

		// $data['code'] = $this->m_loi->getAllByBukti($bukti->KPS_BUKTI_PESANAN_ID);

		$data['content'] = 'sales_data/detail/order_sheet_po';
		$this->load->view('template/template',$data);
	}
	public function detailPoPending($idOsDet)
	{
		$idOsDetReturn=$this->m_order_sheet->getDataOsDetailForReturn($idOsDet);
		$idScForScdPending = $this->m_order_sheet->getIdFromOsdet($idOsDet);
		$dataOsDet=$this->m_order_sheet->getDet($idOsDet);
		$data['data']=$dataOsDet;
		$idBp=$dataOsDet[0]->KPS_BUKTI_PESANAN_ID;
		$idOs=$dataOsDet[0]->KPS_OS_ID;
		$idDs=$dataOsDet[0]->KPS_DELIVERY_SCHEDULE_ID;
		$data['Bpdet']=$this->m_order_sheet->getAllForReturnPending($idOsDetReturn[0]->KPS_OSD_ID_RETURN,$idScForScdPending[0]->KPS_DELIVERY_SCHEDULE_ID);
		$data['detail'] = $this->m_schedule->getDetail($idDs);
		//--- 
		//$datas = $this->m_order_sheet->get($idorder);
		// $bukti = $this->m_pesanan->get($id);
		// $data['bukti'] = $this->m_pesanan->get($id);
		// $data['data'] = $this->m_order_sheet->get($idorder);

		// $data['code'] = $this->m_loi->getAllByBukti($bukti->KPS_BUKTI_PESANAN_ID);
		//---
		$data['content'] = 'sales_data/detail/order_sheet_po_pending';
		$this->load->view('template/template',$data);
	}
	public function addSubForReturnPending($table){
		$data=$this->input->post();
		print_r($data);
		if($data['KPS_DSD_R_PENDING_REMAINING'] >= $data['QUANTITY_DELIVERY']){
			$idForRemainingPending = $data['KPS_DSD_R_PENDING'];
			$dataDsd = $this->m_schedule->getForPending($idForRemainingPending);
			$rem = 0;
			if(count($this->m_schedule->checkBuktiDetailForRePending($dataDsd[0]->KPS_BUKTI_PESANAN_DETAIL_ID_SD,$dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID))==0){
				$dataRem = $this->m_order_sheet->getPendingFromOutForRpending($dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID);
				$rem = $dataRem->QTY_PENDING_OFGD;
			}else{
				$dataRem = $this->m_schedule->getRemainingReturnPending($dataDsd[0]->KPS_BUKTI_PESANAN_DETAIL_ID_SD,$dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID);
				$rem = $dataRem->KPS_DSD_R_PENDING_REMAINING;
			}
			$data['KPS_DSD_R_PENDING_REMAINING'] = $rem - $data['QUANTITY_DELIVERY'];
			$idUpdate = $data['KPS_DELIVERY_SCHEDULE_ID'];
			$dataSchedule = $this->m_schedule->getDetail($idUpdate);
			$total=0;
			foreach ($dataSchedule as $key => $value) {
				$total += $value->QUANTITY_DELIVERY;
			}
			$dataUpdate = array(
				'TOTAL' => $total
			);

			$bpid = $data['KPS_ORDER_SHEET_DETAIL_ID'];
			unset($data['KPS_OS_ID']);
			unset($data['KPS_BUKTI_PESANAN_ID_DS']);
			unset($data['KPS_ORDER_SHEET_DETAIL_ID']);
			$this->m_schedule->update($dataUpdate,$idUpdate);
			$this->m_schedule->insertData($table,$data);

			redirect('order_sheet/detailPo/'.$bpid);
		}else{
			$bpid = $data['KPS_ORDER_SHEET_DETAIL_ID'];
			?>
			<script type="text/javascript">
				alert('Quantity Deliery harus lebih kecil dari Remaining Quantity');
				window.location.href="<?php echo site_url(); ?>/order_sheet/detailPo/<?php echo $bpid; ?>";
			</script>
			<?php
		}
	}
	public function addSubSub($table){
		$data=$this->input->post();
		if($data['REMAINING_QUANTITY'] >= $data['QUANTITY_DELIVERY']){
			$id=$data['KPS_BUKTI_PESANAN_DETAIL_ID_SD'];
			if(count($this->m_schedule->checkBuktiDetail($id))==0){
				$dataRem = $this->m_pesanan->getDetailPesananQty($id);
				$rem = $dataRem->QUANTITY;
			}else{
				$dataRem = $this->m_schedule->getRemaining($id);
				$rem = $dataRem->REMAINING_QUANTITY;
			}
			
			unset($data['buktipesanan']);
			$data['REMAINING_QUANTITY'] = $rem - $data['QUANTITY_DELIVERY'];
			$datare = $data['REMAINING_QUANTITY'];

			$idUpdate = $data['KPS_DELIVERY_SCHEDULE_ID'];
			$dataSchedule = $this->m_schedule->getDetail($idUpdate);
			$total=0;
			foreach ($dataSchedule as $key => $value) {
				$total += $value->QUANTITY_DELIVERY;
			}
			$dataUpdate = array(
				'TOTAL' => $total
			);

			// $data['DELIVERY_PLAN'] = $data['KPS_OS_SCHEDULE_DELIVERY_DATE_TIME'];
			// $osid = $data['KPS_OS_ID'];
			$bpid = $data['KPS_ORDER_SHEET_DETAIL_ID'];
			// $bpid = $data['KPS_BUKTI_PESANAN_ID_DS'];
			unset($data['KPS_OS_ID']);
			unset($data['KPS_BUKTI_PESANAN_ID_DS']);
			unset($data['KPS_ORDER_SHEET_DETAIL_ID']);
			$this->m_schedule->update($dataUpdate,$idUpdate);
			$this->m_schedule->insertData($table,$data);

			redirect('order_sheet/detailPo/'.$bpid);
		}else{
			$bpid = $data['KPS_ORDER_SHEET_DETAIL_ID'];
			?>
			<script type="text/javascript">
				alert('Quantity Deliery harus lebih kecil dari Remaining Quantity');
				// window.location.href="<?php echo site_url(); ?>/order_sheet/detailPo/<?php echo $bpid; ?>/<?php echo $osid; ?>";
				window.location.href="<?php echo site_url(); ?>/order_sheet/detailPo/<?php echo $bpid; ?>";
			</script>
			<?php
		}
		
		
	}
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['data'] = $this->m_order_sheet->get($id);
		$idCus=$data['data']->KPS_OS_CUSTOMER_ID;
		$data['deliv'] = $this->m_order_sheet->getDelivSetupForOs($idCus);
		$data['dataDivisi'] = $this->m_order_sheet->getDivisi($idCus);
		$this->load->view('sales_data/v_edit_order_sheet',$data);
	}	
	public function predel($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['data'] = $this->m_order_sheet->get($id);
		$idCus=$data['data']->KPS_OS_CUSTOMER_ID;
		$data['deliv'] = $this->m_order_sheet->getDelivSetupForOs($idCus);
		$data['dataDivisi'] = $this->m_order_sheet->getDivisi($idCus);
		$this->load->view('sales_data/v_delete_order_sheet',$data);
	}
	public function update(){
		$data=$this->input->post();
		$id=$data['KPS_OS_ID'];
		$revNo=$data['KPS_OS_REV_NO'];
		unset($data['KPS_OS_ID']);
		unset($data['KPS_OS_REV_NO']);
		$data['KPS_OS_REV_NO']=$revNo+1;
		$this->m_order_sheet->update($data,$id);
		redirect('order_sheet');
	}
	public function updateDelete(){
		$id=$this->input->post('KPS_OS_ID');
		$revNo=$this->input->post('KPS_OS_REV_NO');
		$data['KPS_OS_REV_NO']=$revNo+1;
		$data['KPS_OS_FLAG_DELETE']=1;
		$this->m_order_sheet->update($data,$id);
		redirect('order_sheet');
	}
	public function delete($id){
		$this->m_order_sheet->delete($id);
		redirect('order_sheet');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		
		$data['data'] = $this->m_order_sheet->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_OS_ID_DETAIL'];
		unset($data['id']);
		unset($data['KPS_OS_ID_DETAIL']);
		 $this->m_order_sheet->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_order_sheet->get($idRef);
		$status = $data->revisi_no_os+1;
		$this->m_order_sheet->updaterevno($status,$idRef);
		redirect('order_sheet/detail/'.$idRef);
	}
	public function loadIdBpReturn(){
		$id = $this->input->get('id');
		$data= $this->m_order_sheet->getBpidForOsReturn($id);
		echo $data->KPS_BUKTI_PESANAN_ID_OS;
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_order_sheet->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadDivisiOs(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_order_sheet->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadDpOs(){
		$id = $this->input->get('id');
		$dataDelP = $this->m_schedule->getDelivSetupForOs($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDelP as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP;?>"><?php echo $value->PLANT1_CITY;?></option>	
			<?php
		}
	}
	public function lock($id){
		$status = "1";
		$this->m_order_sheet->lock($status,$id);
		redirect('order_sheet');
	}
	public function unlock($id){
		$status = "0";
		$this->m_order_sheet->unlock($status,$id);
		redirect('order_sheet');
	}
	public function loadRemainingPending(){
		$id = $this->input->get('id');
		$dataDsd = $this->m_schedule->getForPending($id);
		$rem = 0;
		if(count($this->m_schedule->checkBuktiDetailForRePending($dataDsd[0]->KPS_BUKTI_PESANAN_DETAIL_ID_SD,$dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID))==0){
			$dataRem = $this->m_order_sheet->getPendingFromOutForRpending($dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID);
			$rem = $dataRem->QTY_PENDING_OFGD;
		}else{
			$dataRem = $this->m_schedule->getRemainingReturnPending($dataDsd[0]->KPS_BUKTI_PESANAN_DETAIL_ID_SD,$dataDsd[0]->KPS_DELIVERY_SCHEDULE_DETAIL_ID);
			$rem = $dataRem->KPS_DSD_R_PENDING_REMAINING;
		}
		echo $rem;
	}
	public function loadGetBpForReturnDsd(){
		$id = $this->input->get('id');
		$dataDsd = $this->m_schedule->getForPending($id);
		echo $dataDsd[0]->KPS_BUKTI_PESANAN_DETAIL_ID_SD;
	}
	public function loadRemainingForOs(){
		$ids = $this->input->post('id');
		//print_r($this->input->get('id'));
		$rem = 0;
		if(count($this->m_schedule->checkBuktiDetail($ids))==0){
			$dataRem = $this->m_pesanan->getDetailPesananQty($ids);
			$rem = $dataRem->QUANTITY;
		}else{
			$ids = $this->input->post('id');
			$dataRem = $this->m_schedule->getRemaining($ids);
			$rem = $dataRem->REMAINING_QUANTITY;
		}
		// print_r($ids);
		echo $rem;
	}

}
