<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Daftar_Karyawan extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/v_daftar_karyawan';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

}
