<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Inventory_Warehouse extends CI_Controller {

	public function index()
	{
		$data['content'] = 'warehouse/v_inventory';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

}
