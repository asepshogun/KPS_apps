<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_Quota_Setup extends CI_Controller {

	public function index()
	{
		$data['content'] = 'ppic/v_delivery_quota_setup';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

}
