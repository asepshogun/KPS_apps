<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Total_Marketing_sales_Analize extends CI_Controller {

	public function index()
	{
		$data['content'] = 'report_management/v_total_marketing_sales_analize';
		$this->load->view('template/template',$data);
	}

	public function detail(){
		$data['content'] = 'report_management/detail/total_marketing_sales_analize';
		$this->load->view('template/template',$data);
	}
}
