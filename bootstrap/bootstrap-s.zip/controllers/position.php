<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Position extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('m_position');
		$this->load->model('m_section');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_position->getAll();
		$data['dataSection'] = $this->m_section->getAll();
		$data['content'] = 'module/v_position';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_position->insert($data);
		redirect('position');
	}
	public function edit($id){
		$data['dataSection'] = $this->m_section->getAll();
		$data['data'] = $this->m_position->get($id);
		$this->load->view('module/v_edit_position',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_position->update($data,$id);
		redirect('position');
	}

}
