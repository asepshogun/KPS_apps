<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_Data extends CI_Controller {

public function __construct(){
		parent::__construct();
		$this->load->model('m_department');
		$this->load->model('m_section');
		$this->load->model('m_group');
		$this->load->model('m_position');
		$this->load->model('m_user_data');
		$this->load->model('m_employee');
		$this->load->model('m_roles');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['dataEmployee'] = $this->m_employee->getAllx();
		$data['dataRoles'] = $this->m_roles->getAll();
		$data['data'] = $this->m_user_data->getAll();
		$data['content'] = 'management/v_user_data';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$dataRoles = $data['roles'];
		unset($data['roles']);

		$dataEmployee=$this->m_employee->get($data['KPS_EMPLOYEE_ID']);
		$data['DEPARTMENT'] = $dataEmployee->DEPT_NAME;
		$data['POSITION'] = $dataEmployee->POS_NAME;
		$data['SECTION'] = $dataEmployee->SEC_NAME;
		
		$idUser = $this->m_user_data->insert($data);
		for($i=0;$i<count($dataRoles);$i++){
			$this->m_roles->insertUserRoles($idUser,$dataRoles[$i]);
		}
		redirect('user_data');
	}
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataRoles'] = $this->m_roles->getAll();
		$data['dataRolesCheck'] = $this->m_roles->getListRoles($id);
		$data['data'] = $this->m_user_data->get($id);
		$this->load->view('management/v_edit_user_data',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		
		$dataRoles = $data['roles'];
		unset($data['roles']);
		
		$this->m_user_data->update($data,$id);
		$this->m_roles->deleteUserRoles($id);
		for($i=0;$i<count($dataRoles);$i++){
			$this->m_roles->insertUserRoles($id,$dataRoles[$i]);
		}

		redirect('user_data');
	}
	public function delete($id){
		$this->m_user_data->delete($id);
		redirect('user_data');
	}

}
