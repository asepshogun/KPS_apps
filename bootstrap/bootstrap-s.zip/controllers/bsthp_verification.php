<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class BSTHP_Verification extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('m_bsthp');
		$this->load->model('m_label');
		$this->load->model('m_bsthp_detail');
		$this->load->model('m_bsthp_detail_sub');

	}
	public function index()
	{	
		$id = $this->input->post();
		if($id){
			$data['data'] = $this->m_bsthp_detail->getVeri($id);
			$data['content'] = 'production/v_bsthp_verification';
			$this->load->view('template/template',$data);
		}else{
			$data['data']="0";
			$data['content'] = 'production/detail/bsthp_verification_pre';
			$this->load->view('template/template',$data);
		}
		
	}

	public function add(){
		$data=$this->input->post();
		$dataBsthp = $this->m_bsthp_detail->getVeriAll($data['code']);
		$idBsthp = $dataBsthp->KPS_BSTHP_ID;
		if(empty($dataBsthp->BSTHP_STATUS_VER)){
			$dataBsthpDetail = $this->m_bsthp_detail->getAll($dataBsthp->KPS_BSTHP_ID);
			$this->m_bsthp->updateStatVer($idBsthp);
			unset($data['code']);

			$data['KPS_BSTHP_ID'] = $idBsthp;
			$data['AREA'] = "FINISHED GOOD";
			$data['VERIFICATION'] = "";
			$data['STATUS_VER'] = "ON THE WAY";
			foreach ($dataBsthpDetail as $bsthpVal) {
				$data['KPS_BSTHP_DETAIL_ID'] = $bsthpVal->KPS_BSTHP_DETAIL_ID;
				$this->m_bsthp_detail->insertVeri($data);
			}
		}
		redirect('bsthp_verification/index/'.$idBsthp);
	}
	
	public function edit($id){
	
	}
	public function verify($id,$status,$idBsthp){
		$statusVer = "closed";
		$data = array(
			'VERIFICATION' => $status,
			'STATUS_VER' => $statusVer
		);
		$bsthpVer=$this->m_bsthp_detail->getIdBsthpByIdVer($id);
		$idBsthpVer=$bsthpVer->KPS_BSTHP_DETAIL_ID;
		$barLabel=$this->m_bsthp_detail->getBarLabelByIdVer($idBsthpVer);
		foreach($barLabel as $barLabelVar){
			$this->m_bsthp_detail->updateStatusLabelDes($barLabelVar->kps_barcode_label_id);
			if($status=="ok"){
				$this->m_bsthp_detail->updateStatusSubDes($barLabelVar->KPS_BSTHP_DETAIL_SUB_ID);
			}
		}
		
		// $this->m_label->updateStatusOTW($labelId);>
		$this->m_bsthp_detail->updateVeri($data,$id);
		redirect('bsthp_verification/index/'.$idBsthp);
	}
	public function detail($id)
	{	
		$data['data'] = $this->m_bsthp_detail_sub->getAll($id);
		$data['dataOnly'] = $this->m_bsthp_detail->get($id);
		$data['pesan'] ="";
		$data['content'] = 'production/detail/bsthp_verification_detail';
		$this->load->view('template/template',$data);
	}

}
