<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sales_Report extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_sales_report');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_sales_report->getAll();
		$data['content'] = 'report_management/v_sales_report';
		$this->load->view('template/template',$data);
	}
	

}

