<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock_Opname extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('m_stockOpname');
		$this->load->model('m_employee');
		$this->load->model('m_label');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{	$data['data'] = $this->m_stockOpname->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['content'] = 'warehouse/v_stock_opname';
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data=$this->input->post();
		$this->m_stockOpname->insert($data);
		redirect('stock_Opname');
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail($id,$pesan="0"){
		$data['detail'] = $this->m_stockOpname->getOnly($id);
		$data['pesan'] = $pesan;
		$data['content'] = 'warehouse/detail/stock_opname';
		$this->load->view('template/template',$data);
	}
	public function add_detail(){
		$data = $this->input->post();
		$barcode = substr($data['no_barcode_item'], 0, -3);
		$orderby = abs(substr($data['no_barcode_item'], -3));
		$dataLabel = $this->m_label->getIdbarcode($barcode,$orderby);
		$pesan="";
		$KPS_STOCK_OPNAME_ID_SUB=$data['KPS_STOCK_OPNAME_ID_SUB'];
		$cekBarcodeLabel=$this->m_stockOpname->cekBarcodeLabel($dataLabel->kps_barcode_label_id);
		$cekEksisStockDet=$this->m_stockOpname->cekEksis($dataLabel->kps_barcode_label_id,$KPS_STOCK_OPNAME_ID_SUB);
		if($dataLabel){
			if(empty($cekEksisStockDet)){
				if($dataLabel->BARCODE_LABEL_DESTINATION){
					if(empty($cekBarcodeLabel->BSTHP_DETAIL_SUB_VER_BY_OUTGOING)){
						$datas['KPS_STOCK_OPNAME_ID_SUB']=$data['KPS_STOCK_OPNAME_ID_SUB'];
						$datas['KPS_STOCK_OPANAME_MADE_BY']=$data['KPS_STOCK_OPANAME_MADE_BY'];
						$datas['KPS_BARCODE_LABEL_ID_STOCK_OPNAME']=$dataLabel->kps_barcode_label_id;
						$this->m_stockOpname->insertDetail($datas);
						echo "Item ini sudah masuk ke stock opname";
					}else{
						echo "Item ini Sudah terdaftar di Outgoing --> tambahkan nomor outgoingnya";
					}
				}else{
					echo "Item ini belum masuk gudang";
				}
			}else{
				echo "Item ini sudah di scan";
			}
		}else{
			echo "No barcode yang anda masukan tidak valid";
		}
	}

}
