<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Schedule extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_schedule');
		$this->load->model('m_employee');
		$this->load->model('m_pesanan');
		$this->load->model('m_quotation');
		$this->load->model('m_pesanan');
		$this->load->model('m_loi');
				$this->load->model('m_customer_information');
				if(!$this->session->userdata('username')){
			redirect('login');
		}

	}
	public function index()
	{
		$data['data'] = $this->m_schedule->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataPesanan'] = $this->m_pesanan->getAll();
		$data['content'] = 'sales_data/v_schedule';
		$this->load->view('template/template',$data);
	}
	public function countPending(){
		$data['databp'] = $this->m_schedule->getDetailPesanan(51);
		$data['dataBpPending'] = $this->m_schedule->getAllPendingGroupBP();
		$data['dataBpRetunrPending'] = $this->m_schedule->getAllReturnPendingGroupBP();
		$data['dataBpPendingNotExe'] = $this->m_schedule->getAllPendingGroupBpNotExe();
		//COUNT PENDING BY BP DETAIL Start
		$data['dataBpPendingBpDetail'] = $this->m_schedule->getAllPendingGroupBPDetailByIdBp(13);
		$data['dataBpRetunrPendingDetail'] = $this->m_schedule->getAllReturnPendingGroupBPDetailByIdBp(13);
		$data['dataBpPendingNotExeBpDetail'] = $this->m_schedule->getAllPendingGroupBpNotExeDetailByIdBp(13);
		//COUNT PENDING BY BP DETAIL ENd
		$data['dataDS'] = $this->m_schedule->getAll();
		$data['content'] = 'sales_data/countPending';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_schedule->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO+1;

		}
		$no = $year."/DS-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_REV_NO'] = $no;
		$data['REV_NO'] = $revNoNew;
		$data['TOTAL'] = 0;
		unset($data['KPS_CUSTOMER_ID_BK']);
		$this->m_schedule->insert($data);
		redirect('schedule');
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_schedule->geth($id);
		$data['content'] = 'sales_data/history/history_ds';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_schedule->del($status,$id);
		redirect('schedule');
	}
	public function undel($id){
		$status = "0";
		$this->m_schedule->undel($status,$id);
		redirect('schedule');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($data['REMAINING_QUANTITY'] >= $data['QUANTITY_DELIVERY']){
			$id=$data['KPS_BUKTI_PESANAN_DETAIL_ID_SD'];
			if(count($this->m_schedule->checkBuktiDetail($id))==0){
				$dataRem = $this->m_pesanan->getDetailPesananQty($id);
				$rem = $dataRem->QUANTITY;
			}else{
				$dataRem = $this->m_schedule->getRemaining($id);
				$rem = $dataRem->REMAINING_QUANTITY;
			}
			
			unset($data['buktipesanan']);
			$data['REMAINING_QUANTITY'] = $rem - $data['QUANTITY_DELIVERY'];
			$datare = $data['REMAINING_QUANTITY'];

			$idUpdate = $data['KPS_DELIVERY_SCHEDULE_ID'];
			$dataSchedule = $this->m_schedule->getDetail($idUpdate);
			$total=0;
			foreach ($dataSchedule as $key => $value) {
				$total += $value->QUANTITY_DELIVERY;
			}
			$dataUpdate = array(
				'TOTAL' => $total
			);
			$this->m_schedule->update($dataUpdate,$idUpdate);
			$cek = $this->m_schedule->cekDP($data['DELIVERY_PLAN'],$data['KPS_BUKTI_PESANAN_DETAIL_ID_SD']);
			if(!is_null($cek->DELIVERY_PLAN)){
				?>
				<script type="text/javascript">
					alert('Tanggal pengiriman sudah di pakai');
					window.location.href="<?php echo site_url(); ?>/schedule/detail/<?php echo $data['KPS_DELIVERY_SCHEDULE_ID']; ?>";
				</script>
				<?php
			}else{
				$this->m_schedule->insertData($table,$data);
				 redirect('schedule/detail/'.$data['KPS_DELIVERY_SCHEDULE_ID']);
			}
			//print_r($cek);


		}else{
			?>
			<script type="text/javascript">
				alert('Quantity Delivery harus lebih kecil dari Remaining Quantity');
				window.location.href="<?php echo site_url(); ?>/schedule/detail/<?php echo $data['KPS_DELIVERY_SCHEDULE_ID']; ?>";
			</script>
			<?php
		}
		
		
	}
	public function detail($id)
	{
		$datas = $this->m_schedule->get($id);
		$data['data'] = $this->m_schedule->get($id);
		$data['detail'] = $this->m_schedule->getDetail($id);
		$gettot = $this->m_schedule->getDetail($id);
		$total = 0;
		for ($i=0; $i < count($gettot); $i++) { 
			$total += $gettot[$i]->QUANTITY_DELIVERY;	
		}
		$data['total'] = $total;
		$this->m_schedule->updatetot($total,$id);
		$data['name'] = $this->m_quotation->getAllDetail();
		$data['number'] = $this->m_quotation->getAllDetail();
		$data['code'] = $this->m_loi->getAllByBuktiForDs($datas->KPS_BUKTI_PESANAN_ID,$id);
		$data['bukti'] = $this->m_pesanan->getAll();
		$data['deliv'] = $this->m_schedule->getDelivSetup($datas->KPS_BUKTI_PESANAN_ID);
		$data['content'] = 'sales_data/detail/schedule';
		$this->load->view('template/template',$data);
	}
	public function editDetail($id,$view,$table,$tableId,$idRoot){
			// echo $tableId;
		$datas = $this->m_schedule->get($idRoot);	
			// print_r($datas);
		$data['detail'] = $this->m_schedule->getDetail($id);
		$data['name'] = $this->m_quotation->getAllDetail();
		$data['number'] = $this->m_quotation->getAllDetail();
		$data['code'] = $this->m_loi->getAllByBuktiForDs($datas->KPS_BUKTI_PESANAN_ID,$idRoot);
		$data['bukti'] = $this->m_pesanan->getAll();
		$data['deliv'] = $this->m_schedule->getDelivSetup($datas->KPS_BUKTI_PESANAN_ID);
		$data['data'] = $this->m_schedule->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function preDelDetail($id,$view,$table,$tableId,$idRoot,$idOsdet="0"){
		$cekOutgoing=$this->m_schedule->cekOutgoing($id);
		if($cekOutgoing){
			$data['data']=$cekOutgoing;
			$this->load->view('sales_data/detail/pre_del_schedule_dsd_warning',$data);
		}else{
			$datas = $this->m_schedule->get($idRoot);	
			$datass = $this->m_schedule->getByDsDet($id);
			$data['detail'] = $this->m_schedule->getDetail($id);
			$data['name'] = $this->m_quotation->getAllDetail();
			$data['number'] = $this->m_quotation->getAllDetail();
			$data['code'] = $this->m_loi->getAllByBuktiForDs($datass->KPS_BUKTI_PESANAN_ID,$idRoot);
			$data['bukti'] = $this->m_pesanan->getAll();
			$data['deliv'] = $this->m_schedule->getDelivSetup($datass->KPS_BUKTI_PESANAN_ID);
			$data['data'] = $this->m_schedule->getTableDetail($table,$tableId,$id);
			$data['idOsdet']=$idOsdet;
			$this->load->view('sales_data/detail/'.$view,$data);
		}
	}
	public function deleteDetail($tableName,$colomId,$idOsdet="0"){
		$data=$this->input->post();
		$dataDsDetail=$this->m_schedule->getDsForDelete($data['KPS_BUKTI_PESANAN_DETAIL_ID_SD']);
		$dataBpDet=$this->m_schedule->getBpDetForDel($data['KPS_BUKTI_PESANAN_DETAIL_ID_SD']);
		$qtyBpDet=$dataBpDet->QUANTITY;
		$idDeliveryDsdet=$data['KPS_DELIVERY_SCHEDULE_DETAIL_ID'];
		$idDS=$data['KPS_DELIVERY_SCHEDULE_ID'];
		// print_r($data);
		// print_r($dataDsDetail);
		// print_r($qtyBpDet);
		foreach($dataDsDetail as $values){
			if($values->KPS_DELIVERY_SCHEDULE_DETAIL_ID != $idDeliveryDsdet){
				$idDsDet = $values->KPS_DELIVERY_SCHEDULE_DETAIL_ID;
				$idBpDsDet = $values->KPS_BUKTI_PESANAN_DETAIL_ID_SD;
				$qtyDeliveryDsdet = $values->QUANTITY_DELIVERY;
				$qtyBpDet =$qtyBpDet-$qtyDeliveryDsdet;
				$datas['REMAINING_QUANTITY'] =$qtyBpDet;
				echo $datas['REMAINING_QUANTITY'] ."<br/>";
				$this->m_schedule->updateFordelete($datas,$idDsDet);
			}
		}
		$this->m_schedule->deleteDsDet($idDeliveryDsdet);
		if($idOsdet){
			redirect('order_sheet/detailPo/'. $idOsdet);
		}else{
			redirect('schedule/detail/'. $idDS);
		}
	}
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataPesanan'] = $this->m_pesanan->getAll();
		
		$data['data'] = $this->m_schedule->get($id);
		$this->load->view('sales_data/v_edit_schedule',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		print_r($data);
		$this->m_schedule->update($data,$id);
		$status = $data['revisi_no_ds']+1;
		$this->m_schedule->updaterevno($status,$id);
		redirect('schedule');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}

	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_schedule->updateDetail($table,$tableId,$data,$id);
		 $data = $this->m_schedule->get($idRef);
		$status = $data->revisi_no_ds+1;
		$this->m_schedule->updaterevno($status,$idRef);
		redirect('schedule/detail/'.$idRef);
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_schedule->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadBuktiPesanan(){
		$id = $this->input->get('id');
		$datas = $this->m_pesanan->getAllByCustForScheduleRev($id);
	 	?>	
	 		<option>-- Select Product --</option>
	 	<?php
	 	foreach ($datas as $value) { ?>
					    <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>"><?php echo "Nomor  Bukti Pesanan : &nbsp;&nbsp;" . $value->REV_NO_BP . " &nbsp;&nbsp; - Nomor PO : &nbsp;&nbsp;" . $value->PO_OS_NO_FROM_CUSTOMER . " &nbsp;&nbsp;- Date PO : &nbsp;&nbsp;" . $value->PO_OS_DATE_FROM_CUSTOMER;?></option>
					    <?php
		}
	}
	public function loadBukti(){
		$id = $this->input->post('id');
		$data = $this->m_pesanan->getDetailPesanan($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_BUKTI_PESANAN_DETAIL_ID;?>">
		    <?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO." - ".$value->LOI_PART_NAME;?>
			</option>
		    <?php } 
	}
	
	public function loadRemaining(){
		$id = $this->input->post('id');
		$rem = 0;
		if(count($this->m_schedule->checkBuktiDetail($id))==0){
			$dataRem = $this->m_pesanan->getDetailPesananQty($id);
			$rem = $dataRem->QUANTITY;
		}else{
			$dataRem = $this->m_schedule->getRemaining($id);
			$rem = $dataRem->REMAINING_QUANTITY;
		}
		echo $rem;
	}
	
	public function lock($id){
		$status = "1";
		$this->m_schedule->lock($status,$id);
		redirect('schedule');
	}
	public function unlock($id){
		$status = "0";
		$this->m_schedule->unlock($status,$id);
		redirect('schedule');
	}

}
