<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Section extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('m_section');
		$this->load->model('m_department');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_section->getAll();
		$data['dataDepartment'] = $this->m_department->getAll();
		$data['content'] = 'module/v_section';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_section->insert($data);
		redirect('section');
	}
	public function edit($id){
		$data['dataDepartment'] = $this->m_department->getAll();
		$data['data'] = $this->m_section->get($id);
		$this->load->view('module/v_edit_section',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_section->update($data,$id);
		redirect('section');
	}

}
