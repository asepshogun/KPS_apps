<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Retur_product extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_retur_product');
		$this->load->model('m_customer_information');
		$this->load->model('m_deliver_order');
		$this->load->model('m_employee');
		$this->load->model('m_quotation');
		$this->load->model('m_loi');
		$this->load->model('m_currency');
		$this->load->model('m_pesanan');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	//revisi retur 22-15-2016 start	
	public function pre_print($id){
		$data['detail'] = $this->m_retur_product->get($id);
		$data['detailx'] = $this->m_retur_product->getDetailPesanan($id);
		$data['dataPO'] = $this->m_retur_product->getDetailPesananRetur($id);
		$this->load->view('sales_data/print/v_pre_print_retur',$data);
	}
	//revisi retur 22-15-2016 end
	
	public function history($id){
		$data['dataInduk']=$this->m_retur_product->getHistoryInduk($id);
		$data['dataDetail']=$this->m_retur_product->getHistoryDetail($id);
		$data['content'] = 'sales_data/history/history_retur';
		$this->load->view('template/template',$data);
	}

	public function index()
	{
		$data['data'] = $this->m_retur_product->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataDO'] = $this->m_deliver_order->getAll();
		$data['content'] = 'sales_data/v_retur_product';
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_retur_product->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO_RTR+1;

		}
		$no = $year."/RTR-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_RETUR'] = $no;
		$data['REV_NO_RTR'] = $revNoNew;
		$data['KPS_RETUR_NO_REVISI'] =0;
		
		$this->m_retur_product->insert($data);
		redirect('retur_product');
	}
	// revisi retur 23-5-2016 start
	public function addSub($table,$tabActive="0"){
		$data=$this->input->post();
		if($table=="kps_retur_barang_bukti_pesan"){
			$idReturBarang=$data['KPS_RETUR_BARANG_ID_DET'];
			$data['KPS_RETUR_BARANG_ID_BUKTIPESAN_RETUR']=$data['KPS_RETUR_BARANG_ID_DET'];
			unset($data['KPS_RETUR_BARANG_ID_DET']);
		}else{
			$idReturBarang=$data['KPS_RETUR_BARANG_ID_DET'];
		}
		$this->m_retur_product->insertData($table,$data);
		redirect('retur_product/detail/'.$idReturBarang,$tabActive);
	}
	
	public function detail($id,$tabActive="0")
	{
		$data['datas'] = $this->m_retur_product->get($id);
		$data['loi'] = $this->m_retur_product->getAllLoiForRetur($id,$data['datas']->KPS_CUSTOMER_ID);
		$data['detail'] = $this->m_retur_product->getDetailPesanan($id);
		$data['detail_bukti_pesan'] = $this->m_retur_product->getDetailPesananRetur($id);
		$data['bukti_pesan'] = $this->m_retur_product->getPesananForAdd($id,$data['datas']->KPS_CUSTOMER_ID);
		$data['tabActive'] = $tabActive;
		$data['content'] = 'sales_data/detail/retur';
		$this->load->view('template/template',$data);
	}
	// revisi retur 23-5-2016 end
	public function preUpdate($id){
		$data['loi'] = $this->m_loi->getAll();
		$data['data'] = $this->m_retur_product->get_retur_detail($id);
		$this->load->view('sales_data/add/pop_up_edit_retur',$data);
	}
	public function preDel($id){
		$data['loi'] = $this->m_loi->getAll();
		$data['data'] = $this->m_retur_product->get_retur_detail($id);
		$this->load->view('sales_data/add/pop_up_delete_retur',$data);
	}
	public function exeUpdate(){
		$data=$this->input->post();
		$idReturDetail=$this->input->post('KPS_RETUR_BARANG_DETAIL_ID');
		$idRetur=$this->input->post('KPS_RETUR_BARANG_ID_DET');
		$data2['KPS_REVISI_NO_RETUR']=$data['KPS_REVISI_NO_RETUR']+1;
		$data2['MADE_BY_RB']=$data['KPS_MADE_BY_RETUR_DETAIL'];
		unset($data['KPS_REVISI_NO_RETUR']);
		unset($data['KPS_RETUR_BARANG_DETAIL_ID']);
		unset($data['KPS_RETUR_BARANG_ID_DET']);
		$this->m_retur_product->update($data2,$idRetur);
		$this->m_retur_product->updateDetail("kps_retur_barang_detail","KPS_RETUR_BARANG_DETAIL_ID",$data,$idReturDetail);
		redirect('retur_product/detail/'. $idRetur);
	}
	public function exeDelete(){
		$data=$this->input->post();
		$idReturDetail=$this->input->post('KPS_RETUR_BARANG_DETAIL_ID');
		$idRetur=$this->input->post('KPS_RETUR_BARANG_ID_DET');
		$data2['KPS_REVISI_NO_RETUR']=$data['KPS_REVISI_NO_RETUR']+1;
		$data2['MADE_BY_RB']=$data['KPS_MADE_BY_RETUR_DETAIL'];
		$this->m_retur_product->update($data2,$idRetur);
		$this->m_retur_product->deleteDetail("kps_retur_barang_detail","KPS_RETUR_BARANG_DETAIL_ID",$idReturDetail);
		redirect('retur_product/detail/'. $idRetur);
	}	
	public function preUpdateInduk($id){
		$data['data'] = $this->m_retur_product->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataDO'] = $this->m_deliver_order->getAll();
		$data['data_detail'] = $this->m_retur_product->get($id);
		$this->load->view('sales_data/add/pop_up_edit_retur_induk',$data);
	}
	public function preDelInduk($id){
		$data['data'] = $this->m_retur_product->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataDO'] = $this->m_deliver_order->getAll();
		$data['data_detail'] = $this->m_retur_product->get($id);
		$this->load->view('sales_data/add/pop_up_delete_retur_induk',$data);
	}
	public function exeUpdateInduk(){
		$data=$this->input->post();
		$idRetur=$this->input->post('KPS_RETUR_BARANG_ID');
		$data['KPS_REVISI_NO_RETUR']=$data['KPS_REVISI_NO_RETUR']+1;
		unset($data['KPS_RETUR_BARANG_ID']);
		$this->m_retur_product->update($data,$idRetur);
		redirect('retur_product');
	}
	public function exeDeleteInduk(){
		$data=$this->input->post();
		$idRetur=$this->input->post('KPS_RETUR_BARANG_ID');
		$data['KPS_REVISI_NO_RETUR']=$data['KPS_REVISI_NO_RETUR']+1;
		$data['KPS_RETUR_FLAG_DELETE']=1;
		unset($data['KPS_RETUR_BARANG_ID']);
		$this->m_retur_product->update($data,$idRetur);
		redirect('retur_product');
	}
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataCurr'] = $this->m_currency->getAll();
		$data['dataDO'] = $this->m_deliver_order->getAll();
		
		$data['data'] = $this->m_retur_product->get($id);
		$this->load->view('sales_data/v_edit_retur_product',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_retur_product->update($data,$id);
		$status = $data['KPS_RETUR_NO_REVISI']+1;
		$this->m_retur_product->updaterevno($status,$id);
		redirect('retur_product');
	}
	public function lock($id){
		$status = "1";
		$this->m_retur_product->lock($status,$id);
		redirect('retur_product');
	}
	public function unlock($id){
		$status = "0";
		$this->m_retur_product->unlock($status,$id);
		redirect('retur_product');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$data['name'] = $this->m_quotation->getAllDetail();
		$data['number'] = $this->m_quotation->getAllDetail();
		$data['code'] = $this->m_loi->getAllDetail();
		
		$data['data'] = $this->m_pesanan->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_pesanan->updateDetail($table,$tableId,$data,$id);
		redirect('pesanan/detail/'.$idRef);
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_pesanan->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}
	public function loadModelPrice(){
		$id = $this->input->post('id');
		$data = $this->m_pesanan->getModelPrice($id);
		echo json_encode($data);
	}

}
