<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Monthly_Marketing_Sales_Growth_Report extends CI_Controller {

	public function index()
	{
		$data['content'] = 'report_management/v_monthly_marketing_sales_growth_report';
		$this->load->view('template/template',$data);
	}

	public function detail(){
		$data['content'] = 'report_management/detail/monthly_marketing_sales_growth_report';
		$this->load->view('template/template',$data);
	}
}
