<?php 
ini_set('display_errors', 1);

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class HistoryPrice extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->helper('exportpdf_helper');     
		$this->load->model('m_quotation');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_quotation->getAllRFQForHistoryPrice();
		$data['content'] = 'sales_data/v_historyprice';
		$this->load->view('template/template',$data);
	}
	

}
