<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Outgoing_OS extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_outgoing_finished');
		$this->load->model('m_employee');
		$this->load->model('m_pesanan');
		$this->load->model('m_quotation');
		$this->load->model('m_pesanan');
		$this->load->model('m_vehicle');
		$this->load->model('m_order_sheet');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_outgoing_finished->getOs();
		$data['dataOf'] = $this->m_outgoing_finished->getAll();
		$data['dataOs'] = $this->m_order_sheet->getAll();
		$data['content'] = 'sales_data/v_outgoing_os';
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data = $this->input->post();
		$id = $data['KPS_OUTGOING_FINISHED_GOOD_ID'];
		unset($data['KPS_OUTGOING_FINISHED_GOOD_ID']);
		$this->m_outgoing_finished->updateOs($data,$id);
		redirect('outgoing_os');
	}
	public function addSub($table){
		$data=$this->input->post();
		print_r($data);
		echo $table;
		$this->m_outgoing_finished->insertData($table,$data);
		$str = $this->db->last_query();
		echo $str;
		redirect('outgoing_finished/detail/'.$data['KPS_OUTGOING_FINISHED_GOOD_ID_D']);
	}
	public function detail($id)
	{;
		$data['data'] = $this->m_outgoing_finished->get($id);
		$data['detail'] = $this->m_outgoing_finished->getDetail($id);
		$data['code'] = $this->m_outgoing_finished->getCode();
		$data['content'] = 'sales_data/detail/outgoing_finished';
		$this->load->view('template/template',$data);
	}
	public function edit($id){
		$data['dataOf'] = $this->m_outgoing_finished->getAll();
		$data['dataOs'] = $this->m_order_sheet->getAll();
		
		$data['data'] = $this->m_outgoing_finished->get($id);
		$this->load->view('sales_data/v_edit_outgoing_os',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		
		unset($data['id']);
		 $this->m_outgoing_finished->update($data,$id);
		redirect('outgoing_os');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		
		$data['data'] = $this->m_outgoing_finished->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_RFQ_ID'];
		unset($data['id']);
		unset($data['KPS_RFQ_ID']);
		 $this->m_outgoing_finished->updateDetail($table,$tableId,$data,$id);
		redirect('outgoing_finished/detail/'.$idRef);
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_outgoing_finished->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}

}