<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mutation extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_mutation');
		$this->load->model('m_customer_information');
		$this->load->model('m_outgoing_finished');
		$this->load->model('m_outgoing_finished_verification');
		$this->load->model('m_bsthp_detail_sub');
		$this->load->model('m_loi');
		$this->load->model('m_label');
	}
	public function index()
	{
		$data['data'] = $this->m_mutation->getAll();
		$data['content'] = 'ppic/v_mutation_item';
		$this->load->view('template/template',$data);
	}
	public function detail($id,$pesan="0"){
		$data['dataOnly']=$this->m_mutation->get($id);
		$data['detail_ver'] = $this->m_outgoing_finished_verification->getAll($data['dataOnly']->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID);
		if($pesan){
			if($pesan==1){
				$dataSub="Code item tidak sesuai dengan yang terdaftar pada Mutasi";
			}elseif($pesan==2){
				$dataSub="Ini adalah Barang NG";
			}elseif($pesan==3){
				$dataSub="Barang belum terdaftar di BSTHP";
			}elseif($pesan==4){
				$dataSub="QTY Barang Melebihi Quota Execution";
			}else{
			$dataout=$this->m_bsthp_detail_sub->getIDOutBySub($pesan);
			$dataSub="Barang Sudah terdaftar pada Outgoing No :".$dataout->NO_OUTGOING ." Tanggal Outgoing : ".$dataout->DATE_OUTGOING;
			}
		}else{
		$dataSub="0";
		}
		// $data['data'] = $this->m_bsthp_detail_sub->getAll($id);
		$dataMutation=$this->m_mutation->getAllMutationByOfg($id);
		$data['pesan'] = $dataSub;
		$data['content'] = 'ppic/detail/mutation_item_detail';
		$this->load->view('template/template',$data);
	}
	public function addVerification($id){
		$data = $this->input->post();
		// $barcode = $data['no_barcode_item'];
		$barcode = substr($data['no_barcode_item'], 0, -3);
		$orderby = abs(substr($data['no_barcode_item'], -3));
		$dataLabel = $this->m_bsthp_detail_sub->getIdsub($barcode,$orderby);
		$idMutation =$data['ID_Mutation'];
		unset($data['ID_Mutation']);
		if($dataLabel){
			$labelId = $dataLabel[0]->KPS_BSTHP_DETAIL_SUB_ID;
			// $getVerBsthpBySub = $this->m_bsthp_detail_sub->getVerBsthpBySub($labelId);
			unset($data['no_barcode_item']);
			$pesan="0";
				if($data['LOI_idByVER']==$dataLabel[0]->KPS_LOI_ID_label){
					if($dataLabel[0]->BSTHP_DETAIL_SUB_VER){
						if(empty($dataLabel[0]->BSTHP_DETAIL_SUB_VER_BY_OUTGOING)){
							$getOUTDet = $this->m_outgoing_finished->getQtyDet($data['KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER']);
							$data['KPS_BSTHP_DETAIL_SUB_ID_VER'] = $labelId;
							$qtyTotalExe=$getOUTDet[0]->QTY_DELIVERY_EXECUTION;
							$qtyTotalVer=$getOUTDet[0]->OUTGOING_DETAIL_QTY_VERIFICATION;
							$qtyTotalExVer=$dataLabel[0]->QUANTITY;
							$qtyTotalVer=$qtyTotalVer+$qtyTotalExVer;
							if($qtyTotalVer<=$qtyTotalExe){
								$qtyTotalVerUpdate['OUTGOING_DETAIL_QTY_VERIFICATION']=$qtyTotalVer;
								unset($data['LOI_idByVER']);
								$this->m_outgoing_finished_verification->insert($data);
								$this->m_bsthp_detail_sub->updateSubByOut($labelId);
								$this->m_outgoing_finished->updateQtyVer($qtyTotalVerUpdate,$data['KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER']);
							}else{
								$pesan="4";
							}
						}else{
							$pesan=$labelId;
							// print_r($pesan);
						}
					}else{
						$pesan="2";
					}
				}else{
					$pesan="1";
				}
			}else{
				$pesan="3";
			}
			redirect('Mutation/detail/'.$idMutation ."/" . $pesan);
	}
	public function add(){
		if($this->input->post()){
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_mutation->getLastId();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->REV+1;

			}
			$no = $year."/MTT-PPIC/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data=$this->input->post();
			$data['NO'] = $no;
			$data['MUTATION_REV_NO'] = $revNoNew;
			unset($data['KPS_CUSTOMER_LIST_ID']);
			unset($data['KPS_CUSTOMER_LIST_ID2']);
			$this->m_mutation->insert($data);
			redirect('mutation');

		}else{
		$data['dataCust'] = $this->m_customer_information->getAll();
		// $data['dataEmp'] = $this->m_employee->getAll();
		$data['dataLoi'] = $this->m_loi->getAll();
		$this->load->view('ppic/add/pop_up_add_mutation',$data);
				// $this->load->view('production/label/pop_up_add_label',$data);

		}
	}
	public function generateOut($id,$date){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_outgoing_finished->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->KPS_OUTGOING_FINISHED_GOOD_ID+1;

		}
		$no = $year."/OTG-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		$data['NO_OUTGOING'] = $no;
		$data['KPS_MUTATION_ID_OGFG'] = $id;
		$data['DELIVERY_DATE'] = $date;
		$data['TOTAL_DELIVERY_EXECUTION'] = 0;
		$this->m_outgoing_finished->insert($data);
		$this->m_mutation->updateStatusOfg($id);
		redirect('mutation/detail',$id);
	}
	public function generateOutDet($id){
		$dataMutation=$this->m_mutation->getAllMutationByOfg($id);
		$data['KPS_OUTGOING_FINISHED_GOOD_ID_D'] = $dataMutation->KPS_OUTGOING_FINISHED_GOOD_ID;
		$data['QTY_DELIVERY_EXECUTION'] = $dataMutation->QTY;
		$table="kps_outgoing_finished_good_detail";
		$this->m_mutation->updateStatusOfgDet($id);
		$this->m_outgoing_finished->insertData($table,$data);
		redirect('mutation/detail',$id);
	}
	public function generateBarcode($id,$idLoi,$totalVer){
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_label->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_LABEL+1;

		}
		$no = $year."/LB-PRO/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_LABEL'] = $no;
		$data['REV_LABEL'] = $revNoNew;

		$data['KPS_LOI_ID_label'] = $idLoi;
		$dataLoi = $this->m_loi->get($idLoi);
		$codeItem = $dataLoi->LOI_CODE_ITEM;
		$standardp= $dataLoi->LOI_STRANDART_PACKING;
		$year = date('Y');
		$day = date('d');
		$month = date('m');
		$data["barcode"]=$codeItem."".$year."".$month."".$day;
		$data["QUANTITY"]=$standardp;
		$data["KPS_LABEL_ID_MUTATION"]=$id;

		$data['qty_barcode']=$totalVer/$data["QUANTITY"];
		
		$barcodeDataDef = $data['barcode'];
		unset($data['barcode']);
		$idLabel = $this->m_label->insert($data);
		
		for($i=0;$i<$data['qty_barcode'];$i++){
			$check = $this->m_label->checkLabelBarcode($barcodeDataDef);
			if(count($check)==0){
				$order = $i+1;
			}else{
				$order = $check[0]->order_label+1;
			}
			
			if(strlen($order)==1){
				$order = "00".$order;
				
			}
			if(strlen($order)==2){
				$order = "0".$order;
				
			}
			if(strlen($order)==3){
				$order = $order;

			}
			echo $order;

			echo $barcodeData = $barcodeDataDef."".$order;
			echo "<br>";
			$idBarcode = $this->m_label->insertBarcode(array('BARCODE_NO' => $barcodeData));

			$dataBar = array(
				// 'barcode_id' => $idBarcode,
				'label_id' => $idLabel,
				'code_label' => $barcodeDataDef,
				'order_label' => $order
			);
			$this->m_label->insertBarcodeLabel($dataBar);
		}
		$this->m_mutation->updateStatusOfgVer($id);
		redirect('mutation/detail',$id);
			
	}
	public function prints($labelId)
	{
		$data['barcode'] = $this->m_label->getDataBarcodeByMutation($labelId);
		$this->load->view('production/print_barcode',$data);
	}
	public function loadProduct(){
		$id = $this->input->post('id');
		$data = $this->m_mutation->getLoiByCust($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_LOI_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
		    <?php } 
	}
	public function loadloi(){
		$id = $this->input->post('id');
		$data = $this->m_mutation->getLoiByCust($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_LOI_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
		    <?php } 
	}
	public function edit($id){
		$data['data'] = $this->m_mutation->get($id);
		$this->load->view('mutation/v_edit_vehicle',$data);
	}
	public function lock($id){
		$this->m_mutation->updatelock($id);
		redirect('mutation');
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_mutation->update($data,$id);
		redirect('vehicle');
	}
	public function KonDecRomawi($angka){
		$hsl = "";
		if($angka<1||$angka>3999){
			$hsl = "Batas Angka 1 s/d 3999";
		}else{
			 while($angka>=1000){
				 $hsl .= "M";
				 $angka -= 1000;
			 }
			 if($angka>=500){
					 if($angka>500){
						 if($angka>=900){
							 $hsl .= "CM";
							 $angka-=900;
						 }else{
							 $hsl .= "D";
							 $angka-=500;
						 }
					 }
				 }
				 while($angka>=100){
					 if($angka>=400){
						 $hsl .= "CD";
						 $angka-=400;
					 }else{
						 $angka-=100;
					 }
				 }
				 if($angka>=50){
					 if($angka>=90){
						 $hsl .= "XC";
						  $angka-=90;
					 }else{
						$hsl .= "L";
						$angka-=50;
					 }
				 }
				 while($angka>=10){
					 if($angka>=40){
						$hsl .= "XL";
						$angka-=40;
					 }else{
						$hsl .= "X";
						$angka-=10;
					 }
				 }
				 if($angka>=5){
					 if($angka==9){
						 $hsl .= "IX";
						 $angka-=9;
					 }else{
						$hsl .= "V"; 
						$angka-=5;
					 }
				 }
				 while($angka>=1){
					 if($angka==4){
						$hsl .= "IV"; 
						$angka-=4;
					 }else{
						$hsl .= "I";
						$angka-=1;
					 }
				 }
			}
			return ($hsl);
	}

}
