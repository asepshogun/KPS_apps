<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Absen_Harian extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/v_absen_harian';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

	public function detail(){
		$data['content'] = 'production/detail/absen_harian';
		$this->load->view('template/template',$data);
	}

	public function monitoring(){
		$data['content'] = 'production/monitoring/v_absen_harian_monitoring';
		$this->load->view('template/template',$data);
	}

}
