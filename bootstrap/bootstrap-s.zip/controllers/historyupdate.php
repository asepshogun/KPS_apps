<?php 
ini_set('display_errors', 1);

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Historyupdate extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->helper('exportpdf_helper');     
		$this->load->model('m_quotation');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_quotation->getAllMonh();
		$data['content'] = 'sales_data/v_historyupdate';
		$this->load->view('template/template',$data);
	}
	public function history($id)
	{
		
		$data['data'] = $this->m_quotation->gethpu($id);
		$data['content'] = 'sales_data/history/history_price_update';
		$this->load->view('template/template',$data);
	}
	

}
