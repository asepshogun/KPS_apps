<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_project');
		$this->load->model('m_req_quotation');
				$this->load->model('m_customer_information');

		$this->load->model('m_employee');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_project->getAll();
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['content'] = 'sales_data/v_project';
		$this->load->view('template/template',$data);
	}
	public function pre_print($id){
		$data['detail'] = $this->m_project->get($id);		
		$this->load->view('sales_data/print/v_pre_print_project',$data);
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_project->geth($id);
		$data['content'] = 'sales_data/history/history_project';
		$this->load->view('template/template',$data);
	}
	public function lock($id){
		$status = "1";
		$this->m_project->lock($status,$id);
		redirect('project');
	}
	public function unlock($id){
		$status = "0";
		$this->m_project->unlock($status,$id);
		redirect('project');
	}
	public function del($id){
		$status = "1";
		$this->m_project->del($status,$id);
		redirect('project');
	}
	public function undel($id){
		$status = "0";
		$this->m_project->undel($status,$id);
		redirect('project');
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_project->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO_FAILED+1;

		}
		$no = $year."/FP-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_FAILED'] = $no;
		$data['REV_NO_FAILED'] = $revNoNew;
		unset($data['KPS_CUSTOMER_ID_BK']);
		$this->m_project->insert($data);
		redirect('project');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_failed_project_attachment"){
			$data['FILENAME'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['upload_path'] = './uploads/failed/';
			$config['allowed_types'] = $ext.'|'.$fileType;

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
			
		}
		$this->m_project->insertData($table,$data);
		redirect('project/detail/'.$data['KPS_FAILED_PROJECT_ID']);
	}
	public function detail($id)
	{;
		$data['data'] = $this->m_project->get($id);
		$data['attach'] = $this->m_project->getDetail("kps_failed_project_attachment","KPS_FAILED_PROJECT_ID",$id);
		$data['content'] = 'sales_data/detail/project';
		$this->load->view('template/template',$data);
	}
	public function edit($id){
		
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['data'] = $this->m_project->get($id);
		$this->load->view('sales_data/v_edit_project',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_project->update($data,$id);
		$status = $data['revisi_no_project']+1;
		$this->m_project->updaterevno($status,$id);
		redirect('project');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		
		$data['data'] = $this->m_project->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$data['FILENAME'] = $_FILES['FILENAME']['name'];
		$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
		$fileType=$_FILES['FILENAME']['type'];
		$config['upload_path'] = './uploads/failed/';
		$config['allowed_types'] = $ext.'|'.$fileType;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('FILENAME'))
		{
			echo $this->upload->display_errors();
			echo "error";
		}
		else
		{
			echo "success";
		}
		$idRef = $data['KPS_FAILED_PROJECT_ID'];
		unset($data['id']);
		unset($data['KPS_FAILED_PROJECT_ID']);
		 $this->m_project->updateDetail($table,$tableId,$data,$id);
		 $data = $this->m_project->get($idRef);
		 $status = $data->revisi_no_rfq+1;
		$this->m_project->updaterevno($status,$idRef);
		redirect('project/detail/'.$idRef);
	}

}
