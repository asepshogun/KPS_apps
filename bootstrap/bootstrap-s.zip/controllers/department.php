<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Department extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_department');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_department->getAll();
		$data['content'] = 'module/v_department';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_department->insert($data);
		redirect('department');
	}
	public function edit($id){
		$data['data'] = $this->m_department->get($id);
		$this->load->view('module/v_edit_department',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_department->update($data,$id);
		redirect('department');
	}
}
