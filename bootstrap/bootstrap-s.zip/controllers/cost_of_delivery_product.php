<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cost_of_delivery_product extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_breakdown_cost');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_breakdown_cost->getAll_J();
		$data['content'] = 'sales_data/cost_of_delivery_product';
		$this->load->view('template/template',$data);
	}
	public function edit($id)
	{
		$data['data'] = $this->m_breakdown_cost->get($id);
		$this->load->view('sales_data/v_edit_codp',$data);
	}
	public function update()
	{
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_breakdown_cost->update($data,$id);
		redirect('cost_of_delivery_product');
	}
}