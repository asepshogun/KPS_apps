<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Inventory extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_bsthp');
		$this->load->model('m_label');
		$this->load->model('m_bsthp_detail');
		$this->load->model('m_bsthp_detail_sub');
		$this->load->model('m_loi');

	}
	public function index()
	{
		$data['data'] = $this->m_label->getDataBrcode();
		$data['dataCount'] = $this->m_label->getDataBarcodeDetailAll();
		$data['content'] = 'production/v_inventory';
		$this->load->view('template/template',$data);
	}
	public function indexCodeItem()
	{
		$data['data'] = $this->m_label->getDataBrcode();
		$data['dataGroup'] = $this->m_label->getDataBrcode_group();
		$data['dataCount'] = $this->m_label->getDataBarcodeDetailAll();
		$data['content'] = 'production/v_inventory_by_codeItem';
		$this->load->view('template/template',$data);
	}
	public function detail($id){
		$data['dataOnly']=$this->m_label->getData_barcode_byID($id);
		$data['data'] = $this->m_label->getDataBarcodeDetail($id);
		$qtyItemOpen=0;
		$qtyBarOpen=0;
		foreach ($data['data'] as $value) { 
			if(empty($value->BARCODE_LABEL_OTW) && empty($value->BARCODE_LABEL_DESTINATION)){
			$qtyItemOpen=$qtyItemOpen+$value->QUANTITY;
			$qtyBarOpen++;
			}
		}
		$qtyItemOTW=0;
		$qtyBarOTW=0;
		foreach ($data['data'] as $value) { 
			if($value->BARCODE_LABEL_OTW && empty($value->BARCODE_LABEL_DESTINATION)){
			$qtyItemOTW=$qtyItemOTW+$value->QUANTITY;
			$qtyBarOTW++;
			}
		}
		$qtyItemClosed=0;
		$qtyBarClosed=0;
		foreach ($data['data'] as $value) { 
			if($value->BARCODE_LABEL_OTW && $value->BARCODE_LABEL_DESTINATION){
			$qtyItemClosed=$qtyItemClosed+$value->QUANTITY;
			$qtyBarClosed++;
			}
		}
		$data['qtyBarOpen']=$qtyBarOpen;
		$data['qtyBarOTW']=$qtyBarOTW;
		$data['qtyBarClosed']=$qtyBarClosed;
		$data['qtyItemClosed']=$qtyItemClosed;
		$data['qtyItemOTW']=$qtyItemOTW;
		$data['qtyItemOpen']=$qtyItemOpen;
		$data['content'] = 'production/detail/inventory';
		$this->load->view('template/template',$data);
	}
}
