<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock_Card_Delivery extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_stock_delivery');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_stock_delivery->getAllx();
		$data['content'] = 'warehouse/v_stock_card_delivery';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail(){
		$data['content'] = 'warehouse/detail/stock_card_delivery';
		$this->load->view('template/template',$data);
	}

}
