<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Marketing_Data extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_marketing');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['content'] = 'management/v_marketing_data';
		$data['data'] = $this->m_marketing->getAll();
		$this->load->view('template/template',$data);
	}

	public function add(){
		$data=$this->input->post();
		$this->m_marketing->insert($data);
		redirect('marketing_data');
	}
	public function edit($id){
		$data['data'] = $this->m_marketing->get($id);
		$this->load->view('management/v_edit_marketing_data',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_marketing->update($data,$id);
		redirect('marketing_data');
	}

	public function delete($id){
		$this->m_marketing->delete($id);
		redirect('marketing_data');
	}

}
