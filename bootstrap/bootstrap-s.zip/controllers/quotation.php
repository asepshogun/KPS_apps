<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Quotation extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_quotation');
		$this->load->model('m_customer_information');
		$this->load->model('m_employee');
		$this->load->model('m_marketing');
		$this->load->model('m_req_quotation');
		$this->load->model('m_breakdown_cost');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	//revisi quotation start
	
	public function preAdd(){
		$data['dataRfq'] = $this->m_quotation->getAllRFQ();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$this->load->view('sales_data/add/pop_up_add_quotation',$data);
	} 

	public function detail($id)
	{
		$datas = $this->m_quotation->get($id);
		$cisId = $datas->KPS_CUSTOMER_ID_RFQ;
		$RfqCus = $datas->RFQ_CUSTOMER_NO;
		$data['data'] = $this->m_quotation->get($id);
		$data['quotation'] = $this->m_quotation->getDetail($id);
		$data['bc'] = $this->m_quotation->getAllBcByRfq($cisId,$RfqCus);
		$data['content'] = 'sales_data/detail/quotation';
		$this->load->view('template/template',$data);
	}
	//revisi quotation end
	
	
	//backup revisi quotation start
		// public function detail($id)
			// {
				// $datas = $this->m_quotation->get($id);
				// $cisId = $datas->KPS_CUSTOMER_ID;
				// $data['data'] = $this->m_quotation->get($id);
				// $data['quotation'] = $this->m_quotation->getDetail($id);
				// $data['bc'] = $this->m_breakdown_cost->getAllByCis($cisId);
				// $data['content'] = 'sales_data/detail/quotation';
				// $this->load->view('template/template',$data);
			// }
	//backup revisi quotation end
	
	
	public function index()
	{
		$data['data'] = $this->m_quotation->getAll();
		$data['dataRfq'] = $this->m_quotation->getAllRFQ();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['content'] = 'sales_data/v_quotation';
		$data['test'] = 'Testing Code';
		$this->load->view('template/template',$data);
	}
	public function pre_print($id){
		$data['detail'] = $this->m_quotation->getAllPrint($id);	
		$this->load->view('sales_data/print/v_pre_print_quotation',$data);
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_quotation->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->rev_no_quo+1;

		}
		$no = $year."/QTN-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_QUO'] = $no;
		$data['rev_no_quo'] = $revNoNew;

		$this->m_quotation->insert($data);
		redirect('quotation');
	}
	public function addSub($table){
		$data=$this->input->post();
		$this->m_quotation->insertData($table,$data);
		redirect('quotation/detail/'.$data['KPS_QUOTATION_ID']);
	}

	public function history($id)
	{
		
		$data['datas'] = $this->m_quotation->geth($id);
		$data['content'] = 'sales_data/history/history_quo';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_quotation->del($status,$id);
		redirect('request_quotation');
	}
	public function undel($id){
		$status = "0";
		$this->m_quotation->undel($status,$id);
		redirect('request_quotation');
	}
	public function edit($id){
		$data['data'] = $this->m_quotation->get($id);
		$data['dataRfq'] = $this->m_req_quotation->getAll();
		$data['dataMarketing'] = $this->m_marketing->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$datas = $this->m_quotation->get($id);
		$data['dataCurr'] = $this->m_req_quotation->getCurr($datas->KPS_RFQ_ID_QUO);
		$data['dataPic'] = $this->m_customer_information->getPicRfq($datas->KPS_RFQ_ID_QUO);

		$this->load->view('sales_data/v_edit_quotation',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_quotation->update($data,$id);
		$status = $data['revisi_no_quo']+1;
		$this->m_quotation->updaterevno($status,$id);
		redirect('quotation');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
			
		// $datas = $this->m_customer_information->getTableDetail($table,$tableId,$id);
		$data['breakdownCost'] = $this->m_breakdown_cost->getAll();
		$data['data'] = $this->m_quotation->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);	
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_QUOTATION_ID'];
		unset($data['id']);
		unset($data['KPS_QUOTATION_ID']);
		 $this->m_quotation->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_quotation->get($idRef);
		$status = $data->revisi_no_quo+1;
		$this->m_quotation->updaterevno($status,$idRef);
		redirect('quotation/detail/'.$idRef);
	}
	public function loadPart(){
		$id = $this->input->get('id');
		$data = $this->m_req_quotation->getDrawing($id);
		header('Content-Type: application/json');
    	echo json_encode( $data );

	}
	public function loadCurr(){
		$id = $this->input->get('id');
		$dataCurr = $this->m_req_quotation->getCurr($id);
		?>
		<option>-- Select Currency --</option>								
		<?php
		foreach ($dataCurr as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_RFQ_CURENCY_ID;?>"><?php echo $value->CURRENCY_NAME;?></option>	
			<?php
		}
	}
	public function loadPic(){
			$id = $this->input->get('id');
			$data = $this->m_quotation->getPic($id);
			?>
			<option>-- Select PIC --</option>					
			<?php
			foreach ($data as $key => $value) {
				?>
				 <option value="<?php echo $value->KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID;?>"><?php echo $value->NAME;?></option>	
				<?php
			}
	}
	public function exportexcel($id){
        //$id = $this->input->post('id');
        
        //$this->load->model('rptexcel/data');
        $res['data'] = $this->m_quotation->excelexport($id);

        $this->load->view('rptexcel/excelexportbetaquo',$res);
	}
	public function exportexcelpre($id){
		//$id = $this->input->post('id');
        
        //$this->load->model('rptexcel/data');
        $res['data'] = $this->m_quotation->excelexport($id);

        $this->load->view('rptexcel/excelexportpreviewquo',$res);
	}

	public function loadProd(){
		$id = $this->input->post('id');
		$data = $this->m_req_quotation->getDrawing($id);
	    header('Content-Type: application/json');
    	echo json_encode( $data );
	}
	public function lock($id){
		$status = "1";
		$this->m_quotation->lock($status,$id);
		redirect('quotation');
	}
	public function unlock($id){
		$status = "0";
		$this->m_quotation->unlock($status,$id);
		redirect('quotation');
	}

}
