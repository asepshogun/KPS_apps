<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_Status extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_delivery_status');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}

	public function index()
	{
		$data['data'] = $this->m_delivery_status->getAllx();
		$data['content'] = 'ppic/v_delivery_status';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail($id){
		$data['data'] = $this->m_delivery_status->getId($id);
		$data['detail'] = $this->m_delivery_status->getDetail($id);
		$data['pending'] = $this->m_delivery_status->getDetailpen($id);
		$data['content'] = 'ppic/detail/delivery_status';
		$this->load->view('template/template',$data);
	}

}
