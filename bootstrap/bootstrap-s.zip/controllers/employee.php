<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_department');
		$this->load->model('m_section');
		$this->load->model('m_group');
		$this->load->model('m_position');
		$this->load->model('m_employee');
		$this->load->model('m_ref');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['dataDomisili'] = $this->m_ref->getKabkota();
		$data['dataDepartment'] = $this->m_department->getAll();
		$data['dataSection'] = $this->m_section->getAll();
		$data['dataGroup'] = $this->m_group->getAll();
		$data['dataPosition'] = $this->m_position->getAll();
		$data['data'] = $this->m_employee->getAll();
		$data['content'] = 'management/v_employee';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_employee->insert($data);
		redirect('employee');
	}
	public function edit($id){
		$datas = $this->m_employee->get($id);
		$deptId = $datas->DEPT_EMPLOYEE_ID;
		$sectId = $datas->SEC_EMPLOYEE_ID;
		$data['dataDomisili'] = $this->m_ref->getKabkota();
		$data['dataDepartment'] = $this->m_department->getAll();
		$data['dataSection'] = $this->m_employee->getChild("kps_section_employee","DEPT_EMPLOYEE_ID_SEC",$deptId);
		$data['dataGroup'] = $this->m_group->getAll();
		$data['dataPosition'] = $this->m_employee->getChild("kps_position_employee","SEC_EMPLOYEE_ID_POS",$sectId);
		$data['data'] = $this->m_employee->get($id);
		$this->load->view('management/v_edit_employee',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_employee->update($data,$id);
		
		redirect('employee');
	}
	public function delete($id){
		$this->m_employee->delete($id);
		redirect('employee');
	}
	public function loadSection(){
		$id = $this->input->get('id');
		$table = $this->input->get('table');
		$field = $this->input->get('field');
		$data = $this->m_employee->getChild($table,$field,$id);
		?>
		<option selected="">-- Select Section --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->SEC_EMPLOYEE_ID;?>"><?php echo $value->SEC_NAME;?></option>	
			<?php
		}
	}
	public function loadPosition(){
		$id = $this->input->get('id');
		$table = $this->input->get('table');
		$field = $this->input->get('field');
		$data = $this->m_employee->getChild($table,$field,$id);
		?>
		<option selected="">-- Select Position --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->POSITION_ID;?>"><?php echo $value->POS_NAME;?></option>	
			<?php
		}
	}
	
}
