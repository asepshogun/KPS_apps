<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Additional_Salary_Jamsostek extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/v_additional_salary_jamsostek';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

	public function detail(){
		$data['content'] = 'production/detail/additional_salary_jamsostek';
		$this->load->view('template/template',$data);
	}

}
