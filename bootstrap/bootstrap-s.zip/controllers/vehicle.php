<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Vehicle extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_vehicle');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_vehicle->getAll();
		$data['content'] = 'module/v_vehicle';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_vehicle->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO+1;

		}
		$no = $year."/DQS-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data=$this->input->post();
		$data['VEHICLE_NO_SURAT'] = $no;
		$data['REV_NO'] = $revNoNew;
		
		$data['PHOTO_OF_TRUCK'] = $_FILES['FILENAME']['name'];
		$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
		$fileType=$_FILES['FILENAME']['type'];
		$config['upload_path'] = './uploads/vehicle/';
		$config['allowed_types'] = $ext.'|'.$fileType;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('FILENAME'))
		{
			echo $this->upload->display_errors();
			echo "error";
		}
		else
		{
			echo "success";
		}
			print_r($data);
			$this->m_vehicle->insert($data);
			redirect('vehicle');
	}
	public function edit($id){
		$data['data'] = $this->m_vehicle->get($id);
		$this->load->view('module/v_edit_vehicle',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_vehicle->update($data,$id);
		redirect('vehicle');
	}
	public function KonDecRomawi($angka){
		$hsl = "";
		if($angka<1||$angka>3999){
			$hsl = "Batas Angka 1 s/d 3999";
		}else{
			 while($angka>=1000){
				 $hsl .= "M";
				 $angka -= 1000;
			 }
			 if($angka>=500){
					 if($angka>500){
						 if($angka>=900){
							 $hsl .= "CM";
							 $angka-=900;
						 }else{
							 $hsl .= "D";
							 $angka-=500;
						 }
					 }
				 }
				 while($angka>=100){
					 if($angka>=400){
						 $hsl .= "CD";
						 $angka-=400;
					 }else{
						 $angka-=100;
					 }
				 }
				 if($angka>=50){
					 if($angka>=90){
						 $hsl .= "XC";
						  $angka-=90;
					 }else{
						$hsl .= "L";
						$angka-=50;
					 }
				 }
				 while($angka>=10){
					 if($angka>=40){
						$hsl .= "XL";
						$angka-=40;
					 }else{
						$hsl .= "X";
						$angka-=10;
					 }
				 }
				 if($angka>=5){
					 if($angka==9){
						 $hsl .= "IX";
						 $angka-=9;
					 }else{
						$hsl .= "V"; 
						$angka-=5;
					 }
				 }
				 while($angka>=1){
					 if($angka==4){
						$hsl .= "IV"; 
						$angka-=4;
					 }else{
						$hsl .= "I";
						$angka-=1;
					 }
				 }
			}
			return ($hsl);
	}

}
