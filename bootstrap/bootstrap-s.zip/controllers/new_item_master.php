<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class New_item_master extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_new_item_master');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_new_item_master->getAll();
		$data['content'] = 'view_new_item_master/index';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$this->m_new_item_master->insert($data);
		redirect('new_item_master');
	}
	public function lock($id){
		$data['ITEM_MASTER_STATUS_LOCK']=1;
		$this->m_new_item_master->update($data,$id);
		redirect('new_item_master');
	}
	public function unlock($id){
		$data['ITEM_MASTER_STATUS_LOCK']="NULL";
		$this->m_new_item_master->update($data,$id);
		redirect('new_item_master');
	}
	public function delete(){
		$data['ITEM_MASTER_STATUS_DELETE']=1;
		$this->m_new_item_master->update($data,$id);
		redirect('new_item_master');
	}
	public function preupdate($id){
		$data['data'] = $this->m_new_item_master->get($id);
		$this->load->view('view_new_item_master/edit_item_master',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$data['ITEM_MASTER_REV_NO'] = $data['ITEM_MASTER_REV_NO']+1;
		 $this->m_new_item_master->update($data,$id);
		 // $status = $data['revisi_no_do']+1;
		// $this->m_deliver_order->updaterevno($status,$id);
		redirect('new_item_master');
	}
	public function history_update($id){
		$data['data'] = $this->m_new_item_master->getAllHistory($id);
		$data['content'] = 'view_new_item_master/index_history';
		$this->load->view('template/template',$data);
	}
}