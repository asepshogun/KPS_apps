<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bsthp extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_bsthp');
		$this->load->model('m_label');
		$this->load->model('m_bsthp_detail');
		$this->load->model('m_bsthp_detail_sub');
		$this->load->model('m_employee');
		$this->load->model('m_loi');

	}
	public function index()
	{
		$data['data'] = $this->m_bsthp->getAll();
		$data['dataEmp'] = $this->m_employee->getAll();
		$data['dataNull'] = $this->m_bsthp->getDataNullForLockAdd();
		$datas = $this->m_bsthp->getAll();
		$data['barcode'] = date('Ymd')."".count($datas)+1;
		$data['content'] = 'production/v_bsthp';
		$this->load->view('template/template',$data);
	}
	public function history($id)
	{
		$data['data'] = $this->m_bsthp->getAllHistory($id);
		$data['content'] = 'production/v_bsthp_history';
		$this->load->view('template/template',$data);
	}
	public function lockHeader($id){
		$this->m_bsthp->updatelock($id);
		redirect('bsthp');
	}
	public function lock($id,$id_bsthp){
		$this->m_bsthp_detail->updatelock($id);
		redirect('bsthp/detail/'.$id_bsthp);
	}
	//Detail Start
	public function detail($id)
	{
		$data['id_bsthp'] = $id;
		$data['data'] = $this->m_bsthp_detail->getAll($id);
		$data['dataOnly'] = $this->m_bsthp->get($id);
		$data['dataLoi'] = $this->m_loi->getAll();
		$data['content'] = 'production/detail/bsthp';
		$this->load->view('template/template',$data);
	}
	public function historyDetail($id)
	{
		$data['data'] = $this->m_bsthp_detail->getAllHistory($id);
		$data['content'] = 'production/v_bsthp_history_detail';
		$this->load->view('template/template',$data);
	}
	public function add_detail(){
			// $dataLabel = $this->m_label->getLabelByBsthp($id);
			$data = $this->input->post();
			$this->m_bsthp_detail->insert($data);
			redirect('bsthp/detail/'.$this->input->post('KPS_BSTHP_ID_det'));
	}
	public function editDetail($id){
		$data['data'] = $this->m_bsthp_detail->getDet($id);
		$data['dataLoi'] = $this->m_loi->getAll();
		$this->load->view('production/v_edit_bsthp_detail',$data);
	}
	public function updateDetail(){
		$idBsthp=$this->input->post('KPS_BSTHP_ID_det');
		$idBsthpDetail=$this->input->post('KPS_BSTHP_DETAIL_ID');
		$data=$this->input->post();
		$dataBsthp['REV']=$dataBsthp['REV']+1;
		unset($data['KPS_BSTHP_ID_det']);
		unset($data['KPS_BSTHP_DETAIL_ID']);
		$this->m_bsthp->updateDetail($data,$idBsthpDetail);
		$this->m_bsthp->update($dataBsthp,$idBsthp);
		redirect('Bsthp/detail/'.$idBsthp);
	}
	//detail end
	// detail sub Start
	public function detail_sub($idet,$id="0",$pesan="0")
	{	if($pesan){
			if($pesan!="W"){
				$data['data'] = $this->m_bsthp_detail_sub->getAll($id);
				$data['dataOnly'] = $this->m_bsthp_detail->get($idet);
				// $data_bsthp = $this->m_bsthp_detail_sub->get_no($pesan);
				$data['pesan'] = $this->m_bsthp_detail_sub->get_no($pesan);
				$data['content'] = 'production/detail/bsthpsub_detail';
				$this->load->view('template/template',$data);
			}else{
				$data['data'] = $this->m_bsthp_detail_sub->getAll($id);
				$data['dataOnly'] = $this->m_bsthp_detail->get($idet);
				$data['pesan'] = $pesan;
				$data['content'] = 'production/detail/bsthpsub_detail';
				$this->load->view('template/template',$data);
			}
		}else{
			$data['data'] = $this->m_bsthp_detail_sub->getAll($id);
			$data['dataOnly'] = $this->m_bsthp_detail->get($idet);
			$data['pesan'] ="";
			$data['content'] = 'production/detail/bsthpsub_detail';
			$this->load->view('template/template',$data);
			}
	}	
	public function history_BSTHPDetailSub($id)
	{	
		$data['data'] = $this->m_bsthp_detail_sub->getAllHistory($id);
		$data['content'] = 'production/detail/bsthpsub_detail_history';
		$this->load->view('template/template',$data);
	}	
	public function preDelete($id){
		$data['data'] = $this->m_bsthp_detail_sub->getSelfData($id);
		$this->load->view('production/v_delete_bsthp_detail_sub',$data);
	}
	public function deleteDetailSub(){
		$data = $this->input->post();
		$id=$data['KPS_BSTHP_DETAIL_SUB_ID'];
		$idBsthp=$data['KPS_BSTHP_ID'];
		$idLabelBarcode=$data['KPS_BARCODE_LABEL_ID_BSTHP_SUB'];
		$idBsthpDetail=$data['KPS_BSTHP_DETAIL_ID'];
		$dataBSTHP_detail = $this->m_bsthp_detail->getDet($idBsthpDetail);
		$qtyItem=$dataBSTHP_detail->jumlah_qty_bsthp;
		$qtyBarcode=$dataBSTHP_detail->qty_barcode_bsthp;
		$codeLOI = $this->m_label->getLoiCode($idLabelBarcode);
		$dataSubDet['KPS_BSTHP_DETAIL_SUB_MADE_BY']=$data['KPS_BSTHP_DETAIL_SUB_MADE_BY'];
		$this->m_bsthp_detail_sub->update($dataSubDet,$id);
		$this->m_bsthp_detail_sub->delete($id);
		$this->m_label->updateStatusOTWToNol($idLabelBarcode);
		$dataTotal['jumlah_qty_bsthp']=$qtyItem-$codeLOI->QUANTITY;
		$dataTotal['qty_barcode_bsthp']=$qtyBarcode-1;
		$this->m_bsthp_detail->update($dataTotal,$idBsthpDetail);
		redirect('bsthp/detail_sub/'. $idBsthp ."/". $idBsthpDetail);
	}
		public function add_detail_sub(){
			// $dataLabel = $this->m_label->getLabelByBsthp($id);
			$data = $this->input->post();
			$barcode = substr($data['no_barcode_item'], 0, -3);
			$orderby = abs(substr($data['no_barcode_item'], -3));
			$dataLabel = $this->m_label->getIdbarcode($barcode,$orderby);
			$dataBSTHP_detail = $this->m_bsthp_detail->getDet($data['KPS_BSTHP_DETAIL_ID_SUB']);
			$qtyItem=$dataBSTHP_detail->jumlah_qty_bsthp;
			$qtyBarcode=$dataBSTHP_detail->qty_barcode_bsthp;
			$pesan="";
			$id_bsthpDet=$this->input->post('KPS_BSTHP_DETAIL_ID_SUB');
			$id_bsthpDet2=$this->input->post('KPS_BSTHP_ID_det');
			if(empty($dataLabel->BARCODE_LABEL_OTW)){
				$labelId = $dataLabel->kps_barcode_label_id;
				$codeLOI = $this->m_label->getLoiCode($labelId);
				$codeLOIfix=$codeLOI->LOI_CODE_ITEM;
				if($codeLOIfix==$data['LOICode']){
					$data['KPS_BARCODE_LABEL_ID_BSTHP_SUB'] = $labelId;
					unset($data['KPS_BSTHP_ID_det']);
					unset($data['LOICode']);
					unset($data['no_barcode_item']);
					$dataTotal['jumlah_qty_bsthp']=$qtyItem+$codeLOI->QUANTITY;
					$dataTotal['qty_barcode_bsthp']=$qtyBarcode+1;
					$this->m_bsthp_detail->update($dataTotal,$data['KPS_BSTHP_DETAIL_ID_SUB']);
					$this->m_bsthp_detail_sub->insert($data);
					$this->m_label->updateStatusOTW($labelId);
					$pesan=0;
				}else{
					$labelId = $dataLabel->kps_barcode_label_id;
					$data['KPS_BARCODE_LABEL_ID_BSTHP_SUB'] = $labelId;
					$pesan="W";
				}
			}else{
				$labelId = $dataLabel->kps_barcode_label_id;
				$data['KPS_BARCODE_LABEL_ID_BSTHP_SUB'] = $labelId;
				$pesan=$labelId;
			}
	redirect('bsthp/detail_sub/'.$id_bsthpDet2."/". $id_bsthpDet ."/".$pesan);
	}
// detail sub End
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_bsthp->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->NO+1;

		}
		$no = $year."/BSTHP-PRO/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data=$this->input->post();
		$data['NO_RECORD'] = $no;
		$data['NO'] = $revNoNew;

		$this->m_bsthp->insert($data);
		redirect('bsthp');
	}	
	

	public function delete($id){
		$this->m_bsthp->delete($id);
		redirect('bsthp');
	}
	public function prints($bsthpID)
	{
		$data['data'] = $this->m_bsthp->getDataPrint($bsthpID);
		$data['data_detail'] = $this->m_bsthp->getDataPrintDetail($bsthpID);
		$this->load->view('production/print_bsthp',$data);
	}
	public function edit($id){
		$data['dataEmp'] = $this->m_employee->getAll();
		$data['data'] = $this->m_bsthp->get($id);
		$this->load->view('production/v_edit_bsthp',$data);
	}
	public function update(){
		$id=$this->input->post('KPS_BSTHP_ID');
		$data=$this->input->post();
		if($data['REV']){
			$data['REV'] = $data['REV']+1;
		}else{
			 $data['REV']=1;
		}
		unset($data['KPS_BSTHP_ID']);
		$this->m_bsthp->update($data,$id);
		redirect('bsthp');
	}
	public function loadLoi(){
		$idCust = $this->input->post('id');
		$data = $this->m_label->getLoiByCust($idCust);
		// echo $this->db->last_query();
		?>
		<option>-- Select Part No - Nama - Model  --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_LOI_ID; ?>"><?php echo $value->LOI_PART_NO." - ".$value->LOI_PART_NAME." - ".$value->LOI_MODEL; ?></option>
			<?php
		}
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	function tampil_bulan ($x) {
    if ($x == 1 ) {
        $bulan = "Januari"; }
    if ($x == 2 ) {
        $bulan = "Februari"; }
    if ($x == 3 ) {
        $bulan = "Maret"; }
    if ($x == 4 ) {
        $bulan = "April"; }
    if ($x == 5 ) {
        $bulan = "Mei"; }
    if ($x == 6 ) {
        $bulan = "Juni"; }
    if ($x == 7 ) {
        $bulan = "Juli"; }
    if ($x == 8 ) {
        $bulan = "Agustus"; }
    if ($x == 9 ) {
        $bulan = "September"; }
    if ($x == 10) {
        $bulan = "Oktober"; }
    if ($x == 11) {
        $bulan = "November"; }
    if ($x == 12) {
        $bulan = "Desember"; }
    return $bulan;
}
}
