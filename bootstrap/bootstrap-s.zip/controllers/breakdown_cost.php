<?php
 if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Breakdown_Cost extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_breakdown_cost');
		$this->load->model('m_customer_information');
		$this->load->model('m_quotation');
		$this->load->model('m_req_quotation');
		$this->load->model('m_employee');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataRfq'] = $this->m_req_quotation->getAllOne();
		$data['data'] = $this->m_breakdown_cost->getAll();
		$data['content'] = 'sales_data/v_breakdown';
		$this->load->view('template/template',$data);
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_breakdown_cost->getLastId();
		$revNoNew = $lastNo->REV_NO_BREAK+1;
		$no = $year."/BR-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_BREAK'] = $no;
		$data['REV_NO_BREAK'] = $revNoNew;
		$data['NOTE'] = '';
		$data['TOTAL_ITEM'] = 0;
		// $revNo = 
		$this->m_breakdown_cost->insert($data);
		redirect('breakdown_cost');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_breakdown_cost_material"){
			$data['SUB_TOTAL'] = $data['QTY_BRUTTO']*$data['PRICE'];
		}
		if($table=="kps_breakdown_cost_manufacturing"){
			$data['AMOUNT'] = $data['TIME']*$data['CHARGE'];
		}
		$this->m_breakdown_cost->insertData($table,$data);
		redirect('breakdown_cost/detail/'.$data['KPS_BREAKDOWN_COST_ID']);
	}
	public function pre_print($id){
		$idbrek = $this->m_breakdown_cost->getDetail($id);
		$data['detail'] = $this->m_breakdown_cost->getDetail($id);
		$data['detailx'] = $this->m_req_quotation->get($idbrek->KPS_RFQ_ID);
		$data['drawing'] = $this->m_req_quotation->getDrawingsx($idbrek->KPS_RFQ_ID);
		$data['pp'] = $this->m_req_quotation->getPPsx($idbrek->KPS_RFQ_ID);
		$data['dep'] = $this->m_breakdown_cost->getDeprex($id);
		$data['tool'] = $this->m_breakdown_cost->getTool($id);
		$data['part'] = $this->m_breakdown_cost->getPart($id);
		$data['material'] = $this->m_breakdown_cost->getMaterial($id);
		$data['manu'] = $this->m_breakdown_cost->getManu($id);
		$data['partpart'] = $this->m_breakdown_cost->getPartPart();
		$data['product'] = $this->m_breakdown_cost->getProduct();
		$data['data'] = $this->m_breakdown_cost->getDetail($id);
		$data['content'] = 'sales_data/detail/breakdown_cost';		
		$this->load->view('sales_data/print/v_pre_print_breakdown',$data);
	}
	public function detail($id)
	{
		$idbrek = $this->m_breakdown_cost->getDetail($id);
		$data['pp'] = $this->m_req_quotation->getPPAllx($idbrek->KPS_RFQ_ID);
		$data['dep'] = $this->m_breakdown_cost->getDepre($id);
		$data['tool'] = $this->m_breakdown_cost->getTool($id);
		$data['part'] = $this->m_breakdown_cost->getPart($id);
		$data['material'] = $this->m_breakdown_cost->getMaterial($id);
		$data['manu'] = $this->m_breakdown_cost->getManu($id);
		$data['partpart'] = $this->m_breakdown_cost->getPartPart();
		$data['product'] = $this->m_breakdown_cost->getProduct();
		$data['data'] = $this->m_breakdown_cost->getDetail($id);
		$data['content'] = 'sales_data/detail/breakdown';
		$this->load->view('template/template',$data);
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_breakdown_cost->geth($id);
		$data['content'] = 'sales_data/history/history_break';
		$this->load->view('template/template',$data);
	}
	public function countBreakdownCost($id){
		$dataBd=$this->m_breakdown_cost->get($id);
		$dep = $this->m_breakdown_cost->getDepre($id);
		$manu = $this->m_breakdown_cost->getManu($id);
		$material = $this->m_breakdown_cost->getMaterial($id);
		$tool = $this->m_breakdown_cost->getTool($id);
		$part = $this->m_breakdown_cost->getPart($id);

		$totalDep = 0;
		$totalManu = 0;
		$totalMaterial = 0;
		$totalTools = 0;
		$totalPart = 0;
		$item = 0;
		foreach ($dep as $valDep) {
			$totalDep += $valDep->qty_unit*$valDep->qty_month*$valDep->periode;
			$item++;
		}
		foreach ($manu as $valManu) {
			$totalManu += $valManu->AMOUNT;
			$item++;
		}
		foreach ($material as $valMaterial) {
			$totalMaterial += $valMaterial->SUB_TOTAL;
			$item++;
		}
		foreach ($tool as $valTool) {
			$totalTools += $valTool->COST;
			$item++;
		}
		foreach ($part as $valPart) {
			$totalPart += $valPart->COST;
			$item++;
		}

		$sub_total_breakdown = $totalMaterial+$totalPart+$totalManu;
		$toolingCost = $totalTools/$totalDep;
		$totalBreakdown = $sub_total_breakdown+$dataBd->packing_charge+$dataBd->transportation_charge+$toolingCost+((($dataBd->overhead_profit)/100)*$sub_total_breakdown);

		$dataUpdate = array(
			'TOTAL_ITEM' => $item,
			'TOTAL_DEPRECIATION' => $totalDep,
			'TOTAL_MATERIAL' => $totalMaterial,
			'TOTAL_MANUFACTURING' => $totalManu,
			'TOTAL_TOOLING' => $totalTools,
			'TOTAL_PART_COST' => $totalPart,
			'sub_total_breakdown' => $sub_total_breakdown,
			'TOOLING_COST' => $toolingCost,
			'total_breakdown' => $totalBreakdown
		);
		print_r($dataUpdate);
		$this->m_breakdown_cost->update($dataUpdate,$id);
		redirect('breakdown_cost/detail/'.$id);
	}
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCustomer'] = $this->m_customer_information->getAll();
		$data['dataRFQ'] = $this->m_req_quotation->getAll();
		$data['data'] = $this->m_breakdown_cost->get($id);
		$this->load->view('sales_data/v_edit_breakdown',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_breakdown_cost->update($data,$id);
		$status = $data['revisi_no_break']+1;
		$this->m_breakdown_cost->updaterevno($status,$id);
		redirect('breakdown_cost');
	}


public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$idbrek = $this->m_breakdown_cost->getDetail($id);
		$data['pp'] = $this->m_req_quotation->getPPAllx($idbrek->KPS_RFQ_ID);
		$data['partpart'] = $this->m_breakdown_cost->getPartPart();
		$data['product'] = $this->m_breakdown_cost->getProduct();
	
		$data['data'] = $this->m_quotation->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		if($table=="kps_breakdown_cost_material"){
			$data['SUB_TOTAL'] = $data['QTY_BRUTTO']*$data['PRICE'];
		}
		if($table=="kps_breakdown_cost_manufacturing"){
			$data['AMOUNT'] = $data['TIME']*$data['CHARGE'];
		}
		$this->m_quotation->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_breakdown_cost->get($idRef);
		$status = $data->revisi_no_break+1;
		$this->m_breakdown_cost->updaterevno($status,$idRef);
		redirect('breakdown_cost/detail/'.$idRef);
	}
	public function loadProd(){
		$id = $this->input->post('id');
		$data = $this->m_breakdown_cost->getProd($id);
	    header('Content-Type: application/json');
    	echo json_encode( $data );
	}
	public function lock($id){
		$status = "1";
		$this->m_breakdown_cost->lock($status,$id);
		redirect('breakdown_cost');
	}
	public function unlock($id){
		$status = "0";
		$this->m_breakdown_cost->unlock($status,$id);
		redirect('breakdown_cost');
	}

}
