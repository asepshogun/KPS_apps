<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_Execution_Other extends CI_Controller {

	public function index()
	{
		$data['content'] = 'warehouse/v_delivery_execution_other';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}

	public function edit($id){
	
	}

	public function delete($id){
	
	}

	public function detail(){
		$data['content'] = 'warehouse/detail/delivery_execution_other';
		$this->load->view('template/template',$data);
	}

	public function execution(){
		$data['content'] = 'warehouse/detail/delivery_execution_other2';
		$this->load->view('template/template',$data);
	}

}
