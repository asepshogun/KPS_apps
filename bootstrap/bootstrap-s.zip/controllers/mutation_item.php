<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mutation extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_mutation');
		$this->load->model('m_customer_information');
		$this->load->model('m_loi');
	}
	public function index()
	{
		$data['data'] = $this->m_mutation->getAll();
		$data['content'] = 'ppic/v_mutation_item';
		$this->load->view('template/template',$data);
	}
	public function detail($id){
		$data['dataOnly']=$this->m_mutation->get($id);
		// $data['data'] = $this->m_bsthp_detail_sub->getAll($id);
		$data['content'] = 'ppic/detail/mutation_item_detail';
		$this->load->view('template/template',$data);
	}
	public function add(){
		if($this->input->post()){
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_mutation->getLastId();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->REV+1;

			}
			$no = $year."/MTT-PPIC/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data=$this->input->post();
			$data['NO'] = $no;
			$data['MUTATION_REV_NO'] = $revNoNew;
			unset($data['KPS_CUSTOMER_LIST_ID']);
			unset($data['KPS_CUSTOMER_LIST_ID2']);
			$this->m_mutation->insert($data);
			redirect('mutation');

		}else{
		$data['dataCust'] = $this->m_customer_information->getAll();
		// $data['dataEmp'] = $this->m_employee->getAll();
		$data['dataLoi'] = $this->m_loi->getAll();
		$this->load->view('ppic/add/pop_up_add_mutation',$data);
				// $this->load->view('production/label/pop_up_add_label',$data);

		}
	}
	public function loadProduct(){
		$id = $this->input->post('id');
		$data = $this->m_mutation->getLoiByCust($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_LOI_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
		    <?php } 
	}
	public function loadloi(){
		$id = $this->input->post('id');
		$data = $this->m_mutation->getLoiByCust($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_LOI_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
		    <?php } 
	}
	public function edit($id){
		$data['data'] = $this->m_mutation->get($id);
		$this->load->view('mutation/v_edit_vehicle',$data);
	}
	public function lock($id){
		$this->m_mutation->updatelock($id);
		redirect('mutation');
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_mutation->update($data,$id);
		redirect('vehicle');
	}
	public function KonDecRomawi($angka){
		$hsl = "";
		if($angka<1||$angka>3999){
			$hsl = "Batas Angka 1 s/d 3999";
		}else{
			 while($angka>=1000){
				 $hsl .= "M";
				 $angka -= 1000;
			 }
			 if($angka>=500){
					 if($angka>500){
						 if($angka>=900){
							 $hsl .= "CM";
							 $angka-=900;
						 }else{
							 $hsl .= "D";
							 $angka-=500;
						 }
					 }
				 }
				 while($angka>=100){
					 if($angka>=400){
						 $hsl .= "CD";
						 $angka-=400;
					 }else{
						 $angka-=100;
					 }
				 }
				 if($angka>=50){
					 if($angka>=90){
						 $hsl .= "XC";
						  $angka-=90;
					 }else{
						$hsl .= "L";
						$angka-=50;
					 }
				 }
				 while($angka>=10){
					 if($angka>=40){
						$hsl .= "XL";
						$angka-=40;
					 }else{
						$hsl .= "X";
						$angka-=10;
					 }
				 }
				 if($angka>=5){
					 if($angka==9){
						 $hsl .= "IX";
						 $angka-=9;
					 }else{
						$hsl .= "V"; 
						$angka-=5;
					 }
				 }
				 while($angka>=1){
					 if($angka==4){
						$hsl .= "IV"; 
						$angka-=4;
					 }else{
						$hsl .= "I";
						$angka-=1;
					 }
				 }
			}
			return ($hsl);
	}

}
