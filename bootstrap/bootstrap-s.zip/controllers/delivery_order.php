<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_Order extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_deliver_order');
		$this->load->model('m_customer_information');
		$this->load->model('m_outgoing_finished');
		$this->load->model('m_employee');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function monitoringDo(){
	$data['data'] = $this->m_deliver_order->getAllMonitoringConfirm();
	$data['content'] = 'sales_data/v_monitoring_delivery_order_confirm';
	$this->load->view('template/template',$data);
	}
	public function index()
	{
		$data['data'] = $this->m_deliver_order->getAll();
		$data['dataPlant'] = $this->m_customer_information->getPlantAll();
		$data['dataOut'] = $this->m_outgoing_finished->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();

		$data['content'] = 'sales_data/v_delivery_order';
		$this->load->view('template/template',$data);
	}
	public function pre_print($id){
		$this->m_deliver_order->updateStatusPrint($id);
		$data['detail'] = $this->m_deliver_order->getALLId($id);	
		$data['data'] = $this->m_deliver_order->getDetailForDO($id);		
		$this->load->view('sales_data/print/v_pre_print_delivery_order',$data);
	}
	public function confirmation($id)
	{
		$data['id'] = $id;
		$data['data'] = $this->m_deliver_order->getConfirm($id);
		$data['dataOnly']=$this->m_deliver_order->get($id);
		$this->load->view('sales_data/v_delivery_order_confirmation',$data);
	}
	public function addSubConfirmation($table){
		$data=$this->input->post();
		$this->m_deliver_order->insertData($table,$data);
		// echo $str = $this->db->last_query();
		redirect('delivery_order');
	}
	public function updateConfirmCustomer(){
		$data=$this->input->post();
		$id=$data['KPS_DELIVERY_ORDER_CONFIRM_ID'];
		unset($data['KPS_DELIVERY_ORDER_CONFIRM_ID']);
		$this->m_deliver_order->updateDetail("kps_delivery_order_confirm","KPS_DELIVERY_ORDER_CONFIRM_ID",$data,$id);
		redirect('delivery_order');
	}
	public function confirmRevisi($id){
		$this->m_deliver_order->confirmRefisiStatus($id);
		redirect('delivery_order');
	}
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_deliver_order->getLastId();
		if(empty($lastNo)){
			$revNoNew = 1;
		}else{
			$revNoNew = $lastNo->REV_NO_DO+1;

		}
		$no = $year."/DO-SLS/".$revNoNew; 
		
		$data['NO_DO'] = $no;
		$data['REV_NO_DO'] = $revNoNew;
		$data['TOTAL_QTY'] = 0;
		unset($data['KPS_CUSTOMER_ID_BK']);
		$this->m_deliver_order->insert($data);
		redirect('delivery_order');
	}
	public function addSub($table){
		$data=$this->input->post();
		$this->m_deliver_order->insertData($table,$data);
		echo $str = $this->db->last_query();
		
		redirect('delivery_order/confirmation/'.$data['OUTGOING_DETAIL']);
	}
	public function detail($id)
	{
		$data['code'] = $this->m_deliver_order->getCode();
		$datas = $this->m_deliver_order->get($id);
		$data['data'] = $this->m_deliver_order->get($id);
		$data['outgoing'] = $this->m_outgoing_finished->getAll();
		$data['detail'] = $this->m_deliver_order->getDetail($datas->KPS_OUTGOING_FINISHED_GOOD_ID_DO);
		$detail = $this->m_deliver_order->getDetail($id);
		$total=0;
		foreach($detail as $value){
			$total += $value->QTY_DELIVERY_EXECUTION;
		}
		$data['total'] = $total;
		$this->m_deliver_order->updatetot($id,$total);
		$data['content'] = 'sales_data/detail/delivery_order';
		$this->load->view('template/template',$data);
	}
	public function edit($id){
		$data['dataPlant'] = $this->m_customer_information->getPlantAll();
		$data['dataOut'] = $this->m_outgoing_finished->getAll();
		$data['dataEmployee'] = $this->m_employee->getAll();
		
		$data['data'] = $this->m_deliver_order->get($id);
		$this->load->view('sales_data/v_edit_delivery_order',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		
		unset($data['id']);
		 $this->m_deliver_order->update($data,$id);
		 $status = $data['revisi_no_do']+1;
		$this->m_deliver_order->updaterevno($status,$id);
		redirect('delivery_order');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$data['code'] = $this->m_deliver_order->getCode();

		$data['data'] = $this->m_deliver_order->getTableDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_deliver_order->updateDetail($table,$tableId,$data,$id);
		 $data = $this->m_deliver_order->get($idRef);
		$status = $data->revisi_no_do+1;
		$this->m_deliver_order->updaterevno($status,$idRef);
		redirect('delivery_order/detail/'.$idRef);
	}
	public function loadOutgoing(){
		$id = $this->input->post('id');
		$data = $this->m_deliver_order->getAllByCustomerForDO($id);
		?>
		<option>-- Select Delivery Schedule --</option>								
		  <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_ID;?>"><?php echo $value->NO_OUTGOING;?></option>
	<?php } 

	}
	public function loadPlant(){
		$id = $this->input->get('id');
		$data = $this->m_deliver_order->getPlant($id);
		?>
		<option>-- Select Plant --</option>								
		<?php
		foreach ($data as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_PLANT_ID;?>">
			 	<?php echo $value->PLANT;?></option>	
			<?php
		}
	}
	public function loadProduct(){
		$id = $this->input->post('id');
		$data = $this->m_outgoing_finished->getDetailProduct($id);
		?>
				<option>-- Select Product --</option>								

		<?php foreach ($data as $value) { ?>
		    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>">
		    	<?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO." - ".$value->LOI_PART_NAME." - ".$value->DELIVERY_PLAN?></option>
		    <?php 
		} 
	}
	public function lock($id){
		$status = "1";
		$this->m_deliver_order->lock($status,$id);
		redirect('delivery_order');
	}
	public function unlock($id){
		$status = "0";
		$this->m_deliver_order->unlock($status,$id);
		redirect('delivery_order');
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_deliver_order->geth($id);
		$data['content'] = 'sales_data/history/history_do';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_deliver_order->del($status,$id);
		redirect('delivery_order');
	}
	public function undel($id){
		$status = "0";
		$this->m_deliver_order->undel($status,$id);
		redirect('delivery_order');
	}

}