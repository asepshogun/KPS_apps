<?php 
ini_set('display_errors', 1);

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Request_Quotation extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		 $this->load->helper('exportpdf_helper');     
		$this->load->model('m_req_quotation');
		$this->load->model('m_customer_information');
		$this->load->model('m_employee');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCustomer'] = $this->m_customer_information->getAll();
		$data['data'] = $this->m_req_quotation->getAll();
		//$data['datah'] = $this->m_req_quotation->getAllh();
		$data['content'] = 'sales_data/v_request_quotation';
		$this->load->view('template/template',$data);
	}
	public function pre_print($id){
		$data['detail'] = $this->m_req_quotation->get($id);
		$data['attach'] = $this->m_req_quotation->getAttach($id);
		$data['drawing'] = $this->m_req_quotation->getDrawing($id);
		$data['part'] = $this->m_req_quotation->getPart($id);
		$data['pp'] = $this->m_req_quotation->getPP($id);
		$data['schedule'] = $this->m_req_quotation->getSchedule($id);
		$data['price'] = $this->m_req_quotation->getPrice($id);
		$data['curr'] = $this->m_req_quotation->getCurr($id);
		//$data['datas'] = $this->m_req_quotation->get($id);
		$data['content'] = 'sales_data/detail/request_quotation';		
		$this->load->view('sales_data/print/v_pre_print_rfq',$data);
	}
	public function lock($id){
		$status = "1";
		$this->m_req_quotation->lock($status,$id);
		redirect('request_quotation');
	}
	public function unlock($id){
		$status = "0";
		$this->m_req_quotation->unlock($status,$id);
		redirect('request_quotation');
	}
	public function history($id)
	{
		
		$data['datas'] = $this->m_req_quotation->geth($id);
		$data['content'] = 'sales_data/history/history_rfq';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_req_quotation->del($status,$id);
		redirect('request_quotation');
	}
	public function undel($id){
		$status = "0";
		$this->m_req_quotation->undel($status,$id);
		redirect('request_quotation');
	}		
	public function add(){
		$data=$this->input->post();
		$year = date('y');
		$month = date('m');
		$lastNo = $this->m_req_quotation->getLastId();
		$revNoNew = $lastNo->RFQ_REV_NO+1;
		$no = $year."/RFQ-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
		
		$data['NO_RFQ'] = $no;
		$data['RFQ_REV_NO'] = $revNoNew;

		$this->m_req_quotation->insert($data);
		redirect('request_quotation');
	}
	public function addSub($table){
		$data=$this->input->post();
		if($table=="kps_rfq_drawing"){
			$year = date('y');
			$month = date('m');
			$data['DRAWING_DATE'] = date('y-m-d');
			$lastNo = $this->m_req_quotation->getLastIdDrawing();
			$revNoNew = $lastNo->REV_DRAWING+1;
			$no = $year."/DWG-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data['DRAWING_NO'] = $no;
			$data['REV_NO'] = $revNoNew;

		}
		if($table=="kps_rfq_attachment"){
		 $data['FILENAME'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['allowed_types'] = $ext.'|'.$fileType;
			$config['upload_path'] = "./uploads/rq/";

			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
		}
		// print_r($data);
		$this->m_req_quotation->insertData($table,$data);
		redirect('request_quotation/detail/'.$data['KPS_RFQ_ID']);
	}
	public function detail($id)
	{
		$data['attach'] = $this->m_req_quotation->getAttach($id);
		$data['drawing'] = $this->m_req_quotation->getDrawings($id);
		$data['drawing_'] = $this->m_req_quotation->getDrawingsh($id);
		$data['part'] = $this->m_req_quotation->getPart($id);
		$data['pp'] = $this->m_req_quotation->getPPs($id);
		$data['schedule'] = $this->m_req_quotation->getSchedule($id);
		$data['price'] = $this->m_req_quotation->getPrice($id);
		$data['curr'] = $this->m_req_quotation->getCurr($id);
		$data['datas'] = $this->m_req_quotation->get($id);
		$data['content'] = 'sales_data/detail/request_quotation';
		$this->load->view('template/template',$data);
	}
	
	// public function del($id){
		// $status = "1";
		// $this->m_req_quotation->del($status,$id);
		// redirect('request_quotation');
	// }
	// public function undel($id){
		// $status = "0";
		// $this->m_req_quotation->undel($status,$id);
		// redirect('request_quotation');
	// }
	public function edit($id){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCustomer'] = $this->m_customer_information->getAll();


		$data['data'] = $this->m_req_quotation->get($id);
		$this->load->view('sales_data/v_edit_request_quotation',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_req_quotation->update($data,$id);
		$status = $data['revisi_no_rfq']+1;
		$this->m_req_quotation->updaterevno($status,$id);
		redirect('request_quotation');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function editDetail($id,$view,$table,$tableId){
		$data['pp'] = $this->m_req_quotation->getPP($id);
		$data['data'] = $this->m_req_quotation->getDetail($table,$tableId,$id);
		$this->load->view('sales_data/detail/'.$view,$data);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['KPS_RFQ_ID'];
		unset($data['id']);
		unset($data['KPS_RFQ_ID']);
		
		if($table=="kps_rfq_attachment"){
			$data['FILENAME'] = $_FILES['FILENAME']['name'];
			$ext=preg_replace("/.*\.([^.]+)$/","\\1", $_FILES['FILENAME']['name']);
			$fileType=$_FILES['FILENAME']['type'];
			$config['allowed_types'] = $ext.'|'.$fileType;
			$config['upload_path'] = "./uploads/rq/";
			
			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('FILENAME'))
			{
				echo $this->upload->display_errors();
				echo "error";
			}
			else
			{
				echo "success";
			}
		}
		$this->m_req_quotation->updateDetail($table,$tableId,$data,$id);
		$data = $this->m_req_quotation->get($idRef);
		$status = $data->revisi_no_rfq+1;
		$this->m_req_quotation->updaterevno($status,$idRef);
		redirect('request_quotation/detail/'.$idRef);
	}
	public function exportpdf($id){
		$ret = '';
		$data = $this->m_req_quotation->excelexport($id);
		print_r($data);
		$res['data'] = $data;
		$pdf_filename = $data[0]->NO_RFQ."_".date('Ymdhis').".pdf";

		$user_info = $this->load->view('rptexcel/pdf', $res, true);
		$output = $user_info;
		generate_pdf($output, $pdf_filename);

		echo $output;
	}
	public function exportexcel($id){
		
        $res['data'] = $this->m_req_quotation->excelexport($id);
        $this->load->view('rptexcel/excelexportbeta',$res);
	}
	public function exportexcelpre($id){
	    $res['data'] = $this->m_req_quotation->excelexport($id);
        $this->load->view('rptexcel/excelexportpreview',$res);
	}

}
