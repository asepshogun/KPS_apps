<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Retur extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/v_retur';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

	public function detail(){
		$data['content'] = 'production/detail/retur';
		$this->load->view('template/template',$data);
	}

	public function monitoring(){
		$data['content'] = 'production/monitoring/v_retur_production_monitoring';
		$this->load->view('template/template',$data);
	}

}
