<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_userdata');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
			$data['content'] = 'dashboard/v_dashboard';
			$this->load->view('template/template',$data);
	}

}
