<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Total_Sales_Monthly_Analize extends CI_Controller {

	public function index()
	{
		$data['content'] = 'report_management/v_total_sales_monthly_analize';
		$this->load->view('template/template',$data);
	}

	public function detail(){
		$data['content'] = 'report_management/detail/total_sales_monthly_analize';
		$this->load->view('template/template',$data);
	}
}
