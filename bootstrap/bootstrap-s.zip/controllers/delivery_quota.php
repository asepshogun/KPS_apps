<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery_quota extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_vehicle');
		$this->load->model('m_delivery_quota');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function index()
	{
		$data['data'] = $this->m_vehicle->getAll();
		$data['content'] = 'ppic/v_delivery_quota';
		$this->load->view('template/template',$data);
	}
	public function detail($id)
	{
		$data['data'] = $this->m_vehicle->get($id);
		$data['datax'] = $this->m_vehicle->getdate($id);
		$gettot = $this->m_vehicle->getdate($id);
		$totalx1 = 0;
		$totalx2 = 0;
		$totaly1 = 0;
		$totaly2 = 0;
		$totalxy1 = 0;
		$totalxy2 = 0;
		$total = 0;
		foreach ($gettot as $value) {
			if($value->PLANT1_LOCAL_JABOTABEK == "Jabotabek"){
		
			$totalx1 += $value->COD_JABODETABEK;
			$totalx2 += $value->COD_JABODETABEK-$value->TOTALS;
			}else{

			$totaly1 += $value->COD_LOCAL;
			$totaly2 += $value->COD_JABODETABEK-$value->TOTALS;
			}
		$totalxy1 = $totalx1 + $totaly1;
		$totalxy2 = $totalx2 + $totaly2;
		$total += $value->TOTALS;
		}

		$datas['TOTAL_STANDARD'] = $totalxy1;
		$datas['TOTAL_ACTUAL'] = $totalxy2;
		$datas['TOTAL_PROFIT'] = $total;

		$this->m_vehicle->update($datas,$id);
		$data['content'] = 'ppic/detail/delivery_quota';
		//print_r($data);
		$this->load->view('template/template',$data);
	}
}