<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pesanan extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_schedule');
		$this->load->model('m_pesanan');
		$this->load->model('m_employee');
		$this->load->model('m_customer_information');
		$this->load->model('m_currency');
		$this->load->model('m_quotation');
		$this->load->model('m_loi');
		if(!$this->session->userdata('username')){
			redirect('login');
		}
	}
	public function deleteDetail($idBpDet){
		$cekData=$this->m_pesanan->cekPesananDet($idBpDet);
		if($cekData){
			$data['data']=$cekData;
			$this->load->view('sales_data/detail/v_delete_bp_detail_warning',$data);
		}else{
			$data['data']=$this->m_pesanan->cekPesananDetForDel($idBpDet);
			$this->load->view('sales_data/detail/v_delete_bp_detail',$data);
		}
		
	}
	public function deleteDetailBp(){
		$data=$this->input->post();
		$KPS_BUKTI_PESANAN_DETAIL_ID=$data['KPS_BUKTI_PESANAN_DETAIL_ID'];
		$KPS_BUKTI_PESANAN_ID=$data['KPS_BUKTI_PESANAN_ID'];
		$datas['MADE_BY_BP_detail']=$data['MADE_BY_BP_detail'];
		$datas['KPS_BP_DETAIL_STATUS_DEL']=1;
		$this->m_pesanan->updateDetailFix($datas,$KPS_BUKTI_PESANAN_DETAIL_ID);
		$this->m_pesanan->deleteDetail($KPS_BUKTI_PESANAN_DETAIL_ID);
		redirect('pesanan/detail/'.$KPS_BUKTI_PESANAN_ID);
	}
	public function editDetail($KPS_BUKTI_PESANAN_DETAIL_ID){
		$data['data']=$this->m_pesanan->cekPesananDetForDel($KPS_BUKTI_PESANAN_DETAIL_ID);
		$this->load->view('sales_data/detail/v_update_bp_detail',$data);
	}
	public function updateDetailBp(){
		$data=$this->input->post();
		$KPS_BUKTI_PESANAN_DETAIL_ID=$data['KPS_BUKTI_PESANAN_DETAIL_ID'];
		$KPS_BUKTI_PESANAN_ID=$data['KPS_BUKTI_PESANAN_ID'];
		$qtyBuktipesananDet=$data['QUANTITY'];
		$dataDsDetail=$this->m_schedule->getDsForDelete($KPS_BUKTI_PESANAN_DETAIL_ID);
		$dataUpdateBp['QUANTITY']=$data['QUANTITY'];
		foreach($dataDsDetail as $values){
			$idDsDet = $values->KPS_DELIVERY_SCHEDULE_DETAIL_ID;
			$qtyBuktipesananDet=$qtyBuktipesananDet-$values->QUANTITY_DELIVERY;
			$datas['REMAINING_QUANTITY'] =$qtyBuktipesananDet;
			$this->m_schedule->updateFordelete($datas,$idDsDet);
		}
			$this->m_pesanan->updateDetailFix($dataUpdateBp,$KPS_BUKTI_PESANAN_DETAIL_ID);
		redirect('pesanan/detail/'.$KPS_BUKTI_PESANAN_ID);
	}
	//revisi buktipesanan TX non TX Start
	public function indexNt()
	{
		$data['data'] = $this->m_pesanan->getAllNT();	
		$data['dataCust'] = $this->m_customer_information->getAllNT();
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCurr'] = $this->m_currency->getAll();
		// $data['dataCurr'] = $this->m_currency->getAll();
		$data['statusTx']="NT";
		$data['content'] = 'sales_data/v_pesanan';
		$this->load->view('template/template',$data);
	}
	
	
	
	public function index()
	{
		$data['data'] = $this->m_pesanan->getAllTX();	
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAllTX();
		$data['dataCurr'] = $this->m_currency->getAll();
		// $data['dataCurr'] = $this->m_currency->getAll();
		$data['statusTx']="TX";
		$data['content'] = 'sales_data/v_pesanan';
		$this->load->view('template/template',$data);
	}
	
	public function preAdd($status){
		$data['dataCust']="";
		if($status=="NT"){
		$data['dataCust'] = $this->m_customer_information->getAllNT();
		$data['statusTx']="NT";
		}else{
		$data['dataCust'] = $this->m_customer_information->getAllTX();
		$data['statusTx']="TX";
		}
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCurr'] = $this->m_currency->getAll();
		$this->load->view('sales_data/add/pop_up_add_bp',$data);
	} 
	public function add($status){
		if($status=="TX"){
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_pesanan->getLastId();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->NO_REV_BP+1;

			}
			$no = $year."/PO-SLS/".$this->KonDecRomawi($month)."/".$revNoNew; 
			
			$data['REV_NO_BP'] = $no;
			$data['NO_REV_BP'] = $revNoNew;
			$cekNOPO = $this->m_pesanan->cekNO($data['PO_OS_NO_FROM_CUSTOMER']);
			if(count($cekNOPO)!=0){
				$this->session->set_flashdata('errorNOPO', 'Terdapat duplikasi PO No Customer');
				redirect('pesanan');
			}else{
				$this->m_pesanan->insert($data);
				redirect('pesanan');
			}
			
		}else{
			$data=$this->input->post();
			$year = date('y');
			$month = date('m');
			$lastNo = $this->m_pesanan->getLastIdNT();
			if(empty($lastNo)){
				$revNoNew = 1;
			}else{
				$revNoNew = $lastNo->KPS_BP_NO_URUT_BP_NT+1;

			}
			$no = $year."/PO-SLSR/".$this->KonDecRomawi($month)."/".$revNoNew; 
			$data['REV_NO_BP'] = $no;
			$data['KPS_BP_NO_URUT_BP_NT'] = $revNoNew;

			$cekNOPO = $this->m_pesanan->cekNO($data['PO_OS_NO_FROM_CUSTOMER']);
			if(count($cekNOPO)!=0){
				$this->session->set_flashdata('errorNOPO', 'Terdapat duplikasi PO No Customer');
				redirect('pesanan/indexNt');
			}else{
				$this->m_pesanan->insert($data);
			redirect('pesanan/indexNt');
			}
			
		}
	}
	//revisi buktipesanan TX non TX end
	public function history($id)
	{
		
		$data['datas'] = $this->m_pesanan->geth($id);
		$data['content'] = 'sales_data/history/history_pesanan';
		$this->load->view('template/template',$data);
	}
	public function del($id){
		$status = "1";
		$this->m_pesanan->del($status,$id);
		redirect('pesanan');
	}
	public function undel($id){
		$status = "0";
		$this->m_pesanan->undel($status,$id);
		redirect('pesanan');
	}
	//revisi PAP start

	public function loadPap(){
	$id = $this->input->get('id');
	$data=$this->m_customer_information->get($id);
	echo $data->CIS_PAYMENT_TO_PERSONAL;
	}
	public function loadSelectPap(){
		$id = $this->input->get('id');
		$data=$this->m_customer_information->get_Pap($id);
		if($data){
		// print_r($data);
		?>
			<option>-- Select Name --</option>								
			<?php
			foreach ($data as $value) {
				?>
				 <option value="<?php echo $value->KPS_CUSTOMER_PAP_ID;?>"><?php echo $value->KPS_PAP_NAME;?></option>
				<?php
			}
		}else{
		?>
		<option>-- Select Name --</option>
		<?php
		}
	}
	// revisi PAP end
	public function pre_print($id){
		$data['detail'] = $this->m_pesanan->get($id);
		$data['detailx'] = $this->m_pesanan->getDetailPesanan($id);
		$this->load->view('sales_data/print/v_pre_print_pesanan',$data);
	}
	
	public function addSub($table){
		$data=$this->input->post();
		$buktiPesanan = $this->m_pesanan->get($data['KPS_BUKTI_PESANAN_ID']);
		$subtotal = $buktiPesanan->SUB_TOTAL_BP;
		$amount = $data['price']*$data['QUANTITY'];
		$subtotal += $amount;
		$tax = $subtotal * 0.1;
		$total = $subtotal + $tax; 
		$dataUpdate = array(
			'SUB_TOTAL_BP' => $subtotal,
			'TAX_BP' => $tax,
			'TOTAL_BP' => $total
		);
		$data['AMOUNT'] = $amount;
		$this->m_pesanan->update($dataUpdate,$data['KPS_BUKTI_PESANAN_ID']);
		$this->m_pesanan->insertData($table,$data);
		redirect('pesanan/detail/'.$data['KPS_BUKTI_PESANAN_ID']);
	}
	public function detail($id)
	{
		$datas = $this->m_pesanan->get($id);
		$data['data'] = $this->m_pesanan->get($id);
		$data['loi'] = $this->m_pesanan->getAllloiByCust($id,$datas->KPS_CUSTOMER_ID);
		$data['detail'] = $this->m_pesanan->getDetailPesanan($id);
		$carisub = $this->m_pesanan->getDetailPesanan($id);
		$subtotal = 0;
		foreach ($carisub as $value) {
			$subtotal += $value->AMOUNT;
		}
		$tax = $subtotal * 0.1;
		$total = $subtotal + $tax; 
		$dataUpdate = array(
			'SUB_TOTAL_BP' => $subtotal,
			'TAX_BP' => $tax,
			'TOTAL_BP' => $total
		);
		$this->m_pesanan->update($dataUpdate,$id);
		$data['content'] = 'sales_data/detail/pesanan';
		$this->load->view('template/template',$data);
	}
	public function edit($id,$idCust){
		$data['dataEmployee'] = $this->m_employee->getAll();
		$data['dataCust'] = $this->m_customer_information->getAll();
		$data['dataCurr'] = $this->m_currency->getAll();
		$data['dataDivisi'] = $this->m_pesanan->getDivisi($idCust);
		
		$data['data'] = $this->m_pesanan->get($id);
		$this->load->view('sales_data/v_edit_pesanan',$data);
	}
	public function update(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_pesanan->update($data,$id);
		$status = $data['revisi_no_bp']+1;
		$this->m_pesanan->updaterevno($status,$id);
		redirect('pesanan');
	}
	public function KonDecRomawi($angka){
    $hsl = "";
    if($angka<1||$angka>3999){
        $hsl = "Batas Angka 1 s/d 3999";
    }else{
         while($angka>=1000){
             $hsl .= "M";
             $angka -= 1000;
         }
         if($angka>=500){
	             if($angka>500){
	                 if($angka>=900){
	                     $hsl .= "CM";
	                     $angka-=900;
	                 }else{
	                     $hsl .= "D";
	                     $angka-=500;
	                 }
	             }
	         }
	         while($angka>=100){
	             if($angka>=400){
	                 $hsl .= "CD";
	                 $angka-=400;
	             }else{
	                 $angka-=100;
	             }
	         }
	         if($angka>=50){
	             if($angka>=90){
	                 $hsl .= "XC";
	                  $angka-=90;
	             }else{
	                $hsl .= "L";
	                $angka-=50;
	             }
	         }
	         while($angka>=10){
	             if($angka>=40){
	                $hsl .= "XL";
	                $angka-=40;
	             }else{
	                $hsl .= "X";
	                $angka-=10;
	             }
	         }
	         if($angka>=5){
	             if($angka==9){
	                 $hsl .= "IX";
	                 $angka-=9;
	             }else{
	                $hsl .= "V"; 
	                $angka-=5;
	             }
	         }
	         while($angka>=1){
	             if($angka==4){
	                $hsl .= "IV"; 
	                $angka-=4;
	             }else{
	                $hsl .= "I";
	                $angka-=1;
	             }
	         }
	    }
	    return ($hsl);
	}
	public function updateDetail($table,$tableId){
		$id=$this->input->post('id');
		$data=$this->input->post();
		$idRef = $data['idRef'];
		unset($data['id']);
		unset($data['idRef']);
		 $this->m_pesanan->updateDetail($table,$tableId,$data,$id);
		 $data = $this->m_pesanan->get($idRef);
		$status = $data->revisi_no_bp+1;
		$this->m_pesanan->updaterevno($status,$idRef);
		redirect('pesanan/detail/'.$idRef);
	}
	public function loadDivisi(){
		$id = $this->input->get('id');
		$dataDivisi = $this->m_pesanan->getDivisi($id);
		?>
		<option>-- Select Divisi --</option>								
		<?php
		foreach ($dataDivisi as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>"><?php echo $value->DIVISI;?></option>	
			<?php
		}
	}

	public function loadCurr(){
		$id = $this->input->get('id');
		$dataCurr = $this->m_pesanan->getCurr($id);
		?>
		<option>-- Select Currency --</option>								
		<?php
		foreach ($dataCurr as $key => $value) {
			?>
			 <option value="<?php echo $value->KPS_CUSTOMER_FINANCE_BANK_ID;?>"><?php echo $value->CURRENCY;?></option>	
			<?php
		}
	}

	public function loadModelPrice(){
		$id = $this->input->post('id');
		$data = $this->m_pesanan->getModelPrice($id);
		echo json_encode($data);
	}
	public function lock($id){
		$status = "1";
		$this->m_pesanan->lock($status,$id);
		redirect('pesanan');
	}
	public function unlock($id){
		$status = "0";
		$this->m_pesanan->unlock($status,$id);
		redirect('pesanan');
	}

}
