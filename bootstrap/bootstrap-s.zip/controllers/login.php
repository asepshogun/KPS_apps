<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('m_userdata');
	}
	public function index()
	{		
		if($this->session->userdata('username')){
			redirect('dashboard');
		}else{
			$this->load->view('login/login');
		}
	}
	public function action(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$checkLogin = $this->m_userdata->checkLogin($username,$password);
		if(count($checkLogin) > 0){
			$this->session->set_userdata('username',$username);
			$this->session->set_userdata('password',$password);
			$this->session->set_userdata('id',$checkLogin->KPS_USERDATA_ID);
			$this->session->set_userdata('name',$checkLogin->EMPLOYEE_NAME);
			$this->session->set_userdata('employeeId',$checkLogin->KPS_EMPLOYEE_ID);
			$this->session->set_userdata('position',$checkLogin->POSITION);
			$this->session->set_userdata('section',$checkLogin->SECTION);
			$this->session->set_userdata('department',$checkLogin->DEPARTMENT);
			$this->session->set_userdata('role',$checkLogin->name);
			redirect('dashboard');
		}else{
			$this->session->set_flashdata('errorlogin', 'Username Atau Password Salah');
			redirect('login');
		}
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect('login');
	}

	public function changes(){
		$id=$this->input->post('id');
		$data=$this->input->post();
		unset($data['id']);
		$this->m_userdata->update($data,$id);
		redirect('dashboard');
	}
}
