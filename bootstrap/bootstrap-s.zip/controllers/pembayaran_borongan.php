<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pembayaran_Borongan extends CI_Controller {

	public function index()
	{
		$data['content'] = 'production/v_pembayaran_borongan';
		$this->load->view('template/template',$data);
	}

	public function add(){
		
	}
	
	public function edit($id){
	
	}

	public function detail(){
		$data['content'] = 'production/pembayaran_borongan';
		$this->load->view('template/template',$data);
	}

}
