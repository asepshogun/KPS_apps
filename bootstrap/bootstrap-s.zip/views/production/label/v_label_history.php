<section class="content-header">
	<h3>Label Data</h3>
	<small>Label Data</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="label_prod" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>No Label</th>
		        <th>Revisi No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>	        
		        <th>No Lot</th>
		        <th>QTY</th>
		        <th>Prod. Date</th>
		        <th>Insp. Date</th>
		        <th>Customer</th>		        
		        <th>Status</th>
		        <th>Made By</th>
		        <th>Update BY</th>
		        <th>Update Date</th>
		        <th>Barcode QTY</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NO_LABEL;?></td>
			        <td><?php echo $value->REV_NO_LABEL;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->NO_LOT;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo $value->PROD_DATE;?></td>
			        <td><?php echo $value->INSP_DATE;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->STATUS;?></td>
			       <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_LABEL_MADE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_LABEL_UPDATE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
			       <td><?php echo $value->UPDATE_TIME;?></td>     
			       <td><?php echo $value->qty_barcode;?></td>     
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>