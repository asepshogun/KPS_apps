<section class="content-header">
	<h3>Label Data</h3>
	<small>Label Data</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="label_produksi" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>No Label</th>
		        <th>Revisi No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>	        
		        <th>No Lot</th>
		        <th>QTY</th>
		        <th>Prod. Date</th>
		        <th>Insp. Date</th>
		        <th>Customer</th>		        
		        <th>Status</th>
		        <th>Made By</th>
		        <th>Barcode QTY</th>
				<th>Print Barcode</th>
				 <th>Update</th>
		        <th>Delete</th>
		        <th>History</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NO_LABEL;?></td>
			        <td><?php echo $value->REV_NO_LABEL;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->NO_LOT;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo $value->PROD_DATE;?></td>
			        <td><?php echo $value->INSP_DATE;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->STATUS;?></td>
			       <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_LABEL_MADE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
			       <td><?php echo $value->qty_barcode;?></td>
					<td>
					<a target="_blank" href="<?php echo site_url() ?>/label/prints/<?php echo $value->KPS_LABEL_ID; ?>">Print</a>
					</td>		        
			
			        <td><a href="" url="<?php echo site_url()."/label/edit/".$value->KPS_LABEL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/label/delete/".$value->KPS_LABEL_ID;?>">Delete</a></td>		        
			        <td><a href="<?php echo site_url()."/label/history/".$value->KPS_LABEL_ID;?>">History</a></td>		        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button href="" url="<?php echo site_url()."/label/add/"?>" type="button" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Label</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
	  
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">  
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->