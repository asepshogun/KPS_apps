<section class="content-header">
	<h3>Label Information Data</h3>
	<small>Label Information Data</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body overflow">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <!-- <th>Operator Name</th>
		        <th>QTY</th> -->
		        <th>Date</th>	        
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Customer</th>		        
		        <th>No Barcode</th>
		        <th>Barcode</th>
		        <th>QTY Barcode</th>
		        <th>Delete</th>
		        <th>Detail</th>		
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <!-- <td><?php echo $value->OPERATOR_NAME;?></td>
			        <td><?php echo $value->QUANTITY;?></td> -->
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td>
			        	
					<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo $value->BARCODE_NO; ?>" />	
					<p>
						<a target="_blank" href="<?php echo site_url() ?>/label_information/prints/<?php echo $value->KPS_LABEL_INFORMATION_ID ?>/<?php echo $value->BARCODE_NO; ?>">Print</a>
					</p>

			        </td>
			        <td><?php echo $value->QTY_BARCODE_LF;?></td>			        			        
			   	        
			        <td><a href="" url="<?php echo site_url()."/label_information/delete/".$value->KPS_LABEL_INFORMATION_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
			        <td><a href="<?php echo site_url()."/label_information/detail/".$value->KPS_LABEL_INFORMATION_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Label</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Label Information Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label_information/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="customers" url="<?php echo site_url()."/quantity/loadLoi"; ?>" name="CUSTOMER_ID">					  
					    <option>-- Select Customer --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part No - Nama - Model</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="lois" name="KPS_ITEM_MASTER_ID_LF">					  
					    <option>-- Select Part No - Nama - Model --</option>				  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-2 control-label">Barcode</label>
		          <div class="col-sm-8">
		            <input type="text" class="form-control" id="barcodeno" name="BARCODE_NO" placeholder="barcode">
		          </div>
		          	<a target="_blank" id="generatebarcodeno" href="" url="<?php echo site_url() ?>/label_information/prints/00/">Generate</a>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY Barcode</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QTY_BARCODE_LF" placeholder="qty barcode">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Label Information Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label_information/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" id="customersed" url="<?php echo site_url()."/quantity/loadLoi"; ?>"  style="width: 100%;" name="CUSTOMER_ID">					  
					    <option>-- Select Customer --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="loised" name="KPS_ITEM_MASTER_ID_LF">
					    <option>-- Select Part Number --</option>			  
					</select>
		          </div>
		        </div>
	
	    		<div class="form-group">
		          <label class="col-sm-2 control-label">Barcode</label>
		          <div class="col-sm-8">
		            <input type="text" class="form-control" id="barcodenoed" name="BARCODE_NO" placeholder="barcode">
		          </div>
		          	<a target="_blank" id="generatebarcodenoed" href="" url="<?php echo site_url() ?>/label_information/prints/00/">Generate</a>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY Barcode</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QTY_BARCODE_LF">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->