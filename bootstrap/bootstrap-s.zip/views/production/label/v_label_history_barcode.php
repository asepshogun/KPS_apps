<section class="content-header">
	<h3>History Setting Print Barcode</h3>
	<small>Riwayat Setel Cetakan Barcode</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="SettingBarcode" class="table table-bordered table-hover  dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>Spacing</th>
		        <th>Font Size</th>
		        <th>Barcode Size</th>	        
		        <th>Made By</th>	        
		        <th>Update By</th>
		        <th>Update Date</th>
		      </tr>
		    </thead>
		    <tbody>
				<?php $no=0; foreach ($datas as $data) { $no++; ?>
					<tr>
						<td><?php echo $data->KPS_BARCODE_PADDING;?></td>
						<td><?php echo $data->KPS_BARCODE_FONT_SIZE;?></td>
						<td><?php echo $data->KPS_BARCODE_SIZE_BARCODE;?></td>
						<td><?php 
							$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->KPS_BARCODE_SETTING_MADE_BY."'");
							$data1 = mysql_fetch_array($query);
							echo $data1['EMPLOYEE_NAME'];
						?></td>
						<td><?php 
							$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->KPS_BARCODE_SETTING_UPDATE_BY."'");
							$data12 = mysql_fetch_array($query2);
							echo $data12['EMPLOYEE_NAME'];
						?></td>
						<td><?php echo $data->KPS_BARCODE_SETTING_DATE;?></td>
					</tr>
				  <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>