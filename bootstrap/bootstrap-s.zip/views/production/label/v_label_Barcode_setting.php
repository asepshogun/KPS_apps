<section class="content-header">
	<h3>Setting Print Barcode</h3>
	<small>Setel Cetakan Barcode</small>
</section>
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Setting</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
					<form action="<?php echo site_url()."/label/updateBarcodeSetting";?>" method="POST" class="form-horizontal">
					<div class="col-lg-6">
					<div class="form-group">
					  <label class="col-lg-3 control-label">Setting Spacing</label>
					  <div class="col-lg-9">
						<input type="number" class="form-control" name="KPS_BARCODE_PADDING" id="KPS_BARCODE_PADDING" value=<?php echo $data->KPS_BARCODE_PADDING; ?> > Default 5 px
					  </div>
					</div>
					<div class="form-group">
					  <label class="col-lg-3 control-label">Setting Font Size</label>
					  <div class="col-lg-9">
						<input type="number" class="form-control" name="KPS_BARCODE_FONT_SIZE" id="KPS_BARCODE_FONT_SIZE" value=<?php echo $data->KPS_BARCODE_FONT_SIZE; ?> > Default 17 px
					  </div>
					</div>
					
					</div>
					<div class="col-lg-6">
					<div class="form-group">
					  <label class="col-lg-3 control-label">Setting Size Barcode</label>
					  <div class="col-lg-9">
						<input type="number" class="form-control" name="KPS_BARCODE_SIZE_BARCODE" id="KPS_BARCODE_SIZE_BARCODE" value=<?php echo $data->KPS_BARCODE_SIZE_BARCODE; ?> > Default 20
					  </div>
					</div>
					
					 <div class="form-group">
					  <label class="col-sm-3 control-label">Made By</label>
					  <div class="col-sm-9">
						 <input type="text" class="form-control" name="KPS_BARCODE_SETTING_MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
						<input type="hidden" class="form-control" name="KPS_BARCODE_SETTING_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
						<input type="hidden" class="form-control" name="KPS_BARCODE_SETTING_ID" value="<?php echo $data->KPS_BARCODE_SETTING_ID ?>">
					  </div>
					</div>
					</div>
					<div class="col-lg-6" align="center">
				        <input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Setting" />
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left"  value="Clear Form" />
						</div>
					</div>	      	
				</form>	             
            </div>			            
        </div>
    </div>
</div>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="SettingBarcode" class="table table-bordered table-hover  dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>Spacing</th>
		        <th>Font Size</th>
		        <th>Barcode Size</th>	        
		        <th>Made By</th>	        
		        <th>Print Preview</th>
		        <th>Reset To Default</th>
		        <th>History</th>
		      </tr>
		    </thead>
		    <tbody>
				<tr>
				<td><?php echo $data->KPS_BARCODE_PADDING;?></td>
				<td><?php echo $data->KPS_BARCODE_FONT_SIZE;?></td>
				<td><?php echo $data->KPS_BARCODE_SIZE_BARCODE;?></td>
				<td><?php 
					$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->KPS_BARCODE_SETTING_MADE_BY."'");
					$data1 = mysql_fetch_array($query);
					echo $data1['EMPLOYEE_NAME'];
				?></td>
				<td><a class="mutation_change" target="_blank" href="<?php echo site_url()."/label/printSettingBarcode/";?>">Print Preview</a></td>		        
				<td><a class="mutation_change"  href="<?php echo site_url()."/label/setDefaultBarcodeSetting/".$data->KPS_BARCODE_SETTING_ID ."/". $this->session->userdata('employeeId');?>">Reset Default</a></td>		        
				<td><a  href="<?php echo site_url()."/label/historyBarcodeSetting/".$data->KPS_BARCODE_SETTING_ID;?>">History</a></td>
			  </tr>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>