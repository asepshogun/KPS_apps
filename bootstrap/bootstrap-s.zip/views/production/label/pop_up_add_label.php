<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Label</h4>
</div>
<div class="modal-body">
		<form action="<?php echo site_url()."/label/add";?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-lg-3 control-label">Customer</label>
		  <div class="col-lg-9">
			<select class="form-control select2" style="width: 100%;" id="labelcustomer" url="<?php echo site_url() ?>/label/loadProduct" name="KPS_CUSTOMER_LIST_ID">					  
				<option>-- Select Customer --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
			<?php echo form_error('KPS_LOI_ID_label'); ?>
		  <label class="col-lg-3 control-label">Code Item</label>
		  <div class="col-lg-9">
			<select class="form-control select2" style="width: 100%;" url="<?php echo site_url() ?>/label/loadBarcode"  id="labelproduct" name="KPS_LOI_ID_label" id="KPS_LOI_ID_label">					  
				<option>-- Select Code Item --</option>
							  
			</select>
		  </div>
		</div>

		<div class="form-group">
			<?php echo form_error('Barcode'); ?>
		  <label class="col-lg-3 control-label">Barcode</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" readonly name="barcode" id="labelbarcode" placeholder="Barcode">
		  </div>
		</div>
		
		<div class="form-group">
			<?php echo form_error('QTY Barcode'); ?>
		  <label class="col-lg-3 control-label">Qty Barcode</label>
		  <div class="col-lg-9">
			<input type="Number" class="form-control" name="qty_barcode" id="qty_barcode" placeholder="EX. 100">
		  </div>
		</div>
		
		<div class="form-group">
			<?php echo form_error('NO_LOT'); ?>
		  <label class="col-lg-3 control-label">No Lot</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="NO_LOT" id="NO_LOT" placeholder="EX. KPS2981N">
		  </div>
		</div>
		<div class="form-group">
			<?php echo form_error('QUANTITY'); ?>
		  <label class="col-lg-3 control-label">QTY Standard Packing</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" value="" readonly=readonly name="QUANTITY" id="labelqtyStandard" placeholder="quantity">
		  </div>
		</div>
		<div class="form-group" style="display:none">
			<?php echo form_error('LENGTH'); ?>
		  <label class="col-lg-3 control-label">Length</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="LENGTH" id="LENGTH" placeholder="length">
		  </div>
		</div>
		<div class="form-group">
			<?php echo form_error('PROD_DATE'); ?>
		  <label class="col-lg-3 control-label">Prod. Date</label>
		  <div class="col-lg-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="PROD_DATE" id="PROD_DATE" placeholder="Pick Date">
		  </div>
		</div>
		<div class="form-group">
			<?php echo form_error('INSP_DATE'); ?>
		  <label class="col-lg-3 control-label">Insp. Date</label>
		  <div class="col-lg-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="INSP_DATE" id="INSP_DATE" placeholder="Pick Date">
		  </div>
		</div>	 
		<div class="form-group">
			<?php echo form_error('STATUS'); ?>
		  <label class="col-lg-3 control-label">Status</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="STATUS" id="STATUS" placeholder="status">
		  </div>
		</div>
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="KPS_LABEL_MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="KPS_LABEL_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
		  </div>
		</div>
		<div class="form-group" style="display: none">
		<?php echo form_error('INSPECTOR'); ?>
		  <label class="col-lg-3 control-label">Inspektor</label>
		  <div class="col-lg-9">
			<select class="form-control select2"  name="INSPECTOR" id="INSPECTOR">					  
				<option value="0">-- Select Inspektor --</option>
				<?php foreach ($dataEmp as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group" style="display:none">
		<?php echo form_error('OPERATOR'); ?>
		  <label class="col-lg-3 control-label">Operator</label>
		  <div class="col-lg-9">
			<select class="form-control select2"  name="OPERATOR" id="OPERATOR">					  
				<option value="0">-- Select Operator --</option>
				<?php foreach ($dataEmp as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group" style="display:none">
		<?php echo form_error('SUB_OPERATOR'); ?>
		  <label class="col-lg-3 control-label">Sub Operator</label>
		  <div class="col-lg-9">
			<select class="form-control select2" name="SUB_OPERATOR" id="SUB_OPERATOR">					  
				<option value="0">-- Select Sub Operator --</option>
				<?php foreach ($dataEmp as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<!--
		<div class="form-group">
		<?php //echo form_error('VISUAL'); ?>
		  <label class="col-lg-3 control-label">Visual</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="VISUAL" id="VISUAL" placeholder="visual">
		  </div>
		</div>
		<div class="form-group"  style="display:none">
		<?php //echo form_error('PROFILE'); ?>
		  <label class="col-lg-3 control-label">Profile</label>
		  <div class="col-lg-9">				            
			<input type="file" class="form-control" name="FILENAME" id="PROFILE">
		  </div>
		</div>
		-->
		<div class="form-group">		          
			<div class="col-sm-12">
				<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Label" />
				<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Label" />
			</div>
		</div>     	
	</form>	             
</div>	
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>