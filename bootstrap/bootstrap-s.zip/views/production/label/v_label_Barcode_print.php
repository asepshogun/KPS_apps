<script type="text/javascript">
	window.print();
</script>
<style>
td{
 padding-bottom: <?php echo $data->KPS_BARCODE_PADDING;?>px;
}
</style>
<table>
		<tr>
			<td align="center">
				<div>
				<br/>
				<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo "KPSCODEBARCODE1001320161705"; ?>&size=<?php echo $data->KPS_BARCODE_SIZE_BARCODE; ?>" />
				<br/>
				<span style="font-size: <?php echo $data->KPS_BARCODE_FONT_SIZE;?>px">
					<?php echo "KPSCODEBARCODE10013"; ?>
					/
					<?php echo "20161705"; ?>
				</span>

				</div>
			</td>
		</tr>
		<tr>
			<td align="center">
				<div>
				<br/>
				<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo "KPSCODEBARCODE1001420161705"; ?>&size=<?php echo $data->KPS_BARCODE_SIZE_BARCODE; ?>" />
				<br/>
				<span style="font-size: <?php echo $data->KPS_BARCODE_FONT_SIZE;?>px">
					<?php echo "KPSCODEBARCODE10014"; ?>
					/
					<?php echo "20161705"; ?>
				</span>

				</div>
			</td>
		</tr>
		<tr>
			<td align="center">
				<div>
				<br/>
				<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo "KPSCODEBARCODE1001520161705"; ?>&size=<?php echo $data->KPS_BARCODE_SIZE_BARCODE; ?>" />
				<br/>
				<span style="font-size: <?php echo $data->KPS_BARCODE_FONT_SIZE;?>px">
					<?php echo "KPSCODEBARCODE10015"; ?>
					/
					<?php echo "20161705"; ?>
				</span>

				</div>
			</td>
		</tr>
		
		
</table>
