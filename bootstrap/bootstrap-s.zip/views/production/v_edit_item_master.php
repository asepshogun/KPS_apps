<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Item Master Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/item_master/update";?>" method="POST" class="form-horizontal">	    		
		<div class="form-group">
          <label class="col-sm-3 control-label">Customer</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="rfq_id">					  
			    <option>-- Select Customer --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>		        
        <div class="form-group">
          <label class="col-sm-3 control-label">Part Number</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO">					  
			    <option>-- Select Part Number --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->KPS_PART_ID;?>"><?php echo $value->PART_NO;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Part Name</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="rfq_id">					  
			    <option>-- Select Part Name --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->KPS_PART_ID;?>"><?php echo $value->PART_NAME;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Code Item</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="LOI_CODE_ITEM">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Total Mold</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="TOTAL_MOLD">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Berat Produk</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="BERAT_PRODUK1">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Rev No</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="Rev No">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Rev Date</label>
          <div class="col-sm-9">
            <input type="text" class="form-control datepicker" name="REV_DATE_CODE_ITEM">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Rev Date Process</label>
          <div class="col-sm-9">
            <input type="text" class="form-control datepicker" name="REV_DATE_PROCESS">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Rev Contain</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="REV_CONTAIN">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Note</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="NOTE">
          </div>
        </div>		        
        <div class="form-group">
          <label class="col-sm-3 control-label">Approved</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO">					  
			    <option>-- Select Approved --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->APPROVED;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Checked</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="rfq_id">					  
			    <option>-- Select Checked --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->CHECKED;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Prepared</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO">					  
			    <option>-- Select Prepared --</option>
			    <?php foreach ($data as $value) { ?>
			    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->PREPRED;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>
        <div class="form-group">		          
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>			      	
    </form>	        	    			      		        
</div>