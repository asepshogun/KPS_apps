<section class="content-header">
	<h3>Harga Borongan</h3>
	<small>Harga Borongan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="harga_borongan" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>	        
		        <th>Mode</th>
		        <th>Customer Name</th>
		        <th>Valid Date From</th>
		        <th>Valid Date Until</th>
		        <th>Note</th>
		        <th>Approved</th>		        
		        <th>Checked</th>
		        <th>Prepared</th>
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>		        
		        <th>Detail Rev</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NAME;?></td>
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->MODE;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>
			        <td><?php echo $value->NOTES;?></td>
			        <td><?php echo $value->APPROVED;?></td>
			        <td><?php echo $value->CHECKED;?></td>
			        <td><?php echo $value->PREPRED;?></td>
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/edit/".$value->KPS_HARGA_BORONGAN_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/delete/".$value->KPS_HARGA_BORONGAN_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/detail/".$value->KPS_HARGA_BORONGAN_ID;?>">Detail</a></td>
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/detail_rev/".$value->NO_REV_NO;?>">Detail Rev</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Harga Borongan</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Harga Borongan Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/harga_borongan/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_PART_NO;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_PART_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_CODE_ITEM;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Model</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MODEL" placeholder="model">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Date From</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_FROM" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Date Until</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_UNTIL" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>	 
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Harga Borongan Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/harga_borongan/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>				  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Model</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MODEL" placeholder="model">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Date From</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_FROM" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Date Until</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_UNTIL" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>	 
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->