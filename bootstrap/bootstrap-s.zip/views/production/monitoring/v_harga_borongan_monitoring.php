<section class="content-header">
	<h3>Harga Borongan Monitoring</h3>
	<small>Harga Borongan Monitoring</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		Show/Hide Column :
        <div class="box-body">              
            <div class="btn-group" role="group" aria-label="...">
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Document Date</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Document No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Rev No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Valid From</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Valid Until</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Code Item</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Part No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Part Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Model</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Tooling No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Customer Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="12">Process</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="13">Tooling Code</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="14">Cav No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="15">Machine Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="16">C/T Man</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="17">C/T Charge</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="18">Engineering</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="19">Production</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="20">Approval Director</a></button>
            </div>
        </div>

		<!--TABLE-->
		<table id="harga_borongan_monitoring" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th colspan="2"><center>Document</center></th>		        
		        <th rowspan="2">Rev No</th>
		        <th colspan="2"><center>Valid</center></th>		        		        
		        <th rowspan="2">Code Item</th>
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Model</th>
		        <th rowspan="2">Tooling No</th>		        
		        <th rowspan="2">Customer Name</th>
		        <th rowspan="2">Process</th>
		        <th rowspan="2">Tooling Code</th>
		        <th rowspan="2">Cav No</th>
		        <th rowspan="2">Machine Name</th>
		        <th colspan="2"><center>C/T (Sec)</center></th>		        
		        <th colspan="2"><center>Price</center></th>		        		        
		        <th rowspan="2">Approval Director</th>
		        <th rowspan="2">Status</th>
		      </tr>
		      <tr>
		      	<th>Date</th>
		        <th>No</th>
		        <th>From</th>	        
				<th>Until</th>
				<th>Man</th>
		        <th>Charge</th>
		        <th>Engineering</th>
		        <th>Production</th>
		      </tr>
		    </thead>
		    <tfoot>
		    	<tr>
		    		<th>No</th>
		    		<th>Date</th>
			        <th>No</th>
			        <th>Rev No</th>
			        <th>From</th>	        
					<th>Until</th>
					<th>Code Item</th>
			        <th>Part No</th>
			        <th>Part Name</th>
			        <th>Model</th>
			        <th>Tooling No</th>		        
			        <th>Customer Name</th>
			        <th>Process</th>
			        <th>Tooling Code</th>
			        <th>Cav No</th>
			        <th>Machine Name</th>
					<th>Man</th>
			        <th>Charge</th>
			        <th>Engineering</th>
			        <th>Production</th>
			        <th>Approval Director</th>
			        <th>Status</th>
		    	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->DOC_NO;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->PART_NAME;?></td>
			        <td><?php echo $value->MODEL;?></td>
			        <td><?php echo $value->TOOLING_NO;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->NAMA_PROSES;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>
			        <td><?php echo $value->CAV_NO;?></td>
			        <td><?php echo $value->MACHINE_NAME;?></td>
			        <td><?php echo $value->CT_MAN;?></td>
			        <td><?php echo $value->CT_CHARGE;?></td>
			        <td><?php echo $value->HARGA_PENGAJUAN_ENGINEERING;?></td>
			        <td><?php echo $value->HARGA_PENGAJUAN_PRODUKSI;?></td>
			        <td><?php echo $value->APPROVED_DIREKTUR;?></td>
			        <td><?php echo $value->STATUS_PROSES;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>