<section class="content-header">
	<h3>Retur Production Monitoring</h3>
	<small>Retur Production Monitoring</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		Show/Hide Column :
        <div class="box-body">              
            <div class="btn-group" role="group" aria-label="...">
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Date</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Rev No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Code Item</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Part Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Part No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">No Label</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">No Barcode</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">QTY</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Units</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Note</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="12">Status</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="13">NIK</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="14">Employee Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="15">Section</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="16">Group</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="17">Number Employee</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="18">Work Hour</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="19">Paid as</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="20">Process</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="21">Harga</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="22">Tooling Code</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="23">Tooling No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="24">Cav No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="25">Machine Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="26">Machine Line</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="27">QTY Barcode</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="28">No Lot</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="29">Production Date</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="30">Pembayaran (Rp)</a></button>
            </div>
        </div>

		<!--TABLE-->
		<table id="retur_production_monitoring" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>No Label</th>
		        <th>No Barcode</th>
		        <th>QTY</th>
		        <th>Units</th>
		        <th>Note</th>
		        <th>Status</th>
		        <th>NIK</th>
		        <th>Employee Name</th>
		        <th>Section</th>
		        <th>Group</th>
		        <th>Number Employee</th>
		        <th>Work Hour</th>
		        <th>Paid as</th>
		        <th>Proses</th>
		        <th>Harga</th>
		        <th>Toolings Code</th>
		        <th>Tooling No</th>
		        <th>Cav No</th>
		        <th>Machine Name</th>
		        <th>Machine Line</th>
		        <th>QTY Barcode</th>
		        <th>No Lot</th>
		        <th>Production Date</th>
		        <th>Pembayaran (Rp)</th>
		      </tr>
		    </thead>
		    <tfoot>
		    	<tr>
		    		<th>No</th>
			        <th>Date</th>
			        <th>No</th>
			        <th>Rev No</th>
			        <th>Code Item</th>
			        <th>Part Name</th>
			        <th>Part No</th>
			        <th>No Label</th>
			        <th>No Barcode</th>
			        <th>QTY</th>
			        <th>Units</th>
			        <th>Note</th>
			        <th>Status</th>
			        <th>NIK</th>
			        <th>Employee Name</th>
			        <th>Section</th>
			        <th>Group</th>
			        <th>Number Employee</th>
			        <th>Work Hour</th>
			        <th>Paid as</th>
			        <th>Proses</th>
			        <th>Harga</th>
			        <th>Toolings Code</th>
			        <th>Tooling No</th>
			        <th>Cav No</th>
			        <th>Machine Name</th>
			        <th>Machine Line</th>
			        <th>QTY Barcode</th>
			        <th>No Lot</th>
			        <th>Production Date</th>
			        <th>Pembayaran (Rp)</th>
		    	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NAME;?></td>
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->NO_LABEL;?></td>
			        <td><?php echo $value->NO_BARCODE;?></td>
			        <td><?php echo $value->QTY;?></td>
			        <td><?php echo $value->UNIT;?></td>
			        <td><?php echo $value->STATUS;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->SECTION;?></td>
			        <td><?php echo $value->GROUP;?></td>
			        <td><?php echo $value->EMPLOYEE_NO;?></td>
			        <td><?php echo $value->PAID_AS;?></td>
			        <td><?php echo $value->PROSES;?></td>
			        <td><?php echo $value->HARGA;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>
			        <td><?php echo $value->TOOLING_NO;?></td>
			        <td><?php echo $value->CAV_NO;?></td>
			        <td><?php echo $value->MACHINE_NAME;?></td>
			        <td><?php echo $value->MACHINE_LINE;?></td>
			        <td><?php echo $value->QTY_BARCODE;?></td>
			        <td><?php echo $value->NO_LOT;?></td>
			        <td><?php echo $value->PRODUCTION_DATE;?></td>
			        <td><?php echo $value->PEMBAYARAN;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>