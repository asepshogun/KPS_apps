<section class="content-header">
	<h3>Absen Harian Monitoring</h3>
	<small>Absen Harian Monitoring</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		Show/Hide Column :
        <div class="box-body">              
            <div class="btn-group" role="group" aria-label="...">
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Date Absen</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Shift</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">NIK</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Employee Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Section</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Absen</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Employee Status</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Group</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Work Hour</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Paid As</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Note</a></button>
            </div>
        </div>

		<!--TABLE-->
		<table id="absen_harian_monitoring" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date Absen</th>
		        <th>Shift</th>
		        <th>NIK</th>
		        <th>Employee Name</th>	        
		        <th>Section</th>
		        <th>Absen</th>
		        <th>Employee Status</th>
		        <th>Group</th>
		        <th>Work Hour (Hour)</th>
		        <th>Paid As</th>		        
		        <th>Note</th>
		      </tr>
		    </thead>
		    <tfoot>
		    	<tr>
		    		<th>No</th>
			        <th>Date Absen</th>
			        <th>Shift</th>
			        <th>NIK</th>
			        <th>Employee Name</th>	        
			        <th>Section</th>
			        <th>Absen</th>
			        <th>Employee Status</th>
			        <th>Group</th>
			        <th>Work Hour (Hour)</th>
			        <th>Paid As</th>		        
			        <th>Note</th>
		    	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->Shift;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->SECTION;?></td>
			        <td><?php echo $value->ABSEN;?></td>
			        <td><?php echo $value->EMPLOYEE_STATUS;?></td>
			        <td><?php echo $value->GROUP_NAME;?></td>
			        <td><?php echo $value->WORK_HOUR_TOTAL;?></td>
			        <td><?php echo $value->PAID_AS;?></td>
			        <td><?php echo $value->NOTE;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>