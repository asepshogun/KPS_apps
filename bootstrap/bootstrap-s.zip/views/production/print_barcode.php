<script type="text/javascript">
	window.print();
</script>
<style>
td{
 padding-bottom: <?php echo $data->KPS_BARCODE_PADDING;?>px;
}
</style>
<table>
	<?php foreach($barcode as $value){ ?>
		<tr>
			<td align="center">
				<div>
				<br/>
				<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo $value->BARCODE_NO; ?>&size=<?php echo $data->KPS_BARCODE_SIZE_BARCODE; ?>" />
				<br/>
				<span style="font-size: <?php echo $data->KPS_BARCODE_FONT_SIZE;?>px">
					<?php echo substr($value->BARCODE_NO,0, -11); ?>
					/
					<?php echo substr($value->BARCODE_NO,12,23); ?>
				</span>

				</div>
			</td>
		</tr>
		<?php } ?>
</table>
