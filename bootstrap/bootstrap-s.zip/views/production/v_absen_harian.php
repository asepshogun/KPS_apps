<section class="content-header">
	<h3>Absen Harian Data</h3>
	<small>Data Absen Harian</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">		
		<!--TABLE-->
		<table id="absen_harian" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Data Absen</th>        
		        <th>Shift</th>
		        <th>Approved</th>		        
		        <th>Checked</th>		        
		        <th>Made By</th>		        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->SHIFT;?></td>			        
			        <td><?php echo $value->APPROVED;?></td>
			        <td><?php echo $value->CHECKED;?></td>		        
			        <td><?php echo $value->MADE_BY;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/absen_harian/update/".$value->KPS_ABSEN_HARIAN_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/absen_harian/delete/".$value->KPS_ABSEN_HARIAN_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/absen_harian/detail/".$value->KPS_ABSEN_HARIAN_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Absen Harian</button>
	</div>
</div>

<!-- Modal ADD TOOL-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Absen Harian Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/absen_harian/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date Absen</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DATE_ABSEN" placeholder="date absen">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Shift</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SHIFT" placeholder="shift">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="APPROVED" placeholder="approved">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED" placeholder="checked">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY" placeholder="made by">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD TOOL-->

<!-- Modal ADD TOOL-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Absen Harian Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/absen_harian/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date Absen</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DATE_ABSEN">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Shift</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SHIFT">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="APPROVED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD TOOL-->