<section class="content-header">
	<h3>BSTHP Detail Data</h3>
	<small>Bukti Serah Terima Hasil Produksi Detail</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="BSTHP_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>QTY Barcode</th>
		        <th>QTY Item</th>	
		        <th>Unit</th>	
		        <th>Note</th>	
		        <th>Update By</th>	
		        <th>UPdate Date</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			     <!--   <td><?php 
			        // $query = $this->db->query("select * from kps_barcode_label where label_id='".$value->KPS_LABEL_ID."'")->first_row();
			        
			        // echo $query->code_label;
			        ?></td>-->
			        <td><?php echo $value->qty_barcode_bsthp;?></td>
			        <td><?php echo $value->jumlah_qty_bsthp;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
			        <td><?php echo $value->NOTE_detail_bsthp;?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_DETAIL_UPDATE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php echo $value->UPDATE_TIME;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
