<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are You Sure Delete This Item</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/bsthp/deleteDetailSub";?>" method="POST" class="form-horizontal">
			<div class="form-group">
			  <label class="col-lg-3 control-label">Code Item</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->LOI_CODE_ITEM; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">part Name</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->LOI_PART_NAME; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">Part Nomor</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->LOI_PART_NO; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">Code Barcode</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->BARCODE_NO; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">QTY Item</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->LOI_STRANDART_PACKING; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">Unit</label>
			  <div class="col-lg-9">
				<input type="hidden" class="form-control" name="KPS_BSTHP_DETAIL_SUB_ID" id="KPS_BSTHP_DETAIL_SUB_ID" value="<?php echo $data->KPS_BSTHP_DETAIL_SUB_ID;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="KPS_BSTHP_DETAIL_ID" id="KPS_BSTHP_DETAIL_ID" value="<?php echo $data->KPS_BSTHP_DETAIL_ID;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="KPS_BSTHP_ID" id="KPS_BSTHP_ID" value="<?php echo $data->KPS_BSTHP_ID;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="KPS_BARCODE_LABEL_ID_BSTHP_SUB" id="KPS_BARCODE_LABEL_ID_BSTHP_SUB" value="<?php echo $data->KPS_BARCODE_LABEL_ID_BSTHP_SUB;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="KPS_BSTHP_DETAIL_SUB_MADE_BY" id="KPS_BSTHP_DETAIL_SUB_MADE_BY" value="<?php echo $this->session->userdata('employeeId');;?>" placeholder="ID BSTHP">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->KPS_RFQ_PART_UNIT; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">		          
				<div class="col-sm-12">
					<input type="submit" class="btn btn-danger btn-flat pull-right" value="YES" />
				</div>
			</div>
	</form>
</div>	
