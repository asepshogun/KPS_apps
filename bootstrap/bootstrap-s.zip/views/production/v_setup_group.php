<section class="content-header">
	<h3>Set Up Group Data</h3>
	<small>Data Set Up Group</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="setup_group" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No / Rev No</th>
		        <th>Area</th>
		        <th>Valid Date From</th>        
		        <th>Valid Date Until</th>
		        <th>Checked</th>		        
		        <th>Made By</th>		        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->AREA;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>			        
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>		        
			        <td><?php echo $value->CHECKED;?></td>			        
			        <td><?php echo $value->MADE_BY;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/setup_group/update/".$value->KPS_SETUP_GROUP_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/setup_group/delete/".$value->KPS_SETUP_GROUP_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/setup_group/detail/".$value->KPS_SETUP_GROUP_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Setup Group</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Setup Group Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/setup_group/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Valid From</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_FROM" placeholder="valid from" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Until</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_UNTIL" placeholder="valid until" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED" placeholder="checked">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY" placeholder="made by">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Setup Group Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/setup_group/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Valid From</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_FROM" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Valid Until</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="VALID_DATE_UNTIL" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->