<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Update Data BSTHP Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/bsthp/updateDetail";?>" method="POST" class="form-horizontal">
			<div class="form-group">
			  <label class="col-lg-3 control-label">Code Item</label>
			 <div class="col-lg-9">
				<select class="form-control select2" id="mutationloi" style="width: 100%; name="KPS_LOI_ID_BSTHP_Detail" disabled >					  
					<option>-- Select Code Item --</option>
						<?php foreach ($dataLoi as $value) { ?>
						<option value="<?php echo $value->KPS_LOI_ID;?>" <?php
								if($value->KPS_LOI_ID==$data->KPS_LOI_ID_BSTHP_Detail){
								echo "selected=''";
							}?>>
							<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
						<?php } ?>			  
				</select>
			  </div>
			</div>

				<input type="hidden" class="form-control" name="KPS_BSTHP_DETAIL_ID" id="KPS_BSTHP_DETAIL_ID" value="<?php echo $data->KPS_BSTHP_DETAIL_ID;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="KPS_BSTHP_ID_det" id="KPS_BSTHP_ID_det" value="<?php echo $data->KPS_BSTHP_ID_det;?>" placeholder="ID BSTHP">
				<input type="hidden" class="form-control" name="MADE_BY_BSTHP_DETAIL" id="MADE_BY_BSTHP_DETAIL" value="<?php echo $this->session->userdata('employeeId');?>" placeholder="ID BSTHP">

			<div class="form-group">
			  <label class="col-lg-3 control-label">Note</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->NOTE_detail_bsthp; ?>">
			  </div>
			</div>
			<div class="form-group">		          
				<div class="col-sm-12">
					<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Data" />
					<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form " />
				</div>
			</div>

	</form>
</div>	
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>