<section class="content-header">
	<h3>Retur Production Data</h3>
	<small>Data Retur Production</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="retur" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><a href="" url="<?php echo site_url()."/retur/update/".$value->KPS_RETUR_PRODUCT_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/retur/delete/".$value->KPS_RETUR_PRODUCT_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/retur/detail/".$value->KPS_RETUR_PRODUCT_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Retur Production</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Retur Production Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/retur/add";?>" method="POST" class="form-horizontal">	    
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" placeholder="code item">
		          </div>
		        </div>		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_LIST_ID;?>"><?php echo $value->CUSTOMER_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Date Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="DATE_RETUR_CUSTOMER" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">PPIC Due Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PPIC_DUE_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Customer Due Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="CUSTOMER_DUE_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">DO No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DO_NO" placeholder="do no">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal Update-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Retur Production Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/retur/update";?>" method="POST" class="form-horizontal">	    
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" placeholder="code item">
		          </div>
		        </div>		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>				  
					</select>
		          </div>
		        </div>		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Date Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="DATE_RETUR_CUSTOMER" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">PPIC Due Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PPIC_DUE_DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Customer Due Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="CUSTOMER_DUE_DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">DO No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DO_NO">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->