<section class="content-header">
	<h3>Employee List Data</h3>
	<small>Data Daftar Karyawan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="daftar_karyawan" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>NIK</th>
		        <th>Nama Karyawan</th>
		        <th>Group</th>
		        <th>Employee Status</th>
		        <th>Bagian</th>
		        <th>Domisili Kerja</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->group_name;?></td>
			        <td><?php echo $value->EMPLOYEE_STATUS;?></td>
			        <td><?php echo $value->test;?></td>
			        <td><?php echo $value->DOMISILI_KERJA;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

</div>