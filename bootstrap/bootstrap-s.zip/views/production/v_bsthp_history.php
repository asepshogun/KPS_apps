<section class="content-header">
	<h3>BSTHP Data</h3>
	<small>Bukti Serah Terima Hasil Produksi</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="BSTHP_RECORD_history" class="table table-bordered table-hover  dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Record</th>
		        <th>Rev No</th>
		        <th>Shift</th>	        
		        <th>Destination Number</th>
		        <th>Barcode Code</th>
		        <th>Barcode Pic</th>	
		        <th>Made By</th>	
		        <th>Distributed By</th>	
		        <th>Accepted By</th>		
		        <th>Update By</th>		
		        <th>Update Date</th>		
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_RECORD;?></td>
			        <td><?php echo $value->REV;?></td>
			        <td><?php echo $value->SHIFT;?></td>
			        <td><?php echo $value->DESTINATION_WAREHOUSE;?></td>
			        <td><?php echo $value->bsthp_barcode_code;?></td>
			        <td>
			        	<img alt="" src="<?php echo site_url(); ?>/label/generateBarcode/code39?text=<?php echo $value->bsthp_barcode_code; ?>" />	
			        </td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_MADE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_DISTRIBUTED_BY."'");
			        	$data2 = mysql_fetch_array($query);
			        	echo $data2['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_ACCEPTED_BY."'");
			        	$data3 = mysql_fetch_array($query);
			        	echo $data3['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_UPDATE_BY."'");
			        	$data4 = mysql_fetch_array($query);
			        	echo $data4['EMPLOYEE_NAME'];
			        ?></td>
					 <td><?php echo $value->UPDATE_TIME;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>