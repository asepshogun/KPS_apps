
<section class="content-header">
	<h3>Bukti Serah Terima Hasil Produksi Verification Data</h3>
	<small>Data Bukti Serah Terima Hasil Produksi Verification</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Bukti Serah Terima Hasil Produksi Verification</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<div class="row">
	            		<form action="<?php echo site_url(); ?>/BSTHP_Verification/add" method="post">
		            		<div class="col-lg-12" align="center">						
						        <label class="col-sm-12 control-label">SCAN BARCODE / TULISKAN CODE BARCODE</label>
							</div>
	            	</div>
	            	<div class="row">	            		
		            	<div class="col-lg-8 col-lg-offset-2">						
						    <input type="text" class="form-control input-lg" name="code" placeholder="barcode code">
						</div>						
	            	</div>
	            	<br>
	            	<div class="row">	            		
	            		<div class="col-lg-12">						
							<div class="col-lg-6" align="center">
					        	<input type="submit" class="btn bg-olive btn-flat" value="Save BSTHP Verification" />
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Refresh BSTHP Verification</button>
					        </div>
						</div>						
	            	</div>
	            				
						</form>	

	            </div>			            
	        </div>
	    </div>
	</div>
	<!--TABLE-->
	<div class="box-body">
		<table id="bsthp_verification" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Record</th>		        
		        <th>Rev No</th>
		        <th>Shift</th>
		        <th>Destination Warehouse No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>		        
		        <th>Part No</th>
		        <th>QTY Item</th>
		        <th>QTY Barcode</th>
		        <th>Verification</th>
		        <th>Detail</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) {$no++ ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_RECORD;?></td>      
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->SHIFT;?></td>
			        <td><?php echo $value->DESTINATION_WAREHOUSE;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->jumlah_qty_bsthp;?></td> 		        
			        <td><?php echo $value->qty_barcode_bsthp;?></td>   
			        <td><?php 
			        if($value->VERIFICATION==""){
			        ?>
						<a href="<?php echo site_url() ?>/BSTHP_Verification/verify/<?php echo $value->KPS_BSTHP_VERIFICATION_DETAIL_ID; ?>/ok/<?php echo $value->KPS_BSTHP_ID?>">
							<button type="button" class="btn bg-olive btn-flat">OK</button>
						</a>
			    		<a href="<?php echo site_url() ?>/BSTHP_Verification/verify/<?php echo $value->KPS_BSTHP_VERIFICATION_DETAIL_ID; ?>/ng/<?php echo $value->KPS_BSTHP_ID?>">
							<button type="button" class="btn bg-olive btn-flat">NG</button>
						</a>
			        <?php
			    	}else{
			    		echo $value->VERIFICATION;
			    	}
			       	?></td>
					<td><a href="<?php echo site_url()."/bSTHP_Verification/detail/".$value->KPS_BSTHP_DETAIL_ID;?>" >Detail</a></td>	
			        <td><?php echo $value->STATUS_VER; ?></td> 		        
			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>