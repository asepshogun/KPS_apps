<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Update Data BSTHP</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/bsthp/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-lg-3 control-label">Shift</label>
		  <div class="col-lg-9">
			<select class="form-control select2" style="width: 100%;" name="SHIFT">					  
				<option>-- Select Shift --</option>
				<option value=1 <?php if($data->SHIFT == 1){ echo "selected";} ?> >1</option>
				<option value=2 <?php if($data->SHIFT == 2){ echo "selected";} ?> >2</option>
				<option value=3 <?php if($data->SHIFT == 3){ echo "selected";} ?> >3</option>
				<option value=4 <?php if($data->SHIFT == 4){ echo "selected";} ?> >4</option>			  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Warehouse Destination</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="DESTINATION_WAREHOUSE" id="DESTINATION_WAREHOUSE" placeholder="barcode" value="FINISHED GOOD" readonly>

		  </div>
		</div>
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="BSTHP_MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="BSTHP_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
			<input type="hidden" class="form-control" name="KPS_BSTHP_ID" value="<?php echo $data->KPS_BSTHP_ID; ?>">
			<input type="hidden" class="form-control" name="REV" value="<?php echo $data->REV; ?>">
		  </div>
		</div>
		<div class="form-group">
		<?php echo form_error('VISUAL'); ?>
		  <label class="col-lg-3 control-label">Barcode</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" placeholder="barcode" value="<?php echo $data->bsthp_barcode_code; ?>" readonly>
		  </div>
		</div>
	  <div class="form-group">
			  <label class="col-sm-3 control-label">Distributed By</label>
			  <div class="col-sm-9">
				<select class="form-control select2" style="width: 100%;"  id="BSTHP_DISTRIBUTED_BY" name="BSTHP_DISTRIBUTED_BY">            
				  <option>-- Select Employee Name --</option>
					<?php foreach ($dataEmp as $value) { ?>
					<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"
					<?php
						if($value->KPS_EMPLOYEE_ID==$data->BSTHP_DISTRIBUTED_BY){
						echo "selected=''";
						}
						?>><?php echo $value->EMPLOYEE_NAME;?></option>
					  <?php } ?>                 
				</select>
			  </div>
		</div> 
		<div class="form-group">
			  <label class="col-sm-3 control-label">Accepted By</label>
			  <div class="col-sm-9">
				<select class="form-control select2" style="width: 100%;"  id="BSTHP_ACCEPTED_BY" name="BSTHP_ACCEPTED_BY">            
				 <option>-- Select Employee Name --</option>
					<?php foreach ($dataEmp as $value) { ?>
					<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"
					<?php
						if($value->KPS_EMPLOYEE_ID==$data->BSTHP_ACCEPTED_BY){
						echo "selected=''";
						}
						?>><?php echo $value->EMPLOYEE_NAME;?></option>
					  <?php } ?>                 
				</select>
			  </div>
		</div>
		<div class="form-group">		          
			<div class="col-sm-12">
			<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save BSTHP" />
		 </div> 
		</div>
	</form>	                         
</div>	
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>