<section class="content-header">
	<h3>Inventory Data</h3>
	<small>Inventory Data</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="inventory_codeitem" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>	        
		        <th>Total QTY Item</th>
		        <th>Total Barcode QTY</th>  
				<th>QTY Item / Barcode Open</th>
				<th>QTY Item / Barcode  OTW</th>
				<th>QTY Item / Barcode  Closed</th>
		        <th>Unit Item</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($dataGroup as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->QTYTOT;?></td>
			        <td><?php echo $value->QTYTOTBar;?></td>
					<?php $qtyTotalItemOpen=0; 
						$qtyTotalBarOpen=0; 
						foreach ($dataCount as $value1) {
							if(empty($value1->BARCODE_LABEL_OTW) && empty($value1->BARCODE_LABEL_DESTINATION) && $value1->KPS_ITEM_MASTER_ID==$value->KPS_ITEM_MASTER_ID){
								$qtyTotalItemOpen=$qtyTotalItemOpen+$value1->QUANTITY;
								$qtyTotalBarOpen++;
							}
						}
					?>
			        <td><?php echo $qtyTotalItemOpen."/".$qtyTotalBarOpen;?></td>
					<?php $qtyTotalItemOTW=0; 
							$qtyTotalBarOTW=0; 
						foreach ($dataCount as $value1) {
							if($value1->BARCODE_LABEL_OTW && empty($value1->BARCODE_LABEL_DESTINATION) && $value1->KPS_ITEM_MASTER_ID==$value->KPS_ITEM_MASTER_ID){
								$qtyTotalItemOTW=$qtyTotalItemOTW+$value1->QUANTITY;
								$qtyTotalBarOTW++;
							}
						}
					?>
			        <td><?php echo $qtyTotalItemOTW."/".$qtyTotalBarOTW;?></td>
					<?php $qtyTotalItemClosed=0; 
						$qtyTotalBarClosed=0; 
						foreach ($dataCount as $value1) {
							if($value1->BARCODE_LABEL_OTW && $value1->BARCODE_LABEL_DESTINATION && $value1->KPS_ITEM_MASTER_ID==$value->KPS_ITEM_MASTER_ID){
								$qtyTotalItemClosed=$qtyTotalItemClosed+$value1->QUANTITY;
								$qtyTotalBarClosed++;
							}
						}
					?>
			        <td><?php echo $qtyTotalItemClosed."/".$qtyTotalBarClosed;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
	  
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Label Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>				  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Lot</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_LOT">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QUANTITY">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Length</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="LENGTH">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Prod. Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PROD_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Insp. Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="INSP_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>	 		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Status</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="STATUS">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Inspektor</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="INSPECTOR">					  
					    <option>-- Select Inspektor --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="OPERATOR">					  
					    <option>-- Select Operator --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Sub Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SUB_OPERATOR">					  
					    <option>-- Select Sub Operator --</option>				  
					</select>
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Visual</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VISUAL">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Profile</label>
		          <div class="col-lg-9">				            
		            <input type="file" class="form-control" name="PROFILE">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->