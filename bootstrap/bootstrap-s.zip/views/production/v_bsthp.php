<section class="content-header">
	<h3>BSTHP Data</h3>
	<small>Bukti Serah Terima Hasil Produksi</small>
</section>
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add BSTHP</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
					<form action="<?php echo site_url()."/bsthp/add";?>" method="POST" class="form-horizontal">
					<div class="col-lg-6">
					<div class="form-group">
					  <label class="col-lg-3 control-label">Shift</label>
					  <div class="col-lg-9">
						<select class="form-control select2" style="width: 100%;" name="SHIFT">					  
							<option>-- Select Shift --</option>
							<option value=1>1</option>
							<option value=2>2</option>
							<option value=3>3</option>
							<option value=4>4</option>			  
						</select>
					  </div>
					</div>
					<div class="form-group">
					  <label class="col-lg-3 control-label">Warehouse Destination</label>
					  <div class="col-lg-9">
						<input type="text" class="form-control" name="DESTINATION_WAREHOUSE" id="DESTINATION_WAREHOUSE" placeholder="barcode" value="FINISHED GOOD" readonly>

					  </div>
					</div>
					 <div class="form-group">
					  <label class="col-sm-3 control-label">Made By</label>
					  <div class="col-sm-9">
						 <input type="text" class="form-control" name="BSTHP_MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
						<input type="hidden" class="form-control" name="BSTHP_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
					  </div>
					</div>
					</div>
					<div class="col-lg-6">
					<div class="form-group">
					<?php echo form_error('VISUAL'); ?>
					  <label class="col-lg-3 control-label">Barcode</label>
					  <div class="col-lg-9">
						<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" placeholder="barcode" value="<?php echo $barcode; ?>" readonly>
					  </div>
					</div>
				  <div class="form-group">
						  <label class="col-sm-3 control-label">Distributed By 1</label>
						  <div class="col-sm-9">
							<select class="form-control select2" style="width: 100%;"  id="BSTHP_DISTRIBUTED_BY" name="BSTHP_DISTRIBUTED_BY">            
							  <option>-- Select Employee Name --</option>
								<?php foreach ($dataEmp as $value) { ?>
								<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>							  <?php } ?>      
							</select>
						  </div>
					</div> 
					<div class="form-group">
						  <label class="col-sm-3 control-label">Distributed By 2</label>
						  <div class="col-sm-9">
							<select class="form-control select2" style="width: 100%;"  id="BSTHP_DISTRIBUTED_BY" name="BSTHP_DISTRIBUTED_BY2">            
							  <option>-- Select Employee Name --</option>
								<?php foreach ($dataEmp as $value) { ?>
								<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>							  <?php } ?>      
							</select>
						  </div>
					</div> 
					<div class="form-group">
						  <label class="col-sm-3 control-label">Accepted By</label>
						  <div class="col-sm-9">
							<select class="form-control select2" style="width: 100%;"  id="BSTHP_ACCEPTED_BY" name="BSTHP_ACCEPTED_BY">            
							  <option>-- Select Employee Name --</option>
								<?php foreach ($dataEmp as $value) { ?>
								<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>							  <?php } ?>      
							</select>
						  </div>
					</div>
					</div>
					<?php
					$status_menu=" ";
					foreach($dataNull as $values){
						if($values->BSTHP_MADE_BY == $this->session->userdata('employeeId')){
						$status_menu=$values->KPS_BSTHP_ID;
						}
					}
					?>
					<div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" 
							<?php if($status_menu && $status_menu!=0){ echo "disabled";} ?>  value="Save BSTHP" />
				       
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left"  value="Clear Form Drawing" />
						</div>
					</div>	      	
				</form>	             
            </div>			            
        </div>
    </div>
</div>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="BSTHP_RECORD" class="table table-bordered table-hover  dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Record</th>
		        <th>Rev No</th>
		        <th>Shift</th>	        
		        <th>Destination Number</th>
		        <th>Barcode Code</th>
		        <th>Barcode Pic</th>	
		        <th>Made By</th>	
		        <th>Distributed By 1</th>	
		        <th>Distributed By 2</th>
		        <th>Accepted By</th>	
		        <th>Edit</th>	
		        <th>Delete</th>	
		        <th>Submit</th>	
		        <th>History</th>	
		        <th>Detail</th>	
		        <th>Print</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr <?php if($value->KPS_BSTHP_ID==$status_menu){ echo "bgcolor=#01DF01"; }else{ echo "bgcolor = #E6E6E6";}?> >
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_RECORD;?></td>
			        <td><?php echo $value->REV;?></td>
			        <td><?php echo $value->SHIFT;?></td>
			        <td><?php echo $value->DESTINATION_WAREHOUSE;?></td>
			        <td><?php echo $value->bsthp_barcode_code;?></td>
			        <td>
			        	<img alt="" src="<?php echo site_url(); ?>/label/generateBarcode/code39?text=<?php echo $value->bsthp_barcode_code; ?>" />	
			        </td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_MADE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_DISTRIBUTED_BY	."'");
			        	$data2 = mysql_fetch_array($query);
			        	echo $data2['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_DISTRIBUTED_BY2	."'");
			        	$data2 = mysql_fetch_array($query);
			        	echo $data2['EMPLOYEE_NAME'];
			        ?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->BSTHP_ACCEPTED_BY	."'");
			        	$data3 = mysql_fetch_array($query);
			        	echo $data3['EMPLOYEE_NAME'];
			        ?></td>
					<td><a href="" url="<?php echo site_url()."/bsthp/edit/".$value->KPS_BSTHP_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a class="mutation_change" href="<?php echo site_url()."/bsthp/delete/".$value->KPS_BSTHP_ID;?>">Delete</a></td>		        
			        <td><a class="mutation_change"  href="<?php echo site_url()."/bsthp/lockHeader/".$value->KPS_BSTHP_ID;?>">Submit</a></td>		        
			        <td><a  href="<?php echo site_url()."/bsthp/history/".$value->KPS_BSTHP_ID;?>">History</a></td>
			        <td><a  href="<?php echo site_url()."/bsthp/detail/".$value->KPS_BSTHP_ID;?>">Detail</a></td>
			        <td><a  target="_blank" href="<?php echo site_url() ?>/bsthp/prints/<?php echo $value->KPS_BSTHP_ID; ?>">Print</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->

<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">  
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->