<section class="content-header">
	<h3>NG & Waste Label Information Data</h3>
	<small>NG & Waste Label Information Data</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="li_ng_waste" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Operator Name</th>
		        <th>QTY</th>
		        <th>Date</th>	        
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Customer</th>		        
		        <th>No Barcode</th>
		        <th>QTY Barcode</th>
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>		
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->OPERATOR_NAME;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NAME;?></td>
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->QTY_BARCODE_LF;?></td>			        			        
			        <td><a href="" url="<?php echo site_url()."/label_information_ng_waste/edit/".$value->KPS_LABEL_INFORMATION_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/label_information_ng_waste/delete/".$value->KPS_LABEL_INFORMATION_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/label_information_ng_waste/detail/".$value->KPS_LABEL_INFORMATION_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Label</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New NG & Waste Label Information Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label_information_ng_waste/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_PART_NO;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_PART_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_CODE_ITEM;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-2 control-label">Barcode</label>
		          <div class="col-sm-8">
		            <input type="text" class="form-control" name="BARCODE_NO" placeholder="barcode">
		          </div>
		          <a href="">Generate</a>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY Barcode</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QTY_BARCODE_LF" placeholder="qty barcode">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">NG & Waste Label Information Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label_information_ng_waste/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>			  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-2 control-label">Barcode</label>
		          <div class="col-sm-8">
		            <input type="text" class="form-control" name="BARCODE_NO">
		          </div>
		          <a href="">Generate</a>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY Barcode</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QTY_BARCODE_LF">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->