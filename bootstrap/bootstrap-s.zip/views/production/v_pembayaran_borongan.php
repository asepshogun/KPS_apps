<section class="content-header">
	<h3>Pembayaran Borongan Data</h3>
	<small>Data Pembayaran Borongan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No / Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_REV_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Month</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date From Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_VALID_FROM_UNTIL" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>
		
	<!--TABLE-->
	<div clas="box-body">
		<table id="pembayaran_borongan" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">NIK</th>
		        <th rowspan="2">Employee Name</th>		        
		        <th rowspan="2">Section</th>
		        <th rowspan="2">Group</th>
		        <th colspan="2"><center>Pembayaran Borongan (Rp)</center></th>
		        <th colspan="3"><center>Insentif</center></th>
		        <th colspan="3"><center>Potongan</center></th>		        
		        <th rowspan="2">Total</th>
		        <th rowspan="2">Note</th>			        	
		      </tr>
		      <tr>
		      	<th>Borongan</th>
		        <th>Retur</th>
		        <th>Cuti</th>
		        <th>Masa Kerja</th>
		        <th>Transport</th>
		        <th>PPH</th>
		        <th>Sanksi</th>	
		        <th>Pot Akses</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>      
			        <td><?php echo $value->SECTION;?></td>
			        <td><?php echo $value->GROUP;?></td>
			        <td><?php echo $value->PEMBAYARAN_BORONGAN;?></td>
			        <td><?php echo $value->PEMBAYARAN_RETUR;?></td>
			        <td><?php echo $value->INSENTIF_CUTI;?></td>
			        <td><?php echo $value->INSENTIF_MASA_KERJA;?></td>      
			        <td><?php echo $value->INSENTIF_TRANSPORT;?></td>
			        <td><?php echo $value->POTONGAN_PPH;?></td>			        
			        <td><?php echo $value->POTONGAN_SANKSI;?></td>		
			        <td><?php echo $value->POTONGAN_POT_AKSES;?></td>		
			        <td><?php echo $value->TOTAL;?></td>
			        <td><?php echo $value->NOTE;?></td>					        		
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>