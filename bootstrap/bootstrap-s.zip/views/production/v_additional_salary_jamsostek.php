<section class="content-header">
	<h3>Additional Salary & Jamsostek Data</h3>
	<small>Data Additional Salary & Jamsostek</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="additional_sj" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>Rev No</th>
		        <th>Month</th>
		        <th>Approved</th>        
		        <th>Checked</th>
		        <th>Made By</th>		        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->MONTH;?></td>
			        <td><?php echo $value->APPROVED;?></td>			        
			        <td><?php echo $value->CHECKED;?></td>
			        <td><?php echo $value->MADE_BY;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/additional_salary_jamsostek/update/".$value->KPS_ADDITIONAL_SALARY_JAMSOSTEK_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/additional_salary_jamsostek/delete/".$value->KPS_ADDITIONAL_SALARY_JAMSOSTEK_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/additional_salary_jamsostek/detail/".$value->KPS_ADDITIONAL_SALARY_JAMSOSTEK_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Salary & Jamsostek</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Additional Salary & Jamsostek Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/additional_salary_jamsostek/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_REV_NO" placeholder="rev no">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Month</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MONTH" placeholder="month">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="APPROVED" placeholder="approved">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED" placeholder="checked">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY" placeholder="made by">
		          </div>
		        </div>	
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Additional Salary & Jamsostek Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/additional_salary_jamsostek/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_REV_NO">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Month</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MONTH">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="APPROVED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY">
		          </div>
		        </div>	
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->