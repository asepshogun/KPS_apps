<section class="content-header">
	<h3>Retur Production Detail Data</h3>
	<small>Detail Data Retur Production</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Retur Production Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<div class="row">
	            		<form>
		            		<div class="col-lg-12" align="center">						
						        <label class="col-sm-12 control-label">SCAN BARCODE / TULISKAN CODE BARCODE</label>
							</div>
						</form>
	            	</div>
	            	<div class="row">	            		
		            	<div class="col-lg-8 col-lg-offset-2">						
						    <input type="text" class="form-control input-lg" name="code" placeholder="barcode code">
						</div>						
	            	</div>
	            	<br>
	            	<div class="row">	            		
	            		<div class="col-lg-12">						
							<div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Save Retur Production</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Refresh Retur Production</button>
					        </div>
						</div>						
	            	</div>
	            					

	            </div>			            
	        </div>
	    </div>
	</div>

	<!--TABLE-->
	<div clas="box-body">
		<table id="retur" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>		        
		        <th>Part No</th>
		        <th>No Label</th>
		        <th>No Barcode</th>
		        <th>QTY</th>
		        <th>Unit</th>
		        <th>Note</th>
		        <th>Delete</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NAME;?></td>      
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->NO_LABEL;?></td>
			        <td><?php echo $value->NO_BARCODE;?></td>
			        <td><?php echo $value->QTY;?></td>      
			        <td><?php echo $value->UNIT;?></td>
			        <td><?php echo $value->NOTE;?></td>			        
			        <td><a href="" url="<?php echo site_url()."/retur/delete/".$value->KPS_RETUR_PRODUCT_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>