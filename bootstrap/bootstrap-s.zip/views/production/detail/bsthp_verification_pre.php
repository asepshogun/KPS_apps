<section class="content-header">
	<h3>Bukti Serah Terima Hasil Produksi Verification Data</h3>
	<small>Data Bukti Serah Terima Hasil Produksi Verification</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Bukti Serah Terima Hasil Produksi Verification</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<div class="row">
	            		<form action="<?php echo site_url(); ?>/BSTHP_Verification/add" method="post">
		            		<div class="col-lg-12" align="center">						
						        <label class="col-sm-12 control-label">SCAN BARCODE / TULISKAN CODE BARCODE</label>
							</div>
	            	</div>
	            	<div class="row">	            		
		            	<div class="col-lg-8 col-lg-offset-2">						
						    <input type="text" class="form-control input-lg" name="code" placeholder="barcode code">
						</div>						
	            	</div>
	            	<br>
	            	<div class="row">	            		
	            		<div class="col-lg-12">						
							<div class="col-lg-6" align="center">
					        	<input type="submit" class="btn bg-olive btn-flat" value="Save BSTHP Verification" />
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Refresh BSTHP Verification</button>
					        </div>
						</div>						
	            	</div>
	            				
						</form>	

	            </div>			            
	        </div>
	    </div>
	</div>
	<!--TABLE-->
	<!--TABLE-->
</div>