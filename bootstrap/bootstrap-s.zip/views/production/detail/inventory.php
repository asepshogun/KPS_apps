<section class="content-header">
	<h3>Inventory Data</h3>
	<small>Inventory Data</small>
	<a href="<?php echo site_url()."/inventory";?>">Back</a>
</section>
<!-- Main content -->
<div class="box-body">
<form method="POST" class="form-horizontal">
				<div class="col-lg-6">
				<div class="form-group">
				  <label class="col-lg-3 control-label">Date</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->DATE?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No Label</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->NO_LABEL?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Code Item</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->LOI_CODE_ITEM?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Part No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->LOI_PART_NO?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Part Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->LOI_PART_NAME?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Customer Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->COMPANY_NAME?>" placeholder="barcode">
				  </div>
				</div>
				</div>
				<div class="col-lg-6">
				<div class="form-group">
					<?php $totalQtyItem=0; foreach ($data as $value1) {
						$totalQtyItem=$totalQtyItem+$value1->QUANTITY;
					}?>
				  <label class="col-lg-3 control-label">Total QTY Item / Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $totalQtyItem."/".count($data);?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Total QTY Item Open / QTY Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $qtyItemOpen."/" .$qtyBarOpen;?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Total QTY Item OTW / QTY Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $qtyItemOTW."/" .$qtyBarOTW;?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Total QTY Item Closed / QTY Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $qtyItemClosed."/" .$qtyBarClosed;?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Unit Item</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $dataOnly->KPS_RFQ_PART_UNIT;?>" placeholder="barcode">
				  </div>
				</div>
				</div>	      	
			</form>
		</div>
<section class="content">
<div class="box">

		<table>
			<tr>
				<td> Status </td>
				<td> : </td>
				<td> Open </td>
			</tr>
			<tr>
				<td> QTY Item Open </td>
				<td> : </td>
				<td><?php echo $qtyItemOpen?></td>
				<td><?php echo $dataOnly->KPS_RFQ_PART_UNIT?></td>
			</tr>
			<tr>
				<td> QTY Barcode Open </td>
				<td> : </td>
				<td><?php echo $qtyBarOpen?></td>
			</tr>
		</table>

	<div class="box-body overflow">
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Barcode NO</th>
		        <th>Barcode Date</th>
		        <th>QYT Item</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { 
				if(empty($value->BARCODE_LABEL_OTW) && empty($value->BARCODE_LABEL_DESTINATION)){$no++; 
				?>
			    <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_DATE;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo "Open";?></td>
				</tr>
		      <?php 
				}
			  } ?>
		    </tbody>
		</table>
	</div>
</div>
<div class="box">
		<table>
		<tr>
			<td> Status </td>
			<td> : </td>
			<td> On The Way </td>
		</tr>
		<tr>
			<td> QTY Item OTW </td>
			<td> : </td>
			<td><?php echo $qtyItemOTW?></td>
			<td><?php echo $dataOnly->KPS_RFQ_PART_UNIT?></td>
		</tr>
		<tr>
			<td> QTY Barcode OTW </td>
			<td> : </td>
			<td><?php echo $qtyBarOTW?></td>
		</tr>
	</table>
	<div class="box-body overflow">
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Barcode NO</th>
		        <th>Barcode Date</th>
		        <th>QYT Item</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no1=0; foreach ($data as $value) 
				{  if($value->BARCODE_LABEL_OTW && empty($value->BARCODE_LABEL_DESTINATION)){
					$no1++;
				?>
			    <tr>
			        <td><?php echo $no1;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_DATE;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo "On The Way";?></td>
				</tr>
		      <?php 
				}
			  } ?>
		    </tbody>
		</table>
	</div>
</div>
<div class="box">
		<table>
		<tr>
			<td> Status </td>
			<td> : </td>
			<td> Closed </td>
		</tr>
		<tr>
			<td> QTY Item Closed </td>
			<td> : </td>
			<td><?php echo $qtyItemClosed?></td>
			<td><?php echo $dataOnly->KPS_RFQ_PART_UNIT?></td>
		</tr>
		<tr>
			<td> QTY Barcode Closed </td>
			<td> : </td>
			<td><?php echo $qtyBarClosed?></td>
		</tr>
	</table>
	<div class="box-body overflow">
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Barcode NO</th>
		        <th>Barcode Date</th>
		        <th>QYT Item</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no2=0; foreach ($data as $value)
				{  if($value->BARCODE_LABEL_OTW && $value->BARCODE_LABEL_DESTINATION){
					$no2++;
				?>
			    <tr>
			        <td><?php echo $no2;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_DATE;?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo "Closed";?></td>
				</tr>
		      <?php 
				}
			  } ?>
		    </tbody>
		</table>
	</div>
</div>
</section>
<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
	  
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Label Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer --</option>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Number --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Part Name --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>				  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Lot</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_LOT">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="QUANTITY">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Length</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="LENGTH">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Prod. Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PROD_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Insp. Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="INSP_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>	 		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Status</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="STATUS">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Inspektor</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="INSPECTOR">					  
					    <option>-- Select Inspektor --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="OPERATOR">					  
					    <option>-- Select Operator --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Sub Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SUB_OPERATOR">					  
					    <option>-- Select Sub Operator --</option>				  
					</select>
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Visual</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VISUAL">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Profile</label>
		          <div class="col-lg-9">				            
		            <input type="file" class="form-control" name="PROFILE">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->