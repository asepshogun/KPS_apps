<section class="content-header">
	<h3>Additional Salary & Jamsostek Data</h3>
	<small>Data Additional Salary & Jamsostek</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No / Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_REV_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Month</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">New Additional Salary & Jamsostek Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Employee Name</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
								    <option>-- Select Employee Name --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Insentif Cuti</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="INSENTIF_CUTI" placeholder="insentif cuti">
					          </div>
					        </div>					        
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Insentif Masa Kerja</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="INSENTIF_MASA_KERJA" placeholder="insentif masa kerja">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Insentif Transport</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="INSENTIF_TRANSPORT" placeholder="insentif transport">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Jamsostek Pph</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="JAMSOSTEK_PPH" placeholder="jamsostek pph">
					          </div>
					        </div>	
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-lg-3 control-label">Jamsostek Sanksi</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="JAMSOSTEK_SANKSI" placeholder="jamsostek sanksi">
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Jamsostek Pot Akses</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="JAMSOSTEK_POT_AKSES" placeholder="jamsostek pot akses">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Note</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="NOTE" placeholder="note">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Total</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="TOTAL" placeholder="total">
					          </div>
					        </div>
				  		</div>
				  		<div class="col-lg-12">
					        <div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Salary & Jamsostek Detail</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Salary & Jamsostek Detail</button>
					        </div>		        
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<!--TABLE-->
	<div clas="box-body">
		<table id="additional_sj_detail" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">NIK</th>
		        <th rowspan="2">Employee Name</th>		        
		        <th rowspan="2">Section</th>
		        <th rowspan="2">Group</th>
		        <th colspan="3"><center>Insentif</center></th>
		        <th colspan="3"><center>Jamsostek</center></th>
		        <th rowspan="2">Total</th>	
		        <th rowspan="2">Note</th>			        	
		      </tr>
		      <tr>
		        <th>Cuti</th>
		        <th>Masa Kerja</th>
		        <th>Transport</th>
		        <th>PPH</th>
		        <th>Sanksi</th>	
		        <th>Pot Akses</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>      
			        <td><?php echo $value->SECTION;?></td>
			        <td><?php echo $value->GROUP;?></td>
			        <td><?php echo $value->INSENTIF_CUTI;?></td>
			        <td><?php echo $value->INSENTIF_MASA_KERJA;?></td>      
			        <td><?php echo $value->INSENTIF_TRANSPORT;?></td>
			        <td><?php echo $value->JAMSOSTEK_PPH;?></td>			        
			        <td><?php echo $value->JAMSOSTEK_SANKSI;?></td>		
			        <td><?php echo $value->JAMSOSTEK_POT_AKSES;?></td>		
			        <td><?php echo $value->TOTAL;?></td>
			        <td><?php echo $value->NOTE;?></td>					        		
			        <td><?php echo $value->Update;?></td>		
			        <td><?php echo $value->Delete;?></td>		
			        <td><a href="" url="<?php echo site_url()."/additional_salary_jamsostek/delete/".$value->KPS_ADDITIONAL_SALARY_JAMSOSTEK_DETAIL_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/additional_salary_jamsostek/delete/".$value->KPS_ADDITIONAL_SALARY_JAMSOSTEK_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>