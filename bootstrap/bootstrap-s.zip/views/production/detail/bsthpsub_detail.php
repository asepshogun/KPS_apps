<section class="content-header">
	<h3>BSTHP Detail Data</h3>
	<small>Bukti Serah Terima Hasil Produksi Detail</small>
</section>
				<form method="POST" class="form-horizontal">
				<div class="col-lg-6">
				<div class="form-group">
				  <label class="col-lg-3 control-label">Date</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->DATE?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No Record</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->NO_RECORD?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->NO?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No REV</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->REV?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Shift</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->SHIFT?>" placeholder="barcode">
				  </div>
				</div>
				</div>
				<div class="col-lg-6">
				<div class="form-group">
				  <label class="col-lg-3 control-label">Warehouse Destination</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->DESTINATION_WAREHOUSE?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Code Product</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->LOI_CODE_ITEM?>" placeholder="Code Product">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Total QTY Product</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="jumlah_qty_bsthp" disabled id="jumlah_qty_bsthp" value="<?php echo $dataOnly->jumlah_qty_bsthp?>" placeholder="Code Product">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $dataOnly->bsthp_barcode_code?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Barcode Pic</label>
				  <div class="col-lg-9">
								     <img alt=""  src="<?php echo site_url(); ?>/label/generateBarcode/code39?text=<?php echo $dataOnly->bsthp_barcode_code; ?>" />	

				  </div>
				</div>
				<div class="box-body">
						<a href="<?php echo site_url()."/bsthp/history_BSTHPDetailSub/".$dataOnly->KPS_BSTHP_DETAIL_ID;?>" class="btn btn-info btn-sm"><i class="fa fa-university"></i> History</a>
					<td><a  target="_blank" href="<?php echo site_url() ?>/bsthp/prints/<?php echo $dataOnly->KPS_BSTHP_ID; ?>" class="btn btn-danger pull-right btn-flat update-link">Print BSTHP</a></td>
				</div>
				</div>	      	
			</form>	             			            
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add BSTHP Detail</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>
			 <div class="box-body">
			 <?php
				if($pesan){
					if($pesan[0]=="W"){
						echo "<label> <font color=red > Code item tidak sesuai dengan yang terdaftar pada BSTHP </font></label>";
					}else{
						echo "<label> <font color=red > Barcode yang anda masukan sudah terdaftar pada BSTHP : ". $pesan[0]->NO_RECORD."</font></label>";
					}
				}
			 ?>
				<form action="<?php echo site_url()."/bsthp/add_detail_sub ";?>" method="POST" class="form-horizontal">
						<div class="form-group">
						  <label class="col-lg-3 control-label">Barcode</label>
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="no_barcode_item" id="no_barcode_item" placeholder="Barcode">
						  </div>
						</div>
						<div class="form-group" style="display:none"> 
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="KPS_BSTHP_DETAIL_ID_SUB" id="KPS_BSTHP_DETAIL_ID_SUB" value="<?php echo $dataOnly->KPS_BSTHP_DETAIL_ID ?>" placeholder="ID BSTHP Detail">
							<input type="text" class="form-control" name="KPS_BSTHP_ID_det" id="KPS_BSTHP_ID_det" value="<?php echo $dataOnly->KPS_BSTHP_ID_det ?>" placeholder="ID BSTHP Detail">
							<input type="text" class="form-control" name="LOICode" id="LOICode" value="<?php echo $dataOnly->LOI_CODE_ITEM?>" placeholder="Code Product">				
						 </div>
						</div>
						<input type="submit" class="btn bg-olive btn-flat pull-left" value="Save Data" />
						<input type="reset" class="btn btn-danger btn-flat pull-right" value="Clear Form " />
				</form>
			</div>
		</div>
	</div>
</div>
<?php 
	// $hallo="CODEDARICLIENT20160302332";
	// $hallo2 = substr($hallo, 0, -3);
	// $hallo3 = substr($hallo,-3);
	// echo $hallo2 . "</br>";
	// echo abs($hallo3);
?>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body overflow">
		<!--TABLE-->
		<table id="BSTHPdetailSub" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Code Barcode</th>
		        <th>Barcode Pic</th>
		        <th>QTY Item</th>	
		        <th>Unit</th>	
		        <th>Delete</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td>	<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo $value->BARCODE_NO; ?>" />

					</td>
			        <td><?php echo $value->LOI_STRANDART_PACKING;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
			        <td><a href="" url="<?php echo site_url()."/bsthp/preDelete/".$value->KPS_BSTHP_DETAIL_SUB_ID;?>" data-toggle="modal" data-target="#delete" class="update-link">Delete</a></td>		        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

</div>

<!--MODAL-->
<!-- Modal ADD-->

<!-- Modal ADD -->

<!-- Modal UPDATE-->

<!-- Modal UPDATE -->
<!-- Modal DELETE-->
<div class="modal fade" id="delete" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">  
	  
	</div>
</div>
<!-- Modal DELETE -->
<!--MODAL-->