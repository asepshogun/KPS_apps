<section class="content-header">
	<h3>Harga Borongan Detail</h3>
	<small>Harga Borongan Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Date From</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_FROM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Date Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_UNTIL" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Harga Borongan Detail Rev</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
	            		<div class="row">
	            			<div class="col-lg-4">
	            				<div class="form-group">
						          <label class="col-lg-3 control-label">Rev No</label>
						          <div class="col-lg-9">
						            <input type="text" class="form-control" name="REV_NO" placeholder="rev no">
						          </div>
						        </div>
	            			</div>
	            			<div class="col-lg-4">
	            				<div class="form-group">
						          <label class="col-lg-3 control-label">Rev Date</label>
						          <div class="col-lg-9">
						            <input type="text" class="form-control" name="REV_DATE" placeholder="rev date">
						          </div>
						        </div>
	            			</div>
	            			<div class="col-lg-4">
	            				<div class="form-group">
						          <label class="col-lg-3 control-label">Rev Contain</label>
						          <div class="col-lg-9">
						            <input type="text" class="form-control" name="REV_CONTAIN" placeholder="rev contain">
						          </div>
						        </div>
	            			</div>
	            		</div>
	            		<div class="row">
	            			<div class="col-lg-6">
	            				<div class="col-lg-6" align="center">
						        	<button type="button" class="btn bg-olive btn-flat pull-left">Save Harga Borongan Detail Rev</button>
						        </div>
	            			</div>
	            			<div class="col-lg-6">
	            				<div class="col-lg-6" align="center">
						        	<button type="button" class="btn bg-olive btn-flat pull-right">Refresh Harga Borongan Detail Rev</button>
						        </div>
	            			</div>
	            		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="harga_borongan_rev" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Rev Date</th>
		        <th>Rev Contain</th>
		        <th>Update</th>		        
		        <th>Delete</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->REV_DATE;?></td>
			        <td><?php echo $value->REV_CONTAIN;?></td>
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/edit/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/delete/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>