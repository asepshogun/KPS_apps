<section class="content-header">
	<h3>Setup Upah Harian Detail</h3>
	<small>Setup Upah Harian Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Valid From</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_FROM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_UNTIL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Setup Upah Harian Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Work Hour</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="WORK_HOUR">					  
								    <option>-- Select Work Hour --</option>								    
								    <option value="7">7</option>								    				 
								    <option value="8">8</option>
								    <option value="9">9</option>
								    <option value="10">10</option>
								    <option value="11">11</option>
								    <option value="12">12</option>
								    <option value="13">13</option>
								    <option value="14">14</option>
								    <option value="15">15</option>
								    <option value="16">16</option>
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Upah Harian Normal Day (Rp)</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="NORMAL_DAY" placeholder="upah harian normal day (rp)">
					          </div>
					        </div>						        	
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-lg-3 control-label">Upah Harian Holiday (Rp)</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="HOLIDAY" placeholder="upah harian holiday (rp)">
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Note</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="NOTE" placeholder="note">
					          </div>
					        </div>
				  		</div>
				  		<div class="col-lg-12">
					        <div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Setup Upah Harian Detail</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Setup Upah Harian Detail</button>
					        </div>		        
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="setup_upah_harian_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		      	<th rowspan="2">No</th>
		        <th rowspan="2">Work Hour</th>
		        <th colspan="2"><center>Upah Harian (Rp)</center></th>		        
		        <th rowspan="2">Note</th>		        
		        <th rowspan="2">Update</th>	        
		        <th rowspan="2">Delete</th>
		      </tr>
		      <tr>
		      	<th>Normal Day</th>		        
		        <th>Holiday</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->WORK_HOUR;?></td>
			        <td><?php echo $value->NORMAL_DAY;?></td>
			        <td><?php echo $value->HOLIDAY;?></td>
			        <td><?php echo $value->NOTE;?></td>
			        <td><a href="" url="<?php echo site_url()."/setup_upah_harian/update/".$value->KPS_SETUP_UPAH_HARIAN_DETAIL_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/setup_upah_harian/delete/".$value->KPS_SETUP_UPAH_HARIAN_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Setup Upah Harian Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/setup_upah_harian/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Work Hour</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="WORK_HOUR">					  
					    <option>-- Select Work Hour --</option>								    
					    <option value="7">7</option>								    				 
					    <option value="8">8</option>
					    <option value="9">9</option>
					    <option value="10">10</option>
					    <option value="11">11</option>
					    <option value="12">12</option>
					    <option value="13">13</option>
					    <option value="14">14</option>
					    <option value="15">15</option>
					    <option value="16">16</option>
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Upah Harian Normal Day (Rp)</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="NORMAL_DAY">
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Upah Harian Holiday (Rp)</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="HOLIDAY">
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Note</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="NOTE">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->


