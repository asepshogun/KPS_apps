<section class="content-header">
	<h3>Setup Group Detail</h3>
	<small>Setup Group Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No / Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_REV_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid From</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_FROM" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">					
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_UNTIL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Setup Upah Harian Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Group</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="GROUP">					  
								    <option>-- Select Group --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->id;?>"><?php echo $value->group_name;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">NIK</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="nik" placeholder="nik">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Employee</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
								    <option>-- Select Employee --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>						        	
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Group</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
								    <option>-- Select Group --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_STATUS;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Number Employee</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="NUMBER_EMPLOYEE_IN_GROUP">					  
								    <option>-- Select Number Employee --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_STATUS;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Note</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="NOTE" placeholder="note">
					          </div>
					        </div>
				  		</div>
				  		<div class="col-lg-12">
					        <div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Setup Group Detail</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Setup Group Detail</button>
					        </div>		        
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="setup_group_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		      	<th>No</th>
		        <th>Group</th>
		        <th>NIK</th>		        
		        <th>Employee Name</th>
		        <th>Employee Status</th>		        
		        <th>Number Employee In Group</th>		        
		        <th>Note</th>		        
		        <th>Update</th>	        
		        <th>Delete</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->GROUP;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->EMPLOYEE_STATUS;?></td>
			        <td><?php echo $value->NUMBER_EMPLOYEE_IN_GROUP;?></td>
			        <td><?php echo $value->NOTE;?></td>
			        <td><a href="" url="<?php echo site_url()."/setup_group/update/".$value->KPS_SETUP_GROUP_DETAIL_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/setup_group/delete/".$value->KPS_SETUP_GROUP_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    

	  </div>
	  
	</div>
</div>
<!-- Modal Update-->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Setup Group Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/setup_group/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Group</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="GROUP">					  
					    <option>-- Select Group --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">NIK</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="nik">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Employee</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
					    <option>-- Select Employee --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Group</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
					    <option>-- Select Group --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Number Employee</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="NUMBER_EMPLOYEE_IN_GROUP">					  
					    <option>-- Select Number Employee --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">Note</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="NOTE">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->