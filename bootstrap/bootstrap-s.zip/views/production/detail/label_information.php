<section class="content-header">
	<h3>Label Information Detail</h3>
	<small>Label Information Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled value="<?php echo $data->COMPANY_NAME ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled value="<?php echo $data->LOI_CODE_ITEM ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NO" disabled value="<?php echo $data->LOI_PART_NO ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled value="<?php echo $data->LOI_PART_NAME ?>">
			          </div>
			        </div>
			       <!--  <div class="form-group">
			          <label class="col-sm-3 control-label">Operator</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="OPERATOR" disabled value="<?php echo $data->OPERATOR ?>">
			          </div>
			        </div>		 -->        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Label Information Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal" method="POST" action="<?php echo site_url() ?>/label_information/addsub">
				  		<div class="col-lg-6">
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Process</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="PROCESS_ID_LFD">					  
								    <option>-- Select Process --</option>
								    <?php foreach ($proses as $value) { ?>
								    <option value="<?php echo $value->KPS_PROSES_ID;?>"><?php echo $value->NAMA_PROSES;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Tooling Code</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_TOOLING_ID_LFD">					  
								    <option>-- Select Tooling Code --</option>
								    <?php foreach ($tooling as $value) { ?>
								    <option value="<?php echo $value->KPS_ITEM_MASTER_TOOLING_ID;?>"><?php echo $value->ASET_CODE;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Machine Name & Line</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
								    <option>-- Select Machine Line --</option>
								    <?php foreach ($machine as $value) { ?>
								    <option value="<?php echo $value->KPS_MACHINE_ID;?>"><?php echo $value->MACHINE_NAME;?> & <?php echo $value->MACHINE_LINE;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					      
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Operator</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
								    <option>-- Select Operator --</option>
								    <?php foreach ($employee as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>		        
				  		</div>
						<input type="hidden" class="form-control" name="KPS_LABEL_INFORMATION_ID" value="<?php echo $data->KPS_LABEL_INFORMATION_ID; ?>">

				  		<div class="col-lg-12">
				  			<div class="col-lg-6" align="center">
					        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Label Information Detail" />
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Label Information Detail</button>
					        </div>
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Process</th>
		        <th>Tooling Code</th>
		        <th>Machine Line</th>
		        <th>Machine Name</th>	        
		        <th>Operator</th>
		        <th>Tooling No</th>
		        <th>Cav No</th>
		        <th>Operator Name</th>
		        <th>No Lot</th>
		        <th>Production Date</th>
		        <th>Update</th>		        
		        <th>Delete</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NAMA_PROSES;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>
			        <td><?php echo $value->MACHINE_LINE;?></td>
			        <td><?php echo $value->MACHINE_NAME;?></td>
			        <td><?php echo $value->OPERATOR;?></td>
			        <td><?php echo $value->TOOLING_NO;?></td>
			        <td><?php echo $value->CAV_NO;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->NO_LOT;?></td>
			        <td><?php echo $value->PRODUCTION_DATE;?></td>
			        <td><a href="" url="<?php echo site_url()."/label_information/edit/".$value->KPS_LABEL_INFORMATION_DETAIL_ID;?>">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/label_information/delete/".$value->KPS_LABEL_INFORMATION_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Label Infromation Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label_information/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Process</label>
		          <div class="col-sm-9"
		            <select class="form-control select2" style="width: 100%;" name="PROSES_ID_LFD">					  
					    <option>-- Select Process --</option>					  
					</select>
		          </div>
		        </div>
	  			<div class="form-group">
		          <label class="col-sm-3 control-label">Tooling Code</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_TOOLING_ID_LFD">					  
					    <option>-- Select Tooling Code --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Machine Line</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
					    <option>-- Select Machine Line --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Machine Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
					    <option>-- Select Machine Name --</option>		  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
					    <option>-- Select Operator --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->