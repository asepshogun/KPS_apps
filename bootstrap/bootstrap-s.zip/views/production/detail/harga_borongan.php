<section class="content-header">
	<h3>Harga Borongan Detail</h3>
	<small>Harga Borongan Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Date From</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_FROM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Date Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_UNTIL" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Harga Borongan Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Process</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
								    <option>-- Select Process --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_PROSES_ID;?>"><?php echo $value->NAMA_PROSES;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Tooling Code</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_TOOLING_ID">					  
								    <option>-- Select Tooling Code --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_TOOLING_ID;?>"><?php echo $value->TOOLING_CODE;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Line Machine</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
								    <option>-- Select Line Machine --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_MACHINE_ID;?>"><?php echo $value->MACHINE_LINE;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Machine Name</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
								    <option>-- Select Machine Name --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_MACHINE_ID;?>"><?php echo $value->MACHINE_NAME;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-lg-3 control-label">C/T (Sec) Machine</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="CT_MACHINE" value="Otomatis">
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">C/T (Sec) Man</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="CT_MAN" value="Otomatis">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">C/T (Sec) Charge (Rp)</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="CT_CHARGE" placeholder="charge">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Harga Approved Produksi</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="HARGA_APPROVED_PRODUKSI" value="Otomatis">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Approved Direktur</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="APPROVED_DIREKTUR" placeholder="approved direktur">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Rev Harga No</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="REV_HARGA_NO" placeholder="rev harga no">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Remaks</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="REMAKS" placeholder="remarks">
					          </div>
					        </div>			        
				  		</div>
				  		<div class="col-lg-12">
				  			<div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Harga Borongan Detail</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Harga Borongan Detail</button>
					        </div>
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="harga_borongan_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">Process</th>
		        <th colspan="2"><center>DOC NO</center></th>
		        <th rowspan="2">Tooling Code</th>
		        <th rowspan="2">Tooling Maker</th>
		        <th rowspan="2">Tooling No</th>
		        <th rowspan="2">Cav No</th>
		        <th rowspan="2">Line Machine</th>
		        <th rowspan="2">Machine Name</th>	        
		        <th colspan="3"><center>C/T (Sec)</center></th>		        
		        <th colspan="2"><center>Harga</center></th>
		        <th rowspan="2">Approved Direktur</th>
		        <th rowspan="2">Rev Harga No</th>
		        <th rowspan="2">Remaks</th>
		        <th rowspan="2">Update</th>		        
		        <th rowspan="2">Delete</th>
		      </tr>
		      <tr>
		      	<th>No</th>
		      	<th>Rev No</th>
		      	<th>Machine</th>
		      	<th>Man</th>
		      	<th>Charge (Rp)</th>
		      	<th>Pengajuan Engineering</th>
		      	<th>Approved Produksi</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NAMA_PROSES;?></td>
			        <td><?php echo $value->DOC_NO;?></td>
			        <td><?php echo $value->DOC_REV_NO;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>
			        <td><?php echo $value->TOOLING_MAKER;?></td>
			        <td><?php echo $value->TOOLING_NO;?></td>
			        <td><?php echo $value->CAV_NO;?></td>
			        <td><?php echo $value->MACHINE_LINE;?></td>
			        <td><?php echo $value->MACHINE_NAME;?></td>
			        <td><?php echo $value->CT_MACHINE;?></td>
			        <td><?php echo $value->CT_MAN;?></td>
			        <td><?php echo $value->CT_CHARGE;?></td>
			        <td><?php echo $value->HARGA_APPROVED_PRODUKSI;?></td>
			        <td><?php echo $value->APPROVED_DIREKTUR;?></td>
			        <td><?php echo $value->REV_HARGA_NO;?></td>
			        <td><?php echo $value->REMAKS;?></td>
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/edit/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/harga_borongan/delete/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>