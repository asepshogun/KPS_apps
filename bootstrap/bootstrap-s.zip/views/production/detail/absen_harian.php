<section class="content-header">
	<h3>Absen Harian Detail</h3>
	<small>Absen Harian Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date Absen</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_ABSEN" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Shift</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="SHIFT" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Absen Harian Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">NIK</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
								    <option>-- Select NIK --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->NIK;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Absen</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="ABSEN">					  
								    <option>-- Select Absen --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_ABSEN_HARIAN_ID;?>"><?php echo $value->MADE_BY;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Work Hour From</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="WORK_HOUR_FROM" placeholder="work hour from">
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Work Hour Until</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="WORK_HOUR_UNTIL" placeholder="work hour until">
					          </div>
					        </div>	
				  		</div>
				  		<div class="col-lg-6">
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Work Hour Break</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="WORK_HOUR_BREAK" placeholder="work hour break">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Paid As</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="PAID_AS">					  
								    <option>-- Select Paid As --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_ABSEN_HARIAN_ID;?>"><?php echo $value->APPROVED;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Note</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="NOTE" placeholder="note">
					          </div>
					        </div>			        
				  		</div>
				  		<div class="col-lg-12">
				  			<div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Absen Harian</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Absen Harian</button>
					        </div>
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!-- <th rowspan="2">No</th>
        <th colspan="3"><center>Request For Quotation</center></th> -->
		<!--TABLE-->
		<table id="absen_harian_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">NIK</th>
		        <th rowspan="2">Employee Name</th>
		        <th rowspan="2">Section</th>
		        <th rowspan="2">Absen</th>
		        <th rowspan="2">Employee Status</th>
		        <th rowspan="2">Group</th>
		        <th colspan="4"><center>Work Hour</center></th>		        
		        <th rowspan="2">Paid As</th>
		        <th rowspan="2">Note</th>	        
		        <th rowspan="2">Delete</th>
		      </tr>
		      <tr>
		      	<th>Work Hour From</th>
		        <th>Work Hour Until</th>
		        <th>Work Hour Break</th>
		        <th>Work Hour Total</th>		      
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->SECTION;?></td>	
			        <td><?php echo $value->ABSEN;?></td>
			        <td><?php echo $value->EMPLOYEE_STATUS;?></td>
			        <td><?php echo $value->GROUP_UPDATE;?></td>
			        <td><?php echo $value->WORK_HOUR_FROM;?></td>
			        <td><?php echo $value->WORK_HOUR_UNTIL;?></td>
			        <td><?php echo $value->WORK_HOUR_BREAK;?></td>
			        <td><?php echo $value->PAID_AS;?></td>
			        <td><?php echo $value->NOTE;?></td>			        		        			        
			        <td><a href="" url="<?php echo site_url()."/absen_harian/delete/".$value->KPS_ABSEN_HARIAN_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>