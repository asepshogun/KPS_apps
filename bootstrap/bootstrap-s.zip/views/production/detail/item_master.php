<section class="content-header">
	<h3>Item Master Data</h3>
	<small>Data Item Master</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $dataOnly->COMPANY_NAME ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="ITEM_MASTER_CODE_ITEM" disabled value="<?php echo $dataOnly->LOI_CODE_ITEM ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="ITEM_MASTER_PART_NAME" disabled value="<?php echo $dataOnly->LOI_PART_NAME ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Berat Produk</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="BERAT_PRODUK1" disabled value="<?php echo $dataOnly->BERAT_PRODUK1 ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Berat Produk + Waster + NG</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="BERAT_PRODUK2" disabled value="<?php echo $dataOnly->BERAT_PRODUK2 ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="ITEM_MASTER_PART_NO" disabled value="<?php echo $dataOnly->LOI_PART_NO ?>">
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Item Master Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">

	            	<div class="col-lg-6">
						<form class="form-horizontal">
							<div class="form-group">
					          <label class="col-sm-3 control-label">Area</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="AREA" placeholder="area">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Code Item</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="ITEM_MASTER_CODE_ITEM" placeholder="code item">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Part Name</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="ITEM_MASTER_PART_NAME" placeholder="part name">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Part No</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="ITEM_MASTER_PART_NO" placeholder="part no">
					          </div>
					        </div>
						</form>
					</div>
					<div class="col-lg-6">
						<form class="form-horizontal">
							<div class="form-group">
					          <label class="col-sm-3 control-label">Process</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="PROCESS_NAME" placeholder="process">
					          </div>
					        </div>				        
						</form>
						<div class="col-lg-6" align="center">
				        	<button type="button" class="btn bg-olive btn-flat pull-right">Save Item Master</button>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="button" class="btn bg-olive btn-flat pull-left">Refresh Item Master</button>
				        </div>
					</div>

	            </div>			            
	        </div>
	    </div>
	</div>

	<!--TABLE-->
	<div class="box-body">
		<table id="item_master_detail" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Area</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Process</th>
		        <th>Detail</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->AREA;?></td>
			        <td><?php echo $value->ITEM_MASTER_CODE_ITEM;?></td>
			        <td><?php echo $value->ITEM_MASTER_PART_NAME;?></td>
			        <td><?php echo $value->ITEM_MASTER_PART_NO;?></td>      
			        <td><?php echo $value->NAMA_PROSES;?></td>      
			        <td><a href="<?php echo site_url()."/item_master_detail/detail/".$value->KPS_ITEM_MASTER_DETAIL_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>