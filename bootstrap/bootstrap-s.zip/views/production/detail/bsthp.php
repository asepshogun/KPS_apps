<section class="content-header">
	<h3>BSTHP Detail Data</h3>
	<small>Bukti Serah Terima Hasil Produksi Detail</small>
</section>
<?php print_r($dataOnly->KPS_BSTHP_ID);?>
				<form method="POST" class="form-horizontal">
				<div class="col-lg-6">
				<div class="form-group">
				  <label class="col-lg-3 control-label">Date</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->DATE?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No Record</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->NO_RECORD?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->NO?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">No REV</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->REV?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Shift</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->SHIFT?>" placeholder="barcode">
				  </div>
				</div>
				</div>
				<div class="col-lg-6">
				<div class="form-group">
				  <label class="col-lg-3 control-label">Warehouse Destination</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" id="bsthp_barcode_code" value="<?php echo $dataOnly->DESTINATION_WAREHOUSE?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Barcode</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" readonly=readonly  id="bsthp_barcode_code" value="<?php echo $dataOnly->bsthp_barcode_code?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Barcode Pic</label>
				  <div class="col-lg-9">
								     <img alt=""  src="<?php echo site_url(); ?>/label/generateBarcode/code39?text=<?php echo $dataOnly->bsthp_barcode_code; ?>" />	

				  </div>
				</div>
				</div>	      	
			</form>	             
			<div class="box-body">
				<td><a  target="_blank" href="<?php echo site_url() ?>/bsthp/prints/<?php echo $dataOnly->KPS_BSTHP_ID; ?>" class="btn btn-danger pull-right btn-flat update-link">Print BSTHP</a></td>
			</div>
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add BSTHP Detail</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>
			 <div class="box-body">
				<form action="<?php echo site_url()."/bsthp/add_detail";?>" method="POST" class="form-horizontal">
					<div class="col-lg-6">
						<div class="form-group">
						  <label class="col-lg-3 control-label">Code Item</label>
						 <div class="col-lg-9">
							<select class="form-control select2" id="mutationloi" name="KPS_LOI_ID_BSTHP_Detail">					  
								<option>-- Select Code Item --</option>
									<?php foreach ($dataLoi as $value) { ?>
									<option value="<?php echo $value->KPS_LOI_ID;?>">
										<?php echo $value->LOI_CODE_ITEM.", Model. ".$value->LOI_MODEL.", Part No. ".$value->LOI_PART_NO.", Part Name: ".$value->LOI_PART_NAME;?></option>
									<?php } ?>			  
							</select>
						  </div>
						</div>
						<div class="form-group" style="display:none"> 
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="KPS_BSTHP_ID_det" id="KPS_BSTHP_ID" value="<?php echo $dataOnly->KPS_BSTHP_ID;?>" placeholder="ID BSTHP">
						  </div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
						  <label class="col-lg-3 control-label">Note</label>
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE" placeholder="Note">
						  </div>
						</div>
						<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Data" />
						<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form " />
					</div>
		
				</form>
			</div>
		</div>
	</div>
</div>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="BSTHP_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>QTY Barcode</th>
		        <th>QTY Item</th>	
		        <th>Unit</th>	
		        <th>Note</th>	
		        <th>Edit</th>	
		        <th>Delete</th>	
		        <th>Submit</th>	
		        <th>History</th>	
		        <th>Detail</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			     <!--   <td><?php 
			        // $query = $this->db->query("select * from kps_barcode_label where label_id='".$value->KPS_LABEL_ID."'")->first_row();
			        
			        // echo $query->code_label;
			        ?></td>-->
			        <td><?php echo $value->qty_barcode_bsthp;?></td>
			        <td><?php echo $value->jumlah_qty_bsthp;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
			        <td><?php echo $value->NOTE_detail_bsthp;?></td>
					<?php 
					if(empty($value->BSTHP_DETAIL_LOCK)){
					?>
					<style>
						.mutation_detail{
						   pointer-events: none;
						   cursor: default;
						   color: grey;
						}
					</style>	
					<?php
					}else{
					?>
					<style>
						.mutation_change{
						   pointer-events: none;
						   cursor: default;
						   color: grey;
						}
					</style>	
					<?php
					}?>
					<td><a href="" url="<?php echo site_url()."/bsthp/editDetail/".$value->KPS_BSTHP_DETAIL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
					<td><a class="mutation_change" href="" url="<?php echo site_url()."/bsthp/delete/".$value->KPS_BSTHP_DETAIL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
			        <td><a class="mutation_change" href="<?php echo site_url()."/bsthp/lock/".$value->KPS_BSTHP_DETAIL_ID . "/" . $id_bsthp;?>">Submit</a></td>		        
			        <td><a  href="<?php echo site_url()."/bsthp/historyDetail/".$value->KPS_BSTHP_DETAIL_ID;?>">History</a></td>
			        <td><a  href="<?php echo site_url()."/bsthp/detail_sub/".$value->KPS_BSTHP_ID_det . "/" . $value->KPS_BSTHP_DETAIL_ID;?>" >Detail</a></td>		        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">  
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->