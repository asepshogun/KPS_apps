<section class="content-header">
	<h3>Label Detail</h3>
	<small>Label Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="QUANTITY" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Prod. Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PROD_DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Insp. Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INSP_DATE" disabled>
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Inspektor</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INSPECTOR" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Operator</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="OPERATOR" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Label Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Code Item</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
								    <option>-- Select Code Item --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->CODE_ITEM;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Process</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
								    <option>-- Select Process --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_PROSES_ID;?>"><?php echo $value->NAMA_PROSES;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">MC</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="REMAKS" placeholder="mc">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-sm-3 control-label">Code Tools</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
								    <option>-- Select Line Machine --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_TOOLING_ID;?>"><?php echo $value->TOOLING_CODE;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
				  		</div>
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Operator</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
								    <option>-- Select Operator --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
				  			<div class="form-group">
					          <label class="col-lg-3 control-label">QTY</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="QUANTITY" placeholder="quantity">
					          </div>
					        </div>				        
				  		</div>
				  		<div class="col-lg-12">
				  			<div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Label Detail</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Label Detail</button>
					        </div>
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Process</th>
		        <th>MC</th>
		        <th>Code Tools</th>	        
		        <th>Operator</th>		        
		        <th>Quantity</th>
		        <th>Update</th>		        
		        <th>Delete</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->NAMA_PROSES;?></td>
			        <td><?php echo $value->MC;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>
			        <td><?php echo $value->Operator;?></td>
			        <td><?php echo $value->Quantity;?></td>
			        <td><a href="" url="<?php echo site_url()."/label/edit/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Update</a></td>		        
			        <td><a href="" url="<?php echo site_url()."/label/delete/".$value->KPS_HARGA_BORONGAN_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Label Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/label/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Code Item --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Process</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Process --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-lg-3 control-label">MC</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="REMAKS">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Tools</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
					    <option>-- Select Line Machine --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Operator</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_MACHINE_ID">					  
					    <option>-- Select Operator --</option>					  
					</select>
		          </div>
		        </div>
	  			<div class="form-group">
		          <label class="col-lg-3 control-label">QTY</label>
		          <div class="col-lg-9">
		            <input type="text" class="form-control" name="QUANTITY">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>		      	
	        </form>	        	    			      		        
	    </div>
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->