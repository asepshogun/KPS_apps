<section class="content-header">
	<h3>BSTHP Detail Data</h3>
	<small>Bukti Serah Terima Hasil Produksi Detail History</small>
</section>           			            
<section class="content"> 
<div class="box">
	<div class="box-body overflow">
		<!--TABLE-->
		<table id="BSTHPdetailSub" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Code Barcode</th>
		        <th>Barcode Pic</th>
		        <th>QTY Item</th>	
		        <th>Unit</th>	
		        <th>Delete By</th>	
		        <th>Delete Date</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td>	<img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo $value->BARCODE_NO; ?>" />

					</td>
			        <td><?php echo $value->LOI_STRANDART_PACKING;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_BSTHP_DETAIL_SUB_UPDATE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></td>			       
			        <td><?php echo $value->UPDATE_TIME;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

</div>
