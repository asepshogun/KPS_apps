<script type="text/javascript">
	window.print();
</script>

<style>
	.rightside{
		float: right;
	}
	.leftside{
		float: left;
	}
</style>
<h3><center>BUKTI SERAH TERIMA HASIL PRODUKSI</center></h3>
</br>
</br>
<div class="leftside">
	<table border=1 width=100%>
		<tr><td>Date</td><td><?php echo $data->DATE?></td></tr>
		<tr><td>No. Record</td><td><?php echo $data->NO_RECORD?></td></tr>
		<tr><td>Rev. No.</td><td><?php echo $data->REV?></td></tr>
		<tr><td>Shift</td><td><?php echo $data->SHIFT?></td></tr>
		<tr><td>Destination Warehouse</td><td><?php echo $data->DESTINATION_WAREHOUSE?></td></tr>
	</table>
</div>
<div class="rightside">
	<table>
		<tr><td></td><td><img alt="" src="<?php echo site_url(); ?>/label/generateBarcode/code39?text=<?php echo $data->bsthp_barcode_code; ?>" /></td></tr>
		<tr><td></td><td align="center"> <?php echo $data->bsthp_barcode_code; ?></td></tr>
		<tr><td>QTY Barcode/Dus :</td></td></tr>
	</table>
</div>
</br>
<table>
	<thead>
	  <tr>
		<th>Code Item</th>
		<th>Part Name</th>		        
		<th>Part No</th>
		<th>QTY Barcode</th>
		<th>QTY Item</th>
		<th>Units</th>
		<th>Note</th>
	  </tr>
	</thead>
	<tbody>
	<?php $no=0; foreach ($data_detail as $value) {$no++ ?>
	  <tr>
		<td><?php echo $value->LOI_CODE_ITEM;?></td>
		<td><?php echo $value->LOI_PART_NAME;?></td>
		<td><?php echo $value->LOI_PART_NO;?></td>
		<td><?php echo $value->qty_barcode_bsthp;?></td>   
		<td><?php echo $value->jumlah_qty_bsthp;?></td> 		        
		<td><?php echo $value->KPS_RFQ_PART_UNIT;?></td> 		        
		<td><?php echo $value->NOTE;?></td> 		        
	  </tr>
  <?php } ?>
	</tbody>
</table><br><br><br>
<div class="rightside">
<table border="1">
	<tbody>
		<tr>
			        <td><center>Made By <br><br><br><br><u><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->BSTHP_MADE_BY	."'");
			        	$data1 = mysql_fetch_array($query);
			        	echo $data1['EMPLOYEE_NAME'];
			        ?></u><br>Admin Production</center></td>
					<td><center>Distributed By<br><br><br><br><u><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->BSTHP_DISTRIBUTED_BY	."'");
			        	$data2 = mysql_fetch_array($query);
			        	echo $data2['EMPLOYEE_NAME'];
			        ?></u><br>Distribution Section</center></td>
					<td><center>Accepted By<br><br><br><br><u><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->BSTHP_ACCEPTED_BY	."'");
			        	$data3 = mysql_fetch_array($query);
			        	echo $data3['EMPLOYEE_NAME'];
			        ?></u><br>Warehouse/WIP</center></td>
		</tr>
	</tbody>
</table>
</div>
<?php foreach($data as $value){
	?>
	<div>
	
	</div>
	<?php
	} ?>
