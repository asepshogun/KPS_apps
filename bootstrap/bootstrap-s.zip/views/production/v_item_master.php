<section class="content-header">
	<h3>Item Master Data</h3>
	<small>Data Item Master</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="item_master" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part Number</th>
		        <th>Model</th>        
		        <th>Total Mold</th>
		        <th>Customer</th>		        
		        <th>LOI Date</th>
		        <th>QTY / Month</th>
		        <th>Periode</th>
		        <th>Berat Product</th>        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		        <th>Add Tooling Inform</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>			        
			        <td><?php echo $value->TOTAL_MOLD;?></td>
			        <td><?php echo $value->COMPANY_NAME	;?></td>
			        <td><?php echo $value->DATE_LOI;?></td>
			        <td>-</td>	
			        <td>-</td>			        
			        <td><?php echo $value->BERAT_PRODUK1;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/item_master/update/".$value->KPS_ITEM_MASTER_ID;?>">Update</a></td>
			        <td><a href="<?php echo site_url()."/item_master/delete/".$value->KPS_ITEM_MASTER_ID;?>">Delete</a></td>
			        <td><a href="<?php echo site_url()."/item_master/detail/".$value->KPS_ITEM_MASTER_ID;?>">Detail</a></td>	
			        <td><a href=""  data-toggle="modal" data-target="#addTool">Add</a></td>		        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Item Master</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Item Master Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/item_master/add";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" url="<?php echo site_url()."/quantity/loadLoi"; ?>" name="customer" id="customers" url="<?php echo site_url()."/quantity/loadLoi"; ?>" name="customer" id="customers">					  
					    <option>-- Select Customer Name --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="lois" name="KPS_LOI_ID">					  
					    <option>-- Select Part Number --</option>
					    				  
					</select>
		          </div>
		        </div>
		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="LOI_CODE_ITEM" placeholder="code item">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Total Mold</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="TOTAL_MOLD" placeholder="total mold">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Berat Produk</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BERAT_PRODUK1" placeholder="berat produk">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="Rev No" placeholder="rev no">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="REV_DATE_CODE_ITEM" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev Date Process</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="REV_DATE_PROCESS" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev Contain</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REV_CONTAIN" placeholder="rev contain">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NOTE" placeholder="note">
		          </div>
		        </div>		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO">					  
					    <option>-- Select Approved --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->APPROVED;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="rfq_id">					  
					    <option>-- Select Checked --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->CHECKED;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Prepared</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO">					  
					    <option>-- Select Prepared --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->kps_item_master_id;?>"><?php echo $value->PREPRED;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal ADD TOOL-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Tooling Information Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/item_master/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Aset Code</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="ASET_CODE" placeholder="aset code">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO" placeholder="no">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Supplier</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SUPPLIER" placeholder="supplier">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD TOOL-->

<!-- Modal ADD TOOL-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal ADD TOOL-->