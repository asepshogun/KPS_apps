 
	<link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
	<link href="<?php echo base_url("bootstrap/plugins/datepicker/css/bootstrap-datepicker3.min.css"); ?>" rel="stylesheet">
<!--wrapper -->

  <script src="<?php echo base_url("bootstrap/plugins/jQuery/jQuery.min.js"); ?>"></script> 
  <script src="<?php echo base_url("bootstrap/js/bootstrap.min.js"); ?>"></script>  
  <script src="<?php echo base_url("bootstrap/dist/js/app.min.js"); ?>"></script>  
  <script src="<?php echo base_url("bootstrap/plugins/select2/select2.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/js/script.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/js/revisiScript.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/datepicker/js/bootstrap-datepicker.min.js"); ?>"></script>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>

