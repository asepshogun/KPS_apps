<?php
	$this->load->view('header');
	$this->load->view($content);	
	$this->load->view('footer');
?>