<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Employee Data Detail</h4>
	    </div>
	    <div class="modal-body">	    	
	    	<form action="<?php echo site_url()."/employee/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">NIK</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NIK" placeholder="nik" value="<?php echo $data->NIK ?>">
		            <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_EMPLOYEE_ID ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Employee Name</label>
		          <div class="col-sm-9">
		            <input type="text" value="<?php echo $data->EMPLOYEE_NAME ?>" class="form-control" name="EMPLOYEE_NAME" placeholder="employee name">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Address</label>
		          <div class="col-sm-9">
		            <input type="text" value="<?php echo $data->ADDRESS_EP ?>" class="form-control" name="ADDRESS_EP" placeholder="address">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Phone Number</label>
		          <div class="col-sm-9">
		            <input type="text" value="<?php echo $data->PHONE_EP ?>" class="form-control" name="PHONE_EP" placeholder="phone number">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Email</label>
		          <div class="col-sm-9">
		            <input type="text" value="<?php echo $data->EMAIL ?>" class="form-control" name="EMAIL" placeholder="email">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Department</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="DEPT_EMPLOYEE_ID" urldivisi="<?php echo site_url(); ?>/employee/loadSection" id="eddept">					  
					    <option>-- Select Department --</option>
					    <?php foreach ($dataDepartment as $value) { ?>
					    <option value="<?php echo $value->DEPT_EMPLOYEE_ID;?>"  <?php if($value->DEPT_EMPLOYEE_ID==$data->DEPT_EMPLOYEE_ID){
			    		echo "selected=''";
			    	} ?>><?php echo $value->DEPT_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Section</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SEC_EMPLOYEE_ID" urldivisi="<?php echo site_url(); ?>/employee/loadPosition" id="edsect">					  
					    <option>-- Select Section --</option>
					    <?php foreach ($dataSection as $value) { ?>
					    <option value="<?php echo $value->SEC_EMPLOYEE_ID;?>"  <?php if($value->SEC_EMPLOYEE_ID==$data->SEC_EMPLOYEE_ID){
			    		echo "selected=''";
			    	} ?>><?php echo $value->SEC_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Position</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="POSITION_ID" id="edspos">					  
					    <option>-- Select Position --</option>
					    <?php foreach ($dataPosition as $value) { ?>
					    <option value="<?php echo $value->POSITION_ID;?>"  <?php if($value->POSITION_ID==$data->POSITION_ID){
			    		echo "selected=''";
			    	} ?>><?php echo $value->POS_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Group</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="kps_group_id">					  
					    <option>-- Select Group --</option>
					    <?php foreach ($dataGroup as $value) { ?>
					    <option value="<?php echo $value->id;?>"  <?php if($value->id==$data->kps_group_id){
			    		echo "selected=''";
			    	} ?>><?php echo $value->group_name;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Domisili Kerja</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="DOMISILI_KERJA">					  
					    <option>-- Select Domisili --</option>
					    <?php foreach ($dataDomisili as $value) { ?>
					    <option value="<?php echo $value->nama_kabkota;?>"  <?php if($value->nama_kabkota==$data->DOMISILI_KERJA){
			    		echo "selected=''";
			    	} ?>><?php echo $value->nama_kabkota;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		         	<label class="col-sm-3 control-label">Employee Status</label>
		          	<div class="col-sm-9">
							<div class="checker"><span>
							<input type="checkbox" value="on" <?php if($data->EMPLOYEE_STATUS=="on"){
			    		echo "checked=''";
			    	} ?> name="EMPLOYEE_STATUS"></span> On</div>
					</div>
		        </div>	
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        	        
	    </div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>