<section class="content-header">
	<h3>Employee Management</h3>
	<small>Manajemen Karyawan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="employees" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>NIK</th>
		        <th>Employee Name</th>
		        <th>Address</th>
		        <th>Phone</th>
		        <th>Mail</th>
		        <th>Department</th>
		        <th>Section</th>
		        <th>Position</th>
		        <th>Group</th>
		        <th>Domisili Kerja</th>
		        <th>Update</th>
		        <th>Delete</th>	        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->ADDRESS_EP;?></td>
			        <td><?php echo $value->PHONE_EP;?></td>
			        <td><?php echo $value->EMAIL;?></td>
			        <td><?php echo $value->DEPT_NAME;?></td>
			        <td><?php echo $value->SEC_NAME;?></td>
			        <td><?php echo $value->POS_NAME;?></td>
			        <td><?php echo $value->group_name;?></td>
			        <td><?php echo $value->DOMISILI_KERJA;?></td>
			        <td><a href="<?php echo site_url()."/employee/edit/".$value->KPS_EMPLOYEE_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/employee/delete/".$value->KPS_EMPLOYEE_ID;?>" class="btn btn-danger btn-sm">Delete</a></td>
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Employee</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Employee</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/employee/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">NIK</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NIK" placeholder="nik" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Employee Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="EMPLOYEE_NAME" placeholder="employee name" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Address</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="ADDRESS_EP" placeholder="address" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Phone Number</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="PHONE_EP" placeholder="phone number" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Email</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="EMAIL" placeholder="email">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Department</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="DEPT_EMPLOYEE_ID" urldivisi="<?php echo site_url(); ?>/employee/loadSection" id="dept">					  
					    <option>-- Select Department --</option>
					    <?php foreach ($dataDepartment as $value) { ?>
					    <option value="<?php echo $value->DEPT_EMPLOYEE_ID;?>"><?php echo $value->DEPT_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Section</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SEC_EMPLOYEE_ID" urldivisi="<?php echo site_url(); ?>/employee/loadPosition" id="sect">					  
					    <option>-- Select Section --</option>
					   				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Position</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="POSITION_ID" urldivisi="<?php echo site_url(); ?>/employee/loadGroup" id="pos">					  
					    <option>-- Select Position --</option>
					  				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Group</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="kps_group_id" id="group">					  
					    <option>-- Select Group --</option>
					    <?php foreach ($dataGroup as $value) { ?>
					    <option value="<?php echo $value->id;?>"><?php echo $value->group_name;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Domisili Kerja</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="DOMISILI_KERJA">					  
					    <option>-- Select Domisili --</option>
					    <?php foreach ($dataDomisili as $value) { ?>
					    <option value="<?php echo $value->nama_kabkota;?>"><?php echo $value->nama_kabkota;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		         	<label class="col-sm-3 control-label">Employee Status</label>
		          	<div class="col-sm-9">
							<div class="checker"><span>
							<input type="checkbox" value="on" name="EMPLOYEE_STATUS"></span> On</div>
					</div>
		        </div>		        

		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->