<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">User Data Detail</h4>
	    </div>
	    <div class="modal-body">	    	
	    	<form action="<?php echo site_url()."/user_data/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Employee</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">	
		            	<option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->KPS_EMPLOYEE_ID){
			    		echo "selected=''";
			    	} ?>><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Username</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="USERNAME" value="<?php echo $data->USERNAME; ?>">
		            <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_USERDATA_ID; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		         	<label class="col-sm-3 control-label">Roles</label>
		          	<div class="col-sm-9">
						<?php foreach ($dataRoles as $valueRoles) { 
							
						?>
							<div class="checker"><span>
							<input type="radio" value="<?php echo $valueRoles->id ?>" name="roles[]"></span><?php echo $valueRoles->description ?></div>
						<?php
						}
						?>			

					</div>
		        </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        	        
	    </div>

	    <script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>