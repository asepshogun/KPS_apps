<section class="content-header">
	<h3>User Data Management</h3>
	<small>Manajemen Data Pengguna</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="user_data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Username</th>
		        <th>NIK</th>
		        <th>Employee Name</th>
		        <th>Department</th>
		        <th>Section</th>
		        <th>Position</th>
		        <th>User Role</th>
		        <th>Detail</th>
		        <th>Delete</th>	        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->USERNAME;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->DEPARTMENT;?></td>
			        <td><?php echo $value->SECTIONUSER;?></td>
			        <td><?php echo $value->POSITION;?></td>
			        <td>
				        <ul style="padding-left:15px;">
				        	
				        <?php 
				        $dataRolesis = $this->m_roles->getListRoles($value->KPS_USERDATA_ID);
				        
				        if(count($dataRolesis)>0){
				        	foreach ($dataRolesis as $key => $values) {
					        	$dataRoleDetail = $this->m_roles->getRolesName($values->roles_id);
					        	?>
					        	<li>
					        		
					        	<?php
					        	echo $dataRoleDetail->description;
					        	?>
					        	</li>
					        	<?php
				        	}
				    	}else{
				    		echo "data kosong";
				    	}
				        ?>
				        </ul>
			        </td>
			        <td><a href="<?php echo site_url()."/user_data/edit/".$value->KPS_USERDATA_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/user_data/delete/".$value->KPS_USERDATA_ID;?>" class="btn btn-danger btn-sm">Delete</a></td>
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New User Data</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New User Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/user_data/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Employee</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_EMPLOYEE_ID">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Username</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="USERNAME" placeholder="username" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Password</label>
		          <div class="col-sm-9">
		            <input type="password" class="form-control" name="PASSWORD" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Confirm Password</label>
		          <div class="col-sm-9">
		            <input type="password" class="form-control" name="PASSWORD" required>
		          </div>
		        </div>
		        <div class="form-group">
		         	<label class="col-sm-3 control-label">Roles</label>
		          	<div class="col-sm-9">
		          		<?php foreach ($dataRoles as $valueRoles) { ?>
							<div class="checker"><span><input type="radio" value="<?php echo $valueRoles->id ?>" name="roles[]"></span> <?php echo $valueRoles->description ?></div>
						<?php
						}
						?>
					</div>
		        </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->