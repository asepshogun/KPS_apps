<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Marketing Data Detail</h4>
	    </div>
	    <div class="modal-body">	    	
	    	<form action="<?php echo site_url()."/marketing_data/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">NIK</label>
		          <div class="col-sm-9">
		            <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_MARKETING_ID; ?>">
		            <input type="text" class="form-control" name="NIK" value="<?php echo $data->NIK?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Marketing Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MARKETING_NAME" value="<?php echo $data->MARKETING_NAME; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Address</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="ADDRESS" value="<?php echo $data->ADDRESS; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Phone Number</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="PHONE" value="<?php echo $data->PHONE; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Email Address</label>
		          <div class="col-sm-9">
		            <input type="email" class="form-control" name="EMAIL" value="<?php echo $data->EMAIL; ?>">
		          </div>
		        </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        	        
	    </div>