<section class="content-header">
	<h3>Marketing Data Management</h3>
	<small>Manajemen Data Marketing</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="marketing" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>NIK</th>
		        <th>Marketing Name</th>
		        <th>Address</th>
		        <th>Phone</th>
		        <th>Email</th>
		        <th>Date Join</th>
		        <th>Update</th>
		        <th>Delete</th>	        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        <td><?php echo $value->ADDRESS;?></td>
			        <td><?php echo $value->PHONE;?></td>
			        <td><?php echo $value->EMAIL;?></td>
			        <td><?php echo $value->DATE_JOIN;?></td>
			        <td><a href="<?php echo site_url()."/marketing_data/edit/".$value->KPS_MARKETING_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/marketing_data/delete/".$value->KPS_MARKETING_ID;?>" class="btn btn-danger btn-sm">Delete</a></td>
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Marketing Data</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Marketing Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/marketing_data/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">NIK</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NIK" placeholder="nik" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Marketing Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MARKETING_NAME" placeholder="marketing name" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Address</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="ADDRESS" placeholder="address" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Phone Number</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="PHONE" placeholder="phone number" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Email Address</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="EMAIL" placeholder="email address" required>
		          </div>
		        </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->