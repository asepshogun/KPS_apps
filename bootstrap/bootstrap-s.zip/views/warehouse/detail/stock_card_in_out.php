<section class="content-header">
	<h3>Stock Card by In Out Detail Data</h3>
	<small>Data Stock Card by In Out Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">	
					<div class="form-group">
			          <label class="col-sm-3 control-label">Area</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="AREA" disabled>
			          </div>
			        </div>        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body overflow">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Product</th>
		        <th>Part No</th>
		        <th>Part Name</th>
		        <th>Model</th>        
		        <th>Customer Name</th>
		        <th>QTY Stock</th>		        
		        <th>QTY Stock Status</th>
		        <th>QTY Breakdown</th>
		        <th>QTY Min Stock</th>
		        <th>QTY Min Stock Status</th>
		        <th>QTY Delivery Pending</th>
		        <th>QTY Delivery Pending Status</th>
		        <th>QTY Booked PO</th>
		        <th>QTY Booked PO Status</th>
		        <th>QTY Outstanding PO/OS</th>
		        <th>QTY Outstanding PO/OS Status</th>
		        <th>Units</th>
		        <th>Status</th>
		        <th>Stock Awal</th>
		        <th>In</th>
		        <th>Out</th>
		        <th>Stock Akhir</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>			        
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->PART_NAME;?></td>
			        <td><?php echo $value->MODEL;?></td>			        
			        <td><?php echo $value->CUSTOMER_NAME;?></td>			        
			        <td><?php echo $value->QTY_STOCK;?></td>
			        <td><?php echo $value->QTY_STOCK_STATUS;?></td>
			        <td><?php echo $value->QTY_BREAKDOWN;?></td>
			        <td><?php echo $value->QTY_MIN_STOCK;?></td>				       
			        <td><?php echo $value->QTY_MIN_STOCK_STATUS;?></td>				        
			        <td><?php echo $value->QTY_DELIVERY_PENDING;?></td>			        
			        <td><?php echo $value->QTY_DELIVERY_PENDING_STATUS;?></td>			        
			        <td><?php echo $value->QTY_BOOKED_PO;?></td>			        
			        <td><?php echo $value->QTY_BOOKED_PO_STATUS;?></td>			        
			        <td><?php echo $value->QTY_OUTSTANDING_PO_OS;?></td>			        
			        <td><?php echo $value->QTY_OUTSTANDING_PO_OS_STATUS;?></td>			        
			        <td><?php echo $value->UNITS;?></td>			        
			        <td><?php echo $value->STATUS;?></td>			        
			        <td><?php echo $value->STOCK_AWAL;?></td>			        
			        <td><?php echo $value->STOCK_IN;?></td>			        
			        <td><?php echo $value->STOCK_OUT;?></td>			        
			        <td><?php echo $value->STOCK_AKHIR;?></td>			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>