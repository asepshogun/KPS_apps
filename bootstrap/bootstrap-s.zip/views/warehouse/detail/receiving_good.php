<section class="content-header">
	<h3>Receiving Goods Data Detail</h3>
	<small>Detail Data Receiving Goods</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="col-lg-6 col-lg-offset-5">
			<a href="<?php echo site_url('receiving_good');?>" class="btn bg-olive btn-flat col-lg-3" role="button">Back</a>
		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="receiving_good_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Process</th>        
		        <th>M/C</th>
		        <th>Tooling Code</th>		        
		        <th>NIK</th>
		        <th>Operator Name</th>
		        <th>QTY</th>
		        <th>Units</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PROCESS;?></td>			        
			        <td><?php echo $value->M_C;?></td>
			        <td><?php echo $value->TOOLING_CODE;?></td>		        
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->OPERATOR;?></td>
			        <td><?php echo $value->QTY;?></td>
			        <td><?php echo $value->UNIT;?></td>			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
