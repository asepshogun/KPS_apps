<section class="content-header">
	<h3>Out Going Finished Good to Other Detail</h3>
	<small>Out Going Finished Good to Other Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No Rev</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Delivery Area</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DELIVERY_AREA" disabled>
			          </div>
			        </div>		        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Add Out Going Finished Good to Other Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<form class="form-horizontal">
				  		<div class="col-lg-6">
				  			<div class="form-group">
					          <label class="col-sm-3 control-label">Code Item</label>
					          <div class="col-sm-9">
					            <select class="form-control select2" style="width: 100%;" name="KPS_ITEM_MASTER_ID">					  
								    <option>-- Select Code Item --</option>
								    <?php foreach ($data as $value) { ?>
								    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->CODE_ITEM;?></option>
								    <?php } ?>					  
								</select>
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Part Name</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="PART_NAME" value="otomatis muncul ketika code item dipilih">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Part No</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="PART_NO" value="otomatis muncul ketika code item dipilih">
					          </div>
					        </div>	
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Model</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="MODEL" value="otomatis muncul ketika code item dipilih">
					          </div>
					        </div>	
				  		</div>
				  		<div class="col-lg-6">
					        <div class="form-group">
					          <label class="col-lg-3 control-label">QTY Worehouse</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="QTY_WAREHOUSE" value="otomatis muncul ketika code item dipilih">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">QTY Delivery Execution</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="QTY_DELIVERY" placeholder="qty delivery execution">
					          </div>
					        </div>
					        <div class="form-group">
					          <label class="col-lg-3 control-label">Unit</label>
					          <div class="col-lg-9">
					            <input type="text" class="form-control" name="QTY_UNIT" value="otomatis muncul ketika code item dipilih">
					          </div>
					        </div>			        
				  		</div>
				  		<div class="col-lg-12">
				  			<div class="col-lg-6" align="center">
					        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Outgoing</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="reset" class="btn bg-olive btn-flat pull-left">Refresh Outgoing</button>
					        </div>
				  		</div>
				  	</form>			              
	            </div>			            
	        </div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="ofgo_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">Code Item</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Part Number</th>
		        <th rowspan="2">Model</th>
		        <th colspan="3"><center>QTY</center></th>
		        <th rowspan="2">Note</th>
		        <th rowspan="2">Update</th>	        
		        <th rowspan="2">Delete</th>
		      </tr>
		      <tr>
		        <th>Warehouse</th>
		        <th>Delivery Execution</th>
		        <th>Unit</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++ ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NIK;?></td>
			        <td><?php echo $value->ABSEN;?></td>
			        <td><?php echo $value->WORK_HOUR_FROM;?></td>
			        <td><?php echo $value->WORK_HOUR_UNTIL;?></td>
			        <td><?php echo $value->WORK_HOUR_BREAK;?></td>
			        <td><?php echo $value->PAID_AS;?></td>
			        <td><?php echo $value->NOTE;?></td>
			        <td><?php echo $value->SECTION;?></td>
			        <td><a href="" url="<?php echo site_url()."/outgoing_finished_good_other/update/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_DETAIL_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/outgoing_finished_good_other/delete/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>