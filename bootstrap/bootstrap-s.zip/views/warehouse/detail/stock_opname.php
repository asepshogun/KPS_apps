<section class="content-header">
	<h3>Stock Opname Detail</h3>
	<small>Stock Opname Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" value="<?php echo $detail->DATE_SON; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Time Base on The CPU</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TIME_BASE_ON_CPU" value="<?php echo $detail->TIME_BASE_ON_CPU; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Month / Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH_YEAR" value="<?php echo $detail->KPS_STOCK_OPNAME_MONTH ."/". $detail->KPS_STOCK_OPNAME_YEAR; ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
						<?php
							$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->APPROVED_SON."'")->first_row();
						?>	
			            <input type="text" class="form-control" name="APPROVED" value="<?php echo $q1->EMPLOYEE_NAME; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
						<?php
							$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->CHECKED_SON."'")->first_row();
						?>	
			            <input type="text" class="form-control" name="CHECKED" value="<?php echo $q2->EMPLOYEE_NAME; ?>" disabled>
			          </div>
			        </div>		
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
						 <?php
							$q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->MADE_BY_SON."'")->first_row();
						?>	
			            <input type="text" class="form-control" name="MADE_BY" value="<?php echo $q3->EMPLOYEE_NAME; ?>" disabled>
			          </div>
			        </div>        
				</form>
			</div>

		</div>
	</div>
	<div class="box-body">
		<div class="col-lg-12">
			<div class="box box-success box-solid">
				<div class="box-header with-border" id="panel-head">
				  <h4 class="box-title" id="titleDetail">ADD STOCK OPNAME</h4>			             
				  <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
				 <div class="box-body">
				 <?php
					if($pesan){
						if($pesan[0]=="W"){
							echo "<label> <font color=red > Code item tidak sesuai dengan yang terdaftar pada BSTHP </font></label>";
						}else{
							echo "<label> <font color=red > Barcode yang anda masukan sudah terdaftar pada BSTHP : ". $pesan[0]->NO_RECORD."</font></label>";
						}
					}
				 ?>
					<form action="<?php echo site_url()."/stock_Opname/add_detail";?>" method="POST" class="form-horizontal">
							<div class="form-group">
							  <label class="col-lg-3 control-label">Barcode</label>
							  <div class="col-lg-9">
								<input type="text" class="form-control" name="no_barcode_item" id="no_barcode_item" placeholder="Barcode">
							  </div>
							</div>
							<div class="form-group" style="display:none"> 
							  <div class="col-lg-9">
								<input type="text" class="form-control" name="KPS_STOCK_OPNAME_ID_SUB" id="KPS_STOCK_OPNAME_ID_SUB" value="<?php echo $detail->KPS_STOCK_OPNAME_ID ?>">
								<input type="hidden" class="form-control" name="KPS_STOCK_OPANAME_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
							 </div>
							</div>
							<input type="submit" class="btn bg-olive btn-flat pull-left" value="Save Data" />
							<input type="reset" class="btn btn-danger btn-flat pull-right" value="Clear Form " />
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="box-body">
		<table id="stock_opname_detail" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
			<thead>
				<th>

			</thead>
		</table>
	</div>
</div>