<section class="content-header">
	<h3>Delivery Execution to Other Detail Data</h3>
	<small>Detail Data Delivery Execution to Other</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NO" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL" value="otomatis bertambah jika ada inputan dari bawah" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
	    <div class="col-lg-12">
	    	<div class="box box-success box-solid">
	            <div class="box-header with-border" id="panel-head">
	              <h4 class="box-title" id="titleDetail">Bukti Serah Terima Hasil Produksi Detail</h4>			             
	              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
	            </div>			            
	            <div class="box-body">
	            	<div class="row">
	            		<div class="col-lg-3">
	            			<div class="form-group">
					          <label class="col-sm-3 control-label">QTY Warehouse</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="QTY_WAREHOUSE" disabled>
					          </div>
					        </div>
	            		</div>
	            		<div class="col-lg-3">
	            			<div class="form-group">
					          <label class="col-sm-3 control-label">QTY Delivery Execution</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="QTY_DELIVERY_EXECUTION" disabled>
					          </div>
					        </div>
	            		</div>
	            		<div class="col-lg-3">
	            			<div class="form-group">
					          <label class="col-sm-3 control-label">QTY Remaining</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="QTY_REMAINING" disabled>
					          </div>
					        </div>
	            		</div>
	            		<div class="col-lg-3">
	            			<div class="form-group">
					          <label class="col-sm-3 control-label">Status</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="STATUS" disabled>
					          </div>
					        </div>
	            		</div>
	            	</div>
	            	<div class="row">
	            		<form>
		            		<div class="col-lg-12" align="center">						
						        <label class="col-sm-12 control-label">SCAN BARCODE / TULISKAN CODE BARCODE</label>
							</div>
						</form>
	            	</div>
	            	<div class="row">	            		
		            	<div class="col-lg-8 col-lg-offset-2">						
						    <input type="text" class="form-control input-lg" name="code" placeholder="barcode code">
						</div>						
	            	</div>
	            	<br>
	            	<div class="row">
	            		<form>
		            		<div class="col-lg-12" align="center">						
						        <label class="col-sm-12 control-label">QTY</label>
							</div>
						</form>
	            	</div>
	            	<div class="row">	            		
		            	<div class="col-lg-2 col-lg-offset-5">						
						    <input type="text" class="form-control" name="QTY" placeholder="unit">
						</div>					
	            	</div>
	            	<br>
	            	<div class="row">	            		
	            		<div class="col-lg-12">						
							<div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Save Execution</button>
					        </div>
					        <div class="col-lg-6" align="center">
					        	<button type="button" class="btn bg-olive btn-flat">Refresh Execution</button>
					        </div>
						</div>						
	            	</div>
	            					

	            </div>			            
	        </div>
	    </div>
	</div>

	<!--TABLE-->
	<div clas="box-body">
		<table id="delivery_execution_other_detail" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">Code Product</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Model</th>
		        <th colspan="5"><center>QTY</center></th>
		        <th colspan="2"><center>Barcode</center></th>
		        <th rowspan="2">Total</th>	
		        <th rowspan="2">Delete</th>	
		      </tr>
		      <tr>
		        <th>Warehouse</th>
		        <th>Delivery Execution</th>		        
		        <th>Remaining</th>
		        <th>Unit</th>
		        <th>Status</th>
		        <th>No</th>
		        <th>QTY</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->QTY_WAREHOUSE;?></td>
			        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>      
			        <td><?php echo $value->QTY_REMAINING;?></td>
			        <td><?php echo $value->UNIT;?></td>
			        <td><?php echo $value->STATUS;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_QTY;?></td>      
			        <td><?php echo $value->TOTAL;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/delivery_execution_other/delete/".$value->KPS_DELIVERY_EXECUTION_OTHER_DETAIL_ID;?>">Delete</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
	<!--TABLE-->
</div>