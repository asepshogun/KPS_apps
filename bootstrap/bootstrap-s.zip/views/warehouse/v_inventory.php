<section class="content-header">
	<h3>Inventory PPIC</h3>
	<small>Inventory PPIC</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="warehouse_inventory" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">Code Item</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Model</th>
		        <th colspan="10"><center>QTY</center></th>			        		        		        		        	 		        		        		        		        		        
		        <th rowspan="2">Status</th>
		       
		      </tr>
		      <tr>
		      	<th>PO First Date</th>
				<th>Discontinue Date</th>
				<th>Breakdown</th>
				<th>Min Inventory</th>
				<th>Max Inventory</th>
				<th>Inventory</th>
				<th>Delivery Pending</th>
				<th>Outstanding PO/OS</th>
				<th>% Inventory Than Breakdown</th>
				<th>Unit</th>
		      </tr>
		    </thead>
		    
		    <tbody>
		    	<?php //$totala=0; $totalb=0; $totalc=0; $totald=0; $totale=0;  
		    	$no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->DATE_BP;?></td>
			        <td><?php echo $value->DISCONTINUE_DATE;?></td>
			        <td><?php echo $value->QTY_MONTH;?></td>
			        <td><?php echo $value->MIN_STOK;?></td>
			        <td><?php echo $value->MAX_STOCK;?></td>
			        <td></td>
			        <td><?php echo $value->QUANTITY_DELIVERY - $value->QTY_DELIVERY_EXECUTION;?></td>
			        <td><?php echo $value->QUANTITY - $value->TOTEX;?></td>
			        <td></td>
			        <td><?php echo $value->unit;?></td>

			        <td><?php 
			        		//if($inventory > $value->MAX_STOCK){

			        		//	}elseif($inventory < $value->MIN_STOCK){

			        		//		}else{
			        		//			echo "GOOD";
			        		//			}?>
			        </td>
			      </tr>
			       <?php 
			      // $totala += $value->QTY_MONTH;
			       //$totalb += $value->MIN_STOK;
			       //$totalc += $value->MAX_STOCK;
			       //$totald += $value->QUANTITY_DELIVERY - $value->QTY_DELIVERY_EXECUTION;
			       //$totale += $value->QUANTITY - $value->TOTEX;
			       } ?>
			      
		     
		    </tbody>

		</table>
		<!--TABLE-->
	</div>
	
</div>