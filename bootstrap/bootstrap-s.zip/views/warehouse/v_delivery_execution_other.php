<section class="content-header">
	<h3>Delivery Execution to Other Data</h3>
	<small>Data Delivery Execution to Other</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="delivery_execution_other" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Customer Name</th>        
		        <th>Outgoing to Other No</th>		        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>			        
			        <td><?php echo $value->NO_OTHER;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/delivery_execution_other/update/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/delivery_execution_other/delete/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/delivery_execution_other/detail/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Delivery Data</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Execution to Other Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_execution_other/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer Name --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_LIST_ID;?>"><?php echo $value->CUSTOMER_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Outgoing to Other No</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_OUTGOING_FINISHED_GOOD_OTHER_ID">					  
					    <option>-- Select Outgoing to Other No --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>"><?php echo $value->NO;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Delivery Execution to Other Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_execution_other/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer Name --</option>				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Outgoing to Other No</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_OUTGOING_FINISHED_GOOD_OTHER_ID">					  
					    <option>-- Select Outgoing to Other No --</option>			  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->