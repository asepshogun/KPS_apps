<section class="content-header">
	<h3>Outgoing Finished Good to Other Report Data</h3>
	<small>Data Outgoing Finished Good to Other Report</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	    <div class="col-lg-4 col-lg-offset-3">
	    	<div class="form-group">
	    		<h5 class="col-sm-10">Last Update 1 January 2016 10:30 PM</h5>
	    		<div class="col-lg-2" align="center">
		        	<button type="button" class="btn bg-olive btn-flat">Refresh</button>
		        </div>
	    	</div>
	    </div>
	</div>

	<div class="box-body">

		Show/Hide Column :
        <div class="box-body">              
            <div class="btn-group" role="group" aria-label="...">
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Outgoing Date</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Outgoing No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Delivery Execution Date</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Delivery Execution No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Status</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Customer Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Part Name</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Part No</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Model</a></button>
              <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Units</a></button>
            </div>
        </div>

		<!--TABLE-->
		<table id="delivery_execution_other_report" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th colspan="2"><center>Outgoing Finished Good to Others</center></th>
		        <th colspan="2"><center>Delivery Execution</center></th>
		        <th rowspan="2">Status</th>
		        <th rowspan="2">Customer Name</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Model</th>
		        <th rowspan="2">Units</th>	
		      </tr>
		      <tr>
		        <th>Date</th>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		      </tr>
		    </thead>
		    <tfoot>
		    	<tr>
		    		<th>Date</th>
			        <th>No</th>
			        <th>Date</th>
			        <th>No</th>
			        <th>Status</th>
			        <th>Customer Name</th>
			        <th>Part Name</th>
			        <th>Part No</th>
			        <th>Model</th>
			        <th>Units</th>
		    	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->OUTGOING_DATE;?></td>
			        <td><?php echo $value->OUTGOING_NO;?></td>      
			        <td><?php echo $value->DE_DATE;?></td>
			        <td><?php echo $value->DE_NO;?></td>
			        <td><?php echo $value->STATUS;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->PART_NAME;?></td>      
			        <td><?php echo $value->PART_NO;?></td>		        
			        <td><?php echo $value->MODEL;?></td>		        
			        <td><?php echo $value->UNITS;?></td>		        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>