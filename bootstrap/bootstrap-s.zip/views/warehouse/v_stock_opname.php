<section class="content-header">
	<h3>Stock Opname Data</h3>
	<small>Data Stock Opname</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="stock_opname" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>Time Based on The CPU</th>
		        <th>Month / Year</th>
		        <th>Approved</th>        
		        <th>CHECKED</th>	
		        <th>MADE_BY</th>	        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE_SON;?></td>
			        <td><?php echo $value->TIME_BASE_ON_CPU;?></td>
			        <td><?php echo $value->KPS_STOCK_OPNAME_MONTH . "/". $value->KPS_STOCK_OPNAME_YEAR;?></td>
			        <td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->APPROVED_SON."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
					<td>
			        <?php
			      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->CHECKED_SON."'")->first_row();
			      		echo $q2->EMPLOYEE_NAME;
			      	?>	
			      	</td>
					<td>
			        <?php
			      		$q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->MADE_BY_SON."'")->first_row();
			      		echo $q3->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			        <td><a href="" url="<?php echo site_url()."/stock_opname/update/".$value->KPS_STOCK_OPNAME_ID;?>">Update</a></td>	        			        
			        <td><a href="" url="<?php echo site_url()."/stock_opname/delete/".$value->KPS_STOCK_OPNAME_ID;?>">Delete</a></td>	        			        
			        <td><a href="<?php echo site_url()."/stock_opname/detail/".$value->KPS_STOCK_OPNAME_ID;?>">Detail</a></td>	        			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Stock Opname Data</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Stock Opname Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/stock_opname/add";?>" method="POST" class="form-horizontal">
				<?php 
					$year = date('Y');
					$month = date('m');
				?>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Month</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="KPS_STOCK_OPNAME_MONTH" placeholder="month year" value="<?php echo $month;?>" readonly>
		          </div>
		        </div> 
				<div class="form-group">
		          <label class="col-sm-3 control-label">Year</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="KPS_STOCK_OPNAME_YEAR" placeholder="month year" value="<?php echo $year;?>" readonly>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
					<select class="form-control select2" style="width: 100%;" name="APPROVED_SON" required>					  
						<option>-- Select Employee --</option>
						<?php foreach ($dataEmployee as $value) { ?>
						<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
						<?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
					<select class="form-control select2" style="width: 100%;" name="CHECKED_SON" required>					  
						<option>-- Select Employee --</option>
						<?php foreach ($dataEmployee as $value) { ?>
						<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
						<?php } ?>					  
					</select>
		          </div>
		        </div>
				 <div class="form-group">
				  <label class="col-sm-3 control-label">Made By</label>
				  <div class="col-sm-9">
					 <input type="text" class="form-control" name="MADE_BY_BPs" disabled value="<?php echo $this->session->userdata('name') ?>">
					<input type="hidden" class="form-control" name="MADE_BY_SON" value="<?php echo $this->session->userdata('employeeId'); ?>">
				  </div>
				</div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Stock Opname Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/stock_opname/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="DELIVERY_AREA" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Time Based on The CPU</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="TIME_BASE_ON_CPU">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Month / Year</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MONTH_YEAR">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="APPROVED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="CHECKED">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->