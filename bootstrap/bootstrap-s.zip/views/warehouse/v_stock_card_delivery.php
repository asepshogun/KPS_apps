<section class="content-header">
	<h3>Stock Card for Delivery Data</h3>
	<small>Data Stock Card for Delivery</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="stock_card_in_out" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
			<thead>
		      <tr>
		        <th rowspan="3">No</th>
		        
		        <th rowspan="3">Code Product</th>
		        <th rowspan="3">Part No</th>
		        <th rowspan="3">Part Name</th>
		        <th rowspan="3">Model</th>        
		        <th rowspan="3">Customer Name</th>
		        <th colspan="12"><center>QTY</center></th>
		        <th rowspan="3">Units</th>
		        <th rowspan="3">Detail</th>
		      </tr>
		      <tr>
		      	<th colspan="2"><center>Stock</center></th>
		      	<th rowspan="2"><center>Breakdown</center></th>
		      	<th colspan="3"><center>Level Stock</center></th>
		      	<th colspan="2"><center>Delivery Pending</center></th>
		      	<th colspan="2"><center>Booked PO</center></th>
		      	<th colspan="2"><center>Outstanding PO/OS</center></th>
		      </tr>
		      <tr>
		      	<th>Stock</th>		        
		        <th>Stock Status</th>
		        <th>Min Stock</th>
		        <th>Max Stock</th>
		        <th>Status</th>
		        <th>Delivery Pending</th>
		        <th>Status</th>
		        <th>Booked</th>
		        <th>Status</th>
		        <th>Outstanding PO/OS</th>
		        <th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			       
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->MODEL;?></td>			        
			        <td><?php echo $value->COMPANY_NAME;?></td>			        
			        <td></td>
			        <td>
			        <?php 

			        ?>
			        </td>
			        <td><?php echo $value->QTY_MONTH;?></td>
			        <td><?php echo $value->MIN_STOK;?></td>				       
			        <td><?php echo $value->MAX_STOCK;?></td>			        
			        <td></td>	
			        <td><?php echo $value->QUANTITY_DELIVERY-$value->QTY_DELIVERY_EXECUTION;?></td>			        
			        <td>
			        <?php 
			        	if($value->QUANTITY_DELIVERY-$value->QTY_DELIVERY_EXECUTION=="0"){
			        		echo "CLOSED";
			        	}else{
			        		echo "OPEN";
			        	}
			        ?>
			        </td>			        
			        <td><?php echo $value->QUANTITY;?></td>			        
			        <td>
			        <?php 
			        	if($value->QUANTITY=="0"){
			        		echo "CLOSED";
			        	}else{
			        		echo "OPEN";
			        	}
			        ?>
			        </td>			        
			        <td><?php echo $value->QUANTITY-$value->QTY_DELIVERY_EXECUTION;?></td>			        
			        <td>
			        <?php 
			        	if($value->QUANTITY-$value->QTY_DELIVERY_EXECUTION=="0"){
			        		echo "CLOSED";
			        	}else{
			        		echo "OPEN";
			        	}
			        ?>
			        </td>			        
			        <td><?php echo $value->MAX_STOCK;?></td>			        
			        <td></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		   
		</table>
		<!--TABLE-->
	</div>
</div>