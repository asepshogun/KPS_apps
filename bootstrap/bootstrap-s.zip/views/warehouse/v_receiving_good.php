<section class="content-header">
	<h3>Receiving Goods Data</h3>
	<small>Data Receiving Goods</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	    <div class="col-lg-4 col-lg-offset-4">
	    	<div class="form-group">
	    		<h5 class="col-sm-9">Last Update 1 January 2016 10:30</h5>
	    		<div class="col-lg-3" align="center">
		        	<button type="button" class="btn bg-olive btn-flat">Refresh</button>
		        </div>
	    	</div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="receiving_good" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th colspan="2"><center>BSTHP</center></th>		        
		        <th rowspan="2">Code Item</th>
		        <th rowspan="2">Part Name</th>        
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Model</th>		        
		        <th rowspan="2">Customer Name</th>
		        <th rowspan="2">QTY</th>
		        <th rowspan="2">Units</th>
		        <th rowspan="2">Barcode No</th>
		        <th rowspan="2">No Lot</th>
		        <th rowspan="2">Production Date</th>
		        <th rowspan="2">Inspection Date</th>
		        <th rowspan="2">Detail</th>
		      </tr>
		      <tr>
		      	<th>BSTHP Date</th>
		        <th>BSTHP No</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->BSTHP_DATE;?></td>
			        <td><?php echo $value->BSTHP_NO;?></td>			        
			        <td><?php echo $value->CODE_ITEM;?></td>
			        <td><?php echo $value->PART_NAME;?></td>		        
			        <td><?php echo $value->PART_NO;?></td>
			        <td><?php echo $value->MODEL;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->QTY;?></td>			        
			        <td><?php echo $value->UNITS;?></td>			        
			        <td><?php echo $value->BARCODE_NO;?></td>			        
			        <td><?php echo $value->NO_LOT;?></td>			        
			        <td><?php echo $value->PRODUCTION_DATE;?></td>			        
			        <td><?php echo $value->INSPECTION_DATE;?></td>			        
			        <td><a href="" url="<?php echo site_url()."/receiving_good/detail/".$value->KPS_RECEIVING_GOOD_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>		    			      
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
