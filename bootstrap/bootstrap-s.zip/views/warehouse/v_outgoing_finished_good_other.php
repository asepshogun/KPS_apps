<section class="content-header">
	<h3>Out Going Finished Good to Other Data</h3>
	<small>Data Out Going Finished Good to Other</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="ofgo" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Customer Name</th>        
		        <th>Delivery Area</th>		        
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>			        
			        <td><?php echo $value->DELIVERY_AREA;?></td>		        
			        <td><a href="" url="<?php echo site_url()."/outgoing_finished_good_other/update/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Update</a></td>
			        <td><a href="" url="<?php echo site_url()."/outgoing_finished_good_other/delete/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Delete</a></td>
			        <td><a href="" url="<?php echo site_url()."/outgoing_finished_good_other/detail/".$value->KPS_OUTGOING_FINISHED_GOOD_OTHER_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Outgoing Data</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Outgoing Finished Good to Other Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_finished_good_other/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer Name --</option>
					    <?php foreach ($data as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_LIST_ID;?>"><?php echo $value->CUSTOMER_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Delivery Area</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DELIVERY_AREA" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Outgoing Finished Good to Other Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_finished_good_other/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_LIST_ID">					  
					    <option>-- Select Customer Name --</option>				  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Delivery Area</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DELIVERY_AREA">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->