<section class="content-header">
	<h3>Item Master</h3>
	<small>Item Master</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="Item_master" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
				<th>Action</th>
				<th>Date Update</th>
				<th>Updated By</th>
				<th>Status Lock</th>
		        <th>Revisi No</th>
		        <th>Code Item</th>
		        <th>Part No</th>
		        <th>Part Name</th>
		        <th>Made By</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td><?php 
						if($value->ITEM_MASTER_STATUS_DELETE){
						echo "DELETE";
						}else{ echo "UPDATE";} ?>
					</td>
			        <td><?php echo $value->ITEM_MASTER_UPDATE_TIME;?></td>
			        <td><?php
			      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->ITEM_MASTER_UPDATE_BY."'")->first_row();
			      		echo $q2->EMPLOYEE_NAME; ?>
				   <td>
			        <?php 
			        	if($value->ITEM_MASTER_STATUS_LOCK){
			        		?> 
			        		<center><span class="label label-danger">lock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->ITEM_MASTER_REV_NO;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_CODE_ITEM;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_PART_NO;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_PART_NAME;?></td>
			        <td>
					 <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->ITEM_MASTER_MADE_BY."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
					?>	
					</td>
				<?php	} ?>
		    </tbody>
		</table>
		<!--TABLE-->