<section class="content-header">
	<h3>Item Master</h3>
	<small>Item Master</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="item_master" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
				<th>Status Lock</th>
		        <th>Revisi No</th>
		        <th>Code Item</th>
		        <th>Part No</th>
		        <th>Part Name</th>
		        <th>Made By</th>
		        <th>Update</th>
		         <th>Delete</th>
		         <th>View History Update</th>
		       
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<th width="20px">Action</th>
		        	<?php
		        	}else{ ?>
					 <th>Lock</th>
				<?php } ?> 
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
				   <td>
			        <?php 
			        	if($value->ITEM_MASTER_STATUS_LOCK){
			        		?> 
			        		<center><span class="label label-danger">lock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->ITEM_MASTER_REV_NO;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_CODE_ITEM;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_PART_NO;?></td>
			        <td><?php echo $value->KPS_ITEM_MASTER_PART_NAME;?></td>
			        <td>
					 <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->ITEM_MASTER_MADE_BY."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
					?>	
					</td>
			        <td><a href="<?php echo site_url()."/new_item_master/preupdate/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-warning btn-sm 
					<?php 	if($value->ITEM_MASTER_STATUS_LOCK==1){
								echo "disabled";
							}else{
								echo "";
			        		}?>"
							data-toggle="modal" data-target="#update" class="update-link">Update</a>
					</td> 
					<td><a href="<?php echo site_url()."/new_item_master/delete/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-danger btn-sm 
					<?php 	if($value->ITEM_MASTER_STATUS_LOCK==1){
								echo "disabled";
							}else{
								echo "";
			        		}?>"data-toggle="modal" data-target="#update" class="update-link">Delete</a>
					</td>
					<td>
						<div class="btn-group">
							<a href="<?php echo site_url()."/new_item_master/history_update/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-info btn-sm" <?php if($value->ITEM_MASTER_REV_NO){ echo "";}else{echo "disabled onclick='return false'";}?>><i class="fa fa-university"></i></a>
						</div>
					</td>
			        <?php 
					if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<td>
						<div class="btn-group">
							<a href="<?php echo site_url()."/new_item_master/lock/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
							<a href="<?php echo site_url()."/new_item_master/unlock/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a>
						</div>
					</td>
		        	<?php
		        	}else{ ?>
					<td>
						<div class="btn-group">
							<a href="<?php echo site_url()."/new_item_master/lock/".$value->KPS_ITEM_MASTER_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
						</div>
					</td>
			<?php	} ?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Item Master</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Item Master</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/new_item_master/add";?>" method="POST" class="form-horizontal">
				<div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_CODE_ITEM" placeholder="Code Item" required >
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Part No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NO" placeholder="Part No">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NAME" placeholder="Part Name" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_DOs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="ITEM_MASTER_MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->
