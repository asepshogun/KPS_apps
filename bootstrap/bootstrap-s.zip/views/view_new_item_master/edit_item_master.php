<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Update Item Mater</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/new_item_master/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Code Item</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_ITEM_MASTER_CODE_ITEM" placeholder="Code Item" required value="<?php echo $data->KPS_ITEM_MASTER_CODE_ITEM; ?>" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Part No</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NO" placeholder="Part No" required value="<?php echo $data->KPS_ITEM_MASTER_PART_NO; ?>" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Part Name</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NAME" placeholder="Part Name" required value="<?php echo $data->KPS_ITEM_MASTER_PART_NAME; ?>" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_DOs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="ITEM_MASTER_MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
			<input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_ITEM_MASTER_ID; ?>">
			<input type="hidden" class="form-control" name="ITEM_MASTER_REV_NO" value="<?php echo $data->ITEM_MASTER_REV_NO; ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	        	     	    			      		        
</div>
