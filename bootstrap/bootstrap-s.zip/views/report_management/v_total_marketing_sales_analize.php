<section class="content-header">
	<h3>Total Marketing Sales Analize</h3>
	<small>Total Marketing Sales Analize</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>		        
		        <th>Year</th>
		        <th>Currency</th>
		        <th>Customer Name</th>
		        <th>Approved</th>
		        <th>Checked</th>
		        <th>Made By</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->YEAR;?></td>
			        <td><?php echo $value->CURRENCY;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->APPROVED;?></td>
			        <td><?php echo $value->CHECKED;?></td>
			        <td><?php echo $value->MADE_BY;?></td>
			        <td><a href="" url="<?php echo site_url()."/total_marketing_sales_analize/detail/".$value->KPS_SALES_TOTAL_ANALIZE_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>