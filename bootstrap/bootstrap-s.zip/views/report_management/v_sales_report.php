<section class="content-header">
	<h3>Sales Report</h3>
	<small>Sales Report</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">		
		<div class="col-lg-7">
			<div class="input-group">
			  <span class="input-group-addon">Filter Date</span>
			  <input type="text" id="datestart" class="form-control datepicker">
			  <span class="input-group-addon">Until</span>
			  <input type="text" id="dateend" class="form-control datepicker">
			</div>
		</div>		
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="sales_report" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Customer Name</th>
		        <th>Marketing Name</th>
		        <th>PO Date</th>
		        <th>PO No</th>
		        <th>Date DO</th>	        
		        <th>DO No</th>	        
		        <th>Invoice Date</th>
		        <th>Invoice No</th>
		        <th>No Item</th>
		        <th>Code Product</th>
		        <th>Part Name</th>
		        <th>Part No</th>		        
		        <th>Model</th>
		        <th>Price</th>
		        <th>Currency</th>
		        <th>QTY</th>
		        <th>Unit</th>
		        <th>Sub Total</th>
		        <th>Sub Total Sales</th>
		        <th>PPN</th>
		        <th>Total</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php 
		    	$no=0;
		    	foreach ($data as $value) { $no++;
		    		$datax = $this->m_sales_report->getId($value->INVOICE_INDUK_ID);

		    		$total=0;; 
		    		foreach ($datax as $value) { ?>
			     	<tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->marketing_id;?></td>
			        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->DATE_DO;?></td>
			        <td><?php echo $value->NO_DO;?></td>
			        <td><?php echo $value->INVOICE_INDUK_DATE;?></td>
			        <td><?php echo $value->INVOICE_INDUK_NO;?></td>
			        <td><?php 
			        		  echo $no;
			        	?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->price;?></td>
			        <td><?php echo $value->CURRENCY_BP;?></td>
			        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
			        <td><?php echo $value->unit;?></td>
			        <td><?php echo $value->QTY_DELIVERY_EXECUTION*$value->price;?></td>
			        <td><?php 
			        		$total += ($value->QTY_DELIVERY_EXECUTION*$value->price)+$total;
			        		echo $total
			        	?></td>
			        <td><?php 
			        		$totalx = $total*0.1;
			        		echo $totalx;
			        	?></td>
			        <td><?php echo $totalx + $total;?></td>
			      </tr>
		      <?php } 
		      }?>
		    	
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
