<section class="content-header">
	<h3>Total Sales Monthly Analize</h3>
	<small>Total Sales Monthly Analize</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>		        
		        <th>Year</th>
		        <th>Currency</th>
		        <th>Marketing Name</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->YEAR;?></td>
			        <td><?php echo $value->CURRENCY;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        <td><a href="" url="<?php echo site_url()."/total_sales_monthly_analize/detail/".$value->KPS_SALES_MONTHLY_ANALIZE_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>