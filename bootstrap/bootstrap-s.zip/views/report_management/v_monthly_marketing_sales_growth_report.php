<section class="content-header">
	<h3>Monthly Marketing Sales Growth Report</h3>
	<small>Monthly Marketing Sales Growth Report</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Month</th>
		        <th>Year</th>
		        <th>Marketing Name</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->MONTH;?></td>
			        <td><?php echo $value->YEAR;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        <td><a href="" url="<?php echo site_url()."/monthly_marketing_sales_growth_report/detail/".$value->KPS_SALES_GROWTH;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>