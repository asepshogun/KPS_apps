<section class="content-header">
	<h3>Monthly Marketing Sales Report</h3>
	<small>Monthly Marketing Sales Report</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="msr" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>		        
		        <th>Year</th>
		        <th>Currency</th>
		        <th>Marketing Name</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE_MSR;?></td>
			        <td><?php echo $value->NO_MSR;?></td>
			        <td><?php echo $value->YEAR_MSR;?></td>
			        <td><?php echo $value->CURRENCY_MSR;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        <td><a href="<?php echo site_url()."/Monthly_Marketing_Sales_Report/detail/".$value->KPS_MSR_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Monthly Marketing Sales Report</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Monthly Marketing Sales Report</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/Monthly_Marketing_Sales_Report/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DATE_MSR" placeholder="Pick Date" value="<?php echo date('Y-m-d') ?>" readonly="readonly">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Year</label>
		          <div class="col-sm-9">
		            
		             <input type="text"  class="form-control" name="YEAR_MSR" placeholder="Year">

		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Currency</label>
		          <div class="col-sm-9">
		            
		             <input type="text"  class="form-control" name="CURRENCY_MSR" placeholder="Year">

		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Marketing Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="MARKETING_ID_MSR">					  
					    <option>-- Select Marketing Name --</option>
					    <?php foreach ($dataMarketing as $value) { ?>
					    <option value="<?php echo $value->KPS_MARKETING_ID;?>"><?php echo $value->MARKETING_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->