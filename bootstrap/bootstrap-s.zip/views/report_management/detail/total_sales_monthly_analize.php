<section class="content-header">
	<h3>Total Sales Monthly Analize Detail</h3>
	<small>Total Sales Monthly Analize Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="YEAR" disabled>
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Marketing Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MARKETING_NAME" disabled>
			          </div>
			        </div>	        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Customer Name</th>
		        <th>Sales Without Tax</th>
		        <th>Sales Include Tax</th>
		        <th>Sales Growth Than Last Month (%)</th>
		        <th>Sales Growth Than Last Year (%)</th>
		        <th>Target Growth</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->SALES_WITHOUT_TAX;?></td>
			        <td><?php echo $value->SALES_INCLUDE_TAX;?></td>
			        <td><?php echo $value->SALES_GROWTH_LAST_MONTH;?></td>
			        <td><?php echo $value->SALES_GROWTH_LAST_YEAR;?></td>
			        <td><?php echo $value->TARGET_GROWTH;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>