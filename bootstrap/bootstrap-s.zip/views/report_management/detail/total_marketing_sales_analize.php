<section class="content-header">
	<h3>Total Marketing Sales Analize Detail</h3>
	<small>Total Marketing Sales Analize Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="YEAR" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY" disabled>
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">					
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED" disabled>
			          </div>
			        </div>	        
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Checked</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MADE_BY" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Month</th>
		        <th>Sales Growth Than Last Month (%)</th>
		        <th>Sales Growth Than Last Year (%)</th>
		        <th>Target Sales Growth (%)</th>
		        <th>Analize</th>
		        <th>Corrective & Preventive Action</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->MONTH;?></td>
			        <td><?php echo $value->SALES_GROWTH_LAST_MONTH;?></td>
			        <td><?php echo $value->SALES_GROWTH_LAST_YEAR;?></td>
			        <td><?php echo $value->TARGET_SALES_GROWTH;?></td>
			        <td><?php echo $value->ANALIZE;?></td>
			        <td><?php echo $value->CORRECTIVE;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>