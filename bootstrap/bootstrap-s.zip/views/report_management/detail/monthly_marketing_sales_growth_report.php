<section class="content-header">
	<h3>Monthly Marketing Sales Growth Report Detail</h3>
	<small>Monthly Marketing Sales Growth Report Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Month</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="YEAR" disabled>
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">					
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Marketing Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MARKETING_NAME" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Customer Name</th>
		        <th>Address</th>
		        <th>Jan Target</th>
		        <th>Jan Actual</th>
		        <th>Feb Target</th>
		        <th>Feb Actual</th>
		        <th>Mar Target</th>
		        <th>Mar Actual</th>
		        <th>April Target</th>
		        <th>April Actual</th>
		        <th>May Target</th>
		        <th>May Actual</th>
		        <th>Jun Target</th>
		        <th>Jun Actual</th>
		        <th>Jul Target</th>
		        <th>Jul Actual</th>
		        <th>Aug Target</th>
		        <th>Aug Actual</th>
		        <th>Sept Target</th>
		        <th>Sept Actual</th>
		        <th>Oct Target</th>
		        <th>Oct Actual</th>
		        <th>Nov Target</th>
		        <th>Nov Actual</th>
		        <th>Dec Target</th>
		        <th>Dec Actual</th>
		        <th>Rates Target</th>
		        <th>Rates Actual</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->CUSTOMER_NAME;?></td>
			        <td><?php echo $value->JAN_TARGET;?></td>
			        <td><?php echo $value->JAN_ACTUAL;?></td>
			        <td><?php echo $value->FEB_TARGET;?></td>
			        <td><?php echo $value->FEB_ACTUAL;?></td>
			        <td><?php echo $value->MAR_TARGET;?></td>
			        <td><?php echo $value->MAR_ACTUAL;?></td>
			        <td><?php echo $value->APR_TARGET;?></td>
			        <td><?php echo $value->APR_ACTUAL;?></td>
			        <td><?php echo $value->MAY_TARGET;?></td>
			        <td><?php echo $value->MAY_ACTUAL;?></td>
			        <td><?php echo $value->JUN_TARGET;?></td>
			        <td><?php echo $value->JUN_ACTUAL;?></td>
			        <td><?php echo $value->JUL_TARGET;?></td>
			        <td><?php echo $value->JUL_ACTUAL;?></td>
			        <td><?php echo $value->AUG_TARGET;?></td>
			        <td><?php echo $value->AUG_ACTUAL;?></td>
			        <td><?php echo $value->SEPT_TARGET;?></td>
			        <td><?php echo $value->SEPT_ACTUAL;?></td>
			        <td><?php echo $value->OCT_TARGET;?></td>
					<td><?php echo $value->OCT_ACTUAL;?></td>
			        <td><?php echo $value->NOV_TARGET;?></td>
			        <td><?php echo $value->NOV_ACTUAL;?></td>
			        <td><?php echo $value->DEC_TARGET;?></td>
			        <td><?php echo $value->DEC_ACTUAL;?></td>
			        <td><?php echo $value->RATES_TARGET;?></td>
					<td><?php echo $value->RATES_ACTUAL;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>