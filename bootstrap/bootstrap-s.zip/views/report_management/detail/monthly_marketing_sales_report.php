<section class="content-header">
	<h3>Monthly Marketing Sales Report Detail</h3>
	<small>Monthly Marketing Sales Report Detail</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" value="<?php echo $dataOnly->NO_MSR; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" value="<?php echo $dataOnly->DATE_MSR; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="YEAR" value="<?php echo $dataOnly->YEAR_MSR; ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY" value="<?php echo $dataOnly->CURRENCY_MSR; ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Marketing Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MARKETING_NAME" value="<?php echo $dataOnly->MARKETING_NAME; ?>" disabled>
			          </div>
			        </div>	        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="msr_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Customer Name</th>
		        <th>Jan Exclude Tax</th>
		        <th>Jan Include Tax</th>
		        <th>Feb Exclude Tax</th>
		        <th>Feb Include Tax</th>
		        <th>Mar Exclude Tax</th>
		        <th>Mar Include Tax</th>
		        <th>April Exclude Tax</th>
		        <th>April Include Tax</th>
		        <th>May Exclude Tax</th>
		        <th>May Include Tax</th>
		        <th>Jun Exclude Tax</th>
		        <th>Jun Include Tax</th>
		        <th>Jul Exclude Tax</th>
		        <th>Jul Include Tax</th>
		        <th>Aug Exclude Tax</th>
		        <th>Aug Include Tax</th>
		        <th>Sept Exclude Tax</th>
		        <th>Sept Include Tax</th>
		        <th>Oct Exclude Tax</th>
		        <th>Oct Include Tax</th>
		        <th>Nov Exclude Tax</th>
		        <th>Nov Include Tax</th>
		        <th>Dec Exclude Tax</th>
		        <th>Dec Include Tax</th>
		        <th>Total</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php 
		    	$no=0; 
		    	$bulan1=0;
		    	$bulan2=0;
		    	$bulan3=0;
		    	$bulan4=0;
		    	$bulan5=0;
		    	$bulan6=0;
		    	$bulan7=0;
		    	$bulan8=0;
		    	$bulan9=0;
		    	$bulan10=0;
		    	$bulan11=0;
		    	$bulan12=0;

		    	foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td>
			        	<?php 
			        		if($value->bulan == 1){
			        			echo $value->total;
			        			$bulan1 = $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 1){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 2){
			        			echo $value->total;
			        			$bulan2 = $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 2){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 3){
			        			echo $value->total;
			        			$bulan3 = $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 3){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 4){
			        			echo $value->total;
			        			$bulan4 = $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 4){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 5){
			        			$bulan5 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 5){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 6){
			        			echo $value->total;
			        			$bulan6 = $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 6){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 7){
			        			$bulan7 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 7){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 8){
			        			$bulan8 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 8){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 9){
			        			$bulan9 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 9){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 10){
			        			$bulan10 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 10){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 11){
			        			$bulan11 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 11){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 12){
			        			$bulan12 = $value->total;
			        			echo $value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		if($value->bulan == 12){
			        			echo ($value->total)*0.1+$value->total;
			        		}
			        	?>
			        </td>
			        <td>
			        	<?php 
			        		echo $bulan1+$bulan2+$bulan3+$bulan4+$bulan5+$bulan6+$bulan7+$bulan8+$bulan9+$bulan10+$bulan11+$bulan12;
			        		
			        	?>
			        </td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>