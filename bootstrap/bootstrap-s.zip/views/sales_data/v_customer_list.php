<section class="content-header">
	<h3>Customer List</h3>
	<small>Monitoring Customer</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		<!-- Show/Hide Column :
		<div class="box-body">				
			<div class="btn-group" role="group" aria-label="...">
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Company Name</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Customer Number</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Customer Industry</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Automotive Type</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Sales Type</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Sales Tax</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Payment</a></button>		  
			</div>
		</div> -->

		<!--TABLE-->
		<table id="cis" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Marketing Name</th>
		        <th>Customer Code</th>
		        <th>Company Name</th>
		        <th>Address</th>
		        <th>Phone</th>
		        <th>Fax</th>
		        <th>Mail</th>
		        <th>Person In Charge</th>
		        <th>Customer Industry</th>
		        <th>Automotive Type</th>
		        <th>Sales Type</th>
		        <th>Sales Tax</th>
		        <th>Payment</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        <td><?php echo $value->CUSTOMER_CODE;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->PLANT;?></td>
			        <td><?php echo $value->TELP;?></td>
			        <td><?php echo $value->FAX;?></td>
			        <td><?php echo $value->EMAIL;?></td>
			        <td><?php echo $value->NAME;?></td>
			        <td><?php echo $value->CUSTOMER_INDUSTRY;?></td>
			        <td><?php echo $value->AUTOMOTIVE_TYPE;?></td>
			        <td><?php echo $value->SALES_TYPE;?></td>
			        <td><?php echo $value->SALES_TAX;?></td>
			        <td><?php echo $value->PAYMENT;?></td>
			     	</tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

<!--MODAL-->