<section class="content-header">
	<h3>History LOI</h3>
	<small>History data LOI</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="loi" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>LOI No</th>
		        <th>LOI Date</th>
		        
		        <th>Customer Name</th>
		        <th>Part Number RFQ</th>
		        <th>Part Name  RFQ</th>
		        <th>Model  RFQ</th>
		        <th>Die Go No</th>
		        <th>QTY Month</th>
		        <th>Periode</th>
		        <th>Discontinue Date</th>
		        <th>Min Stock</th>
		        <th>Max Stock</th>
		        <th>Made By</th>
		        <th>Code Product</th>
		        <th>Part Number </th>
		        <th>Part Name  </th>
		        <th>Model  </th>
		        <th>Standard Packing</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datas as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_loi=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_loi;?></td>
			        <td><?php echo $value->NO_LOI;?></td>
			        <td><?php echo $value->DATE_LOI;?></td>
			        
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>
			        <td><?php echo $value->MODEL;?></td>
			        <td><?php echo $value->LOI_DIE_GO_NO;?></td>
			        <td><?php echo $value->QTY_MONTH;?></td>
			        <td><?php echo $value->PERIODE;?></td>
			        <td><?php echo $value->DISCONTINUE_DATE;?></td>
			        <td><?php echo $value->MIN_STOK;?></td>
			        <td><?php echo $value->MAX_STOCK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->LOI_STRANDART_PACKING;?></td>
			       
		        	
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>