<section class="content-header">
	<h3>History Delivery Order</h3>
	<small>History data Delivery Order</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<!--TABLE-->
		<table id="delivery" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Outgoing Number</th>
		        <th>Outgoing Date</th>
		         <th>Delivery Order Number</th>
		        <th>Delivery Order Date</th>
		        <th>Rev</th>
		        <th>Customer</th>
		        <th>Address</th>
		        <th>PO Date</th>
		        <th>PO Number</th>
		        <th>Vehicle Name</th>
		        <th>Vehicle No</th>
		        <th>Driver</th>
		        <th>Employee Accepted</th>	        
		        <th>Employee Approved</th>		        
		        <th>Employee Known</th>
		        <th>Made By</th>
		        <th>Total Qty</th>
		       
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($datas as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td>
			        <?php 
			        	if($value->status_do=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_do;?></td>
			        <td><?php echo $value->NO_OUTGOING;?></td>
			        <td><?php echo $value->DATE_OUTGOING;?></td>
			        <td><?php echo $value->NO_DO;?></td>
			        <td><?php echo $value->DATE_DO;?></td>
			        <td><?php echo $value->REV_NO_DO;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php 
			        	$query = $this->db->query("select * from kps_outgoing_finished_good_detail 
			        		join kps_delivery_schedule_detail on(kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD)
			        		join kps_customer_delivery_setup on(kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID)
			        		where KPS_OUTGOING_FINISHED_GOOD_ID_D='".$value->KPS_OUTGOING_FINISHED_GOOD_ID_DO."'");
						$datax = $query->first_row();	
						// print_r($datax);
						echo $datax->PLANT1_CITY;
			        ?></td>
			        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_accepted_id."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			      	<td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_approved_id."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			      	<td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_known_id."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			        <td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->user_made_by_id_do."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			        <td><?php echo $value->TOTAL_QTY;?></td>

			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>