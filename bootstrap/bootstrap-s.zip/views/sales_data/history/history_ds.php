<section class="content-header">
	<h3>History Delivery Schedule</h3>
	<small>History data Delivery Schedule</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="schedule" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Bukti Pesanan Number</th>
		        <th>Company Name</th>
		        <th>Delivery Number</th>
		        <th>Delivery Date</th>
		        <th>Employee Checked</th>		        
		        <th>Total</th>		        
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datas as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_ds=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_ds;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->DELIVERY_DATE;?></td>
			         <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->employee_checked_id."'");
			        	$data = mysql_fetch_array($query);
			        	echo $data['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php echo $value->TOTAL;?></td>

			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>