<section class="content-header">
	<h3>History Breakdown Cost</h3>
	<small>History data Breakdown Cost</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	   <table id="breakdown" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Breakdown No</th>
		        <th>Total Material</th>
		        <th>Total Part Cost</th>
		        <th>Total Depreciation</th>
		        <th>Cost</th>
		        <th>Total Tools</th>
		        <th>Total Item</th>
		        <th>Total Manufacturing</th>
		        
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datas as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_break=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_break;?></td>
			        <td><?php echo $value->NO_BREAK;?></td>
			        <td><?php echo $value->TOTAL_MATERIAL;?></td>
			        <td><?php echo $value->TOTAL_PART_COST;?></td>
			        <td><?php echo $value->TOTAL_DEPRECIATION;?></td>
			        <td><?php echo $value->TOOLING_COST;?></td>
			        <td><?php echo $value->TOTAL_TOOLING;?></td>
			        <td><?php echo $value->TOTAL_ITEM;?></td>
			        <td><?php echo $value->TOTAL_MANUFACTURING;?></td>
			       

			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>