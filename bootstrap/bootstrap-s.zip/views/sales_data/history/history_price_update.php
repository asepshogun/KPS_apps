<section class="content-header">
	<h3>History Price Update</h3>
	<small>Histori data Harga Terbaru</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="quotation" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th colspan="2">Quotation</th>
		        <th rowspan="2">Price</th>
		        <th rowspan="2">Unit</th>
		        <th colspan="2">Valid Date</th>
		        <th rowspan="2">Status</th>
		      </tr>
		      <tr>
		      	<th>Date</th>
		      	<th>No</th>
		      	<th>From</th>
		      	<th>Until</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; $data = array_unique($data,SORT_REGULAR); foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->NO_QUO;?></td>
			        <td><?php echo $value->DATE_QUO;?></td>
			        <td><?php echo $value->price;?></td>
			        <td><?php echo $value->unit;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>
			        <td><?php echo "";?></td>
			        
			      
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>