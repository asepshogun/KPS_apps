<section class="content-header">
	<h3>History Failed Project</h3>
	<small>History data Proyek Gagal</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="fproject" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		      	<th>Status</th>
		        <th>Revisi No</th>
		        <th>RFQ Number</th>
		        <th>Customer Name</th>
		        <th>Failed Project Number</th>
		        <th>Failed Project Date</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($datas as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_project=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_project;?></td>
			        <td><?php echo $value->NO_RFQ;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_FAILED;?></td>
			        <td><?php echo $value->DATE_FAILED;?></td>
			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>