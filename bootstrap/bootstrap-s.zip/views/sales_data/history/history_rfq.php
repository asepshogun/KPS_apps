<section class="content-header">
	<h3>Request for Quotation Detail</h3>
	<small>Detail Permintaan untuk RFQ</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="rfq" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Company Name</th>
		        <th>RFQ Date</th>
		        <th>RFQ Number</th>
		        <th>Receiving Date</th>
		        <th>Customer Date</th>
		        <th>Due Date</th>
		        <th>Estimation LOI</th>
		        <th>Target Price</th>
		 		<th>Made By</th>
		 		<th>Update By</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datas as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_rfq=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_rfq;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->DATE_RFQ;?></td>
			        <td><?php echo $value->NO_RFQ;?></td>
			        <td><?php echo $value->RECEIVING_RFQ_DATE;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_DATE;?></td>
			        <td><?php echo $value->DUE_DATE_QUOTATION;?></td>
			        <td><?php echo $value->ESTIMATION_LOI_DATE;?></td>
			        <td><?php echo $value->TARGET_PRICE;?></td>
			        <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->user_made_by_id_rfq."'");
			        	$data = mysql_fetch_array($query);
			        	echo $data['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->UPDATE_BY_RFQ."'");
			        	$data = mysql_fetch_array($query);
			        	echo $data['EMPLOYEE_NAME'];
			        ?></td>
			      
			      </tr>
		      <?php } ?>
		    </tbody>
		   
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>