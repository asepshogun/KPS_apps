<section class="content-header">
	<h3>Return Product History</h3>
	<small>Retur Product History</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
<!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">History</a></li>
                  <li><a href="#tab_2" data-toggle="tab">History Detail</a></li>
                  
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    <div class="box-body">
					<!--TABLE Induk-->
					<table id="retur_product_history_induk" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
							<th>Update By</th>
					        <th>Update Date</th>
					        <th>No Retur</th>
					        <th>Rev No</th>
					        <th>No From Customer</th>
					        <th>Date</th>
					        <th>Customer Name</th>
					        <th>Date Retur Customer</th>
					        <th>PPIC DUE Date</th>
					        <th>Customer DUE Date</th>
					        <th>DO NO</th>
					        <th>Made by</th>
					        <th>Checked Sales</th>
					        <th>Checked QC</th>
					        <th>Knowed</th>
					        <th>Approved</th>
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($dataInduk as $value) { $no++?>
						      <tr>
						        <td><?php echo $no;?></td>
						        <td><?php 
									$query6 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->UPDATE_BY_RB."'");
						        	$data6 = mysql_fetch_array($query6);
						        	echo $data6['EMPLOYEE_NAME'];
						        	?>
								</td>
								<td><?php echo $value->UPDATE_TIME;?></td>
								<td><?php echo $value->NO_RETUR;?></td>
						        <td><?php echo $value->KPS_REVISI_NO_RETUR;?></td>
						        <td><?php echo $value->NO_RETUR_FROM_CUSTOMER;?></td>
						        <td><?php echo $value->DATE_RTR;?></td>
						        <td><?php echo $value->COMPANY_NAME;?></td>
						        <td><?php echo $value->DATE_RETUR_CUSTOMER;?></td>
						        <td><?php echo $value->DUE_DATE_PPIC;?></td>
						        <td><?php echo $value->DUE_DATE_CUSTOMER;?></td>
						        <td><?php echo $value->NO_DO;?></td>
								<td><?php 
									$query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->MADE_BY_RB."'");
						        	$data1 = mysql_fetch_array($query1);
						        	echo $data1['EMPLOYEE_NAME'];
						        	?>
								</td>
								<td><?php 
									$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHECKED_SALES."'");
						        	$data2 = mysql_fetch_array($query2);
						        	echo $data2['EMPLOYEE_NAME'];
						        	?>
								</td>
								<td><?php 
									$query3 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHCEKED_QC."'");
						        	$data3 = mysql_fetch_array($query3);
						        	echo $data3['EMPLOYEE_NAME'];
						        	?>
								</td>
								<td><?php 
									$query4 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KNOWED."'");
						        	$data4 = mysql_fetch_array($query4);
						        	echo $data4['EMPLOYEE_NAME'];
						        	?>
								</td>
								<td><?php 
									$query5 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->APPROVED."'");
						        	$data5 = mysql_fetch_array($query5);
						        	echo $data5['EMPLOYEE_NAME'];
						        	?>
								</td>
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE Induk end-->
				</div>
                  </div><!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    <div class="box-body">
				<table id="retur_detail_data_history" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					<thead>
					  <tr>
						<th>No</th>
						<th>Update By</th>
						<th>Update Date</th>
						<th>Code Item</th>
						<th>Part Name</th>
						<th>Part No</th>
						<th>Model</th>
						<th>QTY</th>
						<th>Unit</th>
						<th>Reason</th>	
					  </tr>
					</thead>
					<tbody>
						<?php $no=0; foreach ($dataDetail as $value) { $no++?>
						  <tr>
							<td><?php echo $no;?></td>
							 <td><?php 
									$query6 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_RETUR_BARANG_DETAIL_UPDATE_BY."'");
									$data6 = mysql_fetch_array($query6);
									echo $data6['EMPLOYEE_NAME'];
									?>
							</td>
							<td><?php echo $value->UPDATE_TIME;?></td>
							<td><?php echo $value->LOI_CODE_ITEM;?></td>
							<td><?php echo $value->LOI_PART_NAME;?></td>
							<td><?php echo $value->LOI_PART_NO;?></td>
							<td><?php echo $value->LOI_MODEL;?></td>      
							<td><?php echo $value->QTY_RTR;?></td>
							<td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
							<td><?php echo $value->REASON;?></td>
						  </tr>
					  <?php } ?>
					</tbody>
				</table>
				</div>
                  </div><!-- /.tab-pane -->
                 
                </div><!-- /.tab-content -->
              </div><!-- nav-tabs-custom -->
	

</div>
</section>
	<!--TABLE Detail End-->
