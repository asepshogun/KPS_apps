<section class="content-header">
	<h3>History Quotation</h3>
	<small>History data Permintaan Barang</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="quotation" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Quotation No</th>
		        <th>Quotation Date</th>
		        <th>Revisi Number</th>
		        <th>Valid From</th>
		        <th>Valid Until</th>
		        <th>Currency</th>
		        <th>RFQ Number</th>
		        <th>Customer Name</th>
		        <th>Address</th>
		        <th>Phone</th>
		        <th>Fax</th>
		        <th>PIC</th>
		        <th>Email</th>
		        <th>Marketing Name</th>
		          
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datas as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_quo=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_quo;?></td>
			        <td><?php echo $value->NO_QUO;?></td>
			        <td><?php echo $value->DATE_QUO;?></td>
			        <td><?php echo $value->RFQ_REV_NO;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>
			        <td><?php echo $value->CURRENCY_NAME;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_NO;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->PLANT;?></td>
			        <td><?php echo $value->PHONE;?></td>
			        <td><?php echo $value->FAX;?></td>
			        <td><?php echo $value->NAME;?></td>
			        <td><?php echo $value->EMAIL;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			      
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>