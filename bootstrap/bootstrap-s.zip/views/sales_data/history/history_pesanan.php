<section class="content-header">
	<h3>History Purchase Order</h3>
	<small>Histori data Bukti Pesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	<!-- Modal HISTORY-->

	    <!--TABLE-->
		<table id="bukti_pesanan" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Date Update</th>
		        <th>Update By</th>
		        <th>Rev No</th>
		        <th>No Bukti Pesanan</th>
		        <th>Company Name</th>
		        <th>Currency</th>
		        <th>PO Number Customer</th>
		        <th>PO Date Customer</th>
		        <th>Sub Total</th>
		        <th>Tax</th>
		        <th>Total</th>
		        <th>Status</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($datas as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			         <td>
			        <?php 
			        	if($value->status_bp=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->UPDATE_TIME;?></td>
					<td><?php 
						$query6 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->UPDATE_BY_BP."'");
						$data6 = mysql_fetch_array($query6);
						echo $data6['EMPLOYEE_NAME'];
						?>
					</td>
			        <td><?php echo $value->revisi_no_bp;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->CURRENCY;?></td>
			        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->SUB_TOTAL_BP;?></td>
			        <td><?php echo $value->TAX_BP;?></td>
			        <td><?php echo $value->TOTAL_BP;?></td>
			        <td><?php echo $value->KPS_BP_STATUS_VERIFIKASI_CUSTOMER;?></td>

			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
		</div>
	</div>
</div>