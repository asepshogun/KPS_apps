<section class="content-header">
	<h3>History Price</h3>
	<small>Riwayat Perubahan Harga</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="history-price" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Model</th>
		        <th>Customer Name</th>
		        <th>View History Price</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++?>
			      <tr>
					<td><?php echo$no; ?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
			        <td><?php echo $value->MODEL;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			      	<td>
						<div class="btn-group">
							<a href="<?php echo site_url()."/historyupdate/history/".$value->KPS_QUOTATION_ID;?>" class="btn btn-info btn-sm" <?php if($value->KPS_QUOTATION_ID){ echo "";}else{echo "disabled onclick='return false'";}?>><i class="fa fa-university"></i></a>
						</div>
					</td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Item Master</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/new_item_master/add";?>" method="POST" class="form-horizontal">
				<div class="form-group">
		          <label class="col-sm-3 control-label">Code Item</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_CODE_ITEM" placeholder="Code Item" required >
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Part No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NO" placeholder="Part No" required>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Part Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_ITEM_MASTER_PART_NAME" placeholder="Part Name" required>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_DOs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="ITEM_MASTER_MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->