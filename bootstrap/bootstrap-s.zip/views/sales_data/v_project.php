<section class="content-header">
	<h3>Failed Project</h3>
	<small>Proyek Gagal</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		<!-- Show/Hide Column :
		<div class="box-body">				
			<div class="btn-group" role="group" aria-label="...">
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">RFQ Number</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Customer Name</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Failed Project Number</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Failed Project Date</a></button>
			</div>
		</div> -->

		<!--TABLE-->
		<table id="fproject" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		      	<th>No</th>
		      	<th>Status</th>
		        <th>Revisi No</th>
		        <th>RFQ Number</th>
		        <th>Customer Name</th>
		        <th>Failed Project Number</th>
		        <th>Failed Project Date</th>
		        <th>Action</th>		        
		         <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	
		        	<th>Lock/Unlock</th>
		        	<?php
		        	}?>    
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			      	<td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_project=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_project;?></td>
			        <td><?php echo $value->NO_RFQ;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_FAILED;?></td>
			        <td><?php echo $value->DATE_FAILED;?></td>
			        
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/project/detail/".$value->KPS_FAILED_PROJECT_ID;?>" <?php if($value->status_project==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/project/edit/".$value->KPS_FAILED_PROJECT_ID;?>" <?php if($value->status_project==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/project/history/".$value->KPS_FAILED_PROJECT_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/project/del/".$value->KPS_FAILED_PROJECT_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/project/pre_print/".$value->KPS_FAILED_PROJECT_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>   
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
			        <td><div class="btn-group">
		        	<a href="<?php echo site_url()."/project/lock/".$value->KPS_FAILED_PROJECT_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        	<a href="<?php echo site_url()."/project/unlock/".$value->KPS_FAILED_PROJECT_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a>
		        	</div>
		        	</td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Failed Project</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Failed Project</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/project/add";?>" method="POST" class="form-horizontal">
		    	<div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <select class="form-control select2" style="width: 100%;" urlcurr="<?php echo site_url()."/pesanan/loadCurr";?>" urldivisi="<?php echo site_url()."/item/loadRFQsFailed";?>" id="cust" name="KPS_CUSTOMER_ID_BK">					  
						    <option>-- Select Company --</option>
						    <?php foreach ($dataCust as $value) { ?>
						    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
						    <?php } ?>					  
						</select>
			          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Request for Quotation</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="modelLoi" name="KPS_RFQ_ID_FAILED">					  
					  				  						    <option>-- Select RFQ --</option>

					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_approved_id">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		         <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_FAILEDs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="MADE_BY_FAILED" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <textarea class="form-control" name="NOTE_FAILED" placeholder="note"></textarea>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->