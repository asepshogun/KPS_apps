<section class="content-header">
	<h3>Outgoing Finished Good Verification</h3>
	<small>Outgoing Finished Good Verification</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="ogfg" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Bukti Pesanan Number</th>
		        <th>Outgoing Number</th>
		        <th>Vehicle</th>
		        <th>Total PO</th>	        
		        <th>Total Delivery Schedule</th>		        
		        <th>Total Delivery Execution</th>        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->NO_OUTGOING;?></td>
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->TOTAL_PO;?></td>
			        <td><?php echo $value->TOTAL_DELIVERY_SHCEDULE;?></td>
			        <td><?php echo $value->TOTAL_DELIVERY_EXECUTION;?></td>	        
			        <td><a href="<?php echo site_url()."/Outgoing_finished_verification/detail/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

