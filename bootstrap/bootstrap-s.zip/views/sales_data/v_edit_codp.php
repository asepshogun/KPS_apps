
<!-- Modal ADD-->

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Form Add Set Up Cost</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo site_url()."/cost_of_delivery_product/update";?>" method="POST" class="form-horizontal">
          <div class="form-group">
              <label for="bankName" class="col-sm-3 control-label">Set Up Cost</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="COST_DELIVERY_PRODUCT" value="<?php echo $data->COST_DELIVERY_PRODUCT?>" placeholder="ex. 40">
                <input type="hidden" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_ID; ?>">
                </div>
            </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
              </div>
            </div>            
          </form>                                       
      </div>
    