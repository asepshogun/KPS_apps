<section class="content-header">
	<h3>Customer Information Sheet</h3>
	<small>Lembar Informasi Pelanggan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">

	<div class="box-body">

		<!-- Show/Hide Column :
		<div class="box-body">				
			<div class="btn-group" role="group" aria-label="...">
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Company Name</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Customer Number</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Customer Industry</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Automotive Type</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Sales Type</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Sales Tax</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Payment</a></button>		  
			</div>
		</div> -->

		<!--TABLE-->
		<table id="cis" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Company Name</th>
		        <th>Customer Number</th>
		        <th>Customer Industry</th>
		        <th>Automotive Type</th>
		        <th>Sales Type</th>
		        <th>Sales Tax</th>
		        <th>Payment</th>
		        <th>Print</th>
		        <th>Update</th>		        
		        <th>Detail</th>
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		        	<th width="20px">Action</th>
		        	<?php
		        	}?>   
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->CUSTOMER_INDUSTRY;?></td>
			        <td><?php echo $value->AUTOMOTIVE_TYPE;?></td>
			        <td><?php echo $value->SALES_TYPE;?></td>
			        <td><?php echo $value->SALES_TAX;?></td>
			        <td><?php echo $value->PAYMENT;?></td>
					<td><a href="<?php echo site_url()."/customer_information/pre_print_Single/".$value->KPS_CUSTOMER_ID;?>" class="btn btn-default btn-sm" target="_blank">Print</a></td>
			        <td><a href="<?php echo site_url()."/customer_information/edit/".$value->KPS_CUSTOMER_ID;?>" class="btn btn-warning btn-sm <?php if($value->status==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
			        <td><a href="<?php echo site_url()."/customer_information/detail/".$value->KPS_CUSTOMER_ID;?>" class="btn btn-primary btn-sm <?php if($value->status==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>">Detail</a></td>
			        <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		        	<td><div class="btn-group">
		        	<a href="<?php echo site_url()."/customer_information/lock/".$value->KPS_CUSTOMER_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        	<?php
		        	}?>
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<a href="<?php echo site_url()."/customer_information/unlock/".$value->KPS_CUSTOMER_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  

			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<table class="table">
			<tr>
				<td>	
					<a href="<?php echo site_url()."/customer_information/prePrintAll/";?>" class="btn btn-primary pull-right btn-flat" target="_blank">Print All</a>
				</td>
				<td>
					<button type="button" href="" url="<?php echo site_url()."/customer_information/preAdd/";?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Customer</button>
				</td>
			</tr>
		</table>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">

	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->