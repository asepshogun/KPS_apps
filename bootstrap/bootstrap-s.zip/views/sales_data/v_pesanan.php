<section class="content-header">
	<h3>Order Evidence</h3>
	<small>Bukti Pesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<?php if($this->session->flashdata('errorNOPO')) { ?>
		      <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-ban"></i> Alert!</h4><h4><center>
		      <?php echo $this->session->flashdata('errorNOPO'); ?> 
		      </center></h4></div>
		<?php } ?>
		<!--TABLE-->
		<table id="bukti_pesanan" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>No Bukti Pesanan</th>
		        <th>Company Name</th>
		        <th>Currency</th>
		        <th>PO Number Customer</th>
		        <th>PO Date Customer</th>
		        <th>Sub Total</th>
		        <th>Tax</th>
		        <th>Total</th>
		        <th>Status</th>
		        <th>Action</th>		        
		        
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"  OR $this->session->userdata('role')=="Sales Regular"){
		        	?> 
		        	<th width="20px">Lock/Unlock</th>
		        	<?php
		        	}?>  
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			         <td>
			        <?php 
			        	if($value->status_bp=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_bp;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->CURRENCY;?></td>
			        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->SUB_TOTAL_BP;?></td>
			        <td><?php echo $value->TAX_BP;?></td>
			        <td><?php echo $value->TOTAL_BP;?></td>
			        <td><?php echo $value->KPS_BP_STATUS_VERIFIKASI_CUSTOMER;?></td>

			        
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/pesanan/detail/".$value->KPS_BUKTI_PESANAN_ID;?>" <?php if($value->status_bp==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/pesanan/edit/".$value->KPS_BUKTI_PESANAN_ID."/".$value->KPS_CUSTOMER_ID_BK;?>" <?php if($value->status_bp==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/pesanan/history/".$value->KPS_BUKTI_PESANAN_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/pesanan/del/".$value->KPS_BUKTI_PESANAN_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/pesanan/pre_print/".$value->KPS_BUKTI_PESANAN_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>      	
			       <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular"){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/pesanan/lock/".$value->KPS_BUKTI_PESANAN_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        		<?php
		        	}?>
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<a href="<?php echo site_url()."/pesanan/unlock/".$value->KPS_BUKTI_PESANAN_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button"  href="" url="<?php echo site_url()."/pesanan/preAdd/". $statusTx ;?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Bukti Pesanan</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">

	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->