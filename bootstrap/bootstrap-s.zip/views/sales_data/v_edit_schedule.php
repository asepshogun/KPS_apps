<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Schedule Data</h4>
</div>
<div class="modal-body">
        <form action="<?php echo site_url()."/schedule/update";?>" method="POST" class="form-horizontal">
          <div class="form-group">
              <label class="col-sm-3 control-label">Bukti Pesanan</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="KPS_BUKTI_PESANAN_ID_DS">           
              <option>-- Select Bukti Pesanan --</option>
              <?php foreach ($dataPesanan as $value) { ?>
              <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>" <?php
            if($value->KPS_BUKTI_PESANAN_ID==$data->KPS_BUKTI_PESANAN_ID_DS){
              echo "selected=''";
            }
            ?>><?php echo $value->REV_NO_BP;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_checked_id">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_checked_id){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Total</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="TOTAL" value="<?php echo $data->TOTAL ?>" placeholder="total">
                <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_DELIVERY_SCHEDULE_ID ?>" placeholder="total">
                <input type="hidden" class="form-control" name="revisi_no_ds" value="<?php echo $data->revisi_no_ds ?>">
              </div>
            </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
              </div>
            </div>              
          </form>                                       
      </div>
      <script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>