<section class="content-header">
	<h3>Request For Quotation Monitoring</h3>
	<small>Monitoring RFQ</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

        
       
              <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">Show/Hide Column</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div><!-- /.box-tools -->
                </div><!-- /.box-header -->
                 <div class="box-body">              
                    <div class="btn-group" role="group" aria-label="...">
                    <ul class="pager">
                      <li><a class="toggle-vis" data-column="0">No</a></li>
                      <li><a class="toggle-vis" data-column="1">RFQ Date</a></li>
                      <li><a class="toggle-vis" data-column="2">RFQ No</a></li>
                      <li><a class="toggle-vis" data-column="3">RFQ Rev No</a></li>
                      <li><a class="toggle-vis" data-column="4">RFQ Customer Date</a></li>
                      <li><a class="toggle-vis" data-column="5">RFQ Customer No</a></li>
                      <li><a class="toggle-vis" data-column="6">Part Name</a></li>
                      <li><a class="toggle-vis" data-column="7">Part No</a></li>
                      <li><a class="toggle-vis" data-column="8">Model</a></li>
                      <li><a class="toggle-vis" data-column="9">Customer Name</a></li>
                      <li><a class="toggle-vis" data-column="10">Marketing Name</a></li>
                      <li><a class="toggle-vis" data-column="11">Breakdown Date</a></li>
                      <li><a class="toggle-vis" data-column="12">Breakdown Price</a></li>
                      <li><a class="toggle-vis" data-column="13">Breakdown Price Tooling</a></li>
                      <li><a class="toggle-vis" data-column="14">Quotation Due Date</a></li>
                      <li><a class="toggle-vis" data-column="15">Quotation Date</a></li>
                      <li><a class="toggle-vis" data-column="16">Quotation Retard Date</a></li>
                      <li><a class="toggle-vis" data-column="17">Quotation Price</a></li>
                      <li><a class="toggle-vis" data-column="18">LOI Date</a></li>
                      <li><a class="toggle-vis" data-column="19">No LOI</a></li>
                      <li><a class="toggle-vis" data-column="20">Date LOI</a></li>
                      <li><a class="toggle-vis" data-column="21">Date Receive</a></li>
                      <li><a class="toggle-vis" data-column="22">No Die Go</a></li>
                      <li><a class="toggle-vis" data-column="23">Coding Product</a></li>
                      <li><a class="toggle-vis" data-column="24">LOI Price</a></li>
                      <li><a class="toggle-vis" data-column="25">Cavity</a></li>
                      <li><a class="toggle-vis" data-column="26">QTY/Month</a></li>
                      <li><a class="toggle-vis" data-column="27">Periode Month</a></li>
                      <li><a class="toggle-vis" data-column="28">Tooling Cost</a></li>
                      <li><a class="toggle-vis" data-column="29">Material</a></li>
                      <li><a class="toggle-vis" data-column="30">LOI Proses</a></li>
                      <li><a class="toggle-vis" data-column="31">Machine</a></li>
                      <li><a class="toggle-vis" data-column="32">Sample</a></li>
                      <li><a class="toggle-vis" data-column="33">PP1</a></li>
                      <li><a class="toggle-vis" data-column="34">Masspro</a></li>
                      <li><a class="toggle-vis" data-column="35">Estimation LOI Date</a></li>
                      <li><a class="toggle-vis" data-column="36">Loi/Failed</a></li>
                      <li><a class="toggle-vis" data-column="37">Tooling Depreciation</a></li>
                      <li><a class="toggle-vis" data-column="38">Status</a></li>
                    </ul>
                    </div>
                </div>
              </div><!-- /.box -->
         
       
				
		<!--TABLE-->
		<table id="rfqmon" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		     <tr>
                <th rowspan="2">No</th>
                <th colspan="3"><center>Request For Quotation</center></th>
                <th colspan="2"><center>RFQ Customer</center></th>
                <th rowspan="2">Part Name</th>
                <th rowspan="2">Part No</th>
                <th rowspan="2">Model</th>
                <th rowspan="2">Customer Name</th>
                <th rowspan="2">Marketing Name</th>
                <th colspan="3"><center>Breakdown Quotation</center></th>
                <th colspan="4"><center>Quotation Price</center></th>
                <th colspan="14"><center>Permohonan Produk Baru (LOI)</center></th>
                <th colspan="3"><center>Schedule</center></th>
                <th rowspan="2">Estimation LOI Date</th>
                <th rowspan="2">Loi/Failed</th>
                <th rowspan="2">Tooling Depreciation</th>
                <th rowspan="2">Status</th>
            </tr>
            <tr>
                <th>Date</th>
                <th>No</th>
                <th>Rev No</th>
                <th>Date</th>
                <th>No</th>
                <th>Date</th>
                <th>Price</th>
                <th>Price Tooling</th>
                <th>Due Date</th>
                <th>Date</th>
                <th>Retard Date</th>
                <th>Price</th>
                <th>Date</th>
                <th>No LOI</th>
                <th>Date LOI</th>
                <th>Date Receive</th>
                <th>No Die GO/PO Cust</th>
                <th>Coding Product</th>
                <th>Price</th>
                <th>Cavity</th>
                <th>Qty/Month</th>
                <th>Periode Month</th>
                <th>Tooling Cost</th>
                <th>Material</th>
                <th>Proses</th>
                <th>Machine</th>
                <th>Sample</th>
                <th>PP1</th>
                <th>Masspro</th>
            </tr>
		    </thead>
		    <tfoot>
		    	<tr>
		    	<th>No</th>
			    <th>Date</th>
                <th>No</th>
                <th>Rev No</th>
                <th>Date</th>
                <th>No</th>
                <th>Part Name</th>
                <th>Part No</th>
                <th>Model</th>
                <th>Customer Name</th>
                <th>Marketing Name</th>
                <th>Date</th>
                <th>Price</th>
                <th>Price Tooling</th>
                <th>Due Date</th>
                <th>Date</th>
                <th>Retard Date</th>
                <th>Price</th>
                <th>Date</th>
                <th>No LOI</th>
                <th>Date LOI</th>
                <th>Date Receive</th>
                <th>No Die GO/PO Cust</th>
                <th>Coding Product</th>
                <th>Price</th>
                <th>Cavity</th>
                <th>Qty/Month</th>
                <th>Periode Month</th>
                <th>Tooling Cost</th>
                <th>Material</th>
                <th>Proses</th>
                <th>Machine</th>
                <th>Sample</th>
                <th>PP1</th>
                <th>Masspro</th>
                <th>Estimation LOI Date</th>
                <th>Loi/Failed</th>
                <th>Tooling Depreciation</th>
                <th>Status</th>
            	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
		    		<tr>
		    	 	<td><?php echo $no;?></td>
			        <td><?php echo $value->DATE_RFQ;?></td>
			        <td><?php echo $value->NO_RFQ;?></td>
			        <td><?php echo $value->RFQ_REV_NO;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_DATE;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_NO;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->marketing_id;?></td>
			        <td><?php echo $value->DATE_BREAK;?></td>
			        <td><?php echo $value->total_breakdown;?></td>
			        <td><?php echo $value->COST;?></td>
			        <td><?php echo $value->DUE_DATE_QUOTATION;?></td>
			        <td></td>
			        <td></td>
			        <td><?php echo $value->price;?></td>
			        <td><?php echo $value->DATE_LOI;?></td>
			        <td><?php echo $value->NO_LOI;?></td>
			        <td></td>
			        <td><?php echo $value->DISCONTINUE_DATE;?></td>
			        <td><?php echo $value->LOI_DIE_GO_NO;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->price;?></td>
			        <td></td>
			        <td><?php echo $value->QTY_MONTH;?></td>
			        <td><?php echo $value->PERIODE;?></td>
			        <td><?php echo $value->COST;?></td>
			        <td></td>
			        <td></td>
			        <td></td>
			        <td><?php echo $value->SAMPLE_MASSPRO;?></td>
			        <td><?php echo $value->PP1;?></td>
			        <td><?php echo $value->MASSPRO;?></td>
			        <td><?php echo $value->ESTIMATION_LOI_DATE;?></td>
			        <td><?php if($value->NO_LOI == NULL){
			        	echo "Failed";
			        }else{
			        	echo "Loi";
			        }?></td>
			        <td><?php echo $value->TOOLING_COST_RFQ;?></td>
			        <td></td>
			     	</tr>
		      <?php } ?>
		    </tbody>
		    
		</table>
		<!--TABLE-->
	</div>


<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->