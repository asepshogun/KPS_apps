<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<h3>Item ini tidak bisa dihapus karena sudah digunakan di outgoing</h3><br/>
	<h3>No Out Going : <?php echo $data->NO_OUTGOING ;?></h3><br/>
	<h3>Date Going : <?php echo $data->DATE_OUTGOING ;?></h3><br/>
</div>