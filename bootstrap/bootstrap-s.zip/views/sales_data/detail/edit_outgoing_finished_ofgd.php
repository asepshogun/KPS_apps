<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Outgoing Finished Good Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/outgoing_finished/updateDetail/kps_outgoing_finished_good_detail/KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
            <label class="col-lg-3 control-label">Delivery Schedule Product & Part</label>
            <div class="col-lg-9">
              <select name="KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD" class="form-control select2" style="width: 100%">
            <option value="0">-- Select Code Product --</option>
            <?php foreach ($code as $value) { ?>
              <option value="<?php echo $value->KPS_DELIVERY_SCHEDULE_DETAIL_ID;?>" <?php
            if($value->KPS_DELIVERY_SCHEDULE_DETAIL_ID==$data->KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD){
              echo "selected=''";
            }
            ?>><?php echo $value->code_product.", Model. ".$value->model.", Part No. ".$value->part_no.", Part Name: ".$value->part_name;?></option>
              <?php } ?>  
          </select>
            </div>
          </div>
   
    <div class="form-group">
      <label class="col-lg-3 control-label">QTY Outstanding PO</label>
      <div class="col-lg-9">
           <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_OUTGOING_FINISHED_GOOD_ID_D;?>">
   
        <input type="text" class="form-control" name="QTY_OUTSTANDING_PO_OS" value="<?php echo $data->QTY_OUTSTANDING_PO_OS;?>">
      </div>
    </div>    
    <div class="form-group">
      <label class="col-lg-3 control-label">QTY Delivery Execution</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QTY_DELIVERY_EXECUTION" value="<?php echo $data->QTY_DELIVERY_EXECUTION;?>">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NOTE" value="<?php echo $data->NOTE;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>