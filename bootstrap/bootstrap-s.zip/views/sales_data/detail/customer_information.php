<section class="content-header">
	<h3>Customer Information Sheet Detail</h3>
	<small>Detail Lembar Informasi Pelanggan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Marketing Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MARKETING_NAME" value="<?php echo $datas->MARKETING_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" value="<?php echo $datas->COMPANY_NAME ?>" name="COMPANY_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Sales Type</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" value="<?php echo $datas->SALES_TYPE ?>" name="SALES_TYPE" disabled>
			          </div>
			        </div> 
					<div class="form-group">
			          <label class="col-sm-3 control-label">Code Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" value="<?php echo $datas->CUSTOMER_CODE ?>" name="SALES_TYPE" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer Industry</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" value="<?php echo $datas->CUSTOMER_INDUSTRY ?>" name="CUSTOMER_INDUSTRY" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Automotive Type</label>
			          <div class="col-sm-9">
			            <input type="text" value="<?php echo $datas->AUTOMOTIVE_TYPE ?>" class="form-control" name="AUTOMOTIVE_TYPE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Sales Tax</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" value="<?php echo $datas->SALES_TAX ?>" name="SALES_TAX" disabled>
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#cp">COMPANY PROFILE</a></li>
			  <li><a data-toggle="tab" href="#plant">PLANT</a></li>
			  <li><a data-toggle="tab" href="#divisi">DIVISI</a></li>
			  <li><a data-toggle="tab" href="#pic">PERSON IN CHARGE</a></li>
			  <li><a data-toggle="tab" href="#mc">MAIN COSTUMER</a></li>
			  <li><a data-toggle="tab" href="#supplier">SUPPLIER</a></li>
			  <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                      FINANCE <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                      <li role="presentation"><a data-toggle="tab" tabindex="-1" href="#finance">FINANCE</a></li>
                      <li role="presentation"><a data-toggle="tab" tabindex="-1" href="#account">ACCOUNT FINANCE</a></li>
                    </ul>
              </li>
			  <li><a data-toggle="tab" href="#ds">DELIVERY SETUP</a></li>
			  <li><a data-toggle="tab" href="#iso">ISO</a></li>
			    <!-- perubahan untuk revisi payment personal start-->
			  <li><a data-toggle="tab" href="#pap">PAYMENT AS PERSONAL</a></li>
			  <!-- perubahan untuk revisi payment personal end-->

			</ul>

			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">
				<?php 
				$data['customerId'] = $datas->KPS_CUSTOMER_ID;
				$data['dataCp'] = $cp;
				$this->load->view('sales_data/detail/customer_information_cp', $data);?>			
			  </div>
			  <div id="plant" class="tab-pane fade">
			    <?php 
				$data['plant'] = $plant;

				$this->load->view('sales_data/detail/customer_information_plant',$data);?>	
			  </div>
			  <div id="divisi" class="tab-pane fade">
			    <?php 
				$data['divis'] = $divisi;
				$this->load->view('sales_data/detail/customer_information_divisi',$data);?>	
			  </div>
			  <div id="pic" class="tab-pane fade">
			    <?php 
				$data['pic'] = $pic;
				$this->load->view('sales_data/detail/customer_information_pic',$data);?>	
			  </div>
			  <div id="mc" class="tab-pane fade">
			    <?php 
				$data['mainc'] = $main;
				$this->load->view('sales_data/detail/customer_information_mc',$data);?>	
			  </div>
			  <div id="supplier" class="tab-pane fade">
			    <?php 
				$data['sup'] = $sup;
				$this->load->view('sales_data/detail/customer_information_supplier',$data);?>	
			  </div>
			  <div id="finance" class="tab-pane fade">
			    <?php 
				$data['finance'] = $finance;
				$this->load->view('sales_data/detail/customer_information_finance',$data);?>	
			  </div>
			  <div id="account" class="tab-pane fade">
			    <?php 
				$data['account'] = $account;
				$this->load->view('sales_data/detail/customer_information_account',$data);?>	
			  </div>
			  <div id="ds" class="tab-pane fade">
			    <?php 
				$data['deliv'] = $deliv;
				$this->load->view('sales_data/detail/customer_information_ds',$data);?>	
			  </div>
			  <div id="iso" class="tab-pane fade">
			    <?php 
				$data['iso'] = $iso;
				$this->load->view('sales_data/detail/customer_information_iso',$data);?>	
			  </div>
			    <!-- perubahan untuk revisi payment personal start-->
			  <div id="pap" class="tab-pane fade">
			    <?php 
				$data['pap'] = $pap;
				$this->load->view('sales_data/detail/customer_information_pap',$data);?>	
			  </div>
			  <!-- perubahan untuk revisi payment personal end-->
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>