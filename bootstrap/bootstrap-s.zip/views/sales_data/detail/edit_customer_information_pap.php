<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Payment As Personal Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_personal_payment/KPS_CUSTOMER_PAP_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KPS_PAP_NAME" value="<?php echo $data->KPS_PAP_NAME;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_PAP_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
   
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>