<section class="content-header">
	<h3>New Item (LOI) Data Detail</h3>
	<small>Detail Data Item Baru (LOI)</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">LOI Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_LOI" value="<?php echo $data->NO_LOI ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">RFQ Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" value="<?php echo $data->NO_RFQ ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Die Go Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DIE_GO_NO" value="<?php echo $data->LOI_DIE_GO_NO ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Discontinue Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DISCONTINUE_DATE" value="<?php echo $data->DISCONTINUE_DATE ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Minimal Stock</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MIN_STOK" value="<?php echo $data->MIN_STOK ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Maximal Stock</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MAX_STOCK" value="<?php echo $data->MAX_STOCK ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active">
			  	<a data-toggle="tab" href="#nia">NEW ITEM ATTACHMENT</a>
			  </li>
			</ul>

			<div class="tab-content">
			  <div id="nia">
				<?php 
				$datas['attach'] = $attach;
				$datas['LOI_ID'] = $data->KPS_LOI_ID;
				$this->load->view('sales_data/detail/item_nia',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>