<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<h4>Item ini tidak bisa dihapus</h4><br/>
	<h4>Jika Ingin Mengapus Item Silahkan Menghubungi Manager Anda</h4><br/>
</div>