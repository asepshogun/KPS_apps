<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Target Price</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_target_price">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">RFQ Target Price</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control datepicker" name="TARGET_PRICEs" disabled value="<?php echo $datas->TARGET_PRICE ?>">
				            <input type="hidden" class="form-control datepicker" name="TARGET_PRICE" disabled value="">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Competitor Name</label>
				          <div class="col-lg-9">
				          		<input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">

				            <input type="text" class="form-control" name="COMPETITIOR_NAME" placeholder="compertitor name">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Competitor Price</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="COMPETITIOR_PRICE" placeholder="competitor price">
				          </div>
				        </div>				        				        
			  		</div>
			        <div class="col-lg-3" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Target Price" />
				        </div>
			        <div class="col-lg-3" align="center">
			        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Target Price" />
			        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="rfq_detail_tp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Target Price</th>
	        <th>Competitor Name</th>
	        <th>Competitor Price</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($price as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->TARGET_PRICE;?></td>
		        <td><?php echo $value->COMPETITIOR_NAME;?></td>
		        <td><?php echo $value->COMPETITIOR_PRICE;?></td>
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_RFQ_TARGET_PRICE_ID."/edit_request_quotation_tp"."/kps_rfq_target_price/KPS_RFQ_TARGET_PRICE_ID";?>" data-toggle="modal" data-target="#updateatp" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateatp" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->