<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Supplier Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_is_supplier/KPS_CUSTOMER_IS_SUPPLIER_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Supplier Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="SUPPLIER_NAME" value="<?php echo $data->SUPPLIER_NAME;?>">
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">Location</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="LOCATION" value="<?php echo $data->LOCATION;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_IS_SUPPLIER_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Busibness Content</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="BUSINESS_CONTENT" value="<?php echo $data->BUSINESS_CONTENT;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>