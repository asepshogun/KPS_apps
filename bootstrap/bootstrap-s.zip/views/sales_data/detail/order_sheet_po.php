<section class="content-header">
	<h3>Order Sheet Data PO Detail</h3>
	<small>Detail Data Order Sheet</small>
</section>
<!-- Main content -->
<section class="content"> 
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_LOI" disabled value="<?php echo $data[0]->KPS_OS_NO ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" disabled value="<?php echo $data[0]->KPS_OS_CREATION_DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Schedule Delivery</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DIE_GO_NO" disabled value="<?php echo $data[0]->KPS_OS_SCHEDULE_DELIVERY_DATE ."/" . $data[0]->KPS_OS_SCHEDULE_DELIVERY_TIME;?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Printed Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DISCONTINUE_DATE" disabled value="<?php echo $data[0]->KPS_OS_PRINTED_DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Kanban</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MIN_STOCK" disabled value="<?php echo $data[0]->KPS_OS_TOTAL_KANBAN ?>">
			          </div>
			        </div>	
			         <div class="form-group">
			          <label class="col-sm-3 control-label">No Bukti Pesanan</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="Bukti" disabled value="<?php echo $data[0]->PO_OS_NO_FROM_CUSTOMER ?> - <?php echo $data[0]->REV_NO_BP ?>">
			          </div>
			        </div>	

				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#osd">ORDER SHEET DETAILS</a></li>
			</ul>
			
			<div class="tab-content">
				<!-- TAB KONTEN 1-->
				<div id="osd" class="tab-pane fade in active">
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>Code Product</th>
						        <th>Part No</th>
						        <th>Part Name</th>
						        <th>Model</th>
						        <th>Delivery Place</th>
						        <th>Delivery Date</th>
						        <th>Delivery Quantity</th>
						        <th>Quantity Remaining</th>
						        <th>NOTE</th>
						        <th>Update</th>	
						        <th>Delete</th>	
						      </tr>
						    </thead>
							<?php //print_r($data[0]->KPS_ORDER_SHEET_DETAIL_ID);?>
						    <tbody>
						    	<?php $no=1; foreach ($detail as $value) { ?>
							      <tr>
							        <td><?php echo $no++;?></td>
							        <td><?php echo $value->LOI_CODE_ITEM;?></td>
							        <td><?php echo $value->LOI_PART_NO;?></td>
							        <td><?php echo $value->LOI_PART_NAME;?></td>
							        <td><?php echo $value->LOI_MODEL;?></td> 
							        <td><?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP_ID;?></td>
							        <td><?php echo $value->DELIVERY_PLAN;?></td> 
							        <td><?php echo $value->QUANTITY_DELIVERY;?></td>
							        <td><?php echo $value->REMAINING_QUANTITY;?></td>
							        <td><?php echo $value->NOTE_DS_DET;?></td>
							     	<td><a href="" url="<?php echo site_url()."/schedule/editDetail/".$value->KPS_DELIVERY_SCHEDULE_DETAIL_ID."/edit_schedule_dsd/kps_delivery_schedule_detail/KPS_DELIVERY_SCHEDULE_DETAIL_ID/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
									<td><a href="" url="<?php echo site_url()."/schedule/preDelDetail/".$value->KPS_DELIVERY_SCHEDULE_DETAIL_ID."/pre_del_schedule_dsd/kps_delivery_schedule_detail/KPS_DELIVERY_SCHEDULE_DETAIL_ID/".$value->KPS_DELIVERY_SCHEDULE_ID ."/". $data[0]->KPS_ORDER_SHEET_DETAIL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>
								  </tr>
						      <?php } ?>
						    </tbody>
						</table>
						<div class="col-lg-12">
							<a class="btn bg-blue btn-flat pull-left" href="<?php echo site_url() ?>/order_sheet/detail/<?php echo $data[0]->KPS_OS_ID; ?>" >Back</a>

							<button type="button" class="btn bg-olive btn-flat pull-right" data-toggle="modal" data-target="#add">Add Order Sheet Detail</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>					
<!--TABLE-->
<!--modal-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">
	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New OS Detail Data</h4>
	    </div>
	    <div class="modal-body">
			<form action="<?php echo site_url()."/order_sheet/addSubSub/kps_delivery_schedule_detail";?>" method="POST" class="form-horizontal">	    					      		        
				<div class="form-group">
					  <label class="col-lg-3 control-label">Product</label>
					  <div class="col-lg-9">
						<select name="KPS_BUKTI_PESANAN_DETAIL_ID_SD" url="<?php echo site_url() ?>/order_Sheet/loadRemainingForOs" id="productschOs" class="form-control select2" style="width:100%"	>
							<option value="0">-- Select Code Product --</option>
							<?php foreach ($Bpdet as $value) { ?>
							<option value="<?php echo $value->KPS_BUKTI_PESANAN_DETAIL_ID;?>">
							<?php echo "Code Item :". $value->LOI_CODE_ITEM." - Model : ".$value->LOI_MODEL." - Part No : ".$value->LOI_PART_NO." - Part Name : ".$value->LOI_PART_NAME;?>
							</option>
							<?php } ?>
						</select>
					  </div>
				</div>
				<div class="form-group">
					  <label class="col-lg-3 control-label">Remaining Quantity</label>
					  <div class="col-lg-9">
						<input type="text" class="form-control" id="remainingquantityOs" readonly="readonly"  name="REMAINING_QUANTITY">
					  </div>
				</div>
				<div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Quantity</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="QUANTITY_DELIVERY" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_DELIVERY_SCHEDULE_ID" value="<?php echo $data[0]->KPS_DELIVERY_SCHEDULE_ID; ?>" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_CUSTOMER_DELIVERY_SETUP_ID" value="<?php echo $data[0]->KPS_CUSTOMER_DELIVERY_SETUP_ID; ?>" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="DELIVERY_PLAN" value="<?php echo $data[0]->KPS_OS_SCHEDULE_DELIVERY_DATE; ?>" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_OS_ID" value="<?php echo $data[0]->KPS_OS_ID; ?>" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_BUKTI_PESANAN_ID_DS" value="<?php echo $data[0]->KPS_BUKTI_PESANAN_ID_DS; ?>" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_ORDER_SHEET_DETAIL_ID" value="<?php echo $data[0]->KPS_ORDER_SHEET_DETAIL_ID; ?>" placeholder="quantity netto">
			      </div>
			    </div>
				<div class="form-group">
			      <label class="col-lg-3 control-label">Note</label>
			      <div class="col-lg-9">
			        <textarea type="text" class="form-control" name="NOTE_DS_DET" placeholder="note"></textarea>	
			      </div>
			    </div>
				<div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>
			</form>
		</div>
	  </div>
	</div>
</div>
<!-- Modal ADD -->
<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--modal-->
