<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Manufacturing Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/breakdown_cost/updateDetail/kps_breakdown_cost_manufacturing/KPS_BREAKDOWN_COST_MANUFACTURING_ID";?>" method="POST" class="form-horizontal">    
    <div class="form-group">
      <label class="col-lg-3 control-label">Processing</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="PROCCESING" value="<?php echo $data->PROCCESING;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Machine</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="MACHINE" value="<?php echo $data->MACHINE;?>">
          <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_MANUFACTURING_ID; ?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BREAKDOWN_COST_ID;?>">

      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Time</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="TIME" value="<?php echo $data->TIME;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Charge</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="CHARGE" value="<?php echo $data->CHARGE;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>