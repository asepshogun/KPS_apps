<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Order Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/delivery_order/updateDetail/kps_delivery_order_detail/KPS_DELIVERY_ORDER_DETAIL_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NOTE_DO" value="<?php echo $data->NOTE_DO;?>">
              <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_DELIVERY_ORDER_DETAIL_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_DELIVERY_ORDER_ID;?>">
   
      </div>
    </div> 
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>