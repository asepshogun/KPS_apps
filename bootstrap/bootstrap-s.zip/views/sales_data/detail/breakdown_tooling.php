<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Tooling</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
				<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/breakdown_cost/addSub/kps_breakdown_cost_tooling">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Tool</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="TOOL" placeholder="tool">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Cost</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="COST" placeholder="cost">
							<input type="hidden" class="form-control" name="KPS_BREAKDOWN_COST_ID" value="<?php echo $KPS_BREAKDOWN_COST_ID; ?>"/>

				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Remarks</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="REMARK" placeholder="remarks">
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Tooling</button>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="reset" class="btn btn-danger btn-flat pull-left">Clear Tooling</button>
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="breakdown_tooling" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Tools</th>
	        <th>Costs</th>
	        <th>Remarks</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($tool as $value) {$no++ ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->TOOL;?></td>
		        <td><?php echo $value->COST;?></td>
		        <td><?php echo $value->REMARK;?></td>
		         <td><a href="" url="<?php echo site_url()."/breakdown_cost/editDetail/".$value->KPS_BREAKDOWN_COST_TOOLING_ID."/edit_breakdown_tooling/kps_breakdown_cost_tooling/KPS_BREAKDOWN_COST_TOOLING_ID";?>" data-toggle="modal" data-target="#updatetool" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->
<!-- Modal UPDATE-->
<div class="modal fade" id="updatetool" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->