<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Attachment</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" enctype="multipart/form-data" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_attachment">
			  		<div class="col-lg-6">
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Attachment Type</label>
				          <div class="col-lg-9">
				            <select name="TYPE" class="form-control ">
								<option value="0">-- Select Part--</option>
								<option value="RFQ Letters">RFQ Letters</option>
								<option value="Drawing">Drawing</option>
								<option value="Others">Others</option>
							</select>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Attachment Title</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="TITLE" placeholder="title">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Attachment</label>
				          <div class="col-lg-9">				            
				            <input type="file" class="form-control" name="FILENAME">
							<input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">

				          </div>
				        </div>				   
				         <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Attachment" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Attachment" />
				        </div>
			  		</div>			  		
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="rfq_detail_attachment" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Attachment Type</th>
	        <th>Title</th>
	        <th>File Name</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($attach as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->TYPE;?></td>
		        <td><?php echo $value->TITLE;?></td>
		        <td>
		        <a href="<?php echo base_url()."uploads/rq/".$value->FILENAME; ?>">
		        <?php echo $value->FILENAME;?>
		        </a>
		        </td>
		        <td><a href="" url="<?php echo site_url()."/request_quotation/editDetail/".$value->KPS_RFQ_ATTACHMENT_ID."/edit_request_quotation_attachment/kps_rfq_attachment/KPS_RFQ_ATTACHMENT_ID";?>" data-toggle="modal" data-target="#updateattachdd" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateattachdd" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->