<!--TABLE-->

<div class="box-body">
	<table id="invoice_detail_id" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Delivery Order Number</th>
	        <th>Sub Total</th>
			<?php if(empty($status_inv_do)){ ?>
	        <th>Delete</th>
			<?php } ?>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($detail as $value) { $no++?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->NO_DO;?></td>
		        <td><?php echo $value->SUB_TOTAL;?></td>
				 <?php if(empty($status_inv_do)){ ?>
				<td><a href="" url="<?php echo site_url()."/invoice/preDelete_detail_DO/".$value->KPS_INVOICE_DETAIL_ID ."/". $idCus ."/". $this->session->userdata('role');?>" data-toggle="modal" data-target="#delete" class="update-link">Delete</a></td>		        
				<?php } ?>
			  </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
		<button type="button" class="btn bg-olive btn-flat pull-right" data-toggle="modal" data-target="#add" class="update-link" <?php if($status_inv_do==1){
		echo "disabled";
			    }else{
			        		echo "";
			        		}?>>Add Delivery Order No</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Invoice Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/invoice/addSub/kps_invoice_detail";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Order Number</label>
			      <div class="col-lg-9">
			        <select id="multiselect" class="form-control select2" multiple="multiple" name="delivery_order_id[]" style="width:100%">
							<option value="0">-- Select Delivery Order--</option>
							<?php foreach($delivery as $data){
								?>
								<option value="<?php echo $data->KPS_DELIVERY_ORDER_ID ?>"><?php echo $data->NO_DO ?></option>

								<?php

								} ?>
					</select>
					<input type="hidden" class="form-control" name="INVOICE_INDUK_ID_DET" value="<?php echo $INVOICE_INDUK_ID;?>"/>
					<input type="hidden" class="form-control" name="idCus" value="<?php echo $idCus;?>"/>
			      </div>
			    </div>        
		<!--        <div class="form-group">
			      <label class="col-lg-3 control-label">Term</label>
			      <div class="col-lg-9">

			        <input type="radio" name="term" value="1"> 1 </input>
			        <input type="radio" name="term" value="2"> 2 </input>
			        <input type="radio" name="term" value="3"> 3 </input>
			        <input type="radio" name="term" value="4"> 4 </input>
			      </div>
			    </div>    -->    
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!-- Modal DELETE -->
<div class="modal fade" id="delete" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal DELETE -->