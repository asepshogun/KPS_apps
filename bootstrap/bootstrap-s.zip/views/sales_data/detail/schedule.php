<section class="content-header">
	<h3>Delivery Schedule Data Detail</h3>
	<small>Detail Data Jadwal Pengiriman</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body ">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->COMPANY_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Delivery Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DELIVERY_DATE" value="<?php echo $data->DELIVERY_DATE ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Delivery Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_REV_NO" value="<?php echo $data->NO_REV_NO ?>" disabled>
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Total</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL" value="<?php echo $total ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#dsd">DELIVERY SCHEDULE DETAIL</a></li>
			</ul>

			<div class="tab-content">
			  <div id="dsd" class="tab-pane fade in active">
				<?php 
				$datas['detail'] = $detail;
				$datas['bukti'] = $bukti;
				// print_r($datas['detail']);
				$datas['KPS_DELIVERY_SCHEDULE_ID'] = $data->KPS_DELIVERY_SCHEDULE_ID;
				$this->load->view('sales_data/detail/schedule_dsd',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>