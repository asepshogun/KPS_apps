
<!--TABLE-->	
<div class="box-body">
	<table id="out_retur_detail" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Item</th>
	        <th>Part Name</th>
	        <th>Part No</th>
	        <th>Model</th>
	        <th>QTY Retur</th>
	        <th>QTY Execution</th>
	        <th>Remaining</th>
	        <th>Unit</th>
	        <th>Reason</th>
	        <th>Action</th>
	        <th>Action</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($detail as $value) { $no++?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td>      
		        <td><?php echo $value->QTY_RTR;?></td>
		        <td>0</td>
				 <td><?php 
						$query2 = mysql_query("select * from kps_outgoing_retur_product_detail where kps_outgoing_retur_product_detail.KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL ='". $value->KPS_RETUR_BARANG_DETAIL_ID ."'ORDER BY kps_outgoing_retur_product_detail.OUTGOING_RETUR_PRODUCT_DETAIL_ID DESC limit 1");
						$data2 = mysql_fetch_array($query2);
			        	if($data2['QTY_REMAINIG_EXECUTION_OUT']){
			        	echo $data2['QTY_REMAINIG_EXECUTION_OUT'];
						}else{
						echo $value->QTY_RTR;
						}
				?></td>
		        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
		        <td><?php echo $value->REASON;?></td>
		        <td><a href=""  url="<?php echo site_url()."/Outgoing_retur_product/add_exe/".$value->KPS_RETUR_BARANG_DETAIL_ID."/". $id_out ."/". $value->KPS_RETUR_BARANG_ID_DET ;?>" data-toggle="modal" data-target="#add_qty" class="update-link">Execution</a></td>
		        <td><a>-</a></td>
		      </tr>
	      <?php } ?>	
		  <?php foreach ($detail_out as $value) {  $no++;?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td>      
		        <td><?php echo $value->QTY_RTR;?></td>
		        <td><?php echo $value->QTY_EXECUTION_OUT;?></td>
		        <td><?php echo $value->QTY_REMAINIG_EXECUTION_OUT;?></td>
		        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
		        <td><?php echo $value->REASON;?></td>
		        <td><a href=""  data-toggle="modal" data-target="#updatedraw" class="update-link">Delete</a></td>
		        <td><a href=""  data-toggle="modal" data-target="#updatedraw" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->
<!--QTY EXECUTION-->
<div class="modal fade" id="add_qty" role="dialog">
	<div class="modal-dialog">
	  <div class="modal-content">
	  
	  </div>
	</div>
</div>
<!--QTY EXECUTION-->

<!-- Modal UPDATE-->
<div class="modal fade" id="add_qty" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">

	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->