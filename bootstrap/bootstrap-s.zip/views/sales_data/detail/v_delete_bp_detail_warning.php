<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Item ini tidak bisa di delete</h4>
</div>
<div class="modal-body">
	<h3>Item ini tidak bisa di delete kerena sudah digunakan di Delivery Schedule</h3><br>
	<h3>NO Delivery Schedule : <?php echo $data->NO_REV_NO; ?></h3><br>
	<h3>Tanggal Delivery Schedule : <?php echo $data->DELIVERY_DATE; ?></h3> <br/>
	<h3>Tanggal Pengiriman : <?php echo $data->DELIVERY_PLAN; ?></h3> <br/>
</div>	
