<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Company Profile Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_company/KPS_CUSTOMER_COMPANY_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3">Type of Company</label>                     
      <div class="col-lg-9">
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Join Venture"> Joint Venture</label>
        <br>
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Local"> Local</label>
        <br>
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Trading"> Trading</label>
        <br>
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Manufacture"> Manufacture</label>
        <br>
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Technical Corporation"> Technical Corporation</label>
        <br>
        <label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="PMA"> PMA</label>
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Main Product</label>
      <div class="col-lg-9">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_COMPANY_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
        <input type="text" class="form-control" name="MAIN_PRODUCT" value="<?php echo $data->MAIN_PRODUCT;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Number of Employees</label>
      <div class="col-lg-9">
      <div class="input-group">
        <input type="text" class="form-control" name="NUMBER_OF_EMPLOYEE" aria-describedby="basic-addon2" value="<?php echo $data->NUMBER_OF_EMPLOYEE;?>">
         <span class="input-group-addon" id="basic-addon2">Employee</span>
      </div>
      </div>
      
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Working Shift</label>
      <div class="col-lg-9">
      <div class="input-group">
        <input type="text" class="form-control" name="WORKING_SHIFT" aria-describedby="basic-addon2" value="<?php echo $data->WORKING_SHIFT;?>">
         <span class="input-group-addon" id="basic-addon2">Shift</span>
      </div>
      </div>
      
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>			      	
  </form>	        	    			      		        
</div>