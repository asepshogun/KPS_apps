<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Attachment Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/request_quotation/updateDetail/kps_rfq_attachment/KPS_RFQ_ATTACHMENT_ID";?>" method="POST" enctype="multipart/form-data" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Attachment Type</label>
      <div class="col-lg-9">
        <select name="TYPE" class="form-control ">
          <option value="0">-- Select Part--</option>
          <option value="RFQ Letters">RFQ Letters</option>
          <option value="Drawing">Drawing</option>
          <option value="Others">Others</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Attachment Title</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="TITLE" value="<?php echo $data->TITLE;?>">

         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_ATTACHMENT_ID;?>">
        <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $data->KPS_RFQ_ID;?>">

        
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Attachment</label>
      <div class="col-lg-9">                    
        <input type="file" class="form-control" name="FILENAME" value="<?php echo $data->FILENAME;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>