<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/schedule/deleteDetail/kps_delivery_schedule_detail/KPS_DELIVERY_SCHEDULE_DETAIL_ID/". $idOsdet;?>" method="POST" class="form-horizontal">
    <div class="form-group">
            <label class="col-lg-3 control-label">Code Product</label>
            <div class="col-lg-9">
              <select name="KPS_BUKTI_PESANAN_DETAIL_ID_SD" class="form-control select2" style="width:100%" disabled>
            <option value="0">-- Select Code Product --</option>
			<option value="<?php echo $data->KPS_BUKTI_PESANAN_DETAIL_ID_SD; ?>" selected>
			   <?php echo $data->LOI_CODE_ITEM." - ".$data->LOI_MODEL." - ".$data->LOI_PART_NO." - ".$data->LOI_PART_NAME;?>
			</option>
            <?php foreach ($code as $value) { ?>
             <option value="<?php echo $value->KPS_BUKTI_PESANAN_DETAIL_ID;?>" <?php if($value->KPS_BUKTI_PESANAN_DETAIL_ID==$data->KPS_BUKTI_PESANAN_DETAIL_ID_SD){ echo "selected=''";} ?>>
              <?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO." - ".$value->LOI_PART_NAME;?>
            </option>
              <?php } ?>
          </select>
            </div>
          </div>
     <div class="form-group">
            <label class="col-lg-3 control-label">Custom Delivery</label>
            <div class="col-lg-9">
              <select name="KPS_CUSTOMER_DELIVERY_SETUP_ID" class="form-control select2" style="width:100%" disabled>
            <option value="0">-- Select Customer Delivery --</option>
            <?php foreach ($deliv as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP;?>" <?php
            if($value->KPS_CUSTOMER_DELIVERY_SETUP==$data->KPS_CUSTOMER_DELIVERY_SETUP_ID){
              echo "selected=''";
            }
            ?>><?php echo $value->PLANT1_CITY;?></option>
              <?php } ?>  
          </select>
            </div>
          </div>
  
    <div class="form-group">
      <label class="col-lg-3 control-label">Delivery Date</label>
      <div class="col-lg-9">
        <input type="text" class="form-control datepicker" name="DELIVERY_PLAN" value="<?php echo $data->DELIVERY_PLAN;?>" readonly="readonly">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Delivery Quantity</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QUANTITY_DELIVERY" value="<?php echo $data->QUANTITY_DELIVERY;?>" readonly>
          <input type="hidden" class="form-control" name="KPS_DELIVERY_SCHEDULE_DETAIL_ID" value="<?php echo $data->KPS_DELIVERY_SCHEDULE_DETAIL_ID;?>">
			<input type="hidden" class="form-control" name="KPS_DELIVERY_SCHEDULE_ID" value="<?php echo $data->KPS_DELIVERY_SCHEDULE_ID;?>">
			<input type="hidden" class="form-control" name="KPS_BUKTI_PESANAN_DETAIL_ID_SD" value="<?php echo $data->KPS_BUKTI_PESANAN_DETAIL_ID_SD;?>">
   
    
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NOTE" value="<?php echo $data->NOTE_DS_DET;?>" disabled>
      </div>
    </div> 
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">YES</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>