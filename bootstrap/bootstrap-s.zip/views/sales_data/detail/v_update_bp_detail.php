<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Update Bukti Pesanan Detail</h4>
</div>
<div class="modal-body">
	<h4>Update Quantity hanya bisa ditambah</h4>
	<form action="<?php echo site_url()."/Pesanan/updateDetailBp";?>" method="POST" class="form-horizontal">
			<div class="form-group">
			  <label class="col-lg-3 control-label">Code Item</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="LOI_CODE_ITEM" id="LOI_CODE_ITEM" placeholder="Note" value="<?php echo $data->LOI_CODE_ITEM; ?>" disabled>
				<input type="hidden" class="form-control" name="KPS_BUKTI_PESANAN_DETAIL_ID" id="KPS_BUKTI_PESANAN_DETAIL_ID"  value="<?php echo $data->KPS_BUKTI_PESANAN_DETAIL_ID; ?>" >
				<input type="hidden" class="form-control" name="KPS_BUKTI_PESANAN_ID" id="KPS_BUKTI_PESANAN_ID"  value="<?php echo $data->KPS_BUKTI_PESANAN_ID; ?>" >
				<input type="hidden" class="form-control" name="MADE_BY_BP" value="<?php echo $this->session->userdata('employeeId'); ?>">
			 </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">Part Name</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="LOI_PART_NAME" id="LOI_PART_NAME" placeholder="Note" value="<?php echo $data->LOI_PART_NAME; ?>" disabled>
			  </div>
			</div>
			<div class="form-group">
			  <label class="col-lg-3 control-label">Part No</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="LOI_PART_NO" id="LOI_PART_NO" placeholder="Note" value="<?php echo $data->LOI_PART_NO; ?>" disabled>
			  </div>
			 </div>
			 <div class="form-group">
			  <label class="col-lg-3 control-label">QTY</label>
			  <div class="col-lg-9">
				<input type="number" class="form-control" name="QUANTITY" id="QUANTITY" min="<?php echo $data->QUANTITY; ?>" placeholder="QUANTITY" value="<?php echo $data->QUANTITY; ?>" required>
				<input type="hidden" class="form-control" name="QUANTITY_old" id="QUANTITY_old"  placeholder="QUANTITY_old" value="<?php echo $data->QUANTITY; ?>">
			  </div>
			 </div>  
			 <div class="form-group">
			  <label class="col-lg-3 control-label">Kanban PO Number</label>
			  <div class="col-lg-9">
				<input type="number" class="form-control" name="KANBAN_PO_NO" id="KANBAN_PO_NO" placeholder="KANBAN_PO_NO" value="<?php echo $data->KANBAN_PO_NO; ?>">
			  </div>
			 </div> 
			<div class="form-group">		          
				<div class="col-sm-12">
					<input type="submit" class="btn btn-danger btn-flat pull-right" value="YES" />
				</div>
			</div>
	</form>
</div>	
