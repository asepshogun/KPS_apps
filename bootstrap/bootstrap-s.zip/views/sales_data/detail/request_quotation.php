<section class="content-header">
	<h3>Request for Quotation Detail</h3>
	<small>Detail Permintaan untuk Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">

			        <div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $datas->COMPANY_NAME ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Receiving RFQ Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="RECEIVING_RFQ_DATE" disabled value="<?php echo $datas->RECEIVING_RFQ_DATE ?>"> 
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">RFQ CUstomer Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="RFQ_CUSTOMER_DATE" disabled value="<?php echo $datas->RFQ_CUSTOMER_DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Due Date Quotation</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DUE_DATE_QUOTATION" disabled value="<?php echo $datas->DUE_DATE_QUOTATION ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Estimation LOI DATE</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="ESTIMATION_LOI_DATE" disabled value="<?php echo $datas->ESTIMATION_LOI_DATE ?>">
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#cp">DRAWING</a></li>
			  <li><a data-toggle="tab" href="#plant">PRODUCTION PLAN</a></li>
			  <li><a data-toggle="tab" href="#divisi">SCHEDULE</a></li>
			  <li><a data-toggle="tab" href="#pic">TARGET PRICE</a></li>
			  <li><a data-toggle="tab" href="#mc">CURRENCY</a></li>
			  <li><a data-toggle="tab" href="#supplier">ATTACHMENT</a></li>
			</ul>
			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">
				<?php 
				$data['id'] = $datas->KPS_RFQ_ID;
				$data['drawing'] = $drawing;
				$this->load->view('sales_data/detail/request_quotation_drawing',$data);?>			
			  </div>
			  <div id="plant" class="tab-pane fade">
			    <?php 
				$data['pp'] = $pp;
				$this->load->view('sales_data/detail/request_quotation_pp',$data);?>	
			  </div>
			  <div id="divisi" class="tab-pane fade">
			    <?php 
				$data['schedule'] = $schedule;
				$this->load->view('sales_data/detail/request_quotation_schedule',$data);?>	
			  </div>
			  <div id="pic" class="tab-pane fade">
			    <?php 
				$data['price'] = $price;
				$this->load->view('sales_data/detail/request_quotation_tp',$data);?>	
			  </div>
			  <div id="mc" class="tab-pane fade">
			    <?php 
				$data['curr'] = $curr;
				$this->load->view('sales_data/detail/request_quotation_currency',$data);?>	
			  </div>
			  <div id="supplier" class="tab-pane fade">
			    <?php 
				$data['attach'] = $attach;
				$this->load->view('sales_data/detail/request_quotation_attachment',$data);?>	
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>