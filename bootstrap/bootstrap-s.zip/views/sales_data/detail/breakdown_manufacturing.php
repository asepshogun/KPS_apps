<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Manufacturing</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
				<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/breakdown_cost/addSub/kps_breakdown_cost_manufacturing">
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Processing</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="PROCCESING" placeholder="Proccesing">
				          </div>
				        </div>
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Machine</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="MACHINE" placeholder="machine">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Time</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="TIME" placeholder="time">
				            <input type="hidden" class="form-control" name="KPS_BREAKDOWN_COST_ID" value="<?php echo $KPS_BREAKDOWN_COST_ID; ?>"/>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Charge</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="CHARGE" placeholder="charge">
				          </div>
				        </div>
				       
				        <div class="col-lg-6" align="center">
				        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Manufacturing</button>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="reset" class="btn btn-danger btn-flat pull-left">Refresh Manufacturing</button>
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="breakdown_manufacturing" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Processing</th>
	        <th>Machine</th>
	        <th>Time</th>
	        <th>Charge</th>
	        <th>Amount</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($manu as $value) {$no++ ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->PROCCESING;?></td>
		        <td><?php echo $value->MACHINE;?></td>
		        <td><?php echo $value->TIME;?></td>
		        <td><?php echo $value->CHARGE;?></td>      
		        <td><?php echo $value->AMOUNT;?></td> 
		         <td><a href="" url="<?php echo site_url()."/breakdown_cost/editDetail/".$value->KPS_BREAKDOWN_COST_MANUFACTURING_ID."/edit_breakdown_manufacturing/kps_breakdown_cost_manufacturing/KPS_BREAKDOWN_COST_MANUFACTURING_ID";?>" data-toggle="modal" data-target="#updatem" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatem" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->