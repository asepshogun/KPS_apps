<section class="content-header">
	<h3>Outgoing Finished Good Data Detail</h3>
	<small>Detail Data Outgoing Finished Good</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Bukti Pesanan</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO_BP" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_VEHICLE_ID" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Driver</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="employee_driver_id" disabled>
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Checked By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Execution</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_DELIVERY_EXECUTION" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#ofgd">OUTGOING FINISHED GOOD DETAIL</a></li>
			</ul>

			<div class="tab-content">
			  <div id="ofgd" class="tab-pane fade in active">
				<?php $this->load->view('sales_data/detail/outgoing_finished_ofgd');?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>