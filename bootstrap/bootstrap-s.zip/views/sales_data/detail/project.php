<section class="content-header">
	<h3>Failed Project Detail</h3>
	<small>Detail Proyek Gagal</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Failed Project Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_FAILED" value="<?php echo $data->NO_FAILED ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Failed Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_FAILED" value="<?php echo $data->DATE_FAILED ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">RFQ Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" value="<?php echo $data->NO_RFQ ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->COMPANY_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Approved By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="EMPLOYEE_NAME" value="<?php echo $data->EMPLOYEE_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Failed Project Note</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NOTE" value="<?php echo $data->NOTE_FAILED ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#fpa">FAILED PROJECT ATTACHMENT</a></li>
			</ul>

			<div class="tab-content">
			  <div id="fpa" class="tab-pane fade in active">
				<?php 
				$datas['attach']=$attach;
				$datas['idfailed']=$data->KPS_FAILED_PROJECT_ID;
				$this->load->view('sales_data/detail/project_fpa',$datas);?>			
			  	
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>