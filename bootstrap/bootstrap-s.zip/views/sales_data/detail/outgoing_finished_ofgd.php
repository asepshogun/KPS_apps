<!--TABLE-->
<div class="box-body">
	<table id="outgoing_finished_ofgd" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Product</th>
	        <th>Part No</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>QTY Delivery Execution</th>
	        <th>QTY Pending Execution</th>
	        <th>QTY Return Pending </th>
	        <th>Note</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td> 
		        <td><?php echo $value->LOI_MODEL;?></td>
		        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
		        <td><?php echo $value->QTY_PENDING_OFGD;?></td>
		        <td><?php echo $value->QTY_RETURN_PENDING_OFGD;?></td>
		        <td><?php echo $value->NOTE_OFGD;?></td>
		        <td><a href="" url="<?php echo site_url()."/outgoing_finished/editDetail/".$value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>/edit_outgoing_finished_ofgd/kps_outgoing_finished_good_detail/KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
		<button type="button" data-toggle="modal" data-target="#add" class="btn bg-olive btn-flat pull-right">Add Outgoing Finished Good Detail</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Outgoing Finished Good Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_finished/addSub/kps_outgoing_finished_good_detail";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Schedule Product & Part</label>
			      <div class="col-lg-9">
			        <select name="KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD" url="<?php echo site_url() ?>/Outgoing_Finished/loadPo" urlPending="<?php echo site_url() ?>/outgoing_finished/loadQtyPending"id="delProd" class="form-control select2" style="width: 100%">
						<option value="0">-- Select Code Product --</option>
						<?php foreach ($schedule as $value) { ?>
					    <option value="<?php echo $value->KPS_DELIVERY_SCHEDULE_DETAIL_ID; ?>"><?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO;?></option>
					    <?php } ?>	
					</select>
			      </div>
			    </div>
			    
			  	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">QTY Warehouse</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" readonly="readonly" id="outware" name="TOTAL_WAREHOUSE" placeholder="qty outstanding po">
			          	
			      </div>
			    </div>		
			     <div class="form-group">
			      <label class="col-lg-3 control-label">QTY PO</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" readonly="readonly" id="outPosss" name="TOTAL_PO" placeholder="qty outstanding po">
			          	
			      </div>
			    </div>		
			     <div class="form-group">
			      <label class="col-lg-3 control-label">QTY Delivery Schedule</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" readonly="readonly" id="outSch" name="TOTAL_DELIVERY_SHCEDULE" placeholder="qty outstanding po">
			          	
			      </div>
			    </div>		
			     <div class="form-group">
			      <label class="col-lg-3 control-label">QTY Delivery Pending</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" readonly="readonly" id="outPending" name="TOTAL_DELIVERY_PENDING" placeholder="qty outstanding po">
			          	
			      </div>
			    </div>		
			      <div class="form-group">
			      <label class="col-lg-3 control-label">QTY Outstanding PO</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" readonly="readonly" id="outPo" name="QTY_OUTSTANDING_PO_OS" placeholder="qty outstanding po">
			       
			        <input type="hidden" class="form-control" id="KPS_OUTGOING_FINISHED_GOOD_ID_D" name="KPS_OUTGOING_FINISHED_GOOD_ID_D" value="<?php echo $data->KPS_OUTGOING_FINISHED_GOOD_ID ?>" placeholder="qty outstanding po">
					<input type="hidden" class="form-control" id="StatusOSOUt" name="StatusOSOUt" value="notOS">

			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">QTY Delivery Execution</label>
			      <div class="col-lg-9">
			        <input type="number" class="form-control" name="QTY_DELIVERY_EXECUTION" placeholder="qty delivery execution">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Note</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="NOTE_OFGD" placeholder="note">
			      </div>
			    </div>        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->