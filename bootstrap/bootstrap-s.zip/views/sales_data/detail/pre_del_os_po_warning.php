<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<h4>Item ini tidak bisa dihapus karena sudah mempunyai data detail</h4><br/>
	<?php foreach($data as $value){?>
	<h6>Code Item : <?php echo $value->LOI_CODE_ITEM ;?></h6>
	<h6>Part Name : <?php echo $value->LOI_PART_NAME ;?></h6>
	<h6>Part No : <?php echo $value->LOI_PART_NAME ;?></h6>
	<h6>QTY : <?php echo $value->QUANTITY_DELIVERY ;?></h6><br/>
	<?php } ?>
</div>