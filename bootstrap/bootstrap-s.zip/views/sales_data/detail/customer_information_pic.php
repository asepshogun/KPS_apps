<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Person In Charge</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
					<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_is_person_in_charge">
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Department</label>
				          <div class="col-lg-9">
				            <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID_PIC" value="<?php echo $customerId; ?>" placeholder="main product">
				       
				            <select name="DEPARTMENT" class="form-control">
								<option value="Director">Director</option>
								<option value="Purchasing">Purchasing</option>
								<option value="Production">Production</option>
								<option value="Finance & Accounting">Finance & Accounting</option>
								<option value="Quality">Quality</option>
							</select>
				          </div>
				        </div>			  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">PIC Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="NAME" placeholder="pic name">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Position</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="POSITION" placeholder="position">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Mobile Phone</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="MOBILE_PHONE" placeholder="mobile phone">
				          </div>
				        </div>			  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Email Address</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="EMAIL" placeholder="email address">
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save PIC" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form PIC" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_pic" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Department</th>
	        <th>PIC Name</th>
	        <th>Position</th>
	        <th>Mobile Phone</th>
	        <th>Email</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($pic as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->DEPARTMENT;?></td>
		        <td><?php echo $value->NAME;?></td>
		        <td><?php echo $value->POSITION;?></td>
		        <td><?php echo $value->MOBILE_PHONE;?></td>		        
		        <td><?php echo $value->EMAIL;?></td>
		         <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID."/edit_customer_information_pic"."/kps_customer_is_person_in_charge/KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID";?>" data-toggle="modal" data-target="#updatepic" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatepic" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->