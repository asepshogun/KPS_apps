<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Item Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/item/updateDetail/kps_loi_detail/KPS_LOI_DETAIL_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Code Product</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="code_product" value="<?php echo $data->code_product;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Number</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="part_no" value="<?php echo $data->part_no;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="part_name" value="<?php echo $data->part_name;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="model" value="<?php echo $data->model;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Product Classification</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="product_classification" value="<?php echo $data->PRODUCT_CLASSIFICATION;?>">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="note" value="<?php echo $data->NOTE;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_LOI_DETAIL_ID;?>">
        <input type="hidden" class="form-control" name="KPS_LOI_ID" value="<?php echo $data->KPS_LOI_ID;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>