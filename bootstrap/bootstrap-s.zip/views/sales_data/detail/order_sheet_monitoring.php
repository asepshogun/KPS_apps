<section class="content-header">
	<h3>Order Sheet Data Detail</h3>
	<small>Detail Data Order Sheet</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_LOI" disabled value="<?php echo $data->KPS_OS_NO; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" disabled value="<?php echo $data->KPS_OS_CREATION_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Schedule Delivery</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DIE_GO_NO" disabled value="<?php echo $data->KPS_OS_SCHEDULE_DELIVERY_DATE ."/" .$data->KPS_OS_SCHEDULE_DELIVERY_TIME; ?>">
			          </div>
			        </div>
		      
			</div>
			<div class="col-lg-6">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Printed Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DISCONTINUE_DATE" disabled value="<?php echo $data->KPS_OS_PRINTED_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Kanban</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MIN_STOCK" disabled value="<?php echo $data->KPS_OS_TOTAL_KANBAN ;?>">
			          </div>
			        </div>	
					<div class="form-group">
			          <label class="col-sm-3 control-label">No OS From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_OS_DN_NO" disabled value="<?php echo $data->KPS_OS_DN_NO; ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date OS From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_OS_DN_DATE" disabled value="<?php echo $data->KPS_OS_DN_DATE; ?>">
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#osd">ORDER SHEET DETAILS</a></li>
			  <li><a data-toggle="tab" href="#osa">ORDER SHEET ATTACHMENT</a></li>
			</ul>
			
			<div class="tab-content">
				<!-- TAB KONTEN 1-->
				<div id="osd" class="tab-pane fade in active">
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>No Bukti Pesanan</th>
						        <th>No PO</th>
						        <th>Detail</th>
						      </tr>
						    </thead>
						    <tbody>
						    	<?php
						    	 $no=0; foreach ($detail as $value) { 
						    	$no++; 
						    	?>
							      <tr>
							        <td><?php echo $no;?></td>
							        <td><?php echo $value->REV_NO_BP;?></td>
							        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
							        <td><a href="<?php echo site_url() ?>/order_sheet/detailPoMonitoring/<?php echo $value->KPS_ORDER_SHEET_DETAIL_ID; ?>" data-toggle="modal">Detail</a></td>
								  </tr>
						      <?php } ?>
						    </tbody>
						</table>
					</div>
					<!--TABLE-->
							
				</div>
				<div id="osa" class="tab-pane fade">					
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_plant" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>					        
						        <th>Attachment Title</th>
						        <th>Attachment File</th>
						      </tr>
						    </thead>
						    <tbody>
						    	<?php $no=0; foreach ($attach as $value) { $no++; ?>
							      <tr>
							        <td><?php echo $no;?></td>
							        <td><?php echo $value->KPS_OS_ATTACHMENT_TITLE;?></td>
							        <td><?php echo $value->KPS_OS_ATTACHMENT_FILE;?></td> 
							      </tr>
						      <?php } ?>
						    </tbody>
						</table>
					</div>
					<!--TABLE-->
				</div>

			</div>
			
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>