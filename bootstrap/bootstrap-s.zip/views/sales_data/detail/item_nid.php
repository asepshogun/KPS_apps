<!--TABLE-->
<div class="box-body">
	<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Item</th>
	        <th>Part Number</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>Product Classification</th>
	        <th>Note</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->code_product;?></td>
		        <td><?php echo $value->part_no;?></td>
		        <td><?php echo $value->part_name;?></td>
		        <td><?php echo $value->model;?></td> 
		        <td><?php echo $value->PRODUCT_CLASSIFICATION;?></td>
		        <td><?php echo $value->NOTE;?></td> 
		        <td><a href="" url="<?php echo site_url()."/item/editDetail/".$value->KPS_LOI_DETAIL_ID."/edit_item_nid/kps_loi_detail/KPS_LOI_DETAIL_ID"; ?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>

		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12">
		<button type="button" data-toggle="modal" data-target="#add" class="btn bg-olive btn-flat pull-right">Add LOI Detail</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Item (LOI)</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/item/addSub/kps_loi_detail";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Code Product</label>
			      <div class="col-lg-9">
			        <input type="hidden" class="form-control" name="KPS_LOI_ID" value="<?php echo $LOI_ID ?>" placeholder="quantity netto">
			        <input type="text" class="form-control" name="code_product" placeholder="quantity netto">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Part Number</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="part_no" value="<?php echo $partno; ?>" placeholder="quantity netto">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Part Name</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="part_name" value="<?php echo $partname; ?>" placeholder="quantity brutto">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Model</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="model" value="<?php echo $model; ?>" placeholder="material price">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Product Classification</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="product_classification" placeholder="Country">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Note</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="note" placeholder="Country">
			      </div>
			    </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->