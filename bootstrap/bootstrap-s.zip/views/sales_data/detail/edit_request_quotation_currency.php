<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Currency Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/request_quotation/updateDetail/kps_rfq_currency/KPS_RFQ_CURENCY_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Currency Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="CURRENCY_NAME" value="<?php echo $data->CURRENCY_NAME;?>">
      </div>
    </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">To IDR</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="TO_IDR" value="<?php echo $data->TO_IDR;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_CURENCY_ID;?>">
        <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $data->KPS_RFQ_ID;?>">

    </div>
  </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>