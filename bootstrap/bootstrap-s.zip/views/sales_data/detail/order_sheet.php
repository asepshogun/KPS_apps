<section class="content-header">
	<h3>Order Sheet Data Detail</h3>
	<small>Detail Data Order Sheet</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_LOI" disabled value="<?php echo $data->KPS_OS_NO; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" disabled value="<?php echo $data->KPS_OS_CREATION_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Schedule Delivery</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DIE_GO_NO" disabled value="<?php echo $data->KPS_OS_SCHEDULE_DELIVERY_DATE ."/" .$data->KPS_OS_SCHEDULE_DELIVERY_TIME; ?>">
			          </div>
			        </div>
		      
			</div>
			<div class="col-lg-6">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Printed Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DISCONTINUE_DATE" disabled value="<?php echo $data->KPS_OS_PRINTED_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Kanban</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MIN_STOCK" disabled value="<?php echo $data->KPS_OS_TOTAL_KANBAN ;?>">
			          </div>
			        </div>	
					<div class="form-group">
			          <label class="col-sm-3 control-label">No OS From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_OS_DN_NO" disabled value="<?php echo $data->KPS_OS_DN_NO; ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date OS From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_OS_DN_DATE" disabled value="<?php echo $data->KPS_OS_DN_DATE; ?>">
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#osd">ORDER SHEET DETAILS</a></li>
			  <li><a data-toggle="tab" href="#osa">ORDER SHEET ATTACHMENT</a></li>
			</ul>
			
			<div class="tab-content">
				<!-- TAB KONTEN 1-->
				<div id="osd" class="tab-pane fade in active">
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>No Bukti Pesanan</th>
						        <th>No PO</th>
						        <th>Detail</th>
						        <th>Delete</th>
						      </tr>
						    </thead>
						    <tbody>
						    	<?php
						    	 $no=0; foreach ($detail as $value) { 
						    	$no++; 
						    	?>
							      <tr>
							        <td><?php echo $no;?></td>
							        <td><?php echo $value->REV_NO_BP;?></td>
							        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
							        <td><a href="<?php echo site_url() ?>/order_sheet/detailPo/<?php echo $value->KPS_ORDER_SHEET_DETAIL_ID; ?>" data-toggle="modal">Detail</a></td>
							      	<td><a href="" url="<?php echo site_url()."/order_sheet/preDelDetailPo/". $value->KPS_ORDER_SHEET_DETAIL_ID;?>" data-toggle="modal" data-target="#delete" class="update-link">Delete</a></td>
								  </tr>
						      <?php } ?>
						    </tbody>
						</table>
						<div class="col-lg-12">
							<button type="button" class="btn bg-olive btn-flat pull-right" data-toggle="modal" data-target="#add">Add Order Sheet Detail</button>
						</div>
					</div>
					<!--TABLE-->
					<!-- Modal ADD-->
					<div class="modal fade" id="add" role="dialog">
						<div class="modal-dialog">

						  <div class="modal-content">
						    <div class="modal-header">
						      <button type="button" class="close" data-dismiss="modal">&times;</button>
						      <h4 class="modal-title">Form New Order Sheet Detail</h4>
						    </div>
						    <div class="modal-body">
						    	<form action="<?php echo site_url()."/order_sheet/addSub/kps_order_sheet_detail";?>" method="POST" class="form-horizontal">	    	
						    	<label>Bukti Pesanan</label>	
						    		<select name="KPS_BUKTI_PESANAN_ID_OS" class="form-control select2" style="width: 100%">
										<option value="0">-- Select Bukti Pesanan --</option>
										<?php foreach ($bukti as $value) { ?>
									    <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>"><?php echo $value->PO_OS_NO_FROM_CUSTOMER." - ".$value->REV_NO_BP; ?></option>
									    <?php } ?>	
									</select>	        
									<input type="hidden" class="form-control" name="KPS_OS_ID" value="<?php echo $data->KPS_OS_ID; ?>">

							        <div class="form-group">		          
							          <div class="col-sm-12">
							            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
							          </div>
							        </div>			      	
						        </form>	        	    			      		        
						    </div>
						  </div>
						  
						</div>
					</div>
					<!-- Modal ADD -->					
				</div>
				<div id="osa" class="tab-pane fade">					
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_plant" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>					        
						        <th>Attachment Title</th>
						        <th>Attachment File</th>
						        <th>Update</th>	
						      </tr>
						    </thead>
						    <tbody>
						    	<?php $no=0; foreach ($attach as $value) { $no++; ?>
							      <tr>
							        <td><?php echo $no;?></td>
							        <td><?php echo $value->KPS_OS_ATTACHMENT_TITLE;?></td>
							        <td><?php echo $value->KPS_OS_ATTACHMENT_FILE;?></td> 
							        <td><a href="" url="<?php echo site_url()."/order_sheet/edit/".$value->KPS_OS_ATTACHMENT_ID;?>" data-toggle="modal" data-target="#updateAttachment" class="update-link">Update</a></td>
							      </tr>
						      <?php } ?>
						    </tbody>
						</table>
						<div class="col-lg-12">
							<button type="button" class="btn bg-olive btn-flat pull-right" data-toggle="modal" data-target="#addAttachment">Add Order Sheet Attachment</button>
						</div>
					</div>
					<!--TABLE-->
					<!-- Modal ADD-->
					<div class="modal fade" id="addAttachment" role="dialog">
						<div class="modal-dialog">

						  <div class="modal-content">
						    <div class="modal-header">
						      <button type="button" class="close" data-dismiss="modal">&times;</button>
						      <h4 class="modal-title">Form New Order Sheet Attachment</h4>
						    </div>
						    <div class="modal-body">
						    	<form action="<?php echo site_url()."/order_sheet/addSub/kps_order_sheet_attachment";?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
								    <div class="form-group">
								      <label class="col-lg-3 control-label">Attachment Title</label>
								      <div class="col-lg-9">
								        <input type="text" class="form-control" name="KPS_OS_ATTACHMENT_TITLE" placeholder="quantity netto">

									<input type="" class="form-control" name="KPS_OS_ID" value="<?php echo $data->KPS_OS_ID; ?>">

								      </div>
								    </div>	
								    <div class="form-group">
							          <label class="col-lg-3 control-label">Attachment</label>
							          <div class="col-lg-9">				            
							            <input type="file" class="form-control" name="FILENAME">
							          </div>
							        </div>	        
							        <div class="form-group">		          
							          <div class="col-sm-12">
							            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
							          </div>
							        </div>			      	
						        </form>	        	    			      		        
						    </div>
						  </div>
						  
						</div>
					</div>
					<!-- Modal ADD -->
				</div>

			</div>
			
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal">&times;</button>
		  <h4 class="modal-title">Order Sheet Data</h4>
		</div>
		<div class="modal-body">
	<form action="<?php echo site_url()."/order_sheet/updateDetail/kps_order_sheet_detail/KPS_ORDER_SHEET_DETAIL_ID";?>" method="POST" class="form-horizontal">
		   <select name="KPS_BUKTI_PESANAN_ID_OS" class="form-control select2" style="width: 100%">
										<option value="0">-- Select Bukti Pesanan --</option>
										<?php foreach ($code as $value) { ?>
									    <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>" ><?php echo "PO NUMBER : ".$value->PO_OS_NO_FROM_CUSTOMER." | Code Product : ". $value->code_product." | Model. ".$value->model." | Part No. ".$value->part_no." | Part Name: ".$value->part_name." | Unit : ".$value->unit." | Quantity : ".$value->QUANTITY; ?></option>
									    <?php } ?>	
									</select>	        
									<input type="hidden" class="form-control" name="KPS_OS_ID_DETAIL" value="<?php echo $data->KPS_OS_ID; ?>">

							        <div class="form-group">		          
							          <div class="col-sm-12">
							            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
							          </div>
							        </div>			         	
		  </form>	        	    			      		        
		</div>
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->

<!-- Modal UPDATE ATTACHMENT-->
<div class="modal fade" id="updateAttachment" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	  	<div class="modal-header">
		  <button type="button" class="close" data-dismiss="modal">&times;</button>
		  <h4 class="modal-title">Order Sheet Attachment</h4>
		</div>
		<div class="modal-body">
	<form action="<?php echo site_url()."/quotation/updateDetail/order_sheet/KPS_ORDER_SHEET_DETAIL_ID";?>" method="POST" class="form-horizontal">
			  <div class="form-group">
			    <label class="col-lg-3 control-label">Attachment Title</label>
			    <div class="col-lg-9">
			      <input type="text" class="form-control" name="TITLE"  value="<?php echo $data->TITLE;?>">
			    </div>
			  </div>  
			  <div class="form-group">
			      <label class="col-lg-3 control-label">Attachment</label>
			      <div class="col-lg-9">                    
			        <input type="file" class="form-control" name="FILENAME" value="<?php echo $data->FILENAME;?>">
			      </div>
			    </div> 
			    <div class="form-group">              
			      <div class="col-sm-12">
			        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
			      </div>
			    </div>         			      	
			  </form>	        	    			      		        
		</div>					    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE ATTACHMENT-->
<!-- Modal UPDATE-->
<div class="modal fade" id="delete" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->