<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Setup</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_delivery_setup/KPS_CUSTOMER_DELIVERY_SETUP";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Plant Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="PLANT1_CITY" value="<?php echo $data->PLANT1_CITY;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_DELIVERY_SETUP;?>">
          <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Plant Location</label>
      <div class="col-lg-9">
        <select name="PLANT1_LOCAL_JABOTABEK" class="form-control">
          <option value="Local">Local</option>
          <option value="Jabotabek">Jabotabek</option>
        </select>
      </div>
    </div> 
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>