<section class="content-header">
	<h3>Invoice Get Number</h3>
	<small>invoice Get Number</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">
			<?php //print_r($data); ?>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Invoice Induk Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INVOICE_INDUK_NO" disabled value="<?php echo $data->INVOICE_INDUK_NO; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Invoice Induk Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INVOICE_INDUK_DATE" disabled value="<?php echo $data->INVOICE_INDUK_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $data->COMPANY_NAME; ?>">
			          </div>
			        </div> 
					<div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY" disabled value="<?php echo "Belum ada decision"//$data->CURRENCY; ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Adress</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PLANT" disabled value="<?php echo $data->PLANT; ?>">
			          </div>
			        </div>	
					<div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PLANT" disabled value="<?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->KPS_INVOICE_INDUK_MADE_BY	."'");
			        	$datae = mysql_fetch_array($query);
			        	echo $datae['EMPLOYEE_NAME'];
						?>">
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-12">
				<button type="button" class="btn bg-olive btn-flat pull-right">Generate Excel</button>
			</div>

		</div>
	</div>

	<div class="box-body">
		
		
        <?php if($this->session->flashdata('errorDP')) { ?>
		      <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-ban"></i> Alert!</h4><h4><center>
		      <?php echo $this->session->flashdata('errorDP'); ?> 
		      </center></h4></div>
		<?php } ?>
                  
			<div class="tab-content">
			  <div id="id" class="tab-pane fade in active">
				<?php 
				$datas['INVOICE_INDUK_ID'] = $data->INVOICE_INDUK_ID;
				$datas['detail'] = $detail;
				$datas['data'] = $data;
				$this->load->view('sales_data/v_invoice',$datas);?>			
			  </div>
			</div>
	</div>

	<div class="box-body">
		
	</div>
</div>