<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Finance Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_finance/KPS_CUSTOMER_FINANCE_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Total Assets</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="TOTAL_ASSETS" value="<?php echo $data->TOTAL_ASSETS;?>">
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">Annual Sales Last Year</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="ANNUAL_SALES_LAST_YEAR" value="<?php echo $data->ANNUAL_SALES_LAST_YEAR;?>">
          <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_FINANCE_ID;?>">
          <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">NPWP Number</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NO_NPWP" value="<?php echo $data->NO_NPWP;?>">
      </div>
    </div>  
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>