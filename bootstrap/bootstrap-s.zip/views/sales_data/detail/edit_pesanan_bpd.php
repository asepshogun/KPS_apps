<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Bukti Pesanan Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/pesanan/updateDetail/kps_bukti_pesanan_detail/KPS_BUKTI_PESANAN_DETAIL_ID";?>" method="POST" class="form-horizontal">
     <div class="form-group">
            <label class="col-lg-3 control-label">Code Product</label>
           <div class="form-group">
            <label class="col-lg-3 control-label">Product</label>
            <div class="col-lg-9">
              <select name="KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_DO" class="form-control select2" style="width: 100%">
            <option value="0">-- Select Product --</option>
            <?php foreach ($code as $value) { ?>
              <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>"><?php echo "Code Product : ". $value->code_product." | Model. ".$value->model." | Part No. ".$value->part_no." | Part Name: ".$value->part_name." | Unit : ".$value->unit." | Quantity : ".$value->QUANTITY; ?></option>
              <?php } ?>  
          </select>
            </div>
          </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Part Number</label>
            <div class="col-lg-9">
              <select name="part_no" class="form-control select2" style="width: 100%">
              <option value="0">-- Select Part Number --</option>
              <?php foreach ($number as $value) { ?>
              <option value="<?php echo $value->part_no;?>" <?php
            if($value->part_no==$data->part_no){
              echo "selected=''";
            }
            ?>><?php echo $value->part_no;?></option>
              <?php } ?>  
          </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Part Name</label>
            <div class="col-lg-9">
              <select name="part_name" class="form-control select2" style="width: 100%">
              <option value="0">-- Select Part Name --</option>
              <?php foreach ($name as $value) { ?>
              <option value="<?php echo $value->part_name;?>" <?php
            if($value->part_name==$data->part_name){
              echo "selected=''";
            }
            ?>><?php echo $value->part_name;?></option>
              <?php } ?>  
          </select>
            </div>
          </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="model" value="<?php echo $data->model;?>">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Kanban PO Number</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KANBAN_PO_NO" value="<?php echo $data->KANBAN_PO_NO;?>">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QUANTITY" value="<?php echo $data->QUANTITY;?>">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Unit</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="unit" value="<?php echo $data->unit;?>">
            <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BUKTI_PESANAN_DETAIL_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BUKTI_PESANAN_ID;?>">
   
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Price</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="price" value="<?php echo $data->price;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>


<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>