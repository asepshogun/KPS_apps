<section class="content-header">
	<h3>Order Sheet Data PO Detail</h3>
	<small>Detail Data Order Sheet</small>
</section>
<!-- Main content -->
<section class="content"> 
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_LOI" disabled value="<?php echo $data[0]->KPS_OS_NO ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Order Sheet Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RFQ" disabled value="<?php echo $data[0]->KPS_OS_CREATION_DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Schedule Delivery</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DIE_GO_NO" disabled value="<?php echo $data[0]->KPS_OS_SCHEDULE_DELIVERY_DATE ."/" . $data[0]->KPS_OS_SCHEDULE_DELIVERY_TIME;?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Printed Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DISCONTINUE_DATE" disabled value="<?php echo $data[0]->KPS_OS_PRINTED_DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Kanban</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MIN_STOCK" disabled value="<?php echo $data[0]->KPS_OS_TOTAL_KANBAN ?>">
			          </div>
			        </div>	
			         <div class="form-group">
			          <label class="col-sm-3 control-label">No Bukti Pesanan</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="Bukti" disabled value="<?php echo $data[0]->PO_OS_NO_FROM_CUSTOMER ?> - <?php echo $data[0]->REV_NO_BP ?>">
			          </div>
			        </div>	

				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#osd">ORDER SHEET DETAILS</a></li>
			</ul>
			
			<div class="tab-content">
				<!-- TAB KONTEN 1-->
				<div id="osd" class="tab-pane fade in active">
					<!--TABLE-->
					<div class="box-body">
						<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>Code Product</th>
						        <th>Part No</th>
						        <th>Part Name</th>
						        <th>Model</th>
						        <th>Delivery Place</th>
						        <th>Delivery Date</th>
						        <th>Delivery Quantity</th>
						        <th>Quantity Remaining</th>
						        <th>NOTE</th>
						      </tr>
						    </thead>
							<?php //print_r($data[0]->KPS_ORDER_SHEET_DETAIL_ID);?>
						    <tbody>
						    	<?php $no=1; foreach ($detail as $value) { ?>
							      <tr>
							        <td><?php echo $no++;?></td>
							        <td><?php echo $value->LOI_CODE_ITEM;?></td>
							        <td><?php echo $value->LOI_PART_NO;?></td>
							        <td><?php echo $value->LOI_PART_NAME;?></td>
							        <td><?php echo $value->LOI_MODEL;?></td> 
							        <td><?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP_ID;?></td>
							        <td><?php echo $value->DELIVERY_PLAN;?></td> 
							        <td><?php echo $value->QUANTITY_DELIVERY;?></td>
							        <td><?php echo $value->REMAINING_QUANTITY;?></td>
							        <td><?php echo $value->NOTE_DS_DET;?></td>
							      </tr>
						      <?php } ?>
						    </tbody>
						</table>
						<div class="col-lg-12">
							<a class="btn bg-blue btn-flat pull-left" href="<?php echo site_url() ?>/order_sheet/detailMonitoring/<?php echo $data[0]->KPS_OS_ID; ?>" >Back</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>					
<!--TABLE-->
<!--modal-->