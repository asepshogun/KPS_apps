<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Drawing Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/request_quotation/updateDetail/kps_rfq_drawing/KPS_RFQ_DRAWING_ID";?>" method="POST" class="form-horizontal">
  <div class="form-group">
      <label class="col-lg-3 control-label">Revisi Drawing Accepted</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="REV_DRAWING" value="<?php echo $data->REV_DRAWING;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Revisi Number</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="REV_NO" value="<?php echo $data->REV_NO;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part No</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KPS_RFQ_PART_NO" value="<?php echo $data->KPS_RFQ_PART_NO;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KPS_RFQ_PART_NAME" value="<?php echo $data->KPS_RFQ_PART_NAME;?>">
          <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_DRAWING_ID;?>">
        <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $data->KPS_RFQ_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Quantity</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KPS_RFQ_PART_QTY" value="<?php echo $data->KPS_RFQ_PART_QTY;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Unit</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="KPS_RFQ_PART_UNIT" value="<?php echo $data->KPS_RFQ_PART_UNIT;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Obsolete Date</label>
      <div class="col-lg-9">
        <input type="date" class="form-control datepicker" name="OBSOLETE_DATE" value="<?php echo $data->OBSOLETE_DATE;?>">
      </div>
    </div>
     <div class="form-group">
      <label class="col-lg-3 control-label">Drawing Date</label>
      <div class="col-lg-9">
        <input type="date" class="form-control datepicker" name="DRAWING_DATE" value="<?php echo $data->DRAWING_DATE;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Drawing Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NOTE" value="<?php echo $data->NOTE;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>