<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Account</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	  <form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_finance_bank">
		
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Name Of The Bank</label>
				          <div class="col-lg-9">
				            <select class="form-control select2" style="width: 100%;" name="KPS_BANK_ID">					  
							    <option>-- Select Bank --</option>
							    <?php foreach ($databank as $value) { ?>
							    <option value="<?php echo $value->KPS_BANK_ID;?>"><?php echo $value->BANK_NAME;?></option>
							    <?php } ?>					  
							</select>
				          </div>
				        </div>			  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Branches</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="branches" placeholder="Branches" required>
				          	<input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="main product">
				       
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Account Number</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="ACCOUNT_NO" placeholder="Account Number" required>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Currency</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="CURRENCY" placeholder="Ex. USD" required>
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Finance" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Finance" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_account" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Name of The Bank</th>
	        <th>Branches</th>
	        <th>Accunt No Number</th>
	        <th>Currency</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($account as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->BANK_NAME;?></td>
		        <td><?php echo $value->BRANCHES;?></td>
		        <td><?php echo $value->ACCOUNT_NO;?></td>	        
		        <td><?php echo $value->CURRENCY;?></td>
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_FINANCE_BANK_ID."/edit_customer_information_account"."/kps_customer_finance_bank/KPS_CUSTOMER_FINANCE_BANK_ID";?>" data-toggle="modal" data-target="#updateAcc" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateAcc" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->