	
<section class="content-header">
	<h3>Breakdown Cost Detail</h3>
	<small>Detail Perincian Harga</small>
</section>
<?php //var_dump($data);?>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">RFQ Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="RFQ_NO" disabled value="<?php echo $data->NO_RFQ ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Material</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_MATERIAL" disabled value="<?php echo $data->TOTAL_MATERIAL ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Part Cost</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_PART_COST" disabled value="<?php echo $data->TOTAL_PART_COST ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Depreciation</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_DEPRECIATION" disabled value="<?php echo $data->TOTAL_DEPRECIATION ?>"> 
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Tooling Cost</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOOLING_COST" disabled value="<?php echo $data->TOOLING_COST ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Tools</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_TOOLING" disabled value="<?php echo $data->TOTAL_TOOLING ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Manufacturing</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_MANUFACTURING" disabled value="<?php echo $data->TOTAL_MANUFACTURING ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Breakdown</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="total_breakdown" disabled value="<?php echo $data->total_breakdown ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-12" align="center">
	        	<a href="<?php echo site_url(); ?>/breakdown_cost/countBreakdownCost/<?php echo $data->KPS_BREAKDOWN_COST_ID ?>">
	        	<button type="button" class="btn bg-olive btn-flat">Count Breakdown Cost</button>
	        	</a>
	        </div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#cp">QTY FOR DEPRECIATION</a></li>
			  <li><a data-toggle="tab" href="#plant">MANUFACTURING COST</a></li>
			  <li><a data-toggle="tab" href="#divisi">MATERIAL COST</a></li>
			  <li><a data-toggle="tab" href="#pic">PURCHASED PART COST</a></li>
			  <li><a data-toggle="tab" href="#mc">TOOLING COST</a></li>
			</ul>

			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">
				<?php 
				$datas['KPS_BREAKDOWN_COST_ID'] = $data->KPS_BREAKDOWN_COST_ID;
				$datas['dep'] = $dep;
				$datas['tool'] = $tool;
				$datas['part'] = $part;
				$datas['material'] = $material;
				$datas['manu'] = $manu;
				$datas['product'] = $product;
				$datas['pp'] = $pp;
				$datas['partpart'] = $partpart;
				$this->load->view('sales_data/detail/breakdown_depreciation',$datas);?>			
			  </div>
			  <div id="plant" class="tab-pane fade">
			    <?php $this->load->view('sales_data/detail/breakdown_manufacturing',$datas);?>	
			  </div>
			  <div id="divisi" class="tab-pane fade">
			    <?php $this->load->view('sales_data/detail/breakdown_material',$datas);?>	
			  </div>
			  <div id="pic" class="tab-pane fade">
			    <?php $this->load->view('sales_data/detail/breakdown_part',$datas);?>	
			  </div>
			  <div id="mc" class="tab-pane fade">
			    <?php $this->load->view('sales_data/detail/breakdown_tooling',$datas);?>	
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>