<!--TABLE-->
<div class="box-body">
	<table id="quotation_qd" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Breakdown Cost</th>
	        <th>Part Number</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>Price</th>
	        <th>Unit</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php 
	    	$no=1; foreach ($data as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->NO_BREAK;?></td>
		        <td><?php echo $value->part_no;?></td>
		        <td><?php echo $value->part_name;?></td>
		        <td><?php echo $value->model;?></td> 
		        <td><?php echo $value->price;?></td>
		        <td><?php echo $value->unit;?></td> 
		        <td><a href="" url="<?php echo site_url()."/quotation/editDetail/".$value->KPS_QUOTATION_DETAIL_ID."/edit_quotation_qd/kps_quotation_detail/KPS_QUOTATION_DETAIL_ID"; ?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
		<button type="button" data-target="#add" data-toggle="modal" class="btn bg-olive btn-flat pull-right">Add Quotation Detail</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Quotation Detail data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/quotation/addSub/kps_quotation_detail";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Breakdown Cost</label>
		          <div class="col-sm-9">
		            <select name="breakdown_cost_id" style="width: 100%;" class="form-control select2" url="<?php echo site_url(); ?>/quotation/loadProd" id="modelQuo">
			          <option value="0">-- Select Breakdown Cost--</option>
			          <?php foreach ($bc as $value) { ?>
					    <option value="<?php echo $value->KPS_BREAKDOWN_COST_ID;?>"><?php echo $value->NO_BREAK;?> - <?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>		
			          
			        </select>
		          </div>
		        </div>
		        <div class="form-group">
			      <label class="col-lg-3 control-label">Part Number</label>
			      <div class="col-lg-9">
			        <input type="hidden" class="form-control" name="KPS_QUOTATION_ID" value="<?php echo $KPS_QUOTATION_ID ?>" placeholder="quantity netto">
			        <input type="text" class="form-control" id="part_no" value="0" readonly="readonly" name="part_no" placeholder="Part No">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Part Name</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" id="part_name" readonly="readonly" value="0" name="part_name" placeholder="quantity brutto">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Model</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" id="model" readonly="readonly" value="0" name="model" placeholder="material price">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Price</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" id="price" value="0" name="price" placeholder="Price">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Unit</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" id="unit" readonly="readonly" value="0" name="unit" placeholder="Unit">
			      </div>
			    </div>	
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
