<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Delivery Setup</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_delivery_setup">
				            	 <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="main product">
			<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Plant Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="PLANT1_CITY" placeholder="plat name">
				       
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">			  						  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Plant Location</label>
				          <div class="col-lg-9">
				            <select name="PLANT1_LOCAL_JABOTABEK" class="form-control">
								<option value="Local">Local</option>
								<option value="Jabotabek">Jabotabek</option>
							</select>
				          </div>
				        </div>				        
			  		</div>
	     	         <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Delivery Setup" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Delivery Setup" />
				        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_ds" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Plant Name</th>
	        <th>Plant Location</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($deliv as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->PLANT1_CITY;?></td>
		        <td><?php echo $value->PLANT1_LOCAL_JABOTABEK;?></td>
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_DELIVERY_SETUP."/edit_customer_information_ds"."/kps_customer_delivery_setup/KPS_CUSTOMER_DELIVERY_SETUP";?>" data-toggle="modal" data-target="#updateds" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateds" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->