f<section class="content-header">
	<h3>Return Product Detail</h3>
	<small>Detail Retur Produk</small>
</section>

<!-- Main content -->
<section class="content">
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">

			        <div class="form-group">
			          <label class="col-sm-3 control-label">NO Outgoing</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RETUR" disabled value="<?php echo $datas->OUTGOING_RETUR_PRODUCT_NO ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date Outgoing</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_RTR" disabled value="<?php echo $datas->OUTGOING_RETUR_PRODUCT_DATE ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO_RTR" disabled value="<?php echo $datas->OUTGOING_RETUR_PRODUCT_NO_REV ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" disabled value="<?php echo $datas->COMPANY_NAME ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">No Retur</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_RETUR_CUSTOMER" disabled value="<?php echo $datas->NO_RETUR ?>">
			          </div>
					 </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_CUSTOMER_ID_RETUR" disabled value="<?php echo $datas->VEHICLE_NAME ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DUE_DATE_PPIC" disabled value="<?php echo $datas->VEHICLE_NO ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Driver</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DUE_DATE_CUSTOMER" disabled value="<?php echo $datas->employee_driver_id ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Assisten</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_DELIVERY_ORDER_ID_RETUR" disabled value="<?php echo $datas->OUTGOING_RETUR_ASISTEN_DRIVER ?>">
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>
	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#cp">Retur Product</a></li>
			</ul>
			<?php if($pesan){?>
			<div class="container">
				<div class="alert alert-danger">
				  <?php echo $pesan; ?> : Nilai Execution Lebih Besar Dari Nilai Remaining / Nilai Yang harus di kirim
				</div>
			</div> 
			<?php } ?>
			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">
				<?php 
				$data['id'] = $datas->KPS_RETUR_BARANG_ID;
				$data['id_out'] = $datas->OUTGOING_RETUR_PRODUCT_ID;
				$data['detail'] = $detail;
				$data['detail_out'] = $detail_out;
				$this->load->view('sales_data/detail/out_retur_detail',$data);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>