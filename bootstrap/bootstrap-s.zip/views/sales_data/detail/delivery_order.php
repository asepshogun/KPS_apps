<section class="content-header">
	<h3>Delivery Order Data Detail</h3>
	<small>Detail Data Surat jalan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Outgoing Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_OUTGOING_FINISHED_GOOD_ID_DO" value="<?php echo $data->NO_DO ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Delivery Order Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_DO" value="<?php echo $data->DATE_DO ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Employee Accepted</label>
			          <div class="col-sm-9">
			          	<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$data->employee_accepted_id."'")->first_row();
			      		?>
			      		<?php
			      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$data->employee_approved_id_DO."'")->first_row();
			      		?>
			      		<?php
			      		$q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$data->employee_known_id."'")->first_row();
			      		?>
			            <input type="text" class="form-control" name="employee_accepted_id" value="<?php echo $q1->EMPLOYEE_NAME ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Employee Approved</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="employee_approved_id" value="<?php echo $q2->EMPLOYEE_NAME ?>" disabled>
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Employee Known</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="employee_known_id" value="<?php echo $q3->EMPLOYEE_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Quantity</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_QTY" value="<?php echo $total; ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#dod">DELIVERY ORDER DETAIL</a></li>
			</ul>

			<div class="tab-content">
			  <div id="dod" class="tab-pane fade in active">
				<?php 
				$datas['KPS_DELIVERY_ORDER_ID'] = $data->KPS_DELIVERY_ORDER_ID;
				$datas['detail'] = $detail;
				$datas['outgoing'] = $outgoing;
				$datas['code'] = $code;

				$this->load->view('sales_data/detail/delivery_order_dod',$datas);
				?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>