<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Schedule</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_schedule">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Model</label>
				          <div class="col-lg-9">
				            <select name="MODEL" class="form-control select2" style="width:100%">
								<option value="0">-- Select Model --</option>
							 <?php foreach ($pp as $value) { ?>
						    <option value="<?php echo $value->MODEL; ?>"><?php echo $value->MODEL;?></option>
						    <?php } ?>		
							</select>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">PP1</label>
				          <div class="col-lg-9">
				          <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">

				            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="PP1" placeholder="Pick Date" >
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Sample Masspro</label>
				          <div class="col-lg-9">
				            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="SAMPLE_MASSPRO" placeholder="Pick Date" >
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Masspro</label>
				          <div class="col-lg-9">
				            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="MASSPRO" placeholder="Pick Date" >
				          </div>
				        </div>				        
			  		</div>
			        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Schedule" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Schedule" />
				        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="rfq_detail_schedule" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Model</th>
	        <th>PP1</th>
	        <th>Sample Masspro</th>
	        <th>Masspro</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($schedule as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->MODEL;?></td>
		        <td><?php echo $value->PP1;?></td>
		        <td><?php echo $value->SAMPLE_MASSPRO;?></td>
		        <td><?php echo $value->MASSPRO;?></td> 
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_RFQ_SCHEDULE_ID."/edit_request_quotation_schedule"."/kps_rfq_schedule/KPS_RFQ_SCHEDULE_ID";?>" data-toggle="modal" data-target="#updateattach" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateattach" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->