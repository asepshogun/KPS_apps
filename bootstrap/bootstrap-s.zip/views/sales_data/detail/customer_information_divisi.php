<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Customer Divisi</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_divisi">
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Divisi Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="DIVISI" placeholder="divisi name">
				          </div>
				        </div>			  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Phone Number</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="TELP" placeholder="phone number">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Fax Number</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="FAX" placeholder="fax number">
				            <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="main product">
				          </div>
				        </div>			  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Established</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="ESTABLISHED" placeholder="established number">
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Divisi" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Divisi" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_divisi" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Divisi Name</th>
	        <th>Phone Number</th>
	        <th>Fax Number</th>
	        <th>Established</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($divisi as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->DIVISI;?></td>
		        <td><?php echo $value->TELP;?></td>
		        <td><?php echo $value->FAX;?></td>
		        <td><?php echo $value->ESTABLISHED;?></td>		        
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_DIVISI_ID."/edit_customer_information_divisi"."/kps_customer_divisi/KPS_CUSTOMER_DIVISI_ID";?>" data-toggle="modal" data-target="#updatedivisi" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatedivisi" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->