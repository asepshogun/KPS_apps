<?php
	if(count($drawing)==0){

?>
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Drawing</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_drawing">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Revisi Drawing Accepted</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="REV_DRAWING" placeholder="No Drawing">
				          </div>
				        </div>
				       <div class="form-group">
				          <label class="col-lg-3 control-label">Part No</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="KPS_RFQ_PART_NO" placeholder="part no">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Part Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="KPS_RFQ_PART_NAME" placeholder="part name">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Part Quantity</label>
				          <div class="col-lg-9">
				            
				            <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">
				            <input type="text" class="form-control" name="KPS_RFQ_PART_QTY" placeholder="part quantity">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Part Unit</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="KPS_RFQ_PART_UNIT" placeholder="part unit">
				          </div>
				        </div>
				        
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Obsolete Date</label>
				          <div class="col-lg-9">
				            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DRAWING_DATE" placeholder="Pick Date">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Drawing Note</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="NOTE" placeholder="drawing note">
				          </div>
				        </div>				        
			  		</div>
			        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-left" value="Save Drawing" />
				        	<input type="reset" class="btn btn-danger btn-flat pull-right" value="Clear Form Drawing" />
				        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>
<?php
}
?>
<!--TABLE-->
<div class="box box-solid">
               
                <div class="box-body">
                  <div class="box-group" id="accordion">
                    <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                    <div class="panel box box-primary">
                      <div class="box-header with-border">
                        <h4 class="box-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                            Drawing Reference
                          </a>
                        </h4>
                      </div>
                      <div id="collapseOne" class="panel-collapse collapse in">
                        <div class="box-body">
						<table id="rfq_detail_drawing" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>Part Number</th>
						        <th>Part Name</th>
						        <th>Qty / Unit</th>
						        <th>Unit</th>
						        <th>Date Drawing</th>
						        <th>Drawing Number</th>
						        <th>Revisi Drawing Accepted</th>
						        <th>Revisi Number</th>
						        <th>Obselete Date</th>
						        <th>Drawing Note</th>
						        <th>Update</th>	
						      </tr>
						    </thead>
						    <tbody>
						    	<?php $no=1; foreach ($drawing as $value) { ?>
							      <tr>
							        <td><?php echo $no++;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>      
							        <td><?php echo $value->KPS_RFQ_PART_QTY;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
							        <td><?php echo $value->DRAWING_DATE;?></td>
							        <td><?php echo $value->DRAWING_NO;?></td>
							        <td><?php echo $value->REV_DRAWING;?></td>
							        <td><?php echo $value->REV_NO;?></td>
							        <td><?php echo $value->OBSOLETE_DATE;?></td>
							        <td><?php echo $value->NOTE;?></td>
							        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_RFQ_DRAWING_ID."/edit_request_quotation_drawing"."/kps_rfq_drawing/KPS_RFQ_DRAWING_ID";?>" data-toggle="modal" data-target="#updatedraw" class="update-link">Update</a></td>
							      </tr>
						      <?php } ?>
						    </tbody>
						</table>
					</div>
					<!--TABLE-->
                      </div>
                    </div>
                    <div class="panel box box-success">
                      <div class="box-header with-border">
                        <h4 class="box-title">
                          <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                            History Drawing Reference
                          </a>
                        </h4>
                      </div>
                      <div id="collapseTwo" class="panel-collapse collapse">
                       <div class="box-body">
						<table id="rfq_detail_drawing" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
						    <thead>
						      <tr>
						        <th>No</th>
						        <th>Part Number</th>
						        <th>Part Name</th>
						        <th>Qty / Unit</th>
						        <th>Unit</th>
						        <th>Date Drawing</th>
						        <th>Drawing Number</th>
						        <th>Revisi Drawing Accepted</th>
						        <th>Revisi Number</th>
						        <th>Obselete Date</th>
						        <th>Drawing Note</th>
						        
						      </tr>
						    </thead>
						    <tbody>
						    	<?php $no=1; foreach ($drawing_ as $value) { ?>
							      <tr>
							        <td><?php echo $no++;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>      
							        <td><?php echo $value->KPS_RFQ_PART_QTY;?></td>
							        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
							        <td><?php echo $value->DRAWING_DATE;?></td>
							        <td><?php echo $value->DRAWING_NO;?></td>
							        <td><?php echo $value->REV_DRAWING;?></td>
							        <td><?php echo $value->REV_NO;?></td>
							        <td><?php echo $value->OBSOLETE_DATE;?></td>
							        <td><?php echo $value->NOTE;?></td>
							        
							      </tr>
						      <?php } ?>
						    </tbody>
						</table>
					</div>
					<!--TABLE-->
                      </div>
                    </div>
                    </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


<!-- Modal UPDATE-->
<div class="modal fade" id="updatedraw" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->