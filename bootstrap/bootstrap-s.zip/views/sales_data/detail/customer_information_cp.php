<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Company Profile</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
				<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_company">

			  		<div class="col-lg-6">
			  			<div class="form-group">
	              			<label class="col-lg-3">Type of Company</label>			              	
			              	<div class="col-lg-9">
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Join Venture"> Joint Venture</label>
			              		<br>
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Local"> Local</label>
			              		<br>
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Trading"> Trading</label>
			              		<br>
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Manufacture"> Manufacture</label>
			              		<br>
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="Technical Corporation"> Technical Corporation</label>
			              		<br>
			              		<label><input type="checkbox" name="TYPE_OF_COMPANY[]" value="PMA"> PMA</label>
			              	</div>
	              		</div>
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Main Product</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="MAIN_PRODUCT" placeholder="main product">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-2 control-label">Number of Employees</label>
				          <div class="col-lg-8">
				          	<div class="input-group">
							  <input type="text" class="form-control" name="NUMBER_OF_EMPLOYEE" placeholder="number of employees" aria-describedby="basic-addon2">
							  <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="main product">
							  <span class="input-group-addon" id="basic-addon2">Employee</span>
							</div>
				          </div>
				          
				        </div>
				        <div class="form-group">
				          <label class="col-lg-2 control-label">Working Shift</label>
				          <div class="col-lg-8">
				            <div class="input-group">
							  <input type="text" class="form-control" name="WORKING_SHIFT" placeholder="Shift" aria-describedby="basic-addon2">
							  <span class="input-group-addon" id="basic-addon2">Shift</span>
							</div>
				          </div>
				          </div>
				         <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Company Profile" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Company Profile" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Type of Company</th>
	        <th>Main Product</th>
	        <th>Number of Employee</th>
	        <th>Working Shift</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($dataCp as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->TYPE_OF_COMPANY;?></td>
		        <td><?php echo $value->MAIN_PRODUCT;?></td>
		        <td><?php echo $value->NUMBER_OF_EMPLOYEE;?></td>
		        <td><?php echo $value->WORKING_SHIFT;?></td>      
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_COMPANY_ID."/edit_customer_information_cp"."/kps_customer_company/KPS_CUSTOMER_COMPANY_ID";?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->