<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Material Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/breakdown_cost/updateDetail/kps_breakdown_cost_material/KPS_BREAKDOWN_COST_MATERIAL_ID";?>" method="POST" class="form-horizontal">    
    <div class="form-group">
      <label class="col-lg-3 control-label">Material</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="MATERIAL" value="<?php echo $data->MATERIAL;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_MATERIAL_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BREAKDOWN_COST_ID;?>">

      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Netto</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QTY_NETTO" value="<?php echo $data->QTY_NETTO;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Brutto</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QTY_BRUTTO" value="<?php echo $data->QTY_BRUTTO;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Material Price</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="PRICE" value="<?php echo $data->PRICE;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Country</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="COUNTRY" value="<?php echo $data->COUNTRY;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>