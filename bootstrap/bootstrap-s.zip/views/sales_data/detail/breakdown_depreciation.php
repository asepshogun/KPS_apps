<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Depreciation</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
				<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/breakdown_cost/addSub/kps_breakdown_cost_depreciation">
			  		<div class="col-lg-6">
			  			<div class="form-group">
	              			<label class="col-lg-3">Model</label>			              	
			              	<div class="col-lg-9">
								 <select name="model" class="form-control select2" url="<?php echo site_url(); ?>/breakdown_cost/loadProd" id="modelBreakDown" style="width: 100%">
						            <option value="0">-- Select Model --</option>
						            <?php foreach ($pp as $value) { ?>
						              <option value="<?php echo $value->MODEL;?>"><?php echo $value->MODEL; ?></option>
						              <?php } ?>  
          						</select>
			              	</div>
	              		</div>
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Unit</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" id="qty_unit" name="qty_unit" value="0" name="QTY_UNIT">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Month</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" id="qty_month" name="qty_month" value="0" name="QTY_MONTH">
				            <input type="hidden" class="form-control" name="KPS_BREAKDOWN_COST_ID" value="<?php echo $KPS_BREAKDOWN_COST_ID; ?>"/>
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Periode</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" id="periode" name="periode" value="0" name="PERIODE">
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Depreciation</button>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="reset" class="btn btn-danger btn-flat pull-left">Reset Depreciation</button>
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="breakdown_depreciation" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Depreciation Model</th>
	        <th>QTY per Unit</th>
	        <th>QTY per Month</th>
	        <th>Depreciation Periode</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($dep as $value) {$no++ ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->model;?></td>
		        <td><?php echo $value->qty_unit;?></td>
		        <td><?php echo $value->qty_month;?></td>
		        <td><?php echo $value->periode;?></td>      
		         <td><a href="" url="<?php echo site_url()."/breakdown_cost/editDetail/".$value->KPS_BREAKDOWN_COST_DEPRECIATION_ID."/edit_breakdown_depreciation/kps_breakdown_cost_depreciation/KPS_BREAKDOWN_COST_DEPRECIATION_ID";?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>

</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->