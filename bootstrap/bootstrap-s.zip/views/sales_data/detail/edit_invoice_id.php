<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Invoice Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/invoice_detail/update";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Delivery Order Number</label>
      <div class="col-lg-9">
        <select id="input-select-order-number" class="form-control ">
            <option value="0">-- Select Delivery Order--</option>
            <option value="1">0 - 2015-10-15</option>
            <option value="2">No - </option>
            <option value="3">1 - 2015-12-05</option>
            <option value="4">1 - 2015-12-05</option>
            <option value="5">15/DO-SLS/XII/4 - 2015-12-11</option>
        </select>
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>