<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Person In Charge Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_is_person_in_charge/KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Department</label>
      <div class="col-lg-9">
        <select name="DEPARTMENT" class="form-control">
          <option value="Director">Director</option>
          <option value="Purchasing">Purchasing</option>
          <option value="Production">Production</option>
          <option value="Finance & Accounting">Finance & Accounting</option>
          <option value="Quality">Quality</option>
        </select>
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">PIC Name</label>
      <div class="col-lg-9">
           <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID_PIC;?>">
        <input type="text" class="form-control" name="NAME" value="<?php  echo $data->NAME;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Position</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="POSITION" value="<?php  echo $data->POSITION;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Mobile Phone</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="MOBILE_PHONE" value="<?php  echo $data->MOBILE_PHONE;?>">
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">Email Address</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="EMAIL" value="<?php  echo $data->EMAIL;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>     			      	
  </form>	        	    			      		        
</div>