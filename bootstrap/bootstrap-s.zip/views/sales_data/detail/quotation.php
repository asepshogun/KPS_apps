<section class="content-header">
	<h3>Quotation Data Detail</h3>
	<small>Detail Data Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Valid From</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_FROM" value="<?php echo $data->VALID_DATE_FROM ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Valid Until</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VALID_DATE_UNTIL" value="<?php echo $data->VALID_DATE_UNTIL ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY_NAME"  value="<?php echo $data->CURRENCY_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Person in Charge</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NAME" value="<?php echo $data->NAME ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Checked By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED_QUO" value="<?php echo $data->NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Approved By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="APPROVED_QUO" value="<?php echo $data->NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Marketing</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="marketing_id" value="<?php echo $data->MARKETING_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Quotation Note</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NOTE_QUO" value="<?php echo $data->NOTE_QUO ?>" disabled>
			          </div>
			        </div>

				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#qd">QUOTATION DETAIL</a></li>
			</ul>

			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">

				<?php 
				$datas['KPS_QUOTATION_ID'] = $data->KPS_QUOTATION_ID;
				$datas['data'] = $quotation;
				
				$this->load->view('sales_data/detail/quotation_qd',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>