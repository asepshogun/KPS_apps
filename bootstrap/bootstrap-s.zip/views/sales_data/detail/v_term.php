
	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Term 
	       <?php 
	      
	      if($termtotal+1<$count){
	      echo "ke"; 
	      echo "-";
	      echo $count;
	      }
	       ?></h4>
	    </div>
	    <div class="modal-body">
			<table id="invoice" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
				<tr>
					<th>
						Term Order
					</th>
					<th>
						DP
					</th>
				</tr>
					<?php
					$total = 0;
					foreach ($data as $key => $value) {
					?>
					<tr>
						<td>
							<?php echo $value->termin_order ?>
						</td>
						<td>
							<?php echo $value->dp ?> %
						</td>
					</tr>
					<?php
					$total += $value->dp;
					}
					?>
					<th>
						TOTAL
					</th>
					<th>
						<?php echo $total; ?> %
					</th>
			</table>
			<?php
			if($total<100){
			?>
	    	<form action="<?php echo site_url()."/invoice/term";?>" method="POST" class="form-horizontal">
	    		
		         <div class="form-group">
			      <label class="col-lg-3 control-label">DP (%)</label>
			      <div class="col-lg-9">
			        <input type="text" name="dp" 
			        <?php
			        if($count==$termtotal){
			        ?>
			        value="<?php echo 100-$total; ?>"
			        readonly="readonly"
			        <?php
			        }
			        ?>
			        placeholder="DP (%)">
			        <input type="hidden" value="<?php echo $invoiceId; ?>" name="invoice_id" >
			        <input type="hidden" value="<?php echo $count; ?>" name="termin_order" >
			        <input type="hidden" value="<?php echo $termtotal; ?>" name="termtotal" >
			      </div>
			    </div>    
		       
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Term</button>
		          </div>
		        </div>			      	
	        </form>	  
	        <?php } ?>      	    			      		        
	    </div>
	  </div>
	  