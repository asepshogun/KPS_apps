<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want change this item </h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/invoice/addFromDelete";?>" method="POST" class="form-horizontal">

		         <div class="form-group">
			      <label class="col-lg-3 control-label">Term</label>
			      <div class="col-lg-9">
			      	<?php 
			      		if($data->term==1){
			      			?>
			      			<input type="radio" name="term" value="1" required > 1 </input>
					        
			      			<?php
			      		}elseif($data->term==2){
			      			?>
			      			
					        <input type="radio" name="term" value="2" required> 2 </input>
					        
			      			<?php
			      		}elseif($data->term==3) {
			      			?>
			      			
					        <input type="radio" name="term" value="3" required > 3 </input>
					        
			      			<?php
			      		}else{
			      			?>
			      			
					        <input type="radio" name="term" value="4" required > 4 </input>
			      			<?php
			      		}

			      	?>
			        
			      </div>
			    </div>    
		        <div class="form-group">
		          <label class="col-sm-3 control-label">DP (%)</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="KPS_INVOICE_DP" placeholder="DP (%)">
					<input type="hidden" class="form-control" name="INVOICE_INDUK_ID_inv" value="<?php echo $data->INVOICE_INDUK_ID_inv;?>"/>
					<input type="hidden" class="form-control" name="KPS_INVOICE_ID" value="<?php echo $data->KPS_INVOICE_ID;?>"/>
					 
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">NO INVOICE FAKTUR PAJAK STRANDAR PENGGANTI</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="KPS_NO_INVOICE_FAKTUR_PAJAK" placeholder="NO INVOICE FAKTUR PAJAK STRANDAR" required>					 
		          </div>
		        </div>
		       
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Prepared By</label>
		          <div class="col-sm-9">
					<input type="text" class="form-control" name="PREPARED_INVOs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="PREPARED_INVO" value="<?php echo $this->session->userdata('employeeId'); ?>">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED_INVO">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="APPROVED_INVO">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	       
</div>