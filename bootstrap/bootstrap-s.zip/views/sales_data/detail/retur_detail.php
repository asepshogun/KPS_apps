<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Retur Detail</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/retur_product/addSub/kps_retur_barang_detail">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Code Item - Part NO - Part Name</label>
							<div class="col-lg-9">
								<select name="KPS_LOI_ID_RETUR" id="pesananloiid"  url="<?php echo site_url(); ?>/pesanan/loadModelPrice" class="form-control select2" style="width: 100%">
									<option value="0">-- Select Code Product - Part Name - Part No --</option>
									<?php foreach ($loi as $value) { ?>
									<option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_CODE_ITEM; ?> - <?php echo $value->LOI_PART_NAME; ?> - <?php echo $value->LOI_PART_NO; ?></option>
									<?php } ?>	
								</select>
							</div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">QTY</label>
				          <div class="col-lg-9">
				            <input type="number" class="form-control" name="QTY_RTR" placeholder="QTY Retur">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Reason</label>
				          <div class="col-lg-9">
				            <input type="hidden" class="form-control" name="KPS_RETUR_BARANG_ID_DET" value="<?php echo $id; ?>">
				            <input type="text" class="form-control" name="REASON" placeholder="Reason Retur">
				          </div>
				        </div>			        
			  		</div>
			        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Retur Detail" />
				       
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Retur Detail" />
				        </div>
					 </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="retur_detail_data" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Item</th>
	        <th>Part Name</th>
	        <th>Part No</th>
	        <th>Model</th>
	        <th>QTY</th>
	        <th>Unit</th>
	        <th>Reason</th>
	        <th>Delete</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($detail as $value) { $no++?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td>      
		        <td><?php echo $value->QTY_RTR;?></td>
		        <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
		        <td><?php echo $value->REASON;?></td>
		        <td><a href=""  url="<?php echo site_url()."/retur_product/preDel/". $value->KPS_RETUR_BARANG_DETAIL_ID ;?>" <?php if($value->OUTGOING_RETUR_PRODUCT_DETAIL_ID){ echo "style=display:none";} ?> data-toggle="modal" data-target="#updatedraw" class="update-link">Delete</a></td>
		        <td><a href=""  url="<?php echo site_url()."/retur_product/preUpdate/". $value->KPS_RETUR_BARANG_DETAIL_ID ;?>" <?php if($value->OUTGOING_RETUR_PRODUCT_DETAIL_ID){ echo "style=display:none";} ?> data-toggle="modal" data-target="#updatedraw" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatedraw" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->