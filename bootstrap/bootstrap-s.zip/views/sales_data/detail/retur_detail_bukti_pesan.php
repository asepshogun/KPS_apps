<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Retur Detail Bukti Pesan</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/retur_product/addSub/kps_retur_barang_bukti_pesan/cpBuk">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">No Bukti pesan / PO</label>
							<div class="col-lg-9">
								<select name="KPS_BUKTI_PESANAN_ID_BUKTIPESAN_RETUR" id="buktiPesan" class="form-control select2" style="width: 100%">
									<option value="0">-- Select No From Kps - No From Customer --</option>
									<?php foreach ($bukti_pesan as $value) { ?>
									<option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>"><?php echo $value->REV_NO_BP; ?> - <?php echo $value->PO_OS_NO_FROM_CUSTOMER; ?></option>
									<?php } ?>	
								</select>
							</div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Note</label>
				          <div class="col-lg-9">
				            <input type="hidden" class="form-control" name="KPS_RETUR_BARANG_ID_DET" value="<?php echo $id; ?>">
				            <input type="text" class="form-control" name="NOTE_buktipesan_retur" placeholder="Note">
				          </div>
				        </div>			        
			  		</div>
			        <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Retur Detail" />
				       
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Retur Detail" />
				        </div>
					 </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="retur_detail_data" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>No Bukti Pesan From KPS</th>
	        <th>PO NO From Customer</th>
	        <th>PO Date From Customer</th>
	        <th>Note</th>
	        <th>Delete</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($detail_bukti_pesan as $value) { $no++?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->REV_NO_BP;?></td>
		        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
		        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
		        <td><?php echo $value->NOTE_buktipesan_retur;?></td>      
		        <td><a href=""  url="<?php echo site_url()."/retur_product/preDelBuktipesan/". $value->KPS_RETUR_BUKTIPESAN_ID ;?>" data-toggle="modal" data-target="#updatedraw" class="update-link">Delete</a></td>
		        <td><a href=""  url="<?php echo site_url()."/retur_product/preUpdateBuktiPesan/". $value->KPS_RETUR_BUKTIPESAN_ID ;?>"data-toggle="modal" data-target="#updatedraw" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatedraw" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->