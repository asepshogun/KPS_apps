<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Tooling Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/breakdown_cost/updateDetail/kps_breakdown_cost_tooling/KPS_BREAKDOWN_COST_TOOLING_ID";?>" method="POST" class="form-horizontal">    
    <div class="form-group">
      <label class="col-lg-3 control-label">Tool</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="TOOL" value="<?php echo $data->TOOL;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Cost</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="COST" value="<?php echo $data->COST;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Remarks</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="REMARK" value="<?php echo $data->REMARK;?>">
         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_TOOLING_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BREAKDOWN_COST_ID;?>">

      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>