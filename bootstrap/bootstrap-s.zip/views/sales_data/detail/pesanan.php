<section class="content-header">
	<h3>Order Proof Data Detail</h3>
	<small>Detail Data Bukti Pesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No Rev Bukti Pemesanan</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->REV_NO_BP ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->COMPANY_NAME ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Divisi</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DIVISI" value="<?php echo $data->DIVISI ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Currency</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CURRENCY_NAME" value="<?php echo $data->CURRENCY ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">PO Number Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PO_OS_NO_FROM_CUSTOMER" value="<?php echo $data->PO_OS_NO_FROM_CUSTOMER ?>" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">PO Date Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PO_OS_DATE_FROM_CUSTOMER" value="<?php echo $data->PO_OS_DATE_FROM_CUSTOMER ?>" disabled>
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Sub Total</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="SUB_TOTAL_BP" value="<?php echo $data->SUB_TOTAL_BP ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Tax</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TAX_BP" value="<?php echo $data->TAX_BP ?>" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_BP" value="<?php echo $data->TOTAL_BP ?>" disabled>
			          </div>
			        </div>			        
				</form>
			</div>


		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#bpd">BUKTI PESANAN DETAIL</a></li>
			</ul>

			<div class="tab-content">
			  <div id="bpd" class="tab-pane fade in active">
				<?php 
				$datas['loi'] = $loi;
				$datas['detail'] = $detail;
				$datas['KPS_BUKTI_PESANAN_ID'] = $data->KPS_BUKTI_PESANAN_ID;
				$this->load->view('sales_data/detail/pesanan_bpd',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>