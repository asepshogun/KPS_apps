<!--TABLE-->
<div class="box-body">
	<table id="project_fpa" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Attachment Type</th>
	        <th>Attachment Title</th>
	        <th>Filename</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($attach as $value) { ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->TYPE;?></td>
		        <td><?php echo $value->TITLE;?></td>
		        <td><a href="<?php echo base_url()."/uploads/loi/".$value->FILENAME; ?>">
					<?php echo $value->FILENAME; ?>
					</a></td> 
		        						      <td><a href="" url="<?php echo site_url()."/item/editDetail/".$value->KPS_FAILED_PROJECT_ATTACHMENT_ID."/edit_project_fpa/kps_failed_project_attachment/KPS_FAILED_PROJECT_ATTACHMENT_ID"; ?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>

		       
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12">
		<button type="button" data-toggle="modal" data-target="#add"  class="btn bg-olive btn-flat pull-right">Add Attachment</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Failed Project Attachment</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/project/addSub/kps_failed_project_attachment";?>" enctype="multipart/form-data" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Attachment Type</label>
			      <div class="col-lg-9">
			        <select name="TYPE" class="form-control ">
						<option value="0">-- Select Type--</option>
						<option value="Failed Letters">Failed Letters</option>
						<option value="LOI">LOI</option>
					</select>
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Attachment Title</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="TITLE" placeholder="quantity netto">
			        <input type="hidden" class="form-control" value="<?php echo $idfailed; ?>" name="KPS_FAILED_PROJECT_ID" placeholder="quantity netto">
			      </div>
			    </div>	
			    <div class="form-group">
		          <label class="col-lg-3 control-label">Attachment</label>
		          <div class="col-lg-9">				            
		            <input type="file" class="form-control" name="FILENAME">
		          </div>
		        </div>	        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->