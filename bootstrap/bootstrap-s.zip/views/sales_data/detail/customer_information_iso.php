<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add ISO</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_iso">
		
			  		<div class="col-lg-6">			  						  			
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Certification Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="NAME_OF_CERTIFICATION" placeholder="certification name">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Certified Date</label>
				          <div class="col-lg-9">
				            <input type="date"class="form-control" name="DATE_CERTIFIED" placeholder="Pick Date" >
				               <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="main product">
				       
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Validity Date</label>
				          <div class="col-lg-9">
				            <input type="date" class="form-control" name="VALIDITY_DATE" placeholder="Pick Date" >
				          </div>
				        </div>	
				         <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save ISO" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form ISO" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_iso" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Certification Name</th>
	        <th>Certified Date</th>
	        <th>Validity Date</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($iso as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->NAME_OF_CERTIFICATION;?></td>
		        <td><?php echo $value->DATE_CERTIFIED;?></td>
		        <td><?php echo $value->VALIDITY_DATE;?></td>
		         <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_ISO_ID."/edit_customer_information_iso"."/kps_customer_iso/KPS_CUSTOMER_ISO_ID";?>" data-toggle="modal" data-target="#updateiso" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updateiso" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->