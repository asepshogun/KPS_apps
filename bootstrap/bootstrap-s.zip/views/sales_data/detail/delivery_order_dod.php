<!--TABLE-->
<div class="box-body">
	<table id="delivery_order_dod" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Product</th>
	        <th>Part No</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>QTY</th>
	        <th>Note</th>
	        <!--<th>Confirm</th>-->
	      </tr>
	    </thead>
	    <tbody>
	    	<?php
	    		 $no=1; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		         <td><?php echo $value->LOI_CODE_ITEM;?></td> 
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td> 
		        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
		        <td><?php echo $value->NOTE;?>-</td>
		        </td>

		       <!-- <td><a href="<?php //echo site_url()."/delivery_order/confirmation/".$value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID;?>" >Confirm</a></td>-->

		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
	<!-- 	<button type="button" data-toggle="modal" data-target="#add" class="btn bg-olive btn-flat pull-right">Add Delivery Order Detail</button> -->
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Order Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_order/addSub/kps_delivery_order_detail";?>" method="POST" class="form-horizontal">
	    	<div class="form-group">
			      <label class="col-lg-3 control-label">Outgoing Finished Good</label>
			      <div class="col-lg-9">
			        <select name="buktipesanan" id="scbuktipesanan" url="<?php echo site_url(); ?>/delivery_order/loadProduct" class="form-control select2" style="width:100%"	>
						<option value="0">-- Select Outgoing Finished --</option>
						<?php foreach ($outgoing as $value) { ?>
					    <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_ID; ?>"><?php echo $value->NO_OUTGOING; ?> </option>
					    <?php } ?>	
					</select>
			      </div>
			    </div>	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Product</label>
			      <div class="col-lg-9">
			        <select name="KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_DO" id="scproduct" class="form-control select2" style="width: 100%">
						<option value="0">-- Select Product --</option>
						
					</select>
			      </div>
			    </div>

			    <div class="form-group">
			      <label class="col-lg-3 control-label">Note</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="NOTE_DO" placeholder="note">
			        <input type="hidden" class="form-control" name="status" value="Not Good (NG)" placeholder="note">
			        <input type="hidden" class="form-control" name="KPS_DELIVERY_ORDER_ID" value="<?php echo $KPS_DELIVERY_ORDER_ID; ?>">
			      </div>
			    </div>        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="confirm" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->

