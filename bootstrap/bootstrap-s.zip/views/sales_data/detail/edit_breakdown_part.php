<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Part Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/breakdown_cost/updateDetail/kps_breakdown_cost_part/KPS_BREAKDOWN_COST_PART_ID";?>" method="POST" class="form-horizontal">    
    <div class="form-group">
      <label class="col-lg-3 control-label">KPS Part Name</label>
      <div class="col-lg-9">
       <input type="text" class="form-control" name="KPS_PART_NAME" value="<?php echo $data->KPS_PART_NAME;?>">
      </div>
    </div>
     <div class="form-group">
      <label class="col-lg-3 control-label">KPS Part No</label>
      <div class="col-lg-9">
       <input type="text" class="form-control" name="KPS_PART_NO" value="<?php echo $data->KPS_PART_NO;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Cost</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="COST" value="<?php echo $data->COST;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BREAKDOWN_COST_ID;?>">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_PART_ID;?>">

      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Country</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="COUNTRY" value="<?php echo $data->COUNTRY;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>