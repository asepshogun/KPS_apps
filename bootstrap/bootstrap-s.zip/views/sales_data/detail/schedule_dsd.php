<!--TABLE-->
<div class="box-body">
	<table id="schedule_dsd" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Product</th>
	        <th>Part No</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>Delivery Place</th>
	        <th>Delivery Date</th>
	        <th>Delivery Quantity</th>
	        <th>Quantity Remaining</th>
	        <th>Note</th>
	        <th>Update</th>	
	        <th>Delete</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td> 
		        <td><?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP_ID;?></td>
		        <td><?php echo $value->DELIVERY_PLAN;?></td> 
		        <td><?php echo $value->QUANTITY_DELIVERY;?></td>
		        <td><?php echo $value->REMAINING_QUANTITY;?></td>
		        <td><?php echo $value->NOTE_DS_DET;?></td>
		     	<td><a href="" url="<?php echo site_url()."/schedule/editDetail/".$value->KPS_DELIVERY_SCHEDULE_DETAIL_ID."/edit_schedule_dsd/kps_delivery_schedule_detail/KPS_DELIVERY_SCHEDULE_DETAIL_ID/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		     	<td><a href="" url="<?php echo site_url()."/schedule/preDelDetail/".$value->KPS_DELIVERY_SCHEDULE_DETAIL_ID."/pre_del_schedule_dsd/kps_delivery_schedule_detail/KPS_DELIVERY_SCHEDULE_DETAIL_ID/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
		<button type="button" data-toggle="modal" data-target="#add" class="btn bg-olive btn-flat pull-right">Add Delivery Schedule Detail</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Schedule Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/schedule/addSub/kps_delivery_schedule_detail";?>" method="POST" class="form-horizontal">	    		
	    		
			   	<div class="form-group">
			      <label class="col-lg-3 control-label">Product</label>
			      <div class="col-lg-9">
			        <select name="KPS_BUKTI_PESANAN_DETAIL_ID_SD" url="<?php echo site_url() ?>/schedule/loadRemaining" id="productsch" class="form-control select2" style="width:100%"	>
						<option value="0">-- Select Code Product --</option>
						<?php foreach ($code as $value) { ?>
					    <option value="<?php echo $value->KPS_BUKTI_PESANAN_DETAIL_ID;?>">
					    <?php echo $value->LOI_CODE_ITEM." - ".$value->LOI_MODEL." - ".$value->LOI_PART_NO." - ".$value->LOI_PART_NAME;?>
						</option>
					    <?php } ?>
					</select>
			      </div>
			    </div>
			   			    <div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Place</label>
			      <div class="col-lg-9">
			      		<select name="KPS_CUSTOMER_DELIVERY_SETUP_ID"  class="form-control select2" style="width:100%"	>
						<option value="0">-- Select Delivery Place --</option>
						<?php foreach ($deliv as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_DELIVERY_SETUP;?>">
					    <?php echo $value->PLANT1_CITY;?>
						</option>
					    <?php } ?>
					</select>
			      </div>
			    </div>
			   	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Remaining Quantity</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" id="remainingquantity" readonly="readonly" value="0" name="REMAINING_QUANTITY">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Quantity</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="QUANTITY_DELIVERY" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_DELIVERY_SCHEDULE_ID" value="<?php echo $KPS_DELIVERY_SCHEDULE_ID; ?>" placeholder="quantity netto">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Delivery Date</label>
			      <div class="col-lg-9">
			        <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DELIVERY_PLAN" placeholder="Pick Date">
			      </div>
			    </div>
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Note</label>
			      <div class="col-lg-9">
			        <textarea type="text" class="form-control" name="NOTE_DS_DET" placeholder="note"></textarea>	
			      </div>
			    </div>        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->