<section class="content-header">
	<h3>Invoice Data DO Detail</h3>
	<small>Detail Data DO Invoice</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group"><?php //var_dump($getTot); ?>
			          <label class="col-sm-3 control-label">Invoice Induk Number</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INVOICE_INDUK_NO" disabled value="<?php echo $data->INVOICE_INDUK_NO; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Invoice Induk Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="INVOICE_INDUK_DATE" disabled value="<?php echo $data->INVOICE_INDUK_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $data->COMPANY_NAME; ?>">
			          </div>
			        </div> 
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Adress</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PLANT" disabled value="<?php echo $data->PLANT; ?>">
			          </div>
			        </div>	
					<div class="form-group">
			          <label class="col-sm-3 control-label">Made By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PLANT" disabled value="<?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->KPS_INVOICE_INDUK_MADE_BY	."'");
			        	$datae = mysql_fetch_array($query);
			        	echo $datae['EMPLOYEE_NAME'];
						?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Pembayaran</label>
			          <div class="col-sm-9">
			           <input type="text" class="form-control" name="APPROVED_INVO" disabled value="<?php echo $data->TOTAL_PEMBAYARAN; ?>"> 
			          </div>
			        </div>					        
				</form>
			</div>
			<div class="col-lg-12" style="margin-top: 30px;">
			 <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular"){
		        	?> 
		        	<div class="btn-group pull-right">
		        	<a href="<?php echo site_url()."/invoice/lockdo/".$data->INVOICE_INDUK_ID ."/". $idCus;?>" <?php if($data->status_inv_do){ echo "disabled onclick = 'return false'";}else{echo " ";} ?> class="btn btn-danger flat"><i class="fa fa-lock"></i> Lock </a>
		        	<?php
		      }?>  
		      <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<a href="<?php echo site_url()."/invoice/unlockdo/".$data->INVOICE_INDUK_ID ."/". $idCus;?>" class="btn btn-success flat"><i class="fa fa-unlock"></i> Unlock </a></div>
		       <?php }?>   	
		      </div>
		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#id">DELIVERY ORDER NO</a></li>
			</ul>

			<div class="tab-content">
			  <div id="id" class="tab-pane fade in active">
				<?php 
				$datas['INVOICE_INDUK_ID'] = $data->INVOICE_INDUK_ID;
				$datas['status_inv_do'] = $data->status_inv_do;
				$datas['detail'] = $detail;
				$datas['delivery'] = $delivery;
				$this->load->view('sales_data/detail/invoice_id',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>