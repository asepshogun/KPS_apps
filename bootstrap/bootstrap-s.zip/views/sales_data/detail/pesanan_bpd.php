<!-- TABLE-->
<div class="box-body">
	<table id="pesanan_bpd" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>LOI Number</th>
	        <th>Kanban PO Number</th>
	        <th>Code Product</th>
	        <th>Part No</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>Quantity</th>
	        <th>Price</th>
	        <th>Amount</th>
	        <th>Update</th>	
	        <th>Delete</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->NO_LOI;?></td>
		        <td><?php echo $value->KANBAN_PO_NO;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td> 
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td>
		        <td><?php echo $value->LOI_MODEL;?></td> 
		        <td><?php echo $value->QUANTITY;?></td>
		        <td><?php echo $value->price;?></td>
		        <td><?php echo $value->AMOUNT;?></td>
		        						    
		        <td><a href="" url="<?php echo site_url()."/pesanan/editDetail/".$value->KPS_BUKTI_PESANAN_DETAIL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>
		        <td><a href="" url="<?php echo site_url()."/pesanan/deleteDetail/".$value->KPS_BUKTI_PESANAN_DETAIL_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
	<div class="col-lg-12" style="margin-top: 30px;">
		<button type="button" data-toggle="modal" data-target="#add" class="btn bg-olive btn-flat pull-right">Add Bukti Pesanan Detail</button>
	</div>
</div>
<!--TABLE-->

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Bukti Pesanan Detail Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/pesanan/addSub/kps_bukti_pesanan_detail";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
			      <label class="col-lg-3 control-label">Code Product</label>
			      <div class="col-lg-9">
			        <select name="KPS_LOI_ID_BK" id="pesananloiid"  url="<?php echo site_url(); ?>/pesanan/loadModelPrice" class="form-control select2" style="width: 100%">
						<option value="0">-- Select Code Product --</option>
						<?php foreach ($loi as $value) { ?>
					    <option value="<?php echo $value->KPS_LOI_ID;?>"><?php echo $value->LOI_CODE_ITEM; ?> - <?php echo $value->LOI_PART_NAME; ?> - <?php echo $value->LOI_PART_NO; ?> - <?php echo $value->LOI_MODEL; ?></option>
					    <?php } ?>	
					</select>
			      </div>
			    </div>
			    <!-- <div class="form-group">
			      <label class="col-lg-3 control-label">Part Name</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" readonly="readonly" id="partname" placeholder="Part Name">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Part No</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" readonly="readonly" id="partno" placeholder="Part No">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Model</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" readonly="readonly" id="model" placeholder="Model">
			      </div>
			    </div>	 -->
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Kanban PO Number</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="KANBAN_PO_NO" placeholder="quantity netto">
			        <input type="hidden" class="form-control" name="KPS_BUKTI_PESANAN_ID" value="<?php echo $KPS_BUKTI_PESANAN_ID; ?>" placeholder="quantity netto">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Quantity</label>
			      <div class="col-lg-9">
			        <input type="text" class="form-control" name="QUANTITY" placeholder="quantity netto">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Unit</label>
			      <div class="col-lg-9">
			        <input type="text" id="peunit" readonly="readonly" class="form-control" name="unit" placeholder="quantity netto">
			      </div>
			    </div>	
			    <div class="form-group">
			      <label class="col-lg-3 control-label">Price</label>
			      <div class="col-lg-9">
			        <input type="text" id="peprice" readonly="readonly" class="form-control" name="price" placeholder="quantity netto">
			      </div>
			    </div>	        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE 