<section class="content-header">
	<h3>Return Product Detail</h3>
	<small>Detail Retur Produk</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">

			        <div class="form-group">
			          <label class="col-sm-3 control-label">NO Retur</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RETUR" disabled value="<?php echo $datas->NO_RETUR ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date Retur</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_RTR" disabled value="<?php echo $datas->DATE_RTR ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Rev No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO_RTR" disabled value="<?php echo $datas->REV_NO_RTR ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">No Retur From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" disabled value="<?php echo $datas->NO_RETUR_FROM_CUSTOMER ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date Retur From Customer</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_RETUR_CUSTOMER" disabled value="<?php echo $datas->DATE_RETUR_CUSTOMER ?>">
			          </div>
					 </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_CUSTOMER_ID_RETUR" disabled value="<?php echo $datas->COMPANY_NAME ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">PPIC DUE Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DUE_DATE_PPIC" disabled value="<?php echo $datas->DUE_DATE_PPIC ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer DUE Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DUE_DATE_CUSTOMER" disabled value="<?php echo $datas->DUE_DATE_CUSTOMER ?>">
			          </div>
			        </div>
				</form>
			</div>

		</div>
	</div>
	<div class="box-body">
		<?php
			$calsstab2="";
			$calsstab1="";
			if($tabActive){
				if($tabActive=="cpBuk"){
				$calsstab2="class=active";
				}else{
					$calsstab1="class=active";
				}
			}else{
					$calsstab1="class=active";
			}
		?>
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li <?php echo $calsstab1; ?> ><a data-toggle="tab" href="#cp">Retur Get Item</a></li>
			  <li <?php echo $calsstab2; ?> ><a data-toggle="tab" href="#cpBuk">Retur Get No Buktipesan</a></li>
			</ul>
			<div class="tab-content">
			  <div id="cp" class="tab-pane fade in active">
				<?php 
				$data['id'] = $datas->KPS_RETUR_BARANG_ID;
				$data['detail'] = $detail;
				$this->load->view('sales_data/detail/retur_detail',$data);?>			
			  </div>
			  <div id="cpBuk" class="tab-pane fade">
				<?php 
				$data['id'] = $datas->KPS_RETUR_BARANG_ID;
				$data['detail_bukti_pesan'] = $detail_bukti_pesan;
				$data['bukti_pesan'] = $bukti_pesan;
				$this->load->view('sales_data/detail/retur_detail_bukti_pesan',$data);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>