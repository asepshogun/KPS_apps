<?php
	if(count($pp)==0){
?>
<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Production Plan</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_production_plan">
			  		<div class="col-lg-6">
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Model</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="MODEL" placeholder="model">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Unit</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="QTY_UNIT" placeholder="quantity unit">
						<input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">

				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Month</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="QTY_MONTH" placeholder="quntity month">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Periode</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="PERIODE" placeholder="periode">
				          </div>
				        </div>				        
			  		</div>
			         <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Production Plan" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Production Plan" />
				        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>
<?php
	}
?>

<!--TABLE-->
<div class="box-body">
	<table id="rfq_detail_pp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Model</th>
	        <th>Quantity Unit</th>
	        <th>Quantity Month</th>
	        <th>Periode</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($pp as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->MODEL;?></td>
		        <td><?php echo $value->QTY_UNIT;?></td>
		        <td><?php echo $value->QTY_MONTH;?></td>
		        <td><?php echo $value->PERIODE;?></td> 
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_RFQ_PRODUCTION_PLAN_ID."/edit_request_quotation_pp"."/kps_rfq_production_plan/KPS_RFQ_PRODUCTION_PLAN_ID";?>" data-toggle="modal" data-target="#updatepp" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatepp" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->