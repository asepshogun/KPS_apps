<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<?php// print_r($detail); ?>
	<form action="<?php echo site_url()."/order_sheet/deletePoOs";?>" method="POST" class="form-horizontal">	    	
		<label>Bukti Pesanan</label>	
			        
		<input type="text" class="form-control" name="KPS_OS_IDs" value="No BP KPS : <?php echo $detail->REV_NO_BP ."-No PO - :". $detail->PO_OS_NO_FROM_CUSTOMER; ?>" disabled>
		<input type="hidden" class="form-control" name="KPS_ORDER_SHEET_DETAIL_ID" value="<?php echo $detail->KPS_ORDER_SHEET_DETAIL_ID; ?>">
		<input type="hidden" class="form-control" name="KPS_OS_ID" value="<?php echo $detail->KPS_OS_ID; ?>">

		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">YES</button>
		  </div>
		</div>			      	
	</form>	  
</div>