<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Quotation Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/quotation/updateDetail/kps_quotation_detail/KPS_QUOTATION_DETAIL_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Breakdown Cost</label>
      <div class="col-lg-9">
        <select name="breakdown_cost_id" class="form-control select2" style="width:100%">
          <option>-- Select Breakdown Cost--</option>
          <?php foreach ($breakdownCost as $value) { ?>            
            <option value="<?php echo $value->KPS_BREAKDOWN_COST_ID;?>" <?php if($value->KPS_BREAKDOWN_COST_ID == $data->breakdown_cost_id){
              echo "selected=''";
            }?>><?php echo $value->NO_BREAK;?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Number</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="part_no" value="<?php echo $data->part_no;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="part_name" value="<?php echo $data->part_name;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="model" value="<?php echo $data->model;?>">
         <input type="hidden" class="form-control" name="KPS_QUOTATION_ID" value="<?php echo $data->KPS_QUOTATION_ID ?>" placeholder="quantity netto">
         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_QUOTATION_DETAIL_ID ?>" placeholder="quantity netto">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Price</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="price" value="<?php echo $data->price;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Unit</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="unit" value="<?php echo $data->unit;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Detail Note</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="note" value="<?php echo $data->note;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>
  <script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>