<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">ISO Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_iso/KPS_CUSTOMER_ISO_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Certification Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="NAME_OF_CERTIFICATION" value="<?php echo $data->NAME_OF_CERTIFICATION;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Certified Date</label>
      <div class="col-lg-9">
         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_ISO_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
     
        <input type="date" class="form-control" name="DATE_CERTIFIED" value="<?php echo $data->DATE_CERTIFIED;?>" >
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Validity Date</label>
      <div class="col-lg-9">
        <input type="date" class="form-control" name="VALIDITY_DATE" value="<?php echo $data->VALIDITY_DATE;?>" >
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>