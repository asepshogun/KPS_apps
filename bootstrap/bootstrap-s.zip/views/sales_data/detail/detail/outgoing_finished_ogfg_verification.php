<!--TABLE-->
<div class="box-body">
	<table id="customer_cp" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Code Product</th>
	        <th>Part No</th>
	        <th>Part Name</th>
	        <th>Model</th>
	        <th>Delivery Execution</th>
	        <th>Detail</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($detail as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td> 
		        <td><?php echo $value->LOI_MODEL;?></td>
		        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
		        <td><a href="<?php echo site_url()."/outgoing_finished_verification/detail_ver/".$value->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID . "/" . $KPS_OUTGOING_FINISHED_GOOD_ID_D;?>">detail</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->