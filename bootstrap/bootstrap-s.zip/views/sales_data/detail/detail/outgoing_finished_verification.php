<section class="content-header">
	<h3>Outgoing Finished Good Data Detail Verification</h3>
	<small>Detail Data Outgoing Finished Good Verification</small>
</section>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">
			<?php //print_r($data)?>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Company Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $data->COMPANY_NAME ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Bukti Pesanan</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO_BP" disabled value="<?php echo $data->REV_NO_BP ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="KPS_VEHICLE_ID" disabled value="<?php echo $data->VEHICLE_NAME ?>">
			          </div>
			        </div>
			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$data->employee_driver_id."'")->first_row();
			?>
			<?php
			      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$data->CHECKED."'")->first_row();
			?>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Driver</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="employee_driver_id" disabled value="<?php echo $q1->EMPLOYEE_NAME ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Checked By</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CHECKED" disabled value="<?php echo $q2->EMPLOYEE_NAME ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Execution</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_DELIVERY_EXECUTION" disabled value="<?php echo $total ?>">
			          </div>
			        </div>			        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->LOI_CODE_ITEM ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->LOI_PART_NO ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->LOI_PART_NAME ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">QTY Execution</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->QTY_DELIVERY_EXECUTION ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">QTY Verification</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->OUTGOING_DETAIL_QTY_VERIFICATION?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">Unit</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $detail[0]->KPS_RFQ_PART_UNIT ?>">
			          </div>
			        </div>
				</form>
			</div>
		</div>
	</div>

	<div class="box-body">
		<div class="nav-tabs-custom">
			<ul class="nav nav-tabs">
			  <li class="active"><a data-toggle="tab" href="#ofgd">OUTGOING FINISHED GOOD DETAIL <?php //var_dump($schedule)?></a></li>
			</ul>

			<div class="tab-content">
			  <div id="ofgd" class="tab-pane fade in active">
				<?php 
				$pesan =$pesan;
				$datas['detail'] = $detail;
				// $datas['schedule'] = $schedule;
				$datas['KPS_OUTGOING_FINISHED_GOOD_ID_D'] = $data->KPS_OUTGOING_FINISHED_GOOD_ID;
				$this->load->view('sales_data/detail/detail/outgoing_finished_ofgd_verification',$datas);?>			
			  </div>
			</div>
		</div>
	</div>

	<div class="box-body">
		
	</div>
</div>