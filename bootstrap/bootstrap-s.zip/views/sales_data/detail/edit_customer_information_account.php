<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Finance Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_finance_bank/KPS_CUSTOMER_FINANCE_BANK_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Bank</label>                     
      <div class="col-lg-9">
         <select name="KPS_BANK_ID" class="form-control select2" style="width: 100%">
              <option value="0">-- Select Bank --</option>
              <?php foreach ($databank as $value) { ?>
                <option value="<?php echo $value->KPS_BANK_ID;?>" <?php
            if($value->KPS_BANK_ID==$data->KPS_BANK_ID){
              echo "selected=''";
            }
            ?>><?php echo $value->BANK_NAME; ?></option>
                <?php } ?>  
            </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Branch</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="BRANCHES" value="<?php echo $data->BRANCHES;?>">
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">Account No</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="ACCOUNT_NO" value="<?php echo $data->ACCOUNT_NO;?>">
          <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_FINANCE_BANK_ID;?>">
          <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Currency</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="CURRENCY" value="<?php echo $data->CURRENCY;?>">
      </div>
    </div>  
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>