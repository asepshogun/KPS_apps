<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Material</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
				<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/breakdown_cost/addSub/kps_breakdown_cost_material">
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Material</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="MATERIAL" placeholder="material">
				          	<input type="hidden" class="form-control" name="KPS_BREAKDOWN_COST_ID" value="<?php echo $KPS_BREAKDOWN_COST_ID; ?>"/>
				          </div>
				        </div>
	              		<div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Netto</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="QTY_NETTO" placeholder="quantity netto">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Quantity Brutto</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="QTY_BRUTTO" placeholder="quantity brutto">
				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">Material Price</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="PRICE" placeholder="material price">
				          </div>
				        </div>
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Country</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="COUNTRY" placeholder="Country">
				          </div>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="submit" class="btn bg-olive btn-flat pull-right">Save Material</button>
				        </div>
				        <div class="col-lg-6" align="center">
				        	<button type="reset" class="btn btn-danger btn-flat pull-left">Refresh Material</button>
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="breakdown_material" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Material</th>
	        <th>QTY Netto</th>
	        <th>QTY Brutto</th>
	        <th>Price</th>
	        <th>Sub Total</th>
	        <th>Country</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=0; foreach ($material as $value) {$no++ ?>
		      <tr>
		        <td><?php echo $no;?></td>
		        <td><?php echo $value->MATERIAL;?></td>
		        <td><?php echo $value->QTY_NETTO;?></td>
		        <td><?php echo $value->QTY_BRUTTO;?></td>
		        <td><?php echo $value->PRICE;?></td>      
		        <td><?php echo $value->SUB_TOTAL;?></td> 
		        <td><?php echo $value->COUNTRY;?></td>
		         <td><a href="" url="<?php echo site_url()."/breakdown_cost/editDetail/".$value->KPS_BREAKDOWN_COST_MATERIAL_ID."/edit_breakdown_material/kps_breakdown_cost_material/KPS_BREAKDOWN_COST_MATERIAL_ID";?>" data-toggle="modal" data-target="#updatemat" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>

	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatemat" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->