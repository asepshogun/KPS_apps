<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Schedule Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/request_quotation/updateDetail/kps_rfq_schedule/KPS_RFQ_SCHEDULE_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
       <input type="text" class="form-control" name="MODEL" value="<?php echo $data->MODEL;?>" readonly>
        
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">PP1</label>
      <div class="col-lg-9">
        <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="PP1" value="<?php echo $data->PP1;?>">

         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_SCHEDULE_ID;?>">
        <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $data->KPS_RFQ_ID;?>">

        
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Sample Masspro</label>
      <div class="col-lg-9">
        <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="SAMPLE_MASSPRO" value="<?php echo $data->SAMPLE_MASSPRO;?>" >
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Masspro</label>
      <div class="col-lg-9">
        <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="MASSPRO" value="<?php echo $data->MASSPRO;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>