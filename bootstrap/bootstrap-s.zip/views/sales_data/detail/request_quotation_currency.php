<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Currency</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/request_quotation/addSub/kps_rfq_currency">
			  		<div class="col-lg-6">
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Currency Name</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="CURRENCY_NAME" placeholder="currency name">
				            	<input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $id; ?>">

				          </div>
				        </div>
			  		</div>
			  		<div class="col-lg-6">
			  			<div class="form-group">
				          <label class="col-lg-3 control-label">To IDR</label>
				          <div class="col-lg-9">
				            <input type="text" class="form-control" name="TO_IDR" placeholder="idr">
				          </div>
				        </div>				        				        
			  		</div>
			        <div class="col-lg-3" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save CUrrency" />
				        </div>
				        <div class="col-lg-3" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form CUrrency" />
				        </div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="rfq_detail_currency" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Currency Name</th>
	        <th>To IDR</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($curr as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->CURRENCY_NAME;?></td>
		        <td><?php echo $value->TO_IDR;?></td>
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_RFQ_CURENCY_ID."/edit_request_quotation_currency"."/kps_rfq_currency/KPS_RFQ_CURENCY_ID";?>" data-toggle="modal" data-target="#updatecurr" class="update-link">Update</a></td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatecurr" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->