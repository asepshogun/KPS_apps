<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Depreciation Detail</h4>
</div>
<div class="modal-body">
 
	<form action="<?php echo site_url()."/breakdown_cost/updateDetail/kps_breakdown_cost_depreciation/KPS_BREAKDOWN_COST_DEPRECIATION_ID";?>" method="POST" class="form-horizontal">    
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>                     
      <div class="col-lg-9">
         <select name="model" class="form-control select2" id="edmodel" url="<?php echo site_url(); ?>/breakdown_cost/loadProd" style="width: 100%">
              <option value="0">-- Select Model --</option>
              <?php foreach ($pp as $value) { ?>
                <option value="<?php echo $value->MODEL;?>" <?php
            if($value->MODEL==$data->model){
              echo "selected=''";
            }
            ?>><?php echo $value->MODEL; ?></option>
                <?php } ?>  
            </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Unit</label>
      <div class="col-lg-9">
        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_DEPRECIATION_ID;?>">
        <input type="hidden" class="form-control" name="idRef" value="<?php echo $data->KPS_BREAKDOWN_COST_ID;?>">

        <input type="text" class="form-control" id="edqty_unit"  name="qty_unit" value="<?php echo $data->qty_unit;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Month</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" id="edqty_month"  name="qty_month" value="<?php echo $data->qty_month;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Periode</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" id="edperiode"  name="periode" value="<?php echo $data->periode;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>