<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Main Customer Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/customer_information/updateDetail/kps_customer_main_customer/KPS_CUSTOMER_MAIN_CUSTOMER_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Company Name</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->COMPANY_NAME;?>">
      </div>
    </div>              
    <div class="form-group">
      <label class="col-lg-3 control-label">Location</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="LOCATION" value="<?php echo $data->LOCATION;?>">
             <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_MAIN_CUSTOMER_ID;?>">
        <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $data->KPS_CUSTOMER_ID;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Busibness Content</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="BUSINESS_CONTENT" value="<?php echo $data->BUSINESS_CONTENT;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>     			      	
  </form>	        	    			      		        
</div>