<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are you sure want delete this item </h4>
</div>
<div class="modal-body">
	<h4>Mr/Mrs. <?php echo $this->session->userdata('name') ?> </h4><br/>
	<h4>Are You Sure Want To Unlock This Item To Delete And Create New Invoice Number ?</h4><br/>
	<form action="<?php echo site_url()."/invoice/unlockDelChangeNumberInvoice";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Unlock By</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="PREPARED_INVOs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="KPS_INVOICE_APP_DELETE_CHANGE_NUMBER" value="<?php echo $this->session->userdata('employeeId'); ?>">
			<input type="hidden" class="form-control" name="KPS_INVOICE_ID" value="<?php echo $data->KPS_INVOICE_ID; ?>">
			<input type="hidden" class="form-control" name="INVOICE_INDUK_ID_inv" value="<?php echo $data->INVOICE_INDUK_ID_inv; ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">YES</button>
		  </div>
		</div>	
	</form>
</div>