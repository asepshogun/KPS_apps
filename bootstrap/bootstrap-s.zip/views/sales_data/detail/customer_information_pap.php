<div class="box-body">
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Add Name For Personal Payment</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>			            
            <div class="box-body">
            	<form class="form-horizontal" method="POST" action="<?php echo site_url(); ?>/customer_information/addSub/kps_customer_personal_payment">
			  		<div class="col-lg-6">			  						  			
				        <div class="form-group">
				          <label class="col-lg-3 control-label">Name</label>
				          <div class="col-lg-9">
				            <input type="text"class="form-control" name="KPS_PAP_NAME" placeholder="Name" >
				               <input type="hidden" class="form-control" name="KPS_CUSTOMER_ID" value="<?php echo $customerId; ?>" placeholder="Customer">
				          </div>
				        </div>
						 <div class="col-lg-6" align="center">
				        	<input type="submit" class="btn bg-olive btn-flat pull-right" value="Save Name" />
				        </div>
				        <div class="col-lg-6" align="center">
				        	<input type="reset" class="btn btn-danger btn-flat pull-left" value="Clear Form Name" />
				        </div>
			  		</div>
			  	</form>			              
            </div>			            
        </div>
    </div>
</div>

<!--TABLE-->
<div class="box-body">
	<table id="customer_iso" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
	    <thead>
	      <tr>
	        <th>No</th>
	        <th>Name</th>
	        <th>Update</th>	
	      </tr>
	    </thead>
	    <tbody>
	    	<?php $no=1; foreach ($pap as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->KPS_PAP_NAME;?></td>
		        <td><a href="" url="<?php echo site_url()."/customer_information/editDetail/".$value->KPS_CUSTOMER_PAP_ID."/edit_customer_information_pap"."/kps_customer_personal_payment/KPS_CUSTOMER_PAP_ID";?>" data-toggle="modal" data-target="#updatepap" class="update-link">Update</a>
		       	</td>
		      </tr>
	      <?php } ?>
	    </tbody>
	</table>
</div>
<!--TABLE-->

<!-- Modal UPDATE-->
<div class="modal fade" id="updatepap" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->