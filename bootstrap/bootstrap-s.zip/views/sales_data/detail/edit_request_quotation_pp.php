<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Production Plan Detail</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/request_quotation/updateDetail/kps_rfq_production_plan/KPS_RFQ_PRODUCTION_PLAN_ID";?>" method="POST" class="form-horizontal">
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="MODEL" value="<?php echo $data->MODEL;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Unit</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QTY_UNIT" value="<?php echo $data->QTY_UNIT;?>">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Quantity Month</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="QTY_MONTH" value="<?php echo $data->QTY_MONTH;?>">
         <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_PRODUCTION_PLAN_ID;?>">
        <input type="hidden" class="form-control" name="KPS_RFQ_ID" value="<?php echo $data->KPS_RFQ_ID;?>">

        
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Periode</label>
      <div class="col-lg-9">
        <input type="text" class="form-control datepicker" name="PERIODE" value="<?php echo $data->PERIODE;?>">
      </div>
    </div>
    <div class="form-group">              
      <div class="col-sm-12">
        <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
      </div>
    </div>         			      	
  </form>	        	    			      		        
</div>