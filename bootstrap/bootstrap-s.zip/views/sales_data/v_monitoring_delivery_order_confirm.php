<section class="content-header">
	<h3>Delivery Order</h3>
	<small>Surat Jalan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="delivery" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th></th>
		        <th colspan=4>Delivery Order</th>

		        <th colspan=2>PO</th>
		        <th colspan=2>OS</th>
		        <th></th>
		        <th colspan=2>Receive by Customer</th>
		        <th></th>
				<th></th>
		        <th></th>       
		      </tr>
			<tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>QTY</th>
		        <th>Units</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		         <th>Customer Name</th>
		        <th> Date</th>
		        <th>Decision</th>
		        <th>Problem</th>
		        <th>Note If NG</th>
		        <th>Status</th>      
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td><?php echo $value->KPS_DELIVERY_ORDER_DELIVERY_DATE;?></td>
			        <td><?php echo $value->NO_DO;?></td>
			        <td><?php echo $value->TOTAL_QTY;?></td>
			        <td><?php echo "uNIT";?></td>
			        <td><?php if($value->KPS_OS_ID_OGFG){
								$query = $this->db->query("select * from kps_order_sheet_detail 
									join kps_order_sheet on(kps_order_sheet.KPS_OS_ID=kps_order_sheet_detail.KPS_OS_ID_DETAIL)
									join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS)
									join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK)
									where KPS_OS_ID_DETAIL='".$value->KPS_OS_ID_OGFG."'");
								$datax = $query->result();
									foreach($datax as $valueOs){
										echo $valueOs->PO_OS_DATE_FROM_CUSTOMER;
									}								
								}else{
								echo $value->PO_OS_DATE_FROM_CUSTOMER;
								}
						?></td>
			        <td><?php if($value->KPS_OS_ID_OGFG){
								foreach($datax as $valueOs){
										echo $valueOs->PO_OS_NO_FROM_CUSTOMER;
								}
							}else {
								echo $value->PO_OS_NO_FROM_CUSTOMER;
							}
					?></td>
			        <td><?php if($value->KPS_OS_ID_OGFG){
								foreach($datax as $valueOs){
										echo $valueOs->KPS_OS_DN_DATE;
								}
							}else { echo "-";}	?></td>
					<td><?php if($value->KPS_OS_ID_OGFG){
								foreach($datax as $valueOs){
										echo $valueOs->KPS_OS_DN_NO;
								}
							}else { echo "-";}	?></td>
			        <td><?php if($value->KPS_OS_ID_OGFG){
								foreach($datax as $valueOs){
										echo $valueOs->COMPANY_NAME;
								}
							}else { echo $value->COMPANY_NAME;}?></td>
			        <td><?php echo $value->RECEIVED_DATE;?></td>
			        <td><?php echo $value->RECEIVED_DECISION;?></td>
			        <td><?php if($value->RECEIVED_DECISION == "OK"){
									echo "-";
								}else{
									echo $value->PROBLEM;
								}
					?></td>
			        <td><?php if($value->RECEIVED_DECISION == "OK"){
									echo "-";
								}else{
									echo $value->NOTE_IF_NG;
								}
					?></td>
			        <td><?php 
						if($value->RECEIVED_DECISION == "OK"){
						echo "CLOSE";
						}else{
						echo "OPEN";
						} ?>
							
					</td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>