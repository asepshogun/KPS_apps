<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Item ini tidak bisa di delete</h4>
</div>
<div class="modal-body">
	<h3>Item ini tidak bisa di delete kerena sudah digunakan di invoice no</h3><br>
	<h3>NO Invoice <?php echo $dataInvoice->NO_INVO; ?></h3><br>
	<h3>Tanggal Invoice <?php echo $dataInvoice->DATE_INVO; ?></h3> <br/>
	<h3>Jika ingin Menghapus Item ini Silahkan Hubungi Manager</h3> <br/>
</div>	
