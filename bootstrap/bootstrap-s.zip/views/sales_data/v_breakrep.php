<section class="content-header">
	<h3>Breakdown Quotation Report</h3>
	<small>Laporan Breakdown & Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		
		
		<!--TABLE-->
		<table id="breakrep" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		     <tr>
                <th rowspan="2">No</th>
                <th colspan="3">Breakdown Quotation</th>
                <th colspan="2">RFQ</th>
                <th colspan="2">Quotation</th>
                <th rowspan="2">Part Name</th>
                <th rowspan="2">Part No</th>
                <th rowspan="2">Model</th>
                <th rowspan="2">Customer Name</th>
                <th rowspan="2">Status</th>
            </tr>
            <tr>
                <th>Date</th>
                <th>No</th>
                <th>Rev No</th>
                <th>Date</th>
                <th>No</th>
                <th>Date</th>
                <th>No</th>
            </tr>
		    </thead>
		    <tfoot>
		    	<tr>
                    <th>No</th>
    		    	<th>Date</th>
                    <th>No</th>
                    <th>Rev No</th>
                    <th>Date</th>
                    <th>No</th>
                    <th>Date</th>
                    <th>No</th>
                    <th>Part Name</th>
                    <th>Part No</th>
                    <th>Model</th>
                    <th>Customer Name</th>
                    <th>Status</th>
            	</tr>
		    </tfoot>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
		    		<tr>
                        <td><?php echo $no;?></td>
		    	 	    <td><?php echo $value->DATE_BREAK;?></td>
                        <td><?php echo $value->NO_BREAK;?></td>
                        <td><?php echo $value->REV_NO_BREAK;?></td>
                        <td><?php echo $value->DATE_RFQ;?></td>
                        <td><?php echo $value->NO_RFQ;?></td>
                        <td><?php echo $value->DATE_QUO;?></td>
                        <td><?php echo $value->NO_QUO;?></td>
                        <td><?php echo $value->part_name;?></td>
                        <td><?php echo $value->part_no;?></td>
                        <td><?php echo $value->model;?></td>
                        <td><?php echo $value->COMPANY_NAME;?></td>
                        <td></td>
			     	</tr>
		      <?php } ?>
		    </tbody>
		    
		</table>
		<!--TABLE-->
	</div>


<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->