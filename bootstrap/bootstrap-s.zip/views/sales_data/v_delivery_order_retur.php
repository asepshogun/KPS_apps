<section class="content-header">
	<h3>Delivery Order Retur</h3>
	<small>Surat Jalan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="delivery_or" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Delivery Order Number</th>
		        <th>Delivery Order Date</th>
		         <th>Customer Name</th>
		         <th>No Retur From Customer</th>
		        <th>Vehicle No</th>
		        <th>Driver</th>
		        <th>Assistant</th>
		        <th>Made By</th>
		        <th>Approved by</th>
		        <th>Note </th>
		        <th>Update</th>		        
		        <th>Delete</th>		        
		   <!--     <th>Print</th> -->
		        <th>Print page</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td><?php echo $value->KPS_DO_RETUR_NO;?></td>
			        <td><?php echo $value->KPS_DO_RETUR_DATE;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_RETUR_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
					<td><?php 
						$query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->employee_driver_id."'");
			        	$data1 = mysql_fetch_array($query1);
			        	echo $data1['EMPLOYEE_NAME'];
			        	?>
					</td> 
					<td><?php echo $value->OUTGOING_RETUR_ASISTEN_DRIVER;?></td>
					<td><?php 
						$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_DO_RETUR_MADE_BY."'");
			        	$data2 = mysql_fetch_array($query2);
			        	echo $data2['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td><?php 
						$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_DO_RETUR_APPROVE_BY."'");
			        	$data2 = mysql_fetch_array($query2);
			        	echo $data2['EMPLOYEE_NAME'];
			        	?>
					</td>
			        <td><?php echo $value->KPS_DELIVERY_ORDER_NOTE;?></td>
			       <!-- <td><a href="" url="<?php // echo site_url()."/delivery_order/edit/".$value->KPS_DELIVERY_ORDER_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php // echo site_url()."/delivery_order/detail/".$value->KPS_DELIVERY_ORDER_ID;?>">Detail</a></td> -->
					<td></td>
					<td></td>
				<!-- <td><a href="" url="<?php echo site_url()."/delivery_order_retur/preprint/".$value->KPS_DELIVERY_ORDER_RETUR_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Print</a></td>-->
					<td><a href="<?php echo site_url()."/delivery_order_retur/preprint2/".$value->KPS_DELIVERY_ORDER_RETUR_ID;?>"  target="_blank">Print</a></td> 
				 </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Deliver Order</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Order Retur Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_order_retur/add";?>" method="POST" class="form-horizontal">
	    		<!--
				<div class="form-group">
	              <label class="col-sm-3 control-label">Company Name</label>
	              <div class="col-sm-9">
	                <select class="form-control select2" style="width: 100%;" urlcurr="<?php //echo site_url()."/delivery_order/loadOutgoing";?>" urldivisi="<?php //echo site_url()."/pesanan/loadDivisi";?>" id="custOutgoing" >           
					  <option>-- Select Company --</option>
					  <?php //foreach ($dataCust as $value) { ?>
					  <option value="<?php //echo $value->KPS_CUSTOMER_ID;?>"><?php //echo $value->COMPANY_NAME;?></option>
					  <?php// } ?>            
					</select>
	              </div>
	            </div> -->
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Outgoing Retur</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="outgoing" urldivisi="<?php echo site_url() ?>/delivery_order/loadPlant" name="OUTGOING_RETUR_PRODUCT_ID_DO">					  
					    <option>-- Select Outgoing Retur --</option>
					  		 <?php foreach ($data_out as $value) { ?>
						<option value="<?php echo $value->OUTGOING_RETUR_PRODUCT_ID;?>"><?php echo "No Outgoing Retur :". $value->OUTGOING_RETUR_PRODUCT_NO ."- No Retur :". $value->NO_RETUR_FROM_CUSTOMER; ?></option>
						  <?php } ?>  		  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_FAILEDs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="KPS_DO_RETUR_MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_DO_RETUR_APPROVE_BY">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <textarea type="text" class="form-control" name="KPS_DELIVERY_ORDER_NOTE" placeholder="Note"></textarea>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->