<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Outgoing Finished Good Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/outgoing_finished/update";?>" method="POST" class="form-horizontal">
	<div class="form-group">
              <label class="col-sm-3 control-label">Bukti Pesanan</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="KPS_BUKTI_PESANAN_ID_OGFG">           
              <option>-- Select Bukti Pesanan --</option>
              <?php foreach ($dataBukti as $value) { ?>
              <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>" <?php
            if($value->KPS_BUKTI_PESANAN_ID==$data->KPS_BUKTI_PESANAN_ID_OGFG){
              echo "selected=''";
            }
            ?>><?php echo $value->REV_NO_BP;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">KPS Vehicle</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="KPS_VEHICLE_ID">            
              <option>-- Select Vehicle --</option>
              <?php foreach ($dataVeh as $value) { ?>
              <option value="<?php echo $value->KPS_VEHICLE_ID;?>" <?php
            if($value->KPS_VEHICLE_ID==$data->KPS_VEHICLE_ID){
              echo "selected=''";
            }
            ?>><?php echo $value->VEHICLE_NO;?> - <?php echo $value->VEHICLE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Driver</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_driver_id">            
              <option>-- Select Driver --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_driver_id){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="CHECKED">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->CHECKED){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Delivery Date</label>
              <div class="col-sm-9">
                <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DELIVERY_DATE" placeholder="Pick Date" value="<?php echo $data->DELIVERY_DATE ?>">
              </div>
                <input type="hidden" class="form-control" name="id" placeholder="Pick Date" value="<?php echo $data->KPS_OUTGOING_FINISHED_GOOD_ID ?>">
                <input type="hidden" class="form-control" name="revisi_no_ogfg" value="<?php echo $data->revisi_no_ogfg ?>">
            </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
              </div>
            </div>	      	
    </form>	        	    			      		        
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>