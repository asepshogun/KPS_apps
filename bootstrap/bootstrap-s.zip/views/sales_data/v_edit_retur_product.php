<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Order Data</h4>
</div>

	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/retur_product/update";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" placeholder="No Retur From Customer" value="<?php echo $data->NO_RETUR_FROM_CUSTOMER; ?>">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Date Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DATE_RETUR_CUSTOMER" placeholder="Pick Date" value="<?php echo $data->DATE_RETUR_CUSTOMER; ?>">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Company Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" urldivisi="<?php echo site_url() ?>/pesanan/loadDivisi" id="divisiPesanan"  name="KPS_CUSTOMER_ID_RETUR" disabled>					  
					    <option>-- Select Company --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"<?php 
					    if($value->KPS_CUSTOMER_ID==$data->KPS_CUSTOMER_ID)
		                echo "selected=''";
		               ?>><?php echo $value->COMPANY_NAME;?></option>
		              <?php } ?>    			  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">PPIC DUE Date</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DUE_DATE_PPIC" placeholder="Pick Date" value="<?php echo $data->DUE_DATE_PPIC; ?>">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Customer DUE Date</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DUE_DATE_CUSTOMER" placeholder="Pick Date" value="<?php echo $data->DUE_DATE_CUSTOMER; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">No DO</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_DELIVERY_ORDER_ID_RETUR" disabled>					  
					    <option>-- Select No DO --</option>
					    <?php foreach ($dataDO as $value) { ?>
					    <option value="<?php echo $value->KPS_DELIVERY_ORDER_ID;?>"<?php 
					    if($value->KPS_DELIVERY_ORDER_ID==$data->KPS_DELIVERY_ORDER_ID)
		                echo "selected=''";
		               ?>><?php echo $value->NO_DO;?></option>
		              <?php } ?> 	  
					</select>
		          </div>
		        </div>
				<div class="form-group">
				  <label class="col-sm-3 control-label">Made By</label>
				  <div class="col-sm-9">
					 <input type="text" class="form-control" name="MADE_BY_RBs" disabled value="<?php echo $this->session->userdata('name') ?>" value="<?php echo $data->MADE_BY_RB; ?>">
					<input type="hidden" class="form-control" name="MADE_BY_RB" value="<?php echo $this->session->userdata('employeeId'); ?>">
					<input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RETUR_BARANG_ID; ?>">
				  </div>
				</div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Sales Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED_SALES">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"<?php 
					    if($value->KPS_EMPLOYEE_ID==$data->CHECKED_SALES)
		                echo "selected=''";
		               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
		              <?php } ?> 				  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">QC Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHCEKED_QC">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"<?php 
					    if($value->KPS_EMPLOYEE_ID==$data->CHCEKED_QC)
		                echo "selected=''";
		               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
		              <?php } ?> 						  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Knowed Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KNOWED">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"<?php 
					    if($value->KPS_EMPLOYEE_ID==$data->KNOWED)
		                echo "selected=''";
		               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
		              <?php } ?> 					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Approved Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="APPROVED">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"<?php 
					    if($value->KPS_EMPLOYEE_ID==$data->APPROVED)
		                echo "selected=''";
		               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
		              <?php } ?> 				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    
	    </div>
	 
<!-- Modal ADD -->