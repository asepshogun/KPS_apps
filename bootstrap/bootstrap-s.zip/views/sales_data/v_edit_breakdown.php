<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Breakdown Cost Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/breakdown_cost/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
          <label class="col-sm-3 control-label">Request for Quotation</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_ID_BREAK">           
              <option>-- Select RFQ --</option>
              <?php foreach ($dataRFQ as $value) { ?>
              <option value="<?php echo $value->KPS_RFQ_ID;?>" <?php if($value->KPS_RFQ_ID==$data->KPS_RFQ_ID_BREAK){
              echo "selected=''";
            } ?>><?php echo $value->NO_RFQ;?></option>
              <?php } ?>            
          </select>   				  
			   		  
			</select>
          </div>
        </div>
        <div class="form-group">
			<label class="col-sm-3 control-label">Customer Respond</label>
			<div class="col-sm-9">						
              <div class="radio">
                <label>
                  <input type="radio" name="CUSTOMER_RESPOND" value="1">
                  1 (Satu)
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="CUSTOMER_RESPOND" value="2">
                  2 (Dua)
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="CUSTOMER_RESPOND" value="3">
                  3 (Tiga)
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="CUSTOMER_RESPOND" value="4">
                  4 (Empat)
                </label>
              </div>		                
			</div>
		</div>
		<div class="form-group">
          <label class="col-sm-3 control-label">Prod Pred Lead Time</label>
          <div class="col-sm-7">
          <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BREAKDOWN_COST_ID ?>">
          <input type="hidden" class="form-control" name="revisi_no_break" value="<?php echo $data->revisi_no_break ?>">
          <input type="text" class="form-control" name="PROD_PREP_LEAD_TIME" value="<?php echo $data->PROD_PREP_LEAD_TIME ?>">
          </div>
          <label class="col-sm-2 control-label" style="text-align:left;">weeks</label>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Packing Charge</label>
          <div class="col-sm-7">
            <input type="text" class="form-control" name="packing_charge" value="<?php echo $data->packing_charge ?>">
          </div>
          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Transportation Charge</label>
          <div class="col-sm-7">
            <input type="text" class="form-control" name="transportation_charge" value="<?php echo $data->transportation_charge ?>">
          </div>
          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Overhead Profit</label>
          <div class="col-sm-7">
            <input type="text" class="form-control" name="overhead_profit" value="<?php echo $data->overhead_profit ?>">
          </div>
          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Breakdown Made By</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="MADE_BY_BREAK" disabled value="<?php echo $this->session->userdata('username') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Breakdown Checked By</label>
          <div class="col-sm-9">
              <select class="form-control select2" style="width: 100%;" name="CHECKED_BREAK">           
              <option>-- Select Checked --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->CHECKED_BREAK){
              echo "selected=''";
            } ?>><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>		  
			    				  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Breakdown Calculated By</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="CALCULATED_BREAK">           
              <option>-- Select Checked --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->CALCULATED_BREAK){
              echo "selected=''";
            } ?>><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>     	  
			    			  
			</select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Breakdown Approved By</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="APPROVED_BREAK">           
              <option>-- Select Checked --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->APPROVED_BREAK){
              echo "selected=''";
            } ?>><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>   		  
			    				  
			</select>
          </div>
        </div>
        <div class="form-group">		          
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>			      	
    </form>	        	    			      		        
</div>