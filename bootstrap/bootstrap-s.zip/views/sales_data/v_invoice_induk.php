<section class="content-header">
	<h3>Invoice</h3>
	<small>invoice</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="invoice" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Rev No</th>
		        <th>Invoice Induk Number</th>
		        <th>Invoice Induk Date</th>
		       <!-- <th>PO Number</th>
		        <th>PO Date</th> -->
		        <th>Company Name</th>
		        <th>Adress</th>
		        <th>Currency</th>
		        <th>Made By</th>	        
		        <th>Total Term(%)</th>
		        <th>Total Sudah Terbayar(Currency)</th>
		        <th>Total Pembayaran(Currency)</th>
		        <th>Insert Detail DO</th>
		        <th>Get No Invoice</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->revisi_no_inv;?></td>
			        <td><?php echo $value->INVOICE_INDUK_NO;?></td>
			        <td><?php echo $value->INVOICE_INDUK_DATE;?></td>
			      <!--  <td><?php //echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php //echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>-->
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->PLANT;?></td>
			        <td><?php echo "Belum TAhu";//$value->CURRENCY;?></td>
			        <td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_INVOICE_INDUK_MADE_BY	."'");
			        	$data = mysql_fetch_array($query);
			        	echo $data['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php echo $value->TOTAL_TERM;?></td>
			        <td><?php echo $value->TOTAL_TERBAYAR;?></td>
			        <td><?php echo $value->TOTAL_PEMBAYARAN;?></td>
			        <td><a href="<?php echo site_url()."/invoice/detail/".$value->INVOICE_INDUK_ID ."/". $value->KPS_CUSTOMER_ID_INDK;?>" class="btn btn-primary btn-sm">Insert</a></td>
			        <td><a href="<?php echo site_url()."/invoice/index_detail_do/".$value->INVOICE_INDUK_ID;?>" class="btn btn-success btn-sm <?php if($value->status_inv_do==0){
		echo "disabled";
			    }else{
			        		echo "";
			        		}?>">Get</a></td>
			       
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Invoice Induk</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Invoice Induk Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/invoice/add_invoice_induk/" . $statusTx;?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Company Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" url="<?php echo site_url()."/invoice/loadBuktiPesanan";?>" id="comschedule" style="width: 100%;" name="KPS_CUSTOMER_ID_INDK">					  
					    <option>-- Select Company --</option>
					    <?php foreach ($dataCom as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				 <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_FAILEDs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="KPS_INVOICE_INDUK_MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->
<!-- Modal UPDATE-->
<div class="modal fade" id="term" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->
