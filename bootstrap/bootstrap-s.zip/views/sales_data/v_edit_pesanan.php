<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Bukti Pesanan Data</h4>
</div>
<div class="modal-body">
        <form action="<?php echo site_url()."/pesanan/update";?>" method="POST" class="form-horizontal">
          <div class="form-group">
              <label class="col-sm-3 control-label">Company Name</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" urldivisi="<?php echo site_url() ?>/pesanan/loadDivisi" id="divisiPesanans"  name="KPS_CUSTOMER_ID_BK">            
              <option>-- Select Company --</option>
              <?php foreach ($dataCust as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_ID;?>" <?php
            if($value->KPS_CUSTOMER_ID==$data->KPS_CUSTOMER_ID_BK){
              echo "selected=''";
            }
            ?>><?php echo $value->COMPANY_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Customer Divisi</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;"  id="EQKPS_CUSTOMER_DIVISI_BKs" name="KPS_CUSTOMER_DIVISI_ID_BK">            
              <option>-- Select Divisi --</option>
                     <?php foreach ($dataDivisi as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_DIVISI_ID;?>" <?php
            if($value->KPS_CUSTOMER_DIVISI_ID==$data->KPS_CUSTOMER_DIVISI_ID_BK){
              echo "selected=''";
            }
            ?>><?php echo $value->DIVISI;?></option>
              <?php } ?>      
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">KPS Currency</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" value="<?php echo $data->CURRENCY; ?>" readonly>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_approved_id">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_approved_id){
              echo "selected=''";
            }
            ?>> <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">PO Number Customer</label>
              <div class="col-sm-9">
              <input type="text" class="form-control" name="PO_OS_NO_FROM_CUSTOMER" value="<?php echo $data->PO_OS_NO_FROM_CUSTOMER; ?>">
                <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_BUKTI_PESANAN_ID; ?>">
                <input type="hidden" class="form-control" name="revisi_no_bp" value="<?php echo $data->revisi_no_bp; ?>">
                                    
              </div>
            </div>
           
            <div class="form-group">
          <label class="col-sm-3 control-label">Status Verifikasi</label>
          <div class="col-sm-9">            
                    <div class="radio">
                      <label>
                        <input type="radio" name="KPS_BP_STATUS_VERIFIKASI_CUSTOMER" value="OK">
                        OK
                      </label>
                    </div>
                    <div class="radio">
                      <label>
                        <input type="radio" name="KPS_BP_STATUS_VERIFIKASI_CUSTOMER" value="Not Good">
                        Not Good
                      </label>
                    </div>                    
          </div>
        </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
              </div>
            </div>              
          </form>                                       
      
      </div>
      <script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>