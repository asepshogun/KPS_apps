
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<!--Di betulkan di revisiRetur.js-->
		<table id="invoice_detail_no"  class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Invoice Number KPS</th>
		        <th>Invoice Number Faktur</th>
		        <th>Invoice Date</th>
<!--		    <th>PO Number</th>
		        <th>PO Date</th>
				<th>Company Name</th>
		        <th>Adress</th> 
		        <th>Currency</th>-->
		        <th>Employee Prepared</th>	        
		        <th>Employee Checked</th>		        
		        <th>Employee Approved</th>
		        <th>Total Qty</th>
		        <th>Amount (Currency)</th>
		        <th>DP</th>
		        <th>VAT (10%)</th>
		        <th>Total (Curreny)</th>
		        <th>Term</th>
		        <th>Nomor Invoice Pengganti</th>
		        <th>Confirm View</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			       
			        <td><?php echo $no?></td>
			        <td><?php echo $value->NO_INVO;?></td>
			        <td><?php echo $value->KPS_NO_INVOICE_FAKTUR_PAJAK;?></td>
			        <td><?php echo $value->DATE_INVO;?></td>
			      	<!--  <td><?php// echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php //echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
					<td><?php //echo $value->COMPANY_NAME;?></td>
			        <td><?php// echo $value->PLANT;?></td> 
			        <td><?php //echo $value->CURRENCY;?></td>-->
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->PREPARED_INVO."'");
			        	$dataEmp = mysql_fetch_array($query);
			        	echo $dataEmp['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php 
			      	$query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHECKED_INVO."'");
			        	$dataEmp1 = mysql_fetch_array($query1);
			        	echo $dataEmp1['EMPLOYEE_NAME'];
			        	
			        	?></td>
			        <td><?php 
			        			        	$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->APPROVED_INVO."'");
			        	$dataEmp2 = mysql_fetch_array($query2);
			        	echo $dataEmp2['EMPLOYEE_NAME'];
			        	?></td>
			        <td><?php echo $value->total_qty;?></td>
			        <td><?php echo $value->total_amount;?></td>
			        <td><?php echo $value->total_amount*($value->KPS_INVOICE_DP/100);?></td>
			        <td><?php echo 0.1*($value->total_amount*($value->KPS_INVOICE_DP/100));?></td>
			        <td><?php echo $value->total_amount*($value->KPS_INVOICE_DP/100)+(0.1*($value->total_amount*($value->KPS_INVOICE_DP/100)));?></td>
			        <td><?php echo $value->KPS_INVOICE_DP;?>%</td>
			        <td><?php if($value->KPS_INVOICE_NOMOR_PENGGANTI){ 
					echo $value->KPS_INVOICE_NOMOR_PENGGANTI;
					}else{
					echo "-";
					}?></td>
			        <td><a href="<?php echo site_url()."/invoice/confirm_view/".$value->KPS_INVOICE_ID_;?>" class="btn btn-default btn-sm"><i class="fa fa-print"></i>Confirm</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Invoice</button>
	</div>
</div>