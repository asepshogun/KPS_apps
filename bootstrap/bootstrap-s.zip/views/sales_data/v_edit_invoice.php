<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Invoice Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/invoice/update";?>" method="POST" class="form-horizontal">
		  <div class="form-group">
              <label class="col-sm-3 control-label">Company Name</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="customer_id">           
              <option>-- Select Company --</option>
              <?php foreach ($dataCom as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_ID;?>" <?php
            if($value->KPS_CUSTOMER_ID==$data->customer_id){
              echo "selected=''";
            }
            ?>><?php echo $value->COMPANY_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Invoice Type</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="invoice_type_id">           
              <option>-- Select Invoice Type --</option>
              <?php foreach ($dataType as $value) { ?>
              <option value="<?php echo $value->id;?>" <?php
            if($value->id==$data->invoice_type_id){
              echo "selected=''";
            }
            ?>><?php echo $value->type_name;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Prepared By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="PREPARED_INVO">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->PREPARED_INVO){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="CHECKED_INVO">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->CHECKED_INVO){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="APPROVED_INVO">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->APPROVED_INVO){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <input type="hidden" name="id" value="<?php echo $data->KPS_INVOICE_ID; ?>"></input>
                <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
              </div>
            </div>    	      	
    </form>	        	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>