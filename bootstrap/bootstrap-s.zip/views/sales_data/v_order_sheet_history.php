<section class="content-header">
	<h3>Order Sheet</h3>
	<small>Lembar Pemesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	
	<!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">Order Sheet</a></li>
                  <li><a href="#tab_2" data-toggle="tab">Order Sheet Pending</a></li>
                  <li><a href="#tab_3" data-toggle="tab">Return Order Sheet Pending</a></li>
                  
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                  <div class="box-body">
                    <!--TABLE-->
					<table id="os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
					        <th>Update by</th>
					        <th>Update Date</th>
					        <th>LOCK</th>
					        <th>Order Sheet Date</th>
					        <th>Order Sheet No</th>
					        <th>Order Sheet Rev No</th>
					        <th>Customer Name</th>
					        <th>Divisi Name</th>
					        <th>Adress</th>
					        <th>Schedule Delivery Date</th>
					        <th>Schedule Delivery Time</th>
					        <th>Delivery Place</th>
					        <th>Printed Date</th>	        
					        <th>OS/DN Date</th>		        
					        <th>OS/DN NO</th>		
							<th>Note</th>		        
					        <th>Approved</th>		        
					        <th>Made By</th>		              
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($data as $value) {$no++ ?>
						      <tr>
						        <td><?php echo $no;?></td>
								 <td><?php
						      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->UPDATE_BY_OS."'")->first_row();
						      		echo $q2->EMPLOYEE_NAME; ?></td> 
								 <td><?php echo $value->UPDATE_TIME;?></td>
						        <td>
						        <?php 
						        	if($value->status_os=="0"){
						        		?> 
						        		<center><span class="label label-info">Unlock</span></center>
						        		<?php
						        	}else{
						        	?> 
						        		<center><span class="label label-danger">lock</span></center>
						        	<?php	
						        	}
						        ?>
						        </td>
						        <td><?php echo $value->KPS_OS_CREATION_DATE;?></td>
						        <td><?php echo $value->KPS_OS_NO;?></td>
						        <td><?php echo $value->KPS_OS_REV_NO;?></td>
						        <td><?php echo $value->COMPANY_NAME;?></td>
						        <td><?php echo $value->DIVISI;?></td>
						        <td>
						        <?php
						      		$q3 = $this->db->query("SELECT * FROM `kps_customer_plant` WHERE KPS_CUSTOMER_ID = '".$value->KPS_CUSTOMER_ID."'")->first_row();
						      		echo $q3->PLANT;
						      	?>	
						      	</td>
						        <td><?php echo $value->KPS_OS_SCHEDULE_DELIVERY_DATE;?></td>
						        <td><?php echo $value->KPS_OS_SCHEDULE_DELIVERY_TIME;?></td>
						        <td><?php echo $value->PLANT1_CITY;?></td>
						        <td><?php echo $value->KPS_OS_PRINTED_DATE;?></td>
						        <td><?php echo $value->KPS_OS_DN_DATE;?></td>
						        <td><?php echo $value->KPS_OS_DN_NO;?></td>
								<td><?php echo $value->NOTE_OS;?></td>
								<td>
						        <?php
						      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_approved_id."'")->first_row();
						      		echo $q1->EMPLOYEE_NAME;
						      	?>	
						      	</td>
								<td>
						        <?php
						      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->MADE_BY_OS."'")->first_row();
						      		echo $q2->EMPLOYEE_NAME;
						      	?>	
						      	</td>  
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE-->
				</div>
</div>