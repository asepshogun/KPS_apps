<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Item (LOI) Data</h4>
</div>
<div class="modal-body">
  <form action="<?php echo site_url()."/item/update";?>" method="POST" class="form-horizontal">
    <!-- <div class="form-group">
          <label class="col-sm-3 control-label">Request for Quotation</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_ID_LOI">            
           <option>-- Select RFQ --</option>
              <?php// foreach ($dataRfq as $value) { ?>
              <option value="<?php //echo $value->KPS_RFQ_ID;?>" <?php
           // if($value->KPS_RFQ_ID==$data->KPS_RFQ_ID_LOI){
            //  echo "selected=''";
         //   }
            ?>><?php //echo $value->NO_RFQ;?></option>
              <?php //} ?>      
      </select>
          </div>
        </div>-->
        <div class="form-group">
          <label class="col-sm-3 control-label">RFQ NO</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" disabled value="<?php echo $data->NO_RFQ ?>" name="NO_RFQ">
       <input type="hidden" class="form-control" value="<?php echo $data->KPS_RFQ_ID_LOI ?>" name="KPS_RFQ_ID_LOI">
          </div>
        </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Code Product</label>
      <div class="col-lg-9">
      <input type="text" class="form-control" name="LOI_CODE_ITEM" value="<?php echo $data->LOI_CODE_ITEM ?>" placeholder="Code Product">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Number</label>
      <div class="col-lg-9">
      <input type="text" class="form-control" id="part_no" name="LOI_PART_NO" value="<?php echo $data->LOI_PART_NO ?>" placeholder="Part No">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Part Name</label>
      <div class="col-lg-9">
      <input type="text" class="form-control" id="part_name" name="LOI_PART_NAME" value="<?php echo $data->LOI_PART_NAME ?>" placeholder="Part Name">
      </div>
    </div>
    <div class="form-group">
      <label class="col-lg-3 control-label">Model</label>
      <div class="col-lg-9">
      <input type="text" class="form-control" id="model" name="LOI_MODEL"  value="<?php echo $data->LOI_MODEL ?>" placeholder="Model">
      </div>
    </div>
     <div class="form-group">
      <label class="col-lg-3 control-label">Product Classification</label>
      <div class="col-lg-9">
      <input type="text" class="form-control" name="LOI_PRODUCT_CLASIFICATION" value="<?php echo $data->LOI_PRODUCT_CLASIFICATION ?>" placeholder="Product Classification">
      </div>
    </div>  
    <div class="form-group">
      <label class="col-lg-3 control-label">Standard Packing</label>
      <div class="col-lg-9">
      <input type="number" class="form-control" name="LOI_STRANDART_PACKING" value="<?php echo $data->LOI_STRANDART_PACKING ?>" placeholder="Standard Packing">
      </div>
    </div>  
    <div class="form-group">
          <label class="col-sm-3 control-label">Die Go Number</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" value="<?php echo $data->LOI_DIE_GO_NO ?>" name="LOI_DIE_GO_NO">
            <input type="hidden" class="form-control" value="<?php echo $data->KPS_LOI_ID ?>" name="id">
            <input type="hidden" class="form-control" name="revisi_no_loi" value="<?php echo $data->revisi_no_loi ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Discontinue Date</label>
          <div class="col-sm-9">
            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control datepicker" value="<?php echo $data->DISCONTINUE_DATE ?>" name="DISCONTINUE_DATE">
          </div>
        </div>
        <div class="form-group">
              <label class="col-sm-3 control-label">Minimal Stock</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="MIN_STOK" value="<?php echo $data->MIN_STOK ?>" placeholder="min stock">
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Maximal Stock</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="MAX_STOCK" value="<?php echo $data->MAX_STOCK ?>" placeholder="max stock">
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="CHECKED_LOI">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->CHECKED_LOI){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">ACCEPTED By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="ACCEPTED_LOI">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->ACCEPTED_LOI){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="APPROVED_LOI">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->APPROVED_LOI){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">New Iten Note</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" name="NOTE" value="<?php echo $data->NOTE ?>" placeholder="note">
              </div>
            </div>
        <div class="form-group">              
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>              
    </form>                                       
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>