<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Pesanan</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Bukti Pesanan</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td><?php echo $detail->DATE_BP;?></td>
                </tr>
                <tr>
                  <th>No </th>
                  <td><?php echo $detail->REV_NO_BP;?></td>
                </tr>
                <tr>
                  <th>Rev No</th>
                  <td><?php echo $detail->revisi_no_bp; ?></td>
                </tr>
                <tr>
                  <th>PO / OS No From Customer</th>
                  <td><?php echo $detail->PO_OS_NO_FROM_CUSTOMER;?></td>
                </tr>
                <tr>
                  <th>PO / OS Date From Customer</th>
                  <td><?php echo $detail->PO_OS_DATE_FROM_CUSTOMER;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                <tr>
                  <th>Divisi</th>
                  <td><?php echo $detail->DIVISI;?></td>
                </tr>
                <tr>
                  <th>Marketing Name</th>
                  <td>
                    <?php 
                      $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->marketing_id."'");
                      $data1 = mysql_fetch_array($query1);
                      echo $data1['EMPLOYEE_NAME'];
                    ?> 
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">            
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <td colspan="2"><b><center>PT. Karya Putra Sangkuriang</center></b></td>
                </tr>
                <tr>
                  <th><center>Approved</center></th>
                  <th><center>Made By</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><br><br><br><br>
                   <?php 
                      $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->APPROVED_BP."'");
                      $data1 = mysql_fetch_array($query1);
                      echo $data1['EMPLOYEE_NAME'];
                    ?> 
                  </td>
                  <td><br><br><br><br>
                    <?php 
                      $query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->MADE_BY_BP."'");
                      $data2 = mysql_fetch_array($query2);
                      echo $data2['EMPLOYEE_NAME'];
                    ?>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th><center>Sales Head</center></th>
                  <th><center>Staff Staff</center></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th>No</th>
                  <th>No LOI</th>
                  <th>Code Product</th>
                  <th>Part No</th>
                  <th>Part Name</th>
                  <th>Model</th>
                  <th>Kanban PO No</th>
                  <th>QTY OS</th>
                  <th>Quantity</th>
                  <th>Units</th>
                  <th>Price</th>
                  <th>Amount</th>                  
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($detailx as $value) { ?>
                <tr>
                  <td><?php echo $no++;?></td>
                  <td><?php echo $value->NO_LOI;?></td>
                  <td><?php echo $value->LOI_CODE_ITEM;?></td> 
                  <td><?php echo $value->LOI_PART_NO;?></td>
                  <td><?php echo $value->LOI_PART_NAME;?></td>
                  <td><?php echo $value->LOI_MODEL;?></td> 
                  <td><?php echo $value->KANBAN_PO_NO;?></td>
                  <td><?php echo "";?></td>
                  <td><?php echo $value->QUANTITY;?></td>
                  <td><?php echo $value->unit;?></td>
                  <td><?php echo $value->price;?></td>
                  <td><?php echo $value->AMOUNT;?></td>                 
                </tr>
                <?php } ?>
                <tr>
                  <td colspan="10" rowspan="5"></td>
                  <th><center>Sub Total</center></th>
                  <td><?php echo $detail->SUB_TOTAL_BP;?></td>                  
                </tr>
                <tr>
                 
                  <th><center>Tax (10%)</center></th>
                  <td><?php echo $detail->TAX_BP;?></td>                  
                </tr>                
                <tr>
                  
                  <th><center>Total</center></th>
                  <td><?php echo $detail->TOTAL_BP;?></td>                  
                </tr>  
                <tr>
                  
                  <th colspan="2"><center>Verification Bukti Pesanan with Customer PO</center></th>             
                </tr>
                <tr>
                  
                  <?php 
                    if($detail->KPS_BP_STATUS_VERIFIKASI_CUSTOMER=="OK"){
                      ?> 
                      <th><center>OK</center></th>             
                      <?php
                    }else{
                      ?>
                      <th><center>NG</center></th>             
                      <?php
                    }
                  ?>

                </tr>
              </tbody>
            </table>
          </div>
        </div>       
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>
