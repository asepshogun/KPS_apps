<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>RFQ Print <?php echo $detail->NO_RFQ;?></title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">
    
  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div>
        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Request For Quotation</h2></center><br><br>
          </div><!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive ">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <th>Date</th>
                <td><?php echo $detail->DATE_RFQ;?></td>
              </tr>
              <tr>
                <th>No</th>
                <td><?php echo $detail->NO_RFQ;?></td>
              </tr>
              <tr>
                <th>Rev No</th>
                <td><?php echo $detail->REV_NO;?></td>
              </tr>
              <tr>
                <th>Customer Name</th>
                <td><?php echo $detail->COMPANY_NAME;?></td>
              </tr>
              <tr>
                <th>Receving RFQ Date</th>
                <td><?php echo $detail->RECEIVING_RFQ_DATE;?></td>
              </tr>
              <tr>
                <th>RFQ Customer Date</th>
                <td><?php echo $detail->RFQ_CUSTOMER_DATE;?></td>
              </tr>
              <tr>
                <th>RFQ Customer No</th>
                <td><?php echo $detail->RFQ_CUSTOMER_NO;?></td>
              </tr>
              <tr>
                <th>Due Date Quotation</th>
                <td><?php echo $detail->DUE_DATE_QUOTATION;?></td>
              </tr>
              <tr>
                <th>Estimation LOI Date</th>
                <td><?php echo $detail->ESTIMATION_LOI_DATE;?></td>
              </tr>
            </tbody>
             
            </table>
          </div><!-- /.col -->
          <div class="col-xs-6 table-responsive">
            <center>REVIEW & ESTIMATION NEW ITEM (ENGINEERING) CLICK</center> <br>
            <center>BREAKDOWN PRICE CLICK</center> <br>
            <table width="100%" class="table">
              <tr>
                <td>Customer Respond</td>
                <?php if($detail->RFQ_CUSTOMER_RESPOND == 1){

                  ?><td><input type="radio" name="group1" value="1" checked> 1</input></td>
                    <td><input type="radio" name="group1" value="1" > 2</input></td>
                    <td><input type="radio" name="group1" value="1" > 3</input></td><?php

                  }elseif($detail->RFQ_CUSTOMER_RESPOND == 2){

                  ?><td><input type="radio" name="group1" value="1" > 1</input></td>
                    <td><input type="radio" name="group1" value="2" checked> 2</input></td>
                    <td><input type="radio" name="group1" value="3" > 3</input></td><?php

                  }else{

                  ?><td><input type="radio" name="group1" value="1" > 1</input></td>
                    <td><input type="radio" name="group1" value="2" > 2</input></td>
                    <td><input type="radio" name="group1" value="3" checked> 3</input></td><?php

                  }?>
              </tr>
            </table>
            <table width="100%" class="table table-bordered">
              <thead>
                <tr>
                  <th colspan="3"><b><center> PT. Karya Putra Sangkuriang</center></b></th>
                </tr>
                <tr>
                  <th><center>Made by</center> </th>
                  <th><center>Checked by</center></th>
                  <th><center>Approved by</center></th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th><b><center>Sales Staff</center></b></th>
                  <th><b><center>Sales Head</center></b></th>
                  <th><b><center>Sales & Purchased</center></b></th>
                </tr>
              </tfoot>
              <tbody>
                <tr>
                <?php
                $q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->user_made_by_id_rfq."'")->first_row();
                
                $q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->employee_checked_by."'")->first_row();
                //echo $q2->EMPLOYEE_NAME;
                $q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->employee_approved_by."'")->first_row();
                //echo $q1->EMPLOYEE_NAME;
                ?>  
                  <td><?php echo $q1->EMPLOYEE_NAME;?></td>
                  <td><?php echo $q2->EMPLOYEE_NAME;?></td>
                  <td><?php echo $q3->EMPLOYEE_NAME;?></td>
                </tr>
              </tbody>
            </table>
            
          </div><!-- /.col -->
          
        </div><!-- /.row -->

        <!-- Table row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           1.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b> Drawing Reff</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           As per enclosed here<br>
           <table width="100%" class="table table-bordered">
             <tr>
               <th>No</th>
               <th>Part No</th>
               <th>Part Name</th>
               <th>QTY/Unit</th>
               <th>Unit</th>
             </tr>
             <?php $no=0; foreach ($drawing as $value) { $no++; ?>
             <tr>
             
               <td><?php echo $no;?></td>
               <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
               <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>
               <td><?php echo $value->KPS_RFQ_PART_QTY;?></td>
               <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>              
             </tr>
              <?php }?>
           </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           2.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b> Production Plan</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           
           <table width="100%" class="table table-bordered">
             <tr>
               <th>No</th>
               <th>Model</th>
               <th>QTY/Unit</th>
               <th>QTY/Month</th>
               <th>Periode</th>
             </tr>
             <?php $no=0; foreach ($pp as $value) { $no++; ?>
             <tr>
               
               <td><?php echo $no;?></td>
               <td><?php echo $value->MODEL;?></td>
               <td><?php echo $value->QTY_UNIT;?></td>
               <td><?php echo $value->QTY_MONTH;?></td>
               <td><?php echo $value->PERIODE;?></td> 
             </tr>
              <?php }?>
           </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           3.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b>Schedule</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           
           <table width="100%" class="table table-bordered">
             <tr>
               <th>No</th>
               <th>Model</th>
               <th>Sample</th>
               <th>PP1</th>
               <th>Masspro</th>
             </tr>
             <?php $no=0; foreach ($schedule as $value) { $no++; ?>
             <tr>
               
               <td><?php echo $no;?></td>
               <td><?php echo $value->MODEL;?></td>
               <td><?php echo $value->SAMPLE_MASSPRO;?></td>
               <td><?php echo $value->PP1;?></td>
               <td><?php echo $value->MASSPRO;?></td> 
             </tr>
             <?php }?>
           </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           4.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b>Target Price</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           
           <table width="100%" class="table table-bordered">
             <tr>
               <th rowspan="2">Target Price</th>
               <th colspan="2">Competitor 1</th>
               <th colspan="2">Competitor 2</th>
               <th colspan="2">Competitor 3</th>
             </tr>
             <tr>
               <th>Name</th>
               <th>Price (Rp)</th>
               <th>Name</th>
               <th>Price (Rp)</th>
               <th>Name</th>
               <th>Price (Rp)</th>
             </tr>
             <tr>
               <td><?php echo $detail->TARGET_PRICE?></td>
               <?php $no=0; foreach ($price as $value) { $no++; ?>
               
               <td><?php echo $value->COMPETITIOR_NAME;?></td>
               <td><?php echo $value->COMPETITIOR_PRICE;?></td>
               <?php }?>

             </tr>
           </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           6.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b>Tooling Cost</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           
           <table width="100%" class="table">
              <tr>
                  <?php if($detail->TOOLING_COST_RFQ == "Depreciation"){

                  ?><td><input type="radio" name="group2" value="1" checked> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Others</input></td><?php

                  }elseif($detail->TOOLING_COST_RFQ == "Not Depreciation"){

                  ?><td><input type="radio" name="group2" value="1"> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1" checked> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Others</input></td><?php

                  }else{

                  ?> <td><input type="radio" name="group2" value="1"> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1" checked> Others</input></td><?php

                  }?>

              </tr>
            </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-1 table-responsive">
           7.
          </div><!-- /.col -->
          <div class="col-xs-3 table-responsive">
           <b>Part Status</b>
          </div><!-- /.col -->
          <div class="col-xs-8 table-responsive">
           
           <table width="100%" class="table">
              <tr>
              <?php if($detail->PART_STATUS == 1){

                ?><td><input type="radio" name="group3" value="1" checked> New Project</input></td>
                <td><input type="radio" name="group3" value="11"> Localization</input></td>
                <td><input type="radio" name="group3" value="12"> Second Supplier</input></td><?php

                  }elseif($detail->PART_STATUS == 2){

                  ?><td><input type="radio" name="group3" value="13"> New Project</input></td>
                <td><input type="radio" name="group3" value="14" checked> Localization</input></td>
                <td><input type="radio" name="group3" value="15"> Second Supplier</input></td><?php

                  }else{

                  ?> <td><input type="radio" name="group3" value="16"> New Project</input></td>
                <td><input type="radio" name="group3" value="17"> Localization</input></td>
                <td><input type="radio" name="group3" value="18" checked> Second Supplier</input></td><?php

                  }?>
              </tr>
            </table>

          </div><!-- /.col -->
        </div><!-- /.row -->
        <div class="row">
          <div class="col-xs-12">
            <div class="panel panel-default">
              <div class="panel-body">
                <br><br><br><br>
              </div>
            </div>
          </div><!-- /.col -->
        </div>
        <!-- title row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->

  </body>
</html>