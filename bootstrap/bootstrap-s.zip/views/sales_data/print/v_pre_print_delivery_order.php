<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Delivery Order</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body> <!--onload="window.print();"-->
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Delivery Order</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
             <!--
				<tr>
                  <th>Outgoing Finished Good Date</th>
                  <td><?php// echo $detail->DATE_OUTGOING;?></td>
                </tr>
                <tr>
                  <th>Outgoing Finished Good No</th>
                  <td><?php// echo $detail->NO_OUTGOING;?></td>
                </tr>
				-->
                <tr>
                  <th>Input Date</th>
                  <td><?php $InputDate=strtotime($detail->DATE_DO);
							$echoInputDate = date( 'd-m-Y H:i:s', $InputDate );
							echo $echoInputDate;
				  ?></td>
                </tr>  
				<tr>
                  <th>Delivery Date</th>
				  <td>
					<?php
					if($detail->KPS_DELIVERY_ORDER_DELIVERY_DATE){
						$deliveryDate=strtotime($detail->KPS_DELIVERY_ORDER_DELIVERY_DATE); 
						$echoDeliveryDate = date( 'd-m-Y', $deliveryDate );
						echo $echoDeliveryDate;
					}else{
						echo "No setting date";
					}
					?>
					</td>
                </tr>
                <tr>
                  <th>No</th>
                  <td><?php echo $detail->NO_DO;?></td>
                </tr><tr>
                  <th>Rev No</th>
                  <td><?php echo $detail->revisi_no_do;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php 
						if($detail->KPS_OS_ID_OGFG){
							$query = $this->db->query("select * from kps_order_sheet 
								join kps_order_sheet_detail on(kps_order_sheet_detail.KPS_OS_ID_DETAIL=kps_order_sheet.KPS_OS_ID)
								join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS)
								join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK)
								where KPS_OS_ID='".$detail->KPS_OS_ID_OGFG."' GROUP BY KPS_CUSTOMER_ID");
							$datax = $query->result();
							foreach($datax as $valueCusOs){
								if($valueCusOs->KPS_BP_CUSTOMER_PAP_ID){
								$qPap = $this->db->query("SELECT * FROM `kps_customer_personal_payment` WHERE KPS_CUSTOMER_PAP_ID = '".$valueCusOs->KPS_BP_CUSTOMER_PAP_ID."'")->first_row();
								echo $qPap->KPS_PAP_NAME;
								}else{
								echo $valueCusOs->COMPANY_NAME;
								}
							}
						}else{
							if($detail->KPS_BP_CUSTOMER_PAP_ID){
							$qPap = $this->db->query("SELECT * FROM `kps_customer_personal_payment` WHERE KPS_CUSTOMER_PAP_ID = '".$detail->KPS_BP_CUSTOMER_PAP_ID."'")->first_row();
							echo $qPap->KPS_PAP_NAME;
							}else{
							echo $detail->COMPANY_NAME;
							}
						}
				  ?></td>
                </tr>
                <tr>
                  <th>Address</th>
                  <td><?php 
						// $query = $this->db->query("select * from kps_outgoing_finished_good_detail 
						  // join kps_delivery_schedule_detail on(kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD)
						  // join kps_customer_delivery_setup on(kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID)
						  // where KPS_OUTGOING_FINISHED_GOOD_ID_D='".$detail->KPS_OUTGOING_FINISHED_GOOD_ID_DO."'");
					// $datax = $query->first_row(); 
					// echo $datax->PLANT1_CITY;
					  ?>
			  <?php 
					$query = $this->db->query("select * from kps_outgoing_finished_good_detail 
						join kps_delivery_schedule_detail on(kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD)
						join kps_bukti_pesanan_detail on(kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD)
						join kps_loi on(kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK)
						join kps_delivery_schedule on(kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID)
						join kps_customer_delivery_setup on(kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID)
						where KPS_OUTGOING_FINISHED_GOOD_ID_D='".$detail->KPS_OUTGOING_FINISHED_GOOD_ID_DO."' GROUP BY PLANT1_CITY");
					$datax = $query->result();	
					$countDatax = count($datax);
					foreach($datax as $plant){
						if($countDatax>=2){
							echo $plant->PLANT1_CITY .":". $plant->NO_REV_NO ." Code Item :". $plant->LOI_CODE_ITEM  ."<br/>" ;
						}else{
						echo $plant->PLANT1_CITY;
						}
					}
				?>
			  </td>
                </tr>
				</table>
				</div>
				 <div class="col-xs-6 table-responsive">
				 <br/>
				 <?php
				 if($detail->KPS_OS_ID_OGFG){
							$query = $this->db->query("select * from kps_order_sheet 
								join kps_order_sheet_detail on(kps_order_sheet_detail.KPS_OS_ID_DETAIL=kps_order_sheet.KPS_OS_ID)
								join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS)
								join kps_customer on(kps_customer.KPS_CUSTOMER_ID=kps_bukti_pesanan.KPS_CUSTOMER_ID_BK)
								where KPS_OS_ID='".$detail->KPS_OS_ID_OGFG."' GROUP BY KPS_OS_ID");
							$datax = $query->result();}
				 ?>
				  <table width="100%" class="table table-bordered" style="padding-top:5px;">
                <tr>
					<?php if($detail->KPS_OS_ID_OGFG){ ?>
					  <th>OS Date</th>
					  <td><?php foreach($datax as $valueCusOs){
								echo $valueCusOs->KPS_OS_CREATION_DATE;
							}?></td>
					 <?php }else { ?>
					 <th>PO Date</th>
					  <td><?php echo $detail->PO_OS_DATE_FROM_CUSTOMER;?></td>
					  <?php } ?>
                </tr>
                <tr>
					<?php if($detail->KPS_OS_ID_OGFG){ ?>
					  <th>OS No</th>
					  <td><?php foreach($datax as $valueCusOs){
								echo $valueCusOs->KPS_OS_NO;
							}?></td>
					 <?php }else { ?>
					 <th>PO No</th>
					  <td><?php echo $detail->PO_OS_NO_FROM_CUSTOMER;?></td>
					  <?php } ?>
                </tr>
                <tr>
                  <th>Vehicle Name</th>
                  <td><?php echo $detail->VEHICLE_NAME;?></td>
                </tr>
                <tr>
                  <th>Vehicle No</th>
                  <td><?php echo $detail->VEHICLE_NO;?></td>
                </tr>
              </tbody>
            </table>
          </div>
          
        </div>
		<?php 
		// print_r($detail);
		?>
        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <th>No</th>
                <th>Code Product</th>
                <th>Part No</th>
                <th>Part Name</th>
                <th>Model</th>
                <th>QTY</th>
                <th>Unit</th>
                <th>Note</th>
              </thead>
              <tbody>
                <?php $no=1; foreach ($data as $value) { ?>
                <tr>
                  <!--DATA DISINI-->
                  <td><?php echo $no++;?></td>
                  <td><?php echo $value->LOI_CODE_ITEM;?></td> 
                  <td><?php echo $value->LOI_PART_NO;?></td>
                  <td><?php echo $value->LOI_PART_NAME;?></td>
                  <td><?php echo $value->LOI_MODEL;?></td> 
                  <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
                  <td><?php echo $value->unit;?></td>
                  <td><?php echo $value->NOTE;?></td>             
                </tr>
                <?php } ?>
                <tr>
                  <td colspan="4"></td>
                  <td>TOTAL</td>
                  <td><?php echo $detail->TOTAL_QTY;?></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>

            Note :
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tr>
                <td><?php echo $detail->NOTE_OGFG;?><br><br><br><br><br><br></td>
              </tr>
            </table>
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th colspan="1"><center><?php if($detail->KPS_BP_CUSTOMER_PAP_ID){
							$qPap = $this->db->query("SELECT * FROM `kps_customer_personal_payment` WHERE KPS_CUSTOMER_PAP_ID = '".$detail->KPS_BP_CUSTOMER_PAP_ID."'")->first_row();
							echo $qPap->KPS_PAP_NAME;
							}else{
							echo $detail->COMPANY_NAME;
							}
				  ?></center></th>
                  <th colspan="4" rowspan="2" ><font size=3px><center>PT. Karya Putra Sangkuriang</center></font></th>
                </tr>
                <tr>
                  <th colspan="1"><center>
					<?php 
					if($detail->KPS_CUSTOMER_DIVISI_ID_BK){
						$queryDivis = $this->db->query("select * from kps_customer_divisi 
						  where KPS_CUSTOMER_DIVISI_ID='".$detail->KPS_CUSTOMER_DIVISI_ID_BK."'");
					$dataDivisi = $queryDivis->first_row(); 
					echo "Divisi : ". $dataDivisi->DIVISI;
					  }else{
					  echo "Divisi";
					  }  ?>  </center></th>
                </tr>
                <tr>
                  <th><center>Accepted</center></th>
                  <th><center>Delivered</center></th>
                  <th><center>Made By</center></th>
                  <th><center>Approved By</center></th>
                  <th><center>Known By</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
					<td><br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<?php
						//$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->employee_accepted_id."'")->first_row();
					//	echo $q1->EMPLOYEE_NAME;?> 
					</td>
					<td>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
					<?php
						$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->user_made_by_id_do."'")->first_row();
						echo $q1->EMPLOYEE_NAME;?>  
					</td>
					<td><br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
					<?php
						$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->user_made_by_id_do."'")->first_row();
						echo $q1->EMPLOYEE_NAME;?>  
					</td>
					<td><br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
					<?php
						$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->employee_approved_id_DO."'")->first_row();
						echo $q1->EMPLOYEE_NAME;?>  	
					</td>
					<td><br/>
						<br/>
						<br/>
						<br/>
						<br/>
						<br/>
					<?php
						$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$detail->employee_known_id."'")->first_row();
						echo $q1->EMPLOYEE_NAME;?>  
					</td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th>&nbsp</th>
                  <th><center>Drive</center></th>
                  <th><center>Sales Staff</center></th>
                  <th><center>Sales Head</center></th>
                  <th><center>Finance Head</center></th>
                </tr>
              </tfoot>
            </table>
            <table width="100%">
              <tr>
                <td>White: Fakturing</td>
                <td>Green: Penjualan</td>
                <td>Yellow: PPICE</td>
                <td>Red 1: Customer</td>
                <td>Red 2: Finance</td>
                <td>Blue: Customer</td>
              </tr>
            </table>
          </div>
        </div>        
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>