<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>Customer Print</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">
    
  </head>
 <body >
 <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
		 <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div>
		 <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Customer List</h2></center><br><br>
          </div><!-- /.col -->
        </div>
		 <div class="row">
		  <div class="col-xs-12">
			<table id="cis" class="table table-bordered"  cellspacing="0" width="100%">
				<thead>
				  <tr>
					<th>No</th>
					<th>Code Customer</th>
					<th>Company Name</th>
					<th>Office</th>
					<th>Plant</th>
					<th>Office Contact</th> 
					
					<th>Contact Person</th>
				  </tr>
				</thead>
				<tbody>
					<?php $no=0; foreach ($data as $value) { $no++;
				
						$query = $this->db->query("select * from kps_customer_plant 
							where KPS_CUSTOMER_ID='".$value->KPS_CUSTOMER_ID."' ORDER BY KPS_CUSTOMER_PLANT_ID");
						$datax = $query->result();
						$query = $this->db->query("select * from kps_customer_plant 
							where KPS_CUSTOMER_ID='".$value->KPS_CUSTOMER_ID."' ORDER BY KPS_CUSTOMER_PLANT_ID");
						$datay = $query->first_row();
						$query1 = $this->db->query("select * from kps_customer_is_person_in_charge 
							where KPS_CUSTOMER_ID_PIC='".$value->KPS_CUSTOMER_ID."' ORDER BY KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID");
						$dataC = $query1->result();	
						
					?>
					  <tr>
						<td><?php echo $no;?></td>
						<td><?php echo $value->CUSTOMER_CODE;?></td>
						<td><?php echo $value->COMPANY_NAME;?></td>
						<td>
							<?php 
							if($datay){
								echo $datay->PLANT;
							}else{
								echo "-";
							}
							?>
						</td>
						<td><?php
								if ($datax) {
									$no=1;
									foreach ($datax as $value){
										echo $no++.". ".$value->PLANT;
										echo "<br>";
									}
								}else{ echo "-"; 
							}?>
						</td>
						<td>
							<?php if($datax){
								$no=1;
								foreach ($datax as $value){
									echo $no++.". "."TELP : ". $value->TELP ." FAX : ". $value->FAX ;	echo "<br>";}

							}?></td>
						<td><?php 
							foreach ($dataC as $value) {
								if($value->DEPARTMENT=="Purchasing"){
								echo "NAME : ". $value->NAME ." PHONE : ". $value->MOBILE_PHONE ." E-MAIL : ". $value->EMAIL;	
								}
							}
							?></td>
					  </tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</body>