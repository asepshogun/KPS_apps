<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Invoice</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body >
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Invoice</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Invoice No</th>
                  <td><?php echo $data->INVOICE_INDUK_NO;?></td>
                </tr>
                <tr>
                  <th>Rev No</th>
                  <td><?php echo $data->revisi_no_inv;?></td>
                </tr>
                <tr>
                  <th>Date</th>
                  <td><?php echo $data->INVOICE_INDUK_DATE;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $data->COMPANY_NAME;?></td>
                </tr>
                <tr>
                  <th>Address</th>
                  <td><?php echo $data->PLANT;?></td>
                </tr>
                <tr>
                  <th>Currency</th>
                  <td><?php echo $data->CURRENCY;?></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">            
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th><center>Date</center></th>
                  <th><center>Approved</center></th>
                  <th><center>Made by</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><center><?php echo date('d - m - Y');?></center></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th>&nbsp</th>
                  <th><center>Manager Sales</center></th>
                  <th><center>Sales Head</center></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                  <th>No</th>
                  <th>Invoice Number</th>
                  <th>Invoice Date</th>
                  <th>Employee Prepared</th>          
                  <th>Employee Checked</th>           
                  <th>Employee Approved</th>
                  <th>Total Qty</th>
                  <th>Amount (Currency)</th>
              </thead>
              <tbody>
              <?php $no=0; foreach ($detail as $value) { $no++; ?>
                <tr>
                  <td><?php echo $no;?></td>
                  <td><?php echo $value->NO_INVO;?></td>
                  <td><?php echo $value->DATE_INVO;?></td>
                  <td><?php 
                    $query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->PREPARED_INVO."'");
                    $data = mysql_fetch_array($query);
                    echo $data['EMPLOYEE_NAME'];
                  ?></td>
                  <td><?php 
                  $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHECKED_INVO."'");
                    $data1 = mysql_fetch_array($query1);
                    echo $data['EMPLOYEE_NAME'];
                    
                    ?></td>
                  <td><?php 
                                  $query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->APPROVED_INVO."'");
                    $data2 = mysql_fetch_array($query2);
                    echo $data['EMPLOYEE_NAME'];
                    ?></td>
                  <td><?php echo $value->total_qty;?></td>
                  <td><?php echo $value->total_amount;?></td>
                </tr>
                <tr>
                  <td colspan="2"></td>
                  <td colspan="3"><center>Total DP (<?php echo $value->KPS_INVOICE_DP;?>%)</center></td>
                  <td></td>
                  <td></td>
                  <td>Rp <?php echo $value->total_amount*($value->KPS_INVOICE_DP/100);?></td>
                </tr>
                <tr>
                  <td colspan="2"></td>
                  <td colspan="3"><center>Total VAT (10 %)</center></td>
                  <td></td>
                  <td></td>
                  <td>Rp <?php echo 0.1*($value->total_amount*($value->KPS_INVOICE_DP/100));?></td>
                </tr>
                <tr>
                  <td colspan="2"></td>
                  <td colspan="3"><center>Total</center></td>
                  <td></td>
                  <td></td>
                  <td>Rp <?php echo $value->total_amount*($value->KPS_INVOICE_DP/100)+(0.1*($value->total_amount*($value->KPS_INVOICE_DP/100)));?></td>
                </tr>
                 <?php } ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="row">
          <div class="col-xs-8 table-responsive">
            <table width="100%">
              <td>Rev Date : </td>
              <td>Rev Note : </td>
            </table>
          </div>                  
          <div class="col-xs-12">
            Note
            <div class="panel panel-default">
              <div class="panel-body">
                <br><br><br><br>
              </div>
            </div>
          </div>
        </div>
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>