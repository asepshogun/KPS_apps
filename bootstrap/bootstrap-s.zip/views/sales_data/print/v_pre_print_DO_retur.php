		<script type="text/javascript">

		
			window.print();

	</script>
<div id="printableArea">

<h3><center>SURAT JALAN</center></h3>
<h3><center>No :  <?php echo $detail[0]->KPS_DO_RETUR_NO;?></center></h3>
<h3><center>Tanggal :  <?php echo $detail[0]->KPS_DO_RETUR_DATE;?></center></h3>
</br>
</br>
<table width="100%">
<tr><td>Berdasarkan permintaan </td><td></td><td></td><td></td><td>dengan no : <?php echo $detail[0]->NO_RETUR_FROM_CUSTOMER;?></td></tr>
<tr><td colspan=4>Kami kirimkan barang-barang Saudara seperti berikut di bawah ini </td></tr>
</table>
<table width="100%" border=1>
	<thead>
	  <tr>
		<th>No</th>
		<th>Part No / Part Name</th>
		<th>QTY</th>
		<th>Satuan</th>
		<th>Keterangan</th>
	  </tr>
	</thead>
	<tbody>
		<?php $no=0; foreach ($detail as $value) { $no=$no+1?>
		  <tr>
			<td><?php echo $no;?></td>
			<td><?php echo $value->LOI_PART_NO ."&nbsp;&nbsp;&nbsp;".$value->LOI_PART_NAME;?></td>
			<td><?php echo $value->QTY_EXECUTION_OUT;?></td>
			<td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
			<td><?php echo $value->KPS_DELIVERY_ORDER_NOTE;?></td>
		  </tr>
	  <?php } ?>
	</tbody>
</table>
</br>
</br>
<table width="100%">
<tr><td>Dikirim Dengan </td><td></td><td></td><td></td><td></td><td>No Polisi : <?php echo $detail[0]->VEHICLE_NO;?></td></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr><td colspan=3>Mohon Diterima dengan Baik </td></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr><td>Yang Menyerahkan </td><td></td><td></td><td>Diterima Oleh</td><td colspan=2>PT. Karya Putra Sangkuriang</td></tr>
<tr><td> </td><td></td><td></td><td><?php echo $detail[0]->COMPANY_NAME;?></td><td>Dibuat</td><td colspan=1>Disetujui</td></tr>
<tr><td height="100"></td></tr>
<tr>
	<td>Sopir : <?php 
				$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->employee_driver_id."'");
				$data2 = mysql_fetch_array($query2);
				echo $data2['EMPLOYEE_NAME'];
				?> 
	</td>
	<td></td><td></td><td>____________________</td><td>__________________________</td><td>__________________________</td>
</tr>
<tr><td>Ass   : <?php echo $detail[0]->OUTGOING_RETUR_ASISTEN_DRIVER;?> </td><td></td><td></td><td>Bag.</td><td>Bag.Pesanan</td><td>Bag.Penjualan</td></tr>
<tr><td>Note :  <?php echo $detail[0]->KPS_DELIVERY_ORDER_NOTE;?></td><td></td><td></td>
<td>
</td>
<td><?php 
		$query4 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_DO_RETUR_MADE_BY."'");
		$data4 = mysql_fetch_array($query4);
		echo $data4['EMPLOYEE_NAME'];
		?> 
</td>
<td><?php 
		$query5 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KPS_DO_RETUR_APPROVE_BY."'");
		$data5 = mysql_fetch_array($query5);
		echo $data5['EMPLOYEE_NAME'];
		?>
</td>
</tr>
</table>
<table	width="100%">
<tr><td>putih : Fakturing</td><td>hijau : penjualan</td><td>kuning : PPIC</td><td>Merah 1 : Konsumen</td><td>Merah 2 : Keuangan</td><td>Biru : Konsumen</td></tr>
</table>
</div>
