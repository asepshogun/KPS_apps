<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Pesanan</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body ><!--onload="window.print();"> -->
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Retur Product</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>No </th>
                  <td><?php echo $detail->NO_RETUR;?></td>
                </tr>
                <tr>
                  <th>Rev No</th>
                  <td><?php echo $detail->KPS_REVISI_NO_RETUR; ?></td>
                </tr>
                <tr>
                  <th> No Retur From Customer</th>
                  <td><?php echo $detail->NO_RETUR_FROM_CUSTOMER;?></td>
                </tr>
                <tr>
                  <th>Date</th>
                  <td><?php echo $detail->DATE_RTR;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                <!-- <tr>
					<?php// $dataRow=count($dataPO)+1; ?>
                  <th rowspan=<?php// echo $dataRow; ?>>PO / OS NO</th>
                </tr> -->
				<?php
				//	foreach($dataPO as $valuePO){ ?>
				<!--		<tr>
							<td><?php //echo $valuePO->PO_OS_NO_FROM_CUSTOMER; ?></td>
						</tr> -->
				<?php//	}
				?>
              </tbody>
            </table>
          </div>
         
        </div>

        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Code Product</th>
                  <th>Part Name</th>
                  <th>Part No</th>
                  <th>Model</th>
                  <th>QTY</th>
                  <th>Units</th>
                  <th>Reason</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($detailx as $value) { ?>
                <tr>
                  <td><?php echo $no++;?></td>
                  <td><?php echo $value->LOI_CODE_ITEM;?></td> 
                  <td><?php echo $value->LOI_PART_NAME;?></td>
                  <td><?php echo $value->LOI_PART_NO;?></td>
                  <td><?php echo $value->LOI_MODEL;?></td> 
                  <td><?php echo $value->QTY_RTR;?></td>
                  <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
                  <td><?php echo $value->REASON;?></td>
                </tr>
                <?php } ?>
              </tbody>
			   <div class="col-xs-6 table-responsive">            
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th><center><?php echo $detail->COMPANY_NAME;?></center></th>
                  <th><center>Checked</center></th>
                  <th><center>Checked</center></th>
                  <th><center>Knowed</center></th>
                  <th><center>Approved</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
					<td></td>
                  <td><center><br><br><br><br>
                   <?php 
                      $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->CHECKED_SALES."'");
                      $data1 = mysql_fetch_array($query1);
                      echo $data1['EMPLOYEE_NAME'];
                    ?> 
				  </center>
				  </td>
                  <td><center><br><br><br><br>
                    <?php 
                      $query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->CHCEKED_QC."'");
                      $data2 = mysql_fetch_array($query2);
                      echo $data2['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
				  <td><center><br><br><br><br>
                    <?php 
                      $query3 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->KNOWED."'");
                      $data3 = mysql_fetch_array($query3);
                      echo $data3['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
				  <td><center><br><br><br><br>
                    <?php 
                      $query4 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->APPROVED."'");
                      $data4 = mysql_fetch_array($query4);
                      echo $data4['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th><center>Konsumen</center></th>
                  <th><center>Sales</center></th>
                  <th><center>QC</center></th>
                  <th><center>PPIC</center></th>
                  <th><center>Sales & Purchase Mgr</center></th>
                </tr>
              </tfoot>
            </table>
          </div>
            </table>
			 <table width="100%">
              <tr>
                <td>Putih: Konsumen</td>
                <td>Kuning: Penjualan</td>
                <td>Hijau: QC</td>
                <td>Merah: PPIC</td>
              </tr>
            </table>
          </div>
        </div>       
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>
