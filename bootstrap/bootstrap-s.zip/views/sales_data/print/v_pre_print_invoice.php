<script type="text/javascript">
	// window.print();
</script>
<style>
	div#visibleValue{
	opacity: 0;
	}
	.ttd table, th, td{
		border: 1px solid black;
	}
	#ttdleft {
		width:250px;
		float:left;
		text-align:center;
	}
	#ttdright {
		width:350px;
		float:right;
		text-align:center;
	}
</style>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Invoice</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body >
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2><u>Invoice</u></h2></center><br><br>
          </div><!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Invoice No</th>
                  <td><?php echo $datas->KPS_NO_INVOICE_FAKTUR_PAJAK;?></td>
                </tr>
				<?php if($datas->KPS_INVOICE_NOMOR_PENGGANTI){?>
				<tr>
                  <th>Invoice No Pengganti</th>
                  <td><?php echo $datas->KPS_INVOICE_NOMOR_PENGGANTI;?></td>
                </tr>
				<?php } ?>
                <tr>
                  <th>Rev No</th>
                  <td><?php echo $data->revisi_no_inv;?></td>
                </tr>
				<?php $countPO=0; $count=0; foreach ($do as $values){ $count++;
									if($count<=6){
							?>	
										<?php if($values->REV_NO_BP){
											$countPO++;
											}else{
												$query = $this->db->query("SELECT *
														FROM `kps_order_sheet_detail` 
														join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS)
														WHERE KPS_OS_ID_DETAIL ='". $values->KPS_OS_ID  ."' AND kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID NOT IN (SELECT `kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID` FROM kps_delivery_order JOIN `kps_outgoing_finished_good` ON `kps_delivery_order`.`KPS_OUTGOING_FINISHED_GOOD_ID_DO`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID` LEFT JOIN `kps_bukti_pesanan` ON `kps_outgoing_finished_good`.`KPS_BUKTI_PESANAN_ID_OGFG`=`kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID` WHERE KPS_DELIVERY_ORDER_ID = '". $values->KPS_DELIVERY_ORDER_ID  ."') GROUP BY KPS_BUKTI_PESANAN_ID");
												$datax = $query->result();
												if($datax){
													foreach ($datax as $valueOS) {
															$countPO++;
													}
												}
											} ?>
							<?php } 
									}?>
				<tr>
					<th rowspan=<?php echo $countPO+1;?>>PO NO </th>
				</tr>
					<?php $count=0; foreach ($do as $values){ $count++;
									if($count<=6){
							?>	
										<?php if($values->REV_NO_BP){
											?> 
											<tr>
												<td>
										<?php	echo $values->PO_OS_NO_FROM_CUSTOMER; ?>
												</td>
											</tr>
										<?php
										}else{
												$query = $this->db->query("SELECT *
														FROM `kps_order_sheet_detail` 
														join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_order_sheet_detail.KPS_BUKTI_PESANAN_ID_OS)
														WHERE KPS_OS_ID_DETAIL ='". $values->KPS_OS_ID  ."' AND kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID NOT IN (SELECT `kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID` FROM kps_delivery_order JOIN `kps_outgoing_finished_good` ON `kps_delivery_order`.`KPS_OUTGOING_FINISHED_GOOD_ID_DO`=`kps_outgoing_finished_good`.`KPS_OUTGOING_FINISHED_GOOD_ID` LEFT JOIN `kps_bukti_pesanan` ON `kps_outgoing_finished_good`.`KPS_BUKTI_PESANAN_ID_OGFG`=`kps_bukti_pesanan`.`KPS_BUKTI_PESANAN_ID` WHERE KPS_DELIVERY_ORDER_ID = '". $values->KPS_DELIVERY_ORDER_ID  ."') GROUP BY KPS_BUKTI_PESANAN_ID");
												$datax = $query->result();
												if($datax){
													foreach ($datax as $valueOS) {
														?> 
														<tr>
															<td>
															<?php	echo $valueOS->PO_OS_NO_FROM_CUSTOMER; ?>
															</td>
														</tr>
												<?php		}
												}
											} ?>
							<?php } 
									}?>
                <tr>
					<?php $countDO=count($do)+2;?>
                  <th rowspan=<?php echo $countDO;?>>Surat Jalan No</th>
				</tr>
				<?php $count=0; foreach ($do as $values){ $count++;
							if($count<=6){ ?>
						<tr>
							<td>
								<?php echo $values->NO_DO; ?>		
							</td>
						</tr>
				<?php		} 
						}?>
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">            
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td><?php echo $data->INVOICE_INDUK_DATE;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
				  <td>
				  <table border="0 ">
							<?php foreach ($do as $values){ ?>
								<tr>
									<td><?php 
										if($values->KPS_BP_CUSTOMER_PAP_ID){
											$qPap = $this->db->query("SELECT * FROM `kps_customer_personal_payment` WHERE KPS_CUSTOMER_PAP_ID = '".$values->KPS_BP_CUSTOMER_PAP_ID."'")->first_row();
											echo $qPap->KPS_PAP_NAME;
										}
									  ?>
									</td>
								</tr>
							<?php } ?>
						</table>
						<?php 
							if(empty($values->KPS_BP_CUSTOMER_PAP_ID)){
								echo $data->COMPANY_NAME;
							}
						?>
				  </td>
                </tr>
                <tr>
                  <th>Address</th>
                  <td><?php if($data->ALAMAT_NPWP){ 
				  echo $data->ALAMAT_NPWP;
				  }else{ echo "-"; }
				  ?></td>
                </tr>
                <tr>
                  <th>Currency</th>
                  <td><?php echo "Currency";//$data->CURRENCY;?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                  <th>No</th>
                  <th>Code Item</th>
                  <th>Part No</th>
                  <th>Part Name</th>          
                  <th>Model</th>           
                  <th>QTY</th>
                  <th>Unit</th>
                  <th>Price / Unit</th>
                  <th>Sub Total</th>
              </thead>
              <tbody>
              <?php $TotalQTY=0; $TotalAmount=0; $no=0; foreach ($do_detail as $value) { $no++; ?>
                <tr>
                  <td><?php echo $no;?></td>
                  <td><?php echo $value->LOI_CODE_ITEM;?></td>
                  <td><?php echo $value->LOI_PART_NO;?></td>
                  <td><?php echo $value->LOI_PART_NAME;?></td>
                  <td><?php echo $value->LOI_MODEL;?></td>
                  <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
                  <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
                  <td><?php echo $value->price;?></td>
                  <td><?php echo $value->QTY_DELIVERY_EXECUTION*$value->price;?></td>
                </tr>
				<?php 
				$TotalQTY=$TotalQTY+$value->QTY_DELIVERY_EXECUTION; 
				$TotalAmount=$TotalAmount+($value->QTY_DELIVERY_EXECUTION*$value->price); 
				
				?>
			<?php } ?>
				<tr>
					<td colspan=4 ></td>
					<td>TOTAL</td>
					<td><?php echo $TotalQTY; ?></td>
					<td colspan=2>Amount (<?php echo "Currency";//$data->CURRENCY;?>)</td>
					<td><?php echo $TotalAmount; ?></td>
				</tr>
                <tr>
                  <td colspan="5"></td>
                  <td colspan="3"><center>Total DP (<?php echo $invoice->KPS_INVOICE_DP;?>%)</center></td>
                  <td>Rp <?php echo $TotalAmount*($invoice->KPS_INVOICE_DP/100);?></td>
				  <?php $DP=$TotalAmount*($invoice->KPS_INVOICE_DP/100); ?>
                </tr>
				<?php if($data->SALES_TAX=="Tax"){ ?>
                <tr>
                  <td colspan="5"></td>
                  <td colspan="3"><center>Total VAT (10 %)</center></td>
                  <td>Rp <?php echo 0.1*$TotalAmount*($invoice->KPS_INVOICE_DP/100);?></td>
				  <?php $TotalAfterTax=0.1*$TotalAmount*($invoice->KPS_INVOICE_DP/100); ?>
                </tr>
				<?php 
				}else{
				$TotalAfterTax=0;
				}
				?>
                <tr>
                  <td colspan="5"></td>
                  <td colspan="3"><center>Total</center></td>
                  <td>Rp <?php echo $DP+$TotalAfterTax; ?></td>
                </tr>
              </tbody>
            </table>
			<div id="ttdleft">
				<table width="100%" class="ttd" style="padding-top:5px;">
				  <tr>
					<td><b> <?php echo $data->COMPANY_NAME; ?> </b></td>
				  </tr> 
				  <tr>
					<td>Approved by,</td>
				  </tr>
				  <tr>
					<td>
					<div id=visibleValue >/ </br>/</br>/</br>/
					</div></td>
				  </tr>
				  <tr>
					<td>Name :  </td>
				  </tr>
				</table>
			</div>
			<div id="ttdright">
				<table width="100%" class="ttd" style="padding-top:5px;">
				  <tr>
					<td colspan=3 ><b> PT. Karya Putra Sangkuriang </b></td>
				  </tr> 
				  <tr>
					<td>Prepared by,</td>
					<td>Checked by,</td>
					<td>Approved by,</td>
				  </tr>
				  <tr>
					<td>
					<div id=visibleValue >/ </br>/</br>/</br>/
					</div>
					</td>
					<td>
					<div id=visibleValue >/ </br>/</br>/</br>/
					</div>
					</td>
					<td>
					<div id=visibleValue >/ </br>/</br>/</br>/
					</div>
					</td>
				  </tr>
				  <tr>
					<td>
					<?php
						$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$invoice->PREPARED_INVO."'")->first_row();
						echo $q1->EMPLOYEE_NAME;
					?>	
					</td><td><?php
						$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$invoice->CHECKED_INVO."'")->first_row();
						echo $q2->EMPLOYEE_NAME;
					?></td><td><?php
						$q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$invoice->APPROVED_INVO."'")->first_row();
						echo $q3->EMPLOYEE_NAME;
					?></td>
				  </tr>
				  <tr>
					<td>Sales Staff</td><td>Finance Staff</td><td>Finance Head</td>
				  </tr>
				</table>
			</div>
          </div>
        </div>
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>