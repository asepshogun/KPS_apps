<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>CIS Print</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">
    
  </head>
  <body >
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div>
        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>CUSTOMER INFORMATION SHEET</h2></center><br><br>
          </div><!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row">
		  <div class="col-xs-12">
				<table width="100%" class="table table-bordered" style="padding-top:5px;">
					<tbody>
						<tr>
							<td>Date : </td>
							<td><?php echo $datas->DATE_CIS?></td>
							<td>No : </td>
							<td colspan=2><?php echo $datas->NO?></td>
							<td>Rev No : </td>
							<td><?php echo $datas->revisi_no?></td>
							
						</tr>
						<tr>
							<td colspan=7> <center>COMPANY PROFILE</center></td>	
						</tr>
						<tr>
							<td colspan=4>Company Name : <?php echo $datas->COMPANY_NAME;?></td>	
							<td colspan=2>Customer Code</td>	
							<td><?php echo $datas->CUSTOMER_CODE; ?></td>	
						</tr>
							<?php 
							if($plant){
							$countPlan=count($plant)+2; 
							}else{
							$countPlan=3;
							}?>
						<tr>
							<td rowspan=<?php echo $countPlan; ?>>Address</td>
						</tr>
						<tr>
							<td colspan=3><center>Plant</center></td>
							<td><center>Telp No</center></td>
							<td><center>Fax No</center></td>
							<td><center>Estabilished</center></td>
						</tr>
							<?php $no=0;
							if($plant){
								foreach($plant as $valuePlant){ $no++;
							?>
							<tr>
								<td>
									Plant <?php echo $no; ?>
								</td>
								<td colspan=2>
									<?php echo $valuePlant->PLANT; ?>
								</td>
								<td>
									<?php echo $valuePlant->TELP; ?>
								</td>
								<td>
									<?php echo $valuePlant->FAX; ?>
								</td>
								<td>
									<?php echo $valuePlant->FAX; ?>
								</td>
							</tr>
							<?php } 
							}else{ ?>
								<tr>
									<td>
										Plan 1
									</td >
									<td colspan=2>
										-
									</td>
									<td>
										-
									</td>
									<td>
										-
									</td>
									<td>
										-
									</td>
								</tr>
							<?php }?>	
						<?php $countDiv=count($divisi)+2; ?>
						<tr>
							<td rowspan=<?php echo $countDiv; ?>>Divis</td>
						</tr>
						<tr>
							<td colspan=3><center>Divisi</center></td>
							<td><center>Telp No</center></td>
							<td><center>Fax No</center></td>
							<td><center>Estabilished</center></td>
						</tr>
							<?php $no=0;
								foreach($divisi as $valueDiv){ $no++;
							?>
							<tr>
								<td>
									Divis  <?php echo $no; ?>
								</td>
								<td colspan=2>
									<?php echo $valueDiv->DIVISI; ?>
								</td>
								<td>
									<?php echo $valueDiv->TELP; ?>
								</td>
								<td>
									<?php echo $valueDiv->FAX; ?>
								</td>
								<td>
									<?php echo $valueDiv->ESTABLISHED; ?>
								</td>
							</tr>
							<?php } ?>
						<tr>
							<td>Type of Company : </td>
							<td colspan=6><center><?php if($cp){ 
							echo $cp[0]->TYPE_OF_COMPANY; }
							else{
								echo "-";
							}
							?></center></td>
							
						</tr>
						<tr>
							<td colspan=7><center>MAIN CUSTOMER</center></td>
						</tr>
						<tr>
							<td colspan=3><center>Company Name</center></td>
							<td colspan=2><center>Location</center></td>
							<td colspan=2><center>Bussines Content</center></td>
						</tr>
						<?php
							if($main){
								foreach($main as $valueMain){ ?>
								<tr>
									<td colspan=3><center><?php echo $valueMain->COMPANY_NAME; ?></center></td>
									<td colspan=2><center><?php echo $valueMain->LOCATION; ?></center></td>
									<td colspan=2><center><?php echo $valueMain->BUSINESS_CONTENT; ?></center></td>
								</tr>
						<?php } 
							} else{ ?>
							<tr>
									<td colspan=3><center>-</center></td>
									<td colspan=2><center>-</center></td>
									<td colspan=2><center>-</center></td>
							</tr>
						<?php	} ?>
						<tr>
							<td colspan=7><center>SUPPLIER/SUB CONTRACT</center></td>
						</tr>
						<tr>
							<td colspan=3><center>Company Name</center></td>
							<td colspan=2><center>Location</center></td>
							<td colspan=2><center>Bussines Content</center></td>
						</tr>
						<?php
							if($sup){
								foreach($sup as $valueSup){ ?>
								<tr>
									<td colspan=3><center><?php echo $valueSup->SUPPLIER_NAME; ?></center></td>
									<td colspan=2><center><?php echo $valueSup->LOCATION; ?></center></td>
									<td colspan=2><center><?php echo $valueSup->BUSINESS_CONTENT; ?></center></td>
								</tr>
						<?php } 
							} else{ ?>
							<tr>
									<td colspan=3><center>-</center></td>
									<td colspan=2><center>-</center></td>
									<td colspan=2><center>-</center></td>
							</tr>
						<?php	} ?>
						<tr>
							<td colspan=7><center>Finance</center></td>
						</tr>
						<?php 
							if($finance){
								foreach($finance as $valueFinance){ ?>
								<tr>
									<td colspan=4>Total Asset</td>
									<td colspan=3><?php echo $valueFinance->TOTAL_ASSETS ?></td>
								</tr>
								<tr>
									<td colspan=4>Annual Sales For The Last Yeart</td>
									<td colspan=3><?php echo $valueFinance->ANNUAL_SALES_LAST_YEAR ?></td>
								</tr>	
								<tr>
									<td colspan=4>No. NPWP :</td>
									<td colspan=3><?php echo $valueFinance->NO_NPWP ?></td>
								</tr>	
								<tr>
									<td colspan=4>Alamat NPWP</td>
									<td colspan=3><?php echo $valueFinance->ALAMAT_NPWP ?></td>
								</tr>
								<?php } 
							}else{ ?>
								<tr>
									<td colspan=4>Total Asset</td>
									<td colspan=3>-</td>
								</tr>
								<tr>
									<td colspan=4>Annual Sales For The Last Yeart</td>
									<td colspan=3>-</td>
								</tr>	
								<tr>
									<td colspan=4>No. NPWP :</td>
									<td colspan=3>-</td>
								</tr>	
								<tr>
									<td colspan=4>Alamat NPWP</td>
									<td colspan=3>-</td>
								</tr>
						<?php	}
						?>
						<tr>
							<td colspan=7><center>BANK REFERENCES</center></td>
						</tr>
						<tr>
							<td><center>No</center></td>
							<td colspan=2><center>Name Of Bank</center></td>
							<td colspan=2><center>Branches</center></td>
							<td><center>Account Number</center></td>
							<td><center>Currency</center></td>
						</tr>
						<?php
							if($account){ $no=0;
								foreach($account as $valueAcc){ $no++ ?>
								<tr>
									<td><center><?php echo $no; ?></center></td>
									<td colspan=2><center><?php echo $valueAcc->BANK_NAME ; ?></center></td>
									<td colspan=2><center><?php echo $valueAcc->BRANCHES ; ?></center></td>
									<td><center><?php echo $valueAcc->ACCOUNT_NO ; ?></center></td>
									<td><center><?php echo $valueAcc->CURRENCY ; ?></center></td>
								</tr>
							<?php	}
							}
						?>
					</tbody>
				</table>
			</div>
          
        </div><!-- /.row -->

        <!-- title row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->

  </body>
</html>