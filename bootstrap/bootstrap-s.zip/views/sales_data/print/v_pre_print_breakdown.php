<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>Breakdown Print <?php echo $detail->NO_RFQ;?></title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">
    
  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div>
        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>BREAKDOWN COST</h2></center><br><br>
          </div><!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive ">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <th>RFQ No</th>
                <td><?php echo $detailx->NO_RFQ;?></td>

              </tr>
              <tr>
                 <th>Part Name</th>
                <td><?php echo $drawing->KPS_RFQ_PART_NAME;?></td>
              </tr>
              <tr>
                <th>Part No</th>
                <td><?php echo $drawing->KPS_RFQ_PART_NO;?></td>
              </tr>
              <tr>
                <th>Model</th>
                <td><?php echo $pp->MODEL;?></td>
              </tr>
               
                
            
            </tbody>
            </table>
          </div>

          <div class="col-xs-6 table-responsive">
          Customer Respond
            <table width="100%" class="table">
              <tr>
                
                <?php if($detail->CUSTOMER_RESPOND == 1){

                  ?><td><input type="radio" name="group1" value="1" checked> 1</input></td>
                    <td><input type="radio" name="group1" value="1" > 2</input></td>
                    <td><input type="radio" name="group1" value="1" > 3</input></td><?php

                  }elseif($detail->CUSTOMER_RESPOND == 2){

                  ?><td><input type="radio" name="group1" value="1" > 1</input></td>
                    <td><input type="radio" name="group1" value="2" checked> 2</input></td>
                    <td><input type="radio" name="group1" value="3" > 3</input></td><?php

                  }else{

                  ?><td><input type="radio" name="group1" value="1" > 1</input></td>
                    <td><input type="radio" name="group1" value="2" > 2</input></td>
                    <td><input type="radio" name="group1" value="3" checked> 3</input></td><?php

                  }?>
              </tr>
            </table>
            <table width="100%" class="table table-bordered">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td colspan="3"><?php echo $detail->DATE_BREAK;?></td>
                </tr>
                <tr>
                  <th>No</th>
                  <td><?php echo $detail->NO_BREAK;?></td>
                  <th>Rev No</th>
                  <td><?php echo $detail->revisi_no_break;?></td>
                </tr>
                <tr>
                  <th>Customer</th>
                  <td colspan="3"><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                
              </tbody>
            </table>
            
          </div><!-- /.col -->
        </div>
        <div class="row">
          <div class="col-xs-6 table-responsive ">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <th><center>ITEM</center></th>
                <td colspan="2"><center>ESTIMATE</center></td>
              </tr>
              <tr>
                <th>1</th>
                <td>Material Cost</td>
                <td><?php echo $detail->TOTAL_MATERIAL;?></td>
              </tr>
              <tr>
                <th>2</th>
                <td>Purchased Part Cost</td>
                <td><?php echo $detail->TOTAL_PART_COST;?></td>
              </tr>
              <tr>
                <th>3</th>
                <td>Manufacturing Cost</td>
                <td><?php echo $detail->TOTAL_MANUFACTURING;?></td>
              </tr>
              <tr>
                <th>4</th>
                <td>Sub Total = (1) + (2) + (3)</td>
                <td><?php echo $detail->sub_total_breakdown;?></td>
              </tr>
              <tr>
                <th>5</th>
                <td>Packing Charge        (%) </td>
                <td><?php echo $detail->packing_charge;?></td>
              </tr>
              <tr>
                <th>6</th>
                <td>Transportation Charge (%)</td>
                <td><?php echo $detail->transportation_charge;?></td>
              </tr>
              <tr>
                <th>7</th>
                <td>Tooling Cost</td>
                <td><?php echo $detail->TOOLING_COST;?></td>
              </tr>
              <tr>
                <th>8</th>
                <td>Overhead & profit   (%)</td>
                <td><?php echo $detail->overhead_profit;?></td>
              </tr>
              <tr>
                <th>9</th>
                <td>Total (4)+(5)+(6)+(7)+(8)</td>
                <td><?php echo $detail->total_breakdown;?></td>
              </tr>
            </tbody>
            </table>
            <br>
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <th colspan="3"><center>Quantity for depreciation</center></th>
               
              </tr>
              <tr>
                <th>1</th>
                <td>QTY Per Unit</td>
                <td><?php echo $dep->qty_unit;?> UNIT</td>
              </tr>
              <tr>
                <th>2</th>
                <td>Projected production<br>Unit per month</td>
                <td><?php echo $dep->qty_month;?></td>
              </tr>
              <tr>
                <th>3</th>
                <td>Depreciation periode</td>
                <td><?php echo $dep->periode;?></td>
              </tr>
            </tbody>
            </table>
            <br>
            <br>(8) Tooling (Break down to procces by procces)
            <br>
            <table id="breakdown_tooling" class="table table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    
                    <th>Tools</th>
                    <th>Costs</th>
                    <th>Remarks</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $no=0; foreach ($tool as $value) {$no++ ?>
                    <tr>
                      
                      <td><?php echo $value->TOOL;?></td>
                      <td><?php echo $value->COST;?></td>
                      <td><?php echo $value->REMARK;?></td>
                    </tr>
                  <?php } ?>
                  <tr>
                      <td>Total Tools</td>  
                      <td><?php echo $detail->TOTAL_TOOLING;?></td>
                      <td></td>
                  </tr>
                  <tr>
                      <td>Tooling Cost</td>  
                      <td><?php echo $detail->TOOLING_COST;?></td>
                      <td></td>
                  </tr>
                </tbody>
            </table>
            <br>
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <th>Prod Prep Lead Time :</th>
                <td><?php echo $detail->PROD_PREP_LEAD_TIME;?> Weeks</td>
              </tr>
            
            </tbody>
            </table>
            Note :
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <tbody>
              <tr>
                <td><br><br><br></td>
              </tr>
            
            </tbody>
            </table>
          </div><!-- /.col -->
          <div class="col-xs-6 table-responsive">
          (1) Material Cost
          <br>
            <table id="breakdown_material" class="table table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Material</th>
                    <th>QTY Netto</th>
                    <th>QTY Brutto</th>
                    <th>Price</th>
                    <th>Sub Total</th>
                    <th>Country</th>
                  
                  </tr>
                </thead>
                <tbody>
                  <?php $no=0; foreach ($material as $value) {$no++ ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $value->MATERIAL;?></td>
                      <td><?php echo $value->QTY_NETTO;?></td>
                      <td><?php echo $value->QTY_BRUTTO;?></td>
                      <td><?php echo $value->PRICE;?></td>      
                      <td><?php echo $value->SUB_TOTAL;?></td> 
                      <td><?php echo $value->COUNTRY;?></td>
                      
                    </tr>
                  <?php } ?>
                  <tr>
                    <td colspan="5">Total</td>
                    <td><?php echo $detail->TOTAL_MATERIAL;?></td>
                    <td></td>
                  </tr>
                </tbody>
            </table>
            <br>
            <br>(2) Purchased Parts Cost
            <br>
            <table id="breakdown_part" class="table table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Part Name</th>
                    <th>Part No</th>
                    <th>Cost</th>
                    <th>Country</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $no=0; foreach ($part as $value) {$no++ ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $value->KPS_PART_NAME;?></td>
                      <td><?php echo $value->KPS_PART_NO;?></td>
                      <td><?php echo $value->COST;?></td>
                      <td><?php echo $value->COUNTRY;?></td> 
                       
                    </tr>
                  <?php } ?>
                  <tr>
                    <td colspan="3">Total</td>
                    <td><?php echo $detail->TOTAL_PART_COST;?></td>
                    <td></td>
                  </tr>
                </tbody>
            </table>
            <br>
            <br>(3) Manufacturing Cost
            <br>
            <table id="breakdown_manufacturing" class="table table-bordered table-hover table-striped dataTable" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Processing</th>
                    <th>Machine</th>
                    <th>Time</th>
                    <th>Charge</th>
                    <th>Amount</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $no=0; foreach ($manu as $value) {$no++ ?>
                    <tr>
                      <td><?php echo $no;?></td>
                      <td><?php echo $value->PROCCESING;?></td>
                      <td><?php echo $value->MACHINE;?></td>
                      <td><?php echo $value->TIME;?></td>
                      <td><?php echo $value->CHARGE;?></td>      
                      <td><?php echo $value->AMOUNT;?></td> 
                      
                    </tr>
                  <?php } ?>
                  <tr>
                    <td colspan="5">Total</td>
                    <td><?php echo $detail->TOTAL_MANUFACTURING;?></td>

                  </tr>
                </tbody>
            </table>
            <table width="100%" class="table table-bordered">
              <thead>
                <tr>
                  <th colspan="3"><b><center> PT. Karya Putra Sangkuriang</center></b></th>
                  <th><b><center> Customer</center></b></th>
                </tr>
                <tr>
                  <th><center>Made by</center> </th>
                  <th><center>Checked by</center></th>
                  <th><center>Calculated</center></th>
                  <th><center>Approved</center></th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th><b><center></center></b></th>
                  <th><b><center></center></b></th>
                  <th><b><center>Irvan Januar</center></b></th>
                  <th><b><center></center></b></th>
                </tr>
              </tfoot>
              <tbody>
                <tr>
                    <td><br><br><br></td>
                    <td><br><br><br></td>
                    <td><br><br><br></td>
                    <td><br><br><br></td>
                </tr>
              </tbody>
            </table>
          </div><!-- /.col -->
          
        </div><!-- /.row -->

        <!-- title row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->

  </body>
</html>