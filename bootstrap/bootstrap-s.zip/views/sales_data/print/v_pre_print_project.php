<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | New Item</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
 <body >
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Failed Project</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td><?php echo $detail->DATE_FAILED;?></td>
                </tr>
                <tr>
                  <th>No / Rev No</th>
                  <td><?php echo $detail->NO_FAILED.' - '.$detail->revisi_no_project;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                <tr>
                  <th>RFQ No</th>
                  <td><?php echo $detail->NO_RFQ;?></td>
                </tr>
                <tr>
                  <th>Part Name</th>
                  <td><?php echo $detail->KPS_RFQ_PART_NAME;?></td>
                </tr>
                <tr>
                  <th>Part No</th>
                  <td><?php echo $detail->KPS_RFQ_PART_NO;?></td>
                </tr>
                <tr>
                  <th>Model</th>
                  <td><?php echo $detail->MODEL;?></td>
                </tr>
               
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">
            <!--table 1-->
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th><center>Made By</center></th>
                  <th><center>Approved</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><br><br><center>
                   <?php 
                      $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->MADE_BY_FAILED."'");
                      $data1 = mysql_fetch_array($query1);
                      echo $data1['EMPLOYEE_NAME'];
                    ?> </center>
                  </td>
                  <td><br><br><center>
                    <?php 
                      $query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->APPROVED_FAILED."'");
                      $data2 = mysql_fetch_array($query2);
                      echo $data2['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th><center><b>Sales Head</b></center></th>
                  <th><center><b>Sales Staff</b></center></th>
                </tr>
              </tfoot>
            </table>
            <!--table 2-->
           
          </div>
        </div> 

        <!--info row 2-->
        <div class="row">
          <div class="col-xs-12">
            Note
            <div class="panel panel-default">
              <div class="panel-body">
                <br><br>
              </div>
            </div>
            <!--table 1-->
            <table width="100%">
              <tbody>
                <tr>
                  <td>LOI or Failed Letters</td>
                  <td>See Attachment</td>
                  <td>See Attachment</td>
                </tr>
                <tr>
                  <td></td>
                  <td>See Attachment</td>
                  <td>See Attachment</td>
                </tr>
              </tbody>
            </table>
            <br>
         
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>