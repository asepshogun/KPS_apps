<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | New Item</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
 <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div> 

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>New Item</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td><?php echo $detail->DATE_LOI;?></td>
                </tr>
                <tr>
                  <th>No / Rev No</th>
                  <td><?php echo $detail->NO_LOI.' - '.$detail->revisi_no_loi;?></td>
                </tr>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                <tr>
                  <th>RFQ No</th>
                  <td><?php echo $detail->NO_RFQ;?></td>
                </tr>
                <tr>
                  <th>Part Name</th>
                  <td><?php echo $detail->KPS_RFQ_PART_NAME;?></td>
                </tr>
                <tr>
                  <th>Part No</th>
                  <td><?php echo $detail->KPS_RFQ_PART_NO;?></td>
                </tr>
                <tr>
                  <th>Model</th>
                  <td><?php echo $detail->MODEL;?></td>
                </tr>
                <tr>
                  <th>LOI/Die Go No</th>
                  <td><?php echo $detail->LOI_DIE_GO_NO;?></td>
                </tr>
                <tr>
                  <th>QTY/Month</th>
                  <td><?php echo $detail->QTY_MONTH;?><div class="pull-right">Pcs/Mtr</div></td>
                </tr>
                <tr>
                  <th>Periode</th>
                  <td><?php echo $detail->PERIODE;?><div class="pull-right">Month</div></td>
                </tr>
                <tr>
                  <th>Discontinue Date</th>
                  <td><?php echo $detail->DISCONTINUE_DATE;?></td>
                </tr>
                <tr>
                  <th>Min Stock</th>
                  <td><?php echo $detail->MIN_STOK;?></td>
                </tr>
                <tr>
                  <th>Max Stock</th>
                  <td><?php echo $detail->MAX_STOCK;?></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">
            <!--table 1-->
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th><center>Made By</center></th>
                  <th><center>Accepted</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><br><br><center>
                   <?php 
                      $query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->MADE_BY_LOI."'");
                      $data1 = mysql_fetch_array($query1);
                      echo $data1['EMPLOYEE_NAME'];
                    ?> </center>
                  </td>
                  <td><br><br><center>
                    <?php 
                      $query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->ACCEPTED_LOI."'");
                      $data2 = mysql_fetch_array($query2);
                      echo $data2['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th><center><b>Sales Head</b></center></th>
                  <th><center><b>Staff ENG</b></center></th>
                </tr>
              </tfoot>
            </table>
            <!--table 2-->
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th><center>Checked</center></th>
                  <th><center>Approved By</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><br><br><center>
                    <?php 
                      $query3 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->CHECKED_LOI ."'");
                      $data3 = mysql_fetch_array($query3);
                      echo $data3['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
                  <td><br><br><center>
                     <?php 
                      $query4 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$detail->APPROVED_LOI."'");
                      $data4 = mysql_fetch_array($query4);
                      echo $data4['EMPLOYEE_NAME'];
                    ?></center>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th><center><b>S & P Mgr</b></center></th>
                  <th><center><b>S & P Mgr</b></center></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div> 

        <!--info row 2-->
        <div class="row">
          <div class="col-xs-12">
            Note
            <div class="panel panel-default">
              <div class="panel-body">
                <br><br>
              </div>
            </div>
            <!--table 1-->
            <table width="100%">
              <tbody>
                <tr>
                  <td>LOI or Failed Letters</td>
                  <td>See Attachment</td>
                  <td>See Attachment</td>
                </tr>
                <tr>
                  <td></td>
                  <td>See Attachment</td>
                  <td>See Attachment</td>
                </tr>
              </tbody>
            </table>
            <br>
            <!--table 2-->
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <td>Code Item</td>
                  <td>Part Name</td>
                  <td>Part No</td>
                  <td>Model</td>
                  <td>Product Classification</td>
                  <td>Note</td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><?php echo $detail->LOI_CODE_ITEM;?></td>
                  <td><?php echo $detail->LOI_PART_NAME;?></td>
                  <td><?php echo $detail->LOI_PART_NO;?></td>
                  <td><?php echo $detail->LOI_MODEL;?></td>
                  <td><?php echo $detail->LOI_PRODUCT_CLASIFICATION;?></td>
                  <td><?php echo $detail->LOI_PART_NOTE;?></td>
                  
                </tr>
              </tbody>
            </table>            
            <!--table 3-->
             
          </div>
        </div>

        <!--info row 3-->
        <div class="row">
          <div class="col-xs-8 table-responsive">
            <table width="100%">
              <tbody>
                <tr>
                  <th>Tooling Cost</th>
                <?php if($detail->TOOLING_COST_RFQ == "Depreciation"){

                  ?><td><input type="radio" name="group2" value="1" checked> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Others</input></td><?php

                  }elseif($detail->TOOLING_COST_RFQ == "Not Depreciation"){

                  ?><td><input type="radio" name="group2" value="1"> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1" checked> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Others</input></td><?php

                  }else{

                  ?> <td><input type="radio" name="group2" value="1"> Depreciation</input></td>
                <td><input type="radio" name="group2" value="1"> Not Depreciation</input></td>
                <td><input type="radio" name="group2" value="1" checked> Others</input></td><?php

                  }?>

                </tr>
              </tbody>
            </table> 
          </div>
        </div>         
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>