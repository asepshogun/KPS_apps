<script type="text/javascript">
	//window.print();
</script>
<style>
	div#visibleValue{
	opacity: 0;
	}
	.ttd table, th, td{
		border: 1px solid black;
	}
	#ttdleft {
		width:250px;
		float:left;
		text-align:center;
	}
	#ttdright {
		width:350px;
		float:right;
		text-align:center;
	}
</style>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Invoice</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body >
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
			 <div class="col-xs-6 table-responsive">
				  <div class="col-xs-12">
					<u><b>PT. Karya Putra Sangkuriang</b></u><br>
					<b>Sales Departement</b>
				  </div><!-- /.col -->
			 </div>
			<div class="col-xs-6 table-responsive"  align="right">            
				<font size=1>FR SLS 01 29</font> <br/>
				<font size=1>Ed/Rev : 01/00</font>
			</div>
		</div>		
		<br/>
		<br/>
		<br/>
		<div class="row">
			<div class="col-xs-6 table-responsive">
			  <div class="col-xs-12" align="right">
				<b>Rekapitulasi Pengiriman Barang (Surat Jalan)</b><br><br>
			  </div><!-- /.col -->
			  <div class="col-xs-12">
				<b><?php 
				foreach ($do as $values){
					if($values->KPS_BP_CUSTOMER_PAP_ID){
						$qPap = $this->db->query("SELECT * FROM `kps_customer_personal_payment` WHERE KPS_CUSTOMER_PAP_ID = '".$data->KPS_BP_CUSTOMER_PAP_ID."'")->first_row();
						echo $qPap->KPS_PAP_NAME;
					}else{
						echo $data->COMPANY_NAME;
					}
				} ?>
				</b><br>
			  </div><!-- /.col -->
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				<br/>
				 <div class="col-xs-12">
					<b>Periode : April 2016 (minggu ke-3)</b>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<b>Invoice  No : <?php echo $datas->KPS_NO_INVOICE_FAKTUR_PAJAK;?></b><br>
					<b>Rec No : 2016/04/148</b>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<b>Rev no : <?php echo $data->revisi_no_inv;?></b>
				  </div><!-- /.col -->
			</div>
			<div class="col-xs-6 table-responsive">
				<table width="100%" class="ttdright"  style="padding-top:5px;">
					  <tr>
						<td>Tanggal</td>
						<td>Prepared by,</td>
						<td>Checked by,</td>
						<td>Approved by,</td>
					  </tr>
					  <tr>
						<td rowspan=2> <?php echo date('Y-m-d'); ?></td>
						<td>
						<div id=visibleValue >/ </br>/</br>/</br>/
						</div>
						</td>
						<td>
						<div id=visibleValue >/ </br>/</br>/</br>/
						</div>
						</td>
						<td>
						<div id=visibleValue >/ </br>/</br>/</br>/
						</div>
						</td>
					  </tr>
					  <tr>
						<td>Sales Staff</td><td>Finance Staff</td><td>Finance Head</td>
					  </tr>
					</table>
			</div>
        </div>
        <!-- title row -->
        <!-- info row -->
		<?php// print_r($do_detail);?>
        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                  <th>No</th>
                  <th>Code Item</th>
                  <th>Part No</th>
                  <th>Part Name</th>          
                  <th>Model</th>           
                  <th>Order Sheet Completed</th>           
                  <th>Tanggal Kirim</th>           
                  <th>No Surat Jalan</th>           
                  <th>QTY</th>
                  <th>Unit</th>
                  <th>Harga</th>
                  <th>Sub Total</th>
                  <th>No Purchase Order</th>
              </thead>
              <tbody>
              <?php $TotalQTY=0; $TotalAmount=0; $no=0; foreach ($do_detail as $value) { $no++; ?>
                <tr>
                  <td><?php echo $no;?></td>
                  <td><?php echo $value->LOI_CODE_ITEM;?></td>
                  <td><?php echo $value->LOI_PART_NO;?></td>
                  <td><?php echo $value->LOI_PART_NAME;?></td>
                  <td><?php echo $value->LOI_MODEL;?></td>
                  <td><?php if($value->KPS_OS_ID_OGFG){
								echo $value->KPS_OS_DN_NO;
							}else{
								echo "-";}
				  ?></td>
                  <td><?php echo $value->KPS_DELIVERY_ORDER_DELIVERY_DATE;?></td>
                  <td><?php echo $value->NO_DO;?></td>
                  <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
                  <td><?php echo $value->KPS_RFQ_PART_UNIT;?></td>
                  <td><?php echo $value->price;?></td>
                  <td><?php echo $value->QTY_DELIVERY_EXECUTION*$value->price;?></td>
                  <td><?php if($value->KPS_OS_ID_OGFG){
								$query = $this->db->query("select * from kps_bukti_pesanan_detail 
								join kps_bukti_pesanan on(kps_bukti_pesanan.KPS_BUKTI_PESANAN_ID=kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_ID)
								where KPS_BUKTI_PESANAN_DETAIL_ID='".$value->KPS_BUKTI_PESANAN_DETAIL_ID_SD."'");
								$dataxPO = $query->first_row();
								echo $dataxPO->PO_OS_NO_FROM_CUSTOMER;
							}else{
							echo $value->PO_OS_NO_FROM_CUSTOMER;
							}
					?></td>
                </tr>
				<?php 
				$TotalQTY=$TotalQTY+$value->QTY_DELIVERY_EXECUTION; 
				$TotalAmount=$TotalAmount+($value->QTY_DELIVERY_EXECUTION*$value->price); 
				
				?>
			<?php } ?>
				<tr>
					<td colspan=7 ></td>
					<td>TOTAL</td>
					<td><?php echo $TotalQTY; ?></td>
					<td colspan=2>Amount (<?php echo "Currency";//$data->CURRENCY;?>)</td>
					<td colspan=2 align=right><?php echo $TotalAmount; ?></td>
				</tr>
                <tr>
                  <td colspan="6"></td>
                  <td colspan="5"><center>Total DP (<?php echo $invoice->KPS_INVOICE_DP;?>%)</center></td>
                  <td colspan=2 align=right>Rp <?php echo $TotalAmount*($invoice->KPS_INVOICE_DP/100);?></td>
				  <?php $DP=$TotalAmount*($invoice->KPS_INVOICE_DP/100); ?>
                </tr>
				<?php if($data->SALES_TAX=="Tax"){ ?>
                <tr>
                  <td colspan="6"></td>
                  <td colspan="5"><center>Total VAT (10 %)</center></td>
                  <td colspan=2 align=right>Rp <?php echo 0.1*$TotalAmount*($invoice->KPS_INVOICE_DP/100);?></td>
				  <?php $TotalAfterTax=0.1*$TotalAmount*($invoice->KPS_INVOICE_DP/100); ?>
                </tr>
				<?php 
				}else{
				$TotalAfterTax=0;
				}
				?>
                <tr>
                  <td colspan="6"></td>
                  <td colspan="5"><center>Total</center></td>
                  <td colspan=2 align=right>Rp <?php echo $DP+$TotalAfterTax; ?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>