<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT. KPS | Quotation Data</title>

    <link href="<?php echo base_url("bootstrap/css/bootstraps.min.css"); ?>" rel="stylesheet" media="all">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet" media="all">

  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice small">
        <!-- header row -->
        <div class="row">
          <div class="col-xs-12">
            <u><b>PT. Karya Putra Sangkuriang</b></u><br>
            <b>Sales Departement</b>
          </div><!-- /.col -->
        </div>

        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <center><h2>Quotation</h2></center><br><br>
          </div><!-- /.col -->
        </div>

        <!-- info row -->
        <div class="row">
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Date</th>
                  <td><?php echo $detail->DATE_QUO;?></td>
                </tr>
                <tr>
                  <th>No / Rev No</th>
                  <td><?php echo $detail->revisi_no_quo;?></td>
                </tr>
                <tr>
                  <th>RFQ No</th>
                  <td><?php echo $detail->RFQ_CUSTOMER_NO;?></td>
                </tr>
                <tr>
                  <th>Valid Date From</th>
                  <td><?php echo $detail->VALID_DATE_FROM;?></td>
                </tr>
                <tr>
                  <th>Valid Date Until</th>
                  <td><?php echo $detail->VALID_DATE_UNTIL;?></td>
                </tr>
                <tr>
                  <th>Currency</th>
                  <td><?php echo $detail->CURRENCY_NAME;?></td>
                </tr>
                <tr>
                  <th>Breakdown No</th>
                  <td><?php echo $detail->NO_BREAK;?></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-xs-6 table-responsive">
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <tbody>
                <tr>
                  <th>Customer Name</th>
                  <td><?php echo $detail->COMPANY_NAME;?></td>
                </tr>
                <tr>
                  <th>Address</th>
                  <td><?php echo $detail->PLANT;?></td>
                </tr>
                <tr>
                  <th>Attention</th>
                  <td></td>
                </tr>
                <tr>
                  <th>Phone/Fax</th>
                  <td><?php echo $detail->PHONE;?></td>
                </tr>
                <tr>
                  <th>Mail</th>
                  <td><?php echo $detail->EMAIL;?></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- info row 2 -->
        <div class="row">
          <div class="col-xs-12 table-responsive">
           Dear Sir/Madam<br>
           We hereby wish to submit our offers as follows:
           <table width="100%" class="table table-bordered" style="padding-top:5px;">
            <thead>
              <tr>
                <th>NO</th>
                <th>Part Name</th>
                <th>Part No</th>
                <th>Model</th>
                <th>Price</th>
                <th>Unit</th>
                <th>Note</th>
              </tr>
            </thead>
            <tbody>
              <td>1</td>
              <td><?php echo $detail->part_name;?></td>
              <td><?php echo $detail->part_no;?></td>
              <td><?php echo $detail->model;?></td>
              <td><?php echo $detail->price;?></td>
              <td><?php echo $detail->unit;?></td>
              <td><?php echo $detail->note;?></td>
            </tbody>
           </table>
           Note   :<br>
           <table width="100%">
           <tr>
              <td>1</td>
              <td>Price Exclude Tax 10%</td>
            </tr>
           <?php 
            if($detail->TOOLING_COST_RFQ=="Depreciation"){
              ?>
               <tr>
                <td>2</td>
                <td>Tooling Depreciation</td>
              </tr>
              <?php
            }else{
              ?>
              <tr>
                <td>2</td>
                <td>Toolings Payment</td>
              </tr>
              <?php
            }
           ?>
      
            <tr>
              <td>3</td>
              <td>Delivery Place</td>
            </tr>
            <tr>
            <?php if(!is_null($detail->NOTE_QUO)){
              ?>
              <td>4</td>
              <td><?php echo $detail->NOTE_QUO;?></td>
              <?php
            }
            ?>
              
            </tr>
           </table>      
           <br>
           We hope the above quotation will meet your requirement and we are looking forward to hearing from you very soon. 
           Thank you for your kind attention and good cooperation.
           <br> 
           <br>        
          </div>
        </div>

        <div class="row">
          <!--table 1-->
          <div class="col-xs-3 table-responsive">
            &nbsp
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th colspan="1"><center>Customer</center></th>
                </tr>
                <tr>
                  <th><center>Approved</center></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><br><br><br><br></td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td>&nbsp</td>
                </tr>
              </tfoot>
            </table>
          </div>
          <!--table 2-->
          <div class="col-xs-9 table-responsive">
            <center>Your sincerely</center>
            <table width="100%" class="table table-bordered" style="padding-top:5px;">
              <thead>
                <tr>
                  <th colspan="3"><center><b>PT. Karya Putra Sangkuriang</b></center></th>
                </tr>
                <tr>
                  <th><center>Made by</center> </th>
                  <th><center>Checked</center></th>
                  <th><center>Approved</center></th>
                </tr>
              </thead>
              <tbody>
                <td><br><br><br><br></td>
                <td><br><br><br><br></td>
                <td><br><br><br><br></td>
              </tbody>
              <tfoot>
                <tr>
                  <th><center><b>Sales Staff</b></center></th>
                  <th><center><b>Sales Head</b></center></th>
                  <th><center><b>Sales & Purchase Mgr</b></center></th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>        
        
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
  </body>
</html>