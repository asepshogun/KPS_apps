<section class="content-header">
	<h3>Order Sheet</h3>
	<small>Lembar Pemesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<?php// print_r($dataPending);?>
	<!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">Order Sheet</a></li>
                  <li><a href="#tab_2" data-toggle="tab">Order Sheet Pending</a></li>
                  <li><a href="#tab_3" data-toggle="tab">Return Order Sheet Pending</a></li>
                  
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                  <div class="box-body">
                    <!--TABLE-->
					<table id="os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th rowspan=2>No</th>
					        <th colspan=2>ORDER SHEET</th>
					        <th colspan=2>ORDER SHEET REQUEST</th>
					        <th colspan=2>PO CUSTOMER</th>
					        <th rowspan=2>Customer</th>
					        <th rowspan=2>Code Item</th>
					        <th rowspan=2>Part Name</th>
					        <th rowspan=2>Part No</th>
					        <th rowspan=2>Model</th>
					        <th colspan=2>OSR</th>
					        <th colspan=4>DO</th>
					        <th colspan=2>Retur</th>
					        <th colspan=2>Total QTY </th>
					        <th colspan=2>Remaining</th>
					        <th rowspan=2>Status</th>  
					      </tr>
						  <tr>
					        <th>Date</th>
					        <th>No</th>
					        <th>Date</th>
					        <th>No</th>
					        <th>Date</th>
					        <th>No</th>	
							<th>QTY</th>		        
					        <th>Units</th>		        
					        <th>Date</th>
					        <th>No SJ</th>
					        <th>QTY</th>
					        <th>Units</th>
					        <th>QTY</th>
					        <th>Units</th>
					        <th>QTY</th>
					        <th>Units</th>
					        <th>QTY</th>
					        <th>Units</th>

						  </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($dataPending as $value) {$no++ ?>
						      <tr>
						        <td><?php echo $no;?></td>
						        <td><?php echo $value->KPS_OS_CREATION_DATE;?></td>
						        <td><?php echo $value->KPS_OS_NO;?></td>
						        <td><?php echo $value->KPS_OS_DN_DATE;?></td>
						        <td><?php echo $value->KPS_OS_DN_NO;?></td>
						        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
						        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
						        <td><?php echo $value->COMPANY_NAME;?></td>
						        <td><?php echo $value->LOI_CODE_ITEM;?></td>
						        <td><?php echo $value->LOI_PART_NAME;?></td>
						        <td><?php echo $value->LOI_PART_NO;?></td>
						        <td><?php echo $value->LOI_MODEL;?></td>	
						        <td><?php echo $value->QUANTITY_DELIVERY;?></td>	
						        <td><?php echo $value->unit;?></td>	
						        <td><?php echo $value->KPS_DELIVERY_ORDER_DELIVERY_DATE;?></td>	
						        <td><?php echo $value->NO_DO;?></td>	
						        <td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>	
						        <td><?php echo $value->unit;?></td>	
						        <td><?php echo "confirm Masalah retur"?></td>	
						        <td><?php echo "confirm Masalah retur"?></td>	
								<td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>	
						        <td><?php echo $value->unit;?></td>		
						        <td><?php echo $value->QTY_PENDING_OFGD;?></td>		
						        <td><?php echo $value->unit;?></td>		
						        <td><?php if($value->QTY_PENDING_OFGD){
									echo "OPEN";
								}else{ echo "CLOSE"; } ?></td>		
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE-->
				</div>
	
</div>