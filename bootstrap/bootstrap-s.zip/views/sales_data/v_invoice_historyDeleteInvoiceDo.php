
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<!--Di betulkan di revisiRetur.js-->
		<table id="invoice_detail_no"  class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Invoice Induk No</th>
		        <th>Customer</th>
		        <th>No DO</th>
		        <th>Confirm View</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			       
			        <td><?php echo $no?></td>
			        <td><?php echo $value->INVOICE_INDUK_NO?></td>
			        <td><?php echo $value->COMPANY_NAME?></td>
			        <td><?php echo $value->NO_DO?></td>
			        <td><a href="<?php echo site_url()."/invoice/confirm_view_Do/".$value->ID;?>" class="btn btn-default btn-sm"><i class="fa fa-print"></i>Confirm</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Invoice</button>
	</div>
</div>