<section class="content-header">
	<h3>Cost Of Delivery Product </h3>
	<small>Cost Of Delivery Product</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
<div class="box-body overflow">
	<div class="box-body">
		<!--TABLE-->
		<table id="codp" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Customer</th>
		        <th>Code Product</th>
		        <th>Part No</th>		        
		        <th>Part Name</th>		        
		        <th>Cost Base ON Breakdown</th>		        
		        <th>Cost Set UP</th>		        
		        <th>Currency</th>		        
		        <th>Status</th>		        
		        <th>Action</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no; ?></td>
			        <td><?php echo $value->COMPANY_NAME; ?></td>
			        <td><?php echo $value->LOI_CODE_ITEM; ?></td>
			        <td><?php echo $value->LOI_PART_NO; ?></td>
			        <td><?php echo $value->LOI_PART_NAME; ?></td>
			        <td><?php echo $value->transportation_charge; ?></td>
			        <td><?php echo $value->COST_DELIVERY_PRODUCT; ?></td>
			        <td><?php echo $value->CURRENCY_NAME; ?></td>
			        <td><?php if($value->COST_DELIVERY_PRODUCT == '0' or $value->COST_DELIVERY_PRODUCT == NULL){
			        	echo "Open";
			        	}else{
			        		echo "Closed";
			        		}?></td>
			        <td><a href="#" url="<?php echo site_url()."/cost_of_delivery_product/edit/".$value->KPS_BREAKDOWN_COST_ID;?>" data-toggle="modal" data-target="#add" class="update-link">Set UP Cost</a></td>
				 </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
</div>
<!--MODAL-->
<div class="modal fade" id="add" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">

    </div>
    
  </div>
</div>
<!-- Modal ADD -->
