<section class="content-header">
	<h3>Outgoing Return Product</h3>
	<small>Outgoing Retur Product</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="outgoing_rp" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>No Outgoing</th>
		        <th>Rev No</th>
		        <th>Date</th>
		        <th>Customer Name</th>
		        <th>NO Retur</th>
		        <th>Vehicle Name</th>
		        <th>Vehicle No</th>
		        <th>Driver</th>
		        <th>Asisten</th>
		        <th>Total</th>
		        <th>Made By</th>
		        <th>Delete</th>		        
		        <th>Update</th>		        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->OUTGOING_RETUR_PRODUCT_NO;?></td>
			        <td><?php echo $value->OUTGOING_RETUR_PRODUCT_NO_REV;?></td>
			        <td><?php echo $value->OUTGOING_RETUR_PRODUCT_DATE;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_RETUR;?></td>
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
			        <td><?php echo $value->employee_driver_id;?></td>
			        <td><?php echo $value->OUTGOING_RETUR_ASISTEN_DRIVER;?></td>
			        <td><?php echo $value->TOTAL_OUTGOING;?></td>
			        <td><?php echo $value->OUTGOING_RETUR_PRODUCT_MADE_BY;?></td>
			        <td><a href="#"  data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
			        <td><a href="#"  data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/outgoing_retur_product/detail/".$value->OUTGOING_RETUR_PRODUCT_ID ."/". $value->KPS_RETUR_BARANG_ID_OUT;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Bukti Pesanan</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Retur Product</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_retur_product/add";?>" method="POST" class="form-horizontal">
				<div class="form-group">
		          <label class="col-sm-3 control-label">Company Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" urldivisi="<?php echo site_url() ?>/pesanan/loadDivisi" id="divisiPesanan">					  
					    <option>-- Select Company --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">No Retur - No Retur From Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" urldivisi="<?php echo site_url() ?>/pesanan/loadDivisi" id="divisiPesanan"  name="KPS_RETUR_BARANG_ID_OUT">					  
					    <option>-- Select No Retur --</option>
					    <?php foreach ($dataRetur as $value) { ?>
					    <option value="<?php echo $value->KPS_RETUR_BARANG_ID;?>"><?php echo $value->NO_RETUR . '  --  ' . $value->NO_RETUR_FROM_CUSTOMER ;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">KPS Vehicle</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_VEHICLE_ID_OG_RTR">					  
					    <option>-- Select Vehicle --</option>
					    <?php foreach ($dataVeh as $value) { ?>
					    <option value="<?php echo $value->KPS_VEHICLE_ID;?>"><?php echo $value->VEHICLE_NO;?> - <?php echo $value->VEHICLE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Driver</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_driver_id">					  
					    <option>-- Select Driver --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Driver Asisten</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="OUTGOING_RETUR_ASISTEN_DRIVER" placeholder="Nama Asisten">
		          </div>
		        </div>
				 <div class="form-group">
				  <label class="col-sm-3 control-label">Made By</label>
				  <div class="col-sm-9">
					 <input type="text" class="form-control" name="OUTGOING_RETUR_PRODUCT_MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
					<input type="hidden" class="form-control" name="OUTGOING_RETUR_PRODUCT_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
				  </div>
				</div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->