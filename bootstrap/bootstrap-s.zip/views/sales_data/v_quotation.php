<section class="content-header">
	<h3>Quotation Data</h3>
	<small>Data Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!-- Show/Hide Column :
		<div class="box-body">
			
		<div class="btn-group" role="group" aria-label="..."><center>

		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Quotation No</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Quotation Date</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Revisi Number</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Valid From</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Valid Until</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Currency</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">RFQ Number </a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Customer Name</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Address</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Phone</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Fax</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="12">PIC </a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="13">Email</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="14">Marketing Name</a></button>
		  </center>
		</div>
		</div> -->
		
		<!--TABLE-->
		<table id="quotation" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Quotation No</th>
		        <th>Quotation Date</th>
		        <th>Revisi Number</th>
		        <th>Valid From</th>
		        <th>Valid Until</th>
		        <th>Currency</th>
		        <th>RFQ Number</th>
		        <th>Customer Name</th>
		        <th>Address</th>
		        <th>Phone</th>
		        <th>Fax</th>
		        <th>PIC</th>
		        <th>Email</th>
		        <th>Marketing Name</th>
		        <th>Action</th>	
		         
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<th width="20px">Action</th>
		        	<?php
		        	}?>       
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_quo=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_quo;?></td>
			        <td><?php echo $value->NO_QUO;?></td>
			        <td><?php echo $value->DATE_QUO;?></td>
			        <td><?php echo $value->RFQ_REV_NO;?></td>
			        <td><?php echo $value->VALID_DATE_FROM;?></td>
			        <td><?php echo $value->VALID_DATE_UNTIL;?></td>
			        <td><?php echo $value->CURRENCY_NAME;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_NO;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->PLANT;?></td>
			        <td><?php echo $value->PHONE;?></td>
			        <td><?php echo $value->FAX;?></td>
			        <td><?php echo $value->NAME;?></td>
			        <td><?php echo $value->EMAIL;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>
			        
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/quotation/detail/".$value->KPS_QUOTATION_ID;?>" <?php if($value->status_quo==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/quotation/edit/".$value->KPS_QUOTATION_ID;?>" <?php if($value->status_quo==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/quotation/history/".$value->KPS_QUOTATION_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/quotation/del/".$value->KPS_QUOTATION_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/quotation/pre_print/".$value->KPS_QUOTATION_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>   
			        <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/quotation/lock/".$value->KPS_QUOTATION_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a><a href="<?php echo site_url()."/quotation/unlock/".$value->KPS_QUOTATION_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
<!-- Revisi For Quotation Start -->
	<div class="box-body">
		<button type="button" href="" url="<?php echo site_url()."/quotation/preAdd/";?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Quotation</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Revisi For Quotation End -->
<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->