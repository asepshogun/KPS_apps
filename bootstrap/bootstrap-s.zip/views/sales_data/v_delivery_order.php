<section class="content-header">
	<h3>Delivery Order</h3>
	<small>Surat Jalan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="delivery" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Print Status</th>
		        <th>Revisi Status</th>
		        <th>Invoice Status</th>
		        <th>Customer Confirm Status</th>
		        <th>Rev No</th>
		        <th>Outgoing Number</th>
		        <th>Outgoing Date</th>
		         <th>Delivery Order Number</th>
		        <th>Delivery Order Input Date</th>
		        <th>Delivery Order Date</th>
		        <th>Rev</th>
		        <th>Customer</th>
		        <th>Customer Plant</th>
		        <th>PO Date</th>
		        <th>PO Number</th>
		        <th>Vehicle Name</th>
		        <th>Vehicle No</th>
		        <th>Driver</th>
		        <th>Employee Accepted</th>	        
		        <th>Employee Approved</th>		        
		        <th>Employee Known</th>
		        <th>Made By</th>
		        <th>Total Qty</th>
		        <th>Action</th>		        
		       
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular" ){
		        	?> 
		        	<th width="20px">Lock/Unlock</th>
		        	<?php
		        	}?> 
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no++;?></td>
			        <td>
			        <?php 
			        	if($value->status_do=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php
						if($value->KPS_DO_STATUS_PRINTED){
							$time = strtotime($value->KPS_DO_STATUS_PRINTED);
							$myFormatForView = date("d/m/Y", $time);
							echo "printed at " . $myFormatForView;
						}else{
							echo "Open Print";
						}
					?></td>
					<td><?php
						if($value->KPS_DO_STATUS_REVISI){
							echo "REVISI" ;
						}else{
							echo "OK";
						}
					?></td>
			        <td><?php 
				   		$invoice = $this->db->query("SELECT * FROM `kps_invoice_detail` WHERE delivery_order_id = '".$value->KPS_DELIVERY_ORDER_ID."'")->first_row();
						if($invoice){
						echo "CLOSE";
						}else{
						echo "OPEN";} ?></td>
			        <td><?php 				   		
						$statusConfirm = $this->db->query("SELECT * FROM `kps_delivery_order_confirm` WHERE KPS_DO_ID_CONFIRM = '".$value->KPS_DELIVERY_ORDER_ID."'")->first_row();
						if($statusConfirm){	
							if($statusConfirm->RECEIVED_DECISION=="NG"){
								echo "OPEN";
							}else{
								echo "CLOSE";
							}
						}else{
							echo "OPEN";
						}
					?></td>
			        <td><?php echo $value->revisi_no_do;?></td>
			        <td><?php echo $value->NO_OUTGOING;?></td>
			        <td><?php echo $value->DATE_OUTGOING;?></td>
			        <td><?php echo $value->NO_DO;?></td>
			        <td><?php echo $value->DATE_DO;?></td>
			        <td><?php echo $value->KPS_DELIVERY_ORDER_DELIVERY_DATE;?></td>
			        <td><?php echo $value->REV_NO_DO;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php 
			        	$query = $this->db->query("select * from kps_outgoing_finished_good_detail 
			        		join kps_delivery_schedule_detail on(kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID=kps_outgoing_finished_good_detail.KPS_DELIVERY_SCHEDULE_DETAIL_ID_FGD)
			        		join kps_bukti_pesanan_detail on(kps_bukti_pesanan_detail.KPS_BUKTI_PESANAN_DETAIL_ID=kps_delivery_schedule_detail.KPS_BUKTI_PESANAN_DETAIL_ID_SD)
			        		join kps_loi on(kps_loi.KPS_LOI_ID=kps_bukti_pesanan_detail.KPS_LOI_ID_BK)
			        		join kps_delivery_schedule on(kps_delivery_schedule.KPS_DELIVERY_SCHEDULE_ID=kps_delivery_schedule_detail.KPS_DELIVERY_SCHEDULE_ID)
			        		join kps_customer_delivery_setup on(kps_customer_delivery_setup.KPS_CUSTOMER_DELIVERY_SETUP=kps_delivery_schedule_detail.KPS_CUSTOMER_DELIVERY_SETUP_ID)
			        		where KPS_OUTGOING_FINISHED_GOOD_ID_D='".$value->KPS_OUTGOING_FINISHED_GOOD_ID_DO."' GROUP BY PLANT1_CITY");
						$datax = $query->result();	
						// print_r($datax);
						// echo $datax->PLANT1_CITY;
						$countDatax = count($datax);
						// print_r($datax);
						foreach($datax as $plant){
							if($countDatax>=2){
								echo $plant->PLANT1_CITY .":". $plant->NO_REV_NO ." Code Item :". $plant->LOI_CODE_ITEM  ."<br/>" ;
							}else{
							echo $plant->PLANT1_CITY;
							}
						}
						// print_r($datax);
			        ?></td>
			        <td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td>
			        <?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_accepted_id."'")->first_row();
			      		echo $q1->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			      	<td>
			        <?php
			      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_approved_id_DO."'")->first_row();
			      		echo $q2->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			      	<td>
			        <?php
			      		$q3 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_known_id."'")->first_row();
			      		echo $q3->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			        <td>
			        <?php
			      		$q4 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->user_made_by_id_do."'")->first_row();
			      		echo $q4->EMPLOYEE_NAME;
			      	?>	
			      	</td>
			        <td><?php echo $value->TOTAL_QTY;?></td>

		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/delivery_order/detail/".$value->KPS_DELIVERY_ORDER_ID;?>" <?php if($value->status_do==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/delivery_order/edit/".$value->KPS_DELIVERY_ORDER_ID;?>" <?php if($value->status_do==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/delivery_order/history/".$value->KPS_DELIVERY_ORDER_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/delivery_order/del/".$value->KPS_DELIVERY_ORDER_ID;?>">Delete</a></li>
                        <li><a href="" url="<?php echo site_url()."/delivery_order/confirmation/".$value->KPS_DELIVERY_ORDER_ID;?>"<?php if($value->KPS_DO_STATUS_PRINTED){ echo " ";}else{echo "disabled onclick = 'return false'";} ?> data-toggle="modal" data-target="#confirm" class="update-link">Confirmation</a></li>
                        <li><a href="<?php echo site_url()."/delivery_order/confirmRevisi/".$value->KPS_DELIVERY_ORDER_ID;?>">Confirm Revisi</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/delivery_order/pre_print/".$value->KPS_DELIVERY_ORDER_ID;?>" <?php if($value->KPS_DO_STATUS_REVISI){ echo "disabled onclick = 'return false'";}else{echo " ";} ?> target="_blank">Print</a></li>
                      </ul>
		        	</div></td>      	
			       
			          <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular" ){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/delivery_order/lock/".$value->KPS_DELIVERY_ORDER_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i>
		        		<?php
		        	}?>  
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	</a><a href="<?php echo site_url()."/delivery_order/unlock/".$value->KPS_DELIVERY_ORDER_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Deliver Order</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Order Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_order/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
	              <label class="col-sm-3 control-label">Company Name</label>
	              <div class="col-sm-9">
	                <select class="form-control select2" style="width: 100%;" urlcurr="<?php echo site_url()."/delivery_order/loadOutgoing";?>" urldivisi="<?php echo site_url()."/pesanan/loadDivisi";?>" id="custOutgoing" name="KPS_CUSTOMER_ID_BK">           
	              <option>-- Select Company --</option>
	              <?php foreach ($dataCust as $value) { ?>
	              <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
	              <?php } ?>            
	          </select>
	              </div>
	            </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Outgoing Finished Good</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="outgoing" urldivisi="<?php echo site_url() ?>/delivery_order/loadPlant" name="KPS_OUTGOING_FINISHED_GOOD_ID_DO">					  
					    <option>-- Select Outgoing --</option>
					  				  
					</select>
		          </div>
		        </div>
				<!--
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Plant</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="plant" name="KPS_CUSTOMER_PLANT_ID_DO">					  
					    <option>-- Select Customer Plant --</option>
					    		  
					</select>
		          </div>
		        </div> -->
				<div class="form-group">
		          <label class="col-sm-3 control-label">Delivery Date</label>
		          <div class="col-sm-9">
		            <input type="date" class="form-control" name="KPS_DELIVERY_ORDER_DELIVERY_DATE" placeholder="pic date" value="<?php echo date('Y-m-d'); ?>" >
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_approved_id_DO">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Accepted By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_accepted_id">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Known By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_known_id">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BY_DOs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="user_made_by_id_do" value="<?php echo $this->session->userdata('employeeId'); ?>">
		          </div>
		        </div>
				<!--
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Address</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="ADDRESS" placeholder="address">
		          </div>
		        </div>
				-->
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!-- Modal CONFIRM -->
<div class="modal fade" id="confirm" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal CINFIRM -->

<!--MODAL-->