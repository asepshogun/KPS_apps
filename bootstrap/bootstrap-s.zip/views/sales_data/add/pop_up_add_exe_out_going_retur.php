<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">QTY Execution Retur</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/Outgoing_retur_product/insertExe/";?>" method="POST" class="form-horizontal">
		
		<div class="form-group">
		  <label class="col-sm-3 control-label">Code Item</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="loi" readonly value="<?php echo $returDetail->LOI_CODE_ITEM;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Part No</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_TIME" disabled value="<?php echo $returDetail->LOI_PART_NO;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Part Name</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_TIME" disabled value="<?php echo $returDetail->LOI_PART_NAME;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Remaining Retur</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="QTY_REMAINIG_EXECUTION_OUT" readonly value="<?php echo $QTY_REMAINIG_EXECUTION_OUT;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">QTY Execution Retur</label>
		  <div class="col-sm-9">
			<input type="number" class="form-control" name="QTY_EXECUTION_OUT" placeholder="EX : 1234531">
			<input type="hidden" class="form-control" name="KPS_RETUR_BARANG_DETAIL_ID_OUT_DETAIL" value="<?php echo $returDetail->KPS_RETUR_BARANG_DETAIL_ID;?>">
			<input type="hidden" class="form-control" name="KPS_RETUR_BARANG_ID_DET" value="<?php echo $returDetail->KPS_RETUR_BARANG_ID_DET;?>">
			<input type="hidden" class="form-control" name="OUTGOING_RETUR_PRODUCT_ID_DETAIL" value="<?php echo $id_outgoing;?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	    
</div>