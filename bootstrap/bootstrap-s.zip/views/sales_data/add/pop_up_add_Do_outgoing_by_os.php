<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Delivery Order By OS</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/delivery_order/add";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Company Name</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" urlOutForDo="<?php echo site_url()."/delivery_order/loadOutgoingOs";?>"  id="custOutgoingOs" name="KPS_CUSTOMER_ID_BK">           
		  <option>-- Select Company --</option>
		  <?php foreach ($dataCust as $value) { ?>
		  <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
		  <?php } ?>            
	  </select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Outgoing Finished Good</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" id="outgoingOsForDo" urlPlantDoOs="<?php echo site_url() ?>/delivery_order/loadPlantOs" name="KPS_OUTGOING_FINISHED_GOOD_ID_DO">					  
				<option>-- Select Outgoing --</option>
							  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Plant</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" id="plantOsForDo" name="KPS_CUSTOMER_PLANT_ID_DO">					  
				<option>-- Select Customer Plant --</option>
						  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_approved_id">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Accepted By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_accepted_id">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Known By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_known_id">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_DOs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY_DO" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	        	    			    			      		            			      		        
</div>