<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Return Pending Order Sheet</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/order_sheet/returnPending/" . $idOs;?>" method="POST" class="form-horizontal">
		
		<div class="form-group">
		  <label class="col-sm-3 control-label">Schedule Delivery Date</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_DATE" placeholder="Pick Date">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Schedule Delivery Time</label>
		  <div class="col-sm-9">
			<input type="time" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_TIME" placeholder="Pick Date">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_approved_id">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		  <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_OSs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY_OS" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-sm-3 control-label">Note</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="NOTE_OS" placeholder="note">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	    
</div>