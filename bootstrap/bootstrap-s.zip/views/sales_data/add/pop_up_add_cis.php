<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Add Customer Information</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/customer_information/add";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Marketing</label>
		  <div class="col-sm-9">
			<select required class="form-control select2" style="width: 100%;" name="marketing_id" >					  
				<option value="">-- Select Marketing --</option>
				<?php foreach ($dataMarketing as $value) { ?>
				<option value="<?php echo $value->KPS_MARKETING_ID;?>"><?php echo $value->MARKETING_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Company Name</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="COMPANY_NAME" placeholder="company name" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Code</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="CUSTOMER_CODE" placeholder="customer code" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">KPS Made By</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="MADE_BY" value="<?php echo $this->session->userdata('name'); ?>" disabled>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">KPS Checked</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="CHECKED">					  
				<option>-- Select Checked --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID; ?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">KPS Approved</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="APPROVED">					  
				<option>-- Select Approved --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Made By</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="CUSTOMER_MADE_BY" placeholder="customer made by">
		  </div>
		</div>		        
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Checked</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="CUSTOMER_CHECKED" placeholder="customer checked">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Approved</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="CUSTOMER_APPROVED" placeholder="customer approved">
		  </div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Customer Industry</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" id="auto" name="CUSTOMER_INDUSTRY" value="Automotive">
				  Automotive
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio" id="nonautuo" name="CUSTOMER_INDUSTRY" value="Non Automotive">
				  Non Automotive
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Automotive Type</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" class="oem" name="AUTOMOTIVE_TYPE" value="OEM" required>
				  OEM
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio"  class="oem" name="AUTOMOTIVE_TYPE" value="Non OEM" required>
				  Non OEM
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Sales Type</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" name="SALES_TYPE" value="Local" required>
				  Local
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio" name="SALES_TYPE" value="Export" required>
				  Export
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Sales Tax</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" name="SALES_TAX" value="Tax" required>
				  Tax
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio" name="SALES_TAX" value="Non Tax" required>
				  Non Tax
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Payment as Personal</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" name="CIS_PAYMENT_TO_PERSONAL" value="1" required>
				  Yes
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio" name="CIS_PAYMENT_TO_PERSONAL" value="2" required>
				  No
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Payment</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="PAYMENT">					  
					<option value="0">— Select Payment —</option>
				  <option value="50% DP, 50% Before Delivery">50% DP, 50% Before Delivery</option>
				  <option value="1 Week After Invoice">1 Week After Invoice</option>
				  <option value="2 Week After Invoice">2 Week After Invoice</option>
				  <option value="1 Month After Invoice">1 Month After Invoice</option>
				  <option value="2 Month After Invoice">2 Month After Invoice</option>
				  <option value="3 Month After Invoice">3 Month After Invoice</option>			    					 
			</select>
		  </div>
		</div>		        
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	        		      		        
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>