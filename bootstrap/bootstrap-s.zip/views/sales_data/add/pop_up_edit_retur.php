<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Update  Retur Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/Retur_product/exeUpdate/";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-lg-3 control-label">Code Item - Part NO - Part Name</label>
			<div class="col-lg-9">
				<select name="KPS_LOI_ID_RETUR" id="pesananloiid"  url="<?php echo site_url(); ?>/pesanan/loadModelPrice" class="form-control select2" style="width: 100%">
					<option value="0">-- Select Code Product - Part Name - Part No --</option>
					<?php foreach ($loi as $value) { ?>
					<option value="<?php echo $value->KPS_LOI_ID;?>" <?php if($value->KPS_LOI_ID==$data->KPS_LOI_ID_RETUR){ echo "selected=''";	} ?>><?php echo $value->LOI_CODE_ITEM; ?> - <?php echo $value->LOI_PART_NAME; ?> - <?php echo $value->LOI_PART_NO; ?></option>
					<?php } ?>	
				</select>
			</div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">QTY</label>
		  <div class="col-lg-9">
			<input type="number" class="form-control" name="QTY_RTR" value="<?php echo $data->QTY_RTR; ?>">
		  </div>
		</div>
		<div class="form-group">
		<label class="col-lg-3 control-label">Reason</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="KPS_RETUR_BARANG_ID_DET" value="<?php echo $data->REASON; ?>">
			<input type="hidden" class="form-control" name="KPS_REVISI_NO_RETUR" value="<?php echo $data->KPS_REVISI_NO_RETUR; ?>">
			<input type="hidden" class="form-control" name="KPS_RETUR_BARANG_DETAIL_ID" value="<?php echo $data->KPS_RETUR_BARANG_DETAIL_ID; ?>">
			<input type="hidden" class="form-control" name="KPS_RETUR_BARANG_ID_DET" value="<?php echo $data->KPS_RETUR_BARANG_ID_DET; ?>">
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-sm-3 control-label">Update By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="KPS_MADE_BY_RETUR_DETAILs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="KPS_MADE_BY_RETUR_DETAIL" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>			
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	
</div>