<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Outgoing By OS</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/pesanan/add";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Company Name</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;"  urldivisi="<?php echo site_url()."/pesanan/loadDivisi";?>" urlcurr="<?php echo site_url()."/pesanan/loadCurr";?>" id="divisiPesanan" name="KPS_CUSTOMER_ID_BK">					  
				<option>-- Select Company --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Customer Divisi</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;"  id="qdivisi" name="KPS_CUSTOMER_DIVISI_ID_BK">					  
				<option>-- Select Divisi --</option>
								  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">KPS Currency</label>
		  <div class="col-sm-9">
			<select class="form-control select2" id="qcurr" style="width: 100%;" name="CURRENCY_BP">					  
				<option>-- Select Currency --</option>
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_approved_id">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">PO Number Customer</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="PO_OS_NO_FROM_CUSTOMER" placeholder="po number customer">
			<input type="hidden" value="0" class="form-control" name="SUB_TOTAL_BP" placeholder="po number customer">
			<input type="hidden" value="0" class="form-control" name="TAX_BP" placeholder="po number customer">
			<input type="hidden" value="0" class="form-control" name="TOTAL_BP" placeholder="po number customer">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">PO Date Customer</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="PO_OS_DATE_FROM_CUSTOMER" placeholder="Pick Date">
		  </div>
		</div>
	   
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_FAILEDs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="user_made_by_id" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Status Verifikasi</label>
			<div class="col-sm-9">						
			  <div class="radio">
				<label>
				  <input type="radio" name="KPS_BP_STATUS_VERIFIKASI_CUSTOMER" value="OK">
				  OK
				</label>
			  </div>
			  <div class="radio">
				<label>
				  <input type="radio" name="KPS_BP_STATUS_VERIFIKASI_CUSTOMER" value="Not Good">
				  Not Good
				</label>
			  </div>		                
			</div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	         			      		            			      		        
</div>