<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Form New Quotation Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/quotation/add";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Request for Quotation</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" urlcurr="<?php echo site_url()."/quotation/loadCurr";?>" urlpic="<?php echo site_url()."/quotation/loadPic";?>" name="KPS_RFQ_ID_QUO" id="qrfq_id">					  
				<option>-- Select RFQ --</option>
				<?php foreach ($dataRfq as $value) { ?>
				<option value="<?php echo $value->KPS_RFQ_ID; ?>"><?php echo $value->COMPANY_NAME." - ".$value->NO_RFQ." - ".$value->RFQ_CUSTOMER_NO;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">RFQ Currency</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO" id="QKPS_RFQ_CURENCY_ID_QUO">	
			<option>-- Select Currency --</option>					  			  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Valid From</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="VALID_DATE_FROM" placeholder="Pick Date">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Valid Until</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="VALID_DATE_UNTIL" placeholder="Pick Date" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Person in Charge</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="kps_customer_is_person_in_charge_quo" id="qpic">					 
				<option>-- Select PIC --</option>					
	
			</select>
		  </div>
		</div>
		
		<div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_QUOs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY_QUO" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Checked By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="CHECKED_QUO">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="APPROVED_QUO">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Quotation Note</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="NOTE_QUO" placeholder="note">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	  	        	          		      		        
</div>
<?php
$this->load->view('template/lib');
?>