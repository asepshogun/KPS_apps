<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Add LOI</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/item/add";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Company Name</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" urlcurr="<?php echo site_url()."/pesanan/loadCurr";?>" urldivisi="<?php echo site_url()."/item/loadRFQs";?>" id="cust" name="KPS_CUSTOMER_ID_BK">					  
				<option>-- Select Company --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Request for Quotation</label>
		  <div class="col-sm-9">
			<select class="form-control select2"  url="<?php echo site_url()."/item/loadProd2";?>" id="modelLoi" style="width: 100%;" name="KPS_RFQ_ID_LOI">					  
				<option>-- Select RFQ --</option>
								  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Item Master</label>
		  <div class="col-sm-9">
			<select class="form-control select2" url="<?php echo site_url()."/item/loadProd";?>" id="loiItemMaster" style="width: 100%;" name="KPS_LOI_ITEM_MASTER_ID">					  
				<option>-- Select Item Master --</option>
				<?php foreach ($itemMaster as $values) { ?>
				<option value="<?php echo $values->KPS_ITEM_MASTER_ID;?>"> Code Item : <?php echo $values->KPS_ITEM_MASTER_CODE_ITEM;?> -- Part No : <?php echo $values->KPS_ITEM_MASTER_PART_NO;?> -- Part Name : <?php echo $values->KPS_ITEM_MASTER_PART_NAME;?></option>
				<?php } ?>			  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Code Product</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" id="code_item" name="LOI_CODE_ITEM" readonly=readonly placeholder="Code Item" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Part Number</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" id="part_no" name="LOI_PART_NO" readonly=readonly  placeholder="Part No" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Part Name</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" id="part_name" name="LOI_PART_NAME" readonly=readonly  placeholder="Part Name" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Model</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" id="model" name="LOI_MODEL" readonly=readonly  placeholder="Model" required>
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-lg-3 control-label">Standard Packing</label>
		  <div class="col-lg-9">
			<input type="number" class="form-control" id="standardPacking" name="LOI_STRANDART_PACKING"  placeholder="Standard Packing" required>
		  </div>
		</div>
		 <div class="form-group">
		  <label class="col-lg-3 control-label">Product Classification</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="LOI_PRODUCT_CLASIFICATION" placeholder="Product Classification">
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-lg-3 control-label">Note</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="LOI_PART_NOTE" placeholder="Note">
		  </div>
		</div>		 
		<div class="form-group">
		  <label class="col-sm-3 control-label">Die Go Number</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="LOI_DIE_GO_NO" placeholder="die go no">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Discontinue Date</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DISCONTINUE_DATE" placeholder="Pick Date">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Minimal Stock</label>
		  <div class="col-sm-9">
			<input type="number" class="form-control" name="MIN_STOK" placeholder="min stock" required>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Maximal Stock</label>
		  <div class="col-sm-9">
			<input type="number" class="form-control" name="MAX_STOCK" placeholder="max stock" required>
		  </div>
		</div>
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_LOIs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY_LOI" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Checked By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="CHECKED_LOI">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Accepted By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="ACCEPTED_LOI">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="APPROVED_LOI">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">New Item Note</label>
		  <div class="col-sm-9">
			<textarea class="form-control" name="note" placeholder="note"></textarea>
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	       	     	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>