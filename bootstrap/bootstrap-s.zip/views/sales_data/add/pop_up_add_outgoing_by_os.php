<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Outgoing By OS</h4>
</div>
<div class="modal-body">
	
	<form action="<?php echo site_url()."/outgoing_finished/addByOs";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">Company Name</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;"  urlOsOut="<?php echo site_url()."/outgoing_finished/loadOsOut";?>" id="CustomerForOsOut">					  
				<option>-- Select Company --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">No OS / DN</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" id="osForOutGoing" urlDsOsOut="<?php echo site_url()."/outgoing_finished/loadDateForOs";?>" name="KPS_OS_ID_OGFG">					  
				<option>-- Select Order Sheet --</option>				  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">KPS Vehicle</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="KPS_VEHICLE_ID">					  
				<option>-- Select Vehicle --</option>
				<?php foreach ($dataVeh as $value) { ?>
				<option value="<?php echo $value->KPS_VEHICLE_ID;?>"><?php echo $value->VEHICLE_NO;?> - <?php echo $value->VEHICLE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Driver</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_driver_id">					  
				<option>-- Select Driver --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Checked By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="CHECKED">					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		  <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-sm-3 control-label">Delivery Schedule</label>
		  <div class="col-sm-9">
			<input type="date" class="form-control" readonly="readonly" id="DdForOsOut" name="DELIVERY_DATE" placeholder="Delivery Date">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	        	    			      		            			      		        
</div>