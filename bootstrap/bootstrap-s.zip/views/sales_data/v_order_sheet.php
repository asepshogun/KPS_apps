<section class="content-header">
	<h3>Order Sheet</h3>
	<small>Lembar Pemesanan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	
	<!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">Order Sheet</a></li>
                  <li><a href="#tab_2" data-toggle="tab">Order Sheet Pending</a></li>
                  <li><a href="#tab_3" data-toggle="tab">Return Order Sheet Pending</a></li>
                  
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                  <div class="box-body">
                    <!--TABLE-->
							<?php if($this->session->flashdata('errorNoOs')) { ?>
								  <div class="alert alert-danger alert-dismissable">
								  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								  <h4><i class="icon fa fa-ban"></i> Alert!</h4><h4><center>
								  <?php echo $this->session->flashdata('errorNoOs'); ?> 
								  </center></h4></div>
							<?php } ?>
					<table id="os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
					        <th>LOCK</th>
					        <th>Order Sheet Date</th>
					        <th>Order Sheet No</th>
					        <th>Order Sheet Rev No</th>
					        <th>Customer Name</th>
					        <th>Divisi Name</th>
					        <th>Adress</th>
					        <th>Schedule Delivery Date</th>
					        <th>Schedule Delivery Time</th>
					        <th>Delivery Place</th>
					        <th>Printed Date</th>	        
					        <th>OS/DN Date</th>		        
					        <th>OS/DN NO</th>		
							<th>Note</th>		        
					        <th>Approved</th>		        
					        <th>Made By</th>		              
					        <th>Delete</th>		        			        
					        <th>Update</th>		        
					        <th>Detail</th>
					        <th>History</th>
					        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
					        	?> 
					        	<th width="20px">Action</th>
					        	<?php
					        	}?>  
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($data as $value) {$no++ ?>
						      <tr>
						        <td><?php echo $no;?></td>
						        <td>
						        <?php 
						        	if($value->status_os=="0"){
						        		?> 
						        		<center><span class="label label-info">Unlock</span></center>
						        		<?php
						        	}else{
						        	?> 
						        		<center><span class="label label-danger">lock</span></center>
						        	<?php	
						        	}
						        ?>
						        </td>
						        <td><?php echo $value->KPS_OS_CREATION_DATE;?></td>
						        <td><?php echo $value->KPS_OS_NO;?></td>
						        <td><?php echo $value->KPS_OS_REV_NO;?></td>
						        <td><?php echo $value->COMPANY_NAME;?></td>
						        <td><?php echo $value->DIVISI;?></td>
						        <td>
						        <?php
						      		$q3 = $this->db->query("SELECT * FROM `kps_customer_plant` WHERE KPS_CUSTOMER_ID = '".$value->KPS_CUSTOMER_ID."'")->first_row();
						      		echo $q3->PLANT;
						      	?>	
						      	</td>
						        <td><?php echo $value->KPS_OS_SCHEDULE_DELIVERY_DATE;?></td>
						        <td><?php echo $value->KPS_OS_SCHEDULE_DELIVERY_TIME;?></td>
						        <td><?php echo $value->PLANT1_CITY;?></td>
						        <td><?php echo $value->KPS_OS_PRINTED_DATE;?></td>
						        <td><?php echo $value->KPS_OS_DN_DATE;?></td>
						        <td><?php echo $value->KPS_OS_DN_NO;?></td>
								<td><?php echo $value->NOTE_OS;?></td>
								<td>
						        <?php
						      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->employee_approved_id."'")->first_row();
						      		echo $q1->EMPLOYEE_NAME;
						      	?>	
						      	</td>
								<td>
						        <?php
						      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$value->MADE_BY_OS."'")->first_row();
						      		echo $q2->EMPLOYEE_NAME;
						      	?>	
						      	</td>
								<td><a  href="" url="<?php echo site_url()."/order_sheet/predel/".$value->KPS_OS_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>		        
						        <td><a href="" url="<?php echo site_url()."/order_sheet/edit/".$value->KPS_OS_ID;?>" class="btn btn-warning btn-sm <?php if($value->status_os==1){
						        	echo "disabled";
						        	}else{
						        		echo "";
						        		}?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
						        <td><a href="<?php echo site_url()."/order_sheet/detail/".$value->KPS_OS_ID;?>" class="btn btn-primary btn-sm <?php if($value->status_os==1){
						        	echo "disabled";
						        	}else{
						        		echo "";
						        		}?>">Detail</a></td>
						         <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
					        	?> 
					        	<td><div class="btn-group"><a href="<?php echo site_url()."/order_sheet/lock/".$value->KPS_OS_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a><a href="<?php echo site_url()."/order_sheet/unlock/".$value->KPS_OS_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
					        	<?php
					        	}?>
								<td><a  href="<?php echo site_url()."/order_sheet/history/".$value->KPS_OS_ID;?>">History</a></td>		        						
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE-->
				</div>

				<div class="box-body">
					<button type="button" href="" url="<?php echo site_url()."/order_sheet/add/";?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Order Sheet</button>
				</div>
                  </div><!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    <div class="box-body">
					<!--TABLE-->
					<h4>Order Sheet Pending</h4>
					<div class="box-body overflow">
					<table id="os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
					        <th>Order Sheet Date</th>
					        <th>Order Sheet No</th>
					        <th>Order Sheet Rev No</th>
					        <th>Customer Name</th>
					        <th>Divisi Name</th>
					        <th>Adress</th>
					        <th>Schedule Delivery Date</th>
					        <th>Schedule Delivery Time</th>
					        <th>Delivery Place</th>
					        <th>Printed Date</th>	        
					        <th>OS/DN Date</th>		        
					        <th>OS/DN NO</th>		        
					        <th>Total Pending</th>		        
					        <th>Approved</th>		        
					        <th>Made By</th>		              	        
					        <th>Detail</th>
							<th>Return Pending</th>
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($dataPending as $valuep) {$no++ ?>
						      <?php if($valuep->TotalPending){ ?>
								  <tr>
									<td><?php echo $no;?></td>
									<td><?php echo $valuep->KPS_OS_CREATION_DATE;?></td>
									<td><?php echo $valuep->KPS_OS_NO;?></td>
									<td><?php echo $valuep->KPS_OS_REV_NO;?></td>
									<td><?php echo $valuep->COMPANY_NAME;?></td>
									<td><?php echo $valuep->DIVISI;?></td>
									<td>
									<?php
										$q3 = $this->db->query("SELECT * FROM `kps_customer_plant` WHERE KPS_CUSTOMER_ID = '".$valuep->KPS_CUSTOMER_ID."'")->first_row();
										echo $q3->PLANT;
									?>	
									</td>
									<td><?php echo $valuep->KPS_OS_SCHEDULE_DELIVERY_DATE;?></td>
									<td><?php echo $valuep->KPS_OS_SCHEDULE_DELIVERY_TIME;?></td>
									<td><?php echo $valuep->PLANT1_CITY;?></td>
									<td><?php echo $valuep->KPS_OS_PRINTED_DATE;?></td>
									<td><?php echo $valuep->KPS_OS_DN_DATE;?></td>
									<td><?php echo $valuep->KPS_OS_DN_NO;?></td>
									<td><?php echo $valuep->TotalPending;?></td>
									<td>
									<?php
										$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$valuep->employee_approved_id."'")->first_row();
										echo $q1->EMPLOYEE_NAME;
									?>	
									</td>
									<td>
									<?php
										$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$valuep->MADE_BY_OS."'")->first_row();
										echo $q2->EMPLOYEE_NAME;
									?>	
									</td>        
									<td><a href="<?php echo site_url()."/order_sheet/detailPending/".$valuep->KPS_OS_ID;?>" class="btn btn-primary btn-sm ">Detail</a></td>
									<td><button type="button" href="" url="<?php echo site_url()."/order_sheet/returnPending/".$valuep->KPS_OS_ID;?>" class="btn btn-primary btn-sm update-link" data-toggle="modal" data-target="#addReturnPending">Return pending</button></td>

								  </tr>
					      <?php 
								}
						  } ?>
					    </tbody>
					</table>
					</div>
					<!--TABLE-->
				</div>
                  </div><!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_3">
                    <div class="box-body">
					<!--TABLE-->
					<h4>Return Pending Order Sheet</h4>
					<div class="box-body overflow">
					<table id="os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
					        <th>Order Sheet Date</th>
					        <th>Order Sheet No</th>
					        <th>Order Sheet Rev No</th>
					        <th>Customer Name</th>
					        <th>Divisi Name</th>
					        <th>Adress</th>
					        <th>Schedule Delivery Date</th>
					        <th>Schedule Delivery Time</th>
					        <th>Delivery Place</th>
					        <th>Printed Date</th>	        
					        <th>OS/DN Date</th>		        
					        <th>OS/DN NO</th>		        	        
					        <th>Note</th>		        	        
					        <th>Approved</th>		        
					        <th>Made By</th>		              	        
							<th>OS No Before</th>
					        <th>Detail</th>
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($dataRtnPending as $valueR) {$no++ ?>
						      <tr>
						        <td><?php echo $no;?></td>
						        <td><?php echo $valueR->KPS_OS_CREATION_DATE;?></td>
						        <td><?php echo $valueR->KPS_OS_NO;?></td>
						        <td><?php echo $valueR->KPS_OS_REV_NO;?></td>
						        <td><?php echo $valueR->COMPANY_NAME;?></td>
						        <td><?php echo $valueR->DIVISI;?></td>
						        <td>
						        <?php
						      		$q3 = $this->db->query("SELECT * FROM `kps_customer_plant` WHERE KPS_CUSTOMER_ID = '".$valueR->KPS_CUSTOMER_ID."'")->first_row();
						      		echo $q3->PLANT;
						      	?>	
						      	</td>
						        <td><?php echo $valueR->KPS_OS_SCHEDULE_DELIVERY_DATE;?></td>
						        <td><?php echo $valueR->KPS_OS_SCHEDULE_DELIVERY_TIME;?></td>
						        <td><?php echo $valueR->PLANT1_CITY;?></td>
						        <td><?php echo $valueR->KPS_OS_PRINTED_DATE;?></td>
						        <td><?php echo $valueR->KPS_OS_DN_DATE;?></td>
						        <td><?php echo $valueR->KPS_OS_DN_NO;?></td>
						        <td><?php echo $valueR->NOTE_OS;?></td>
								<td>
						        <?php
						      		$q1 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$valueR->employee_approved_id."'")->first_row();
						      		echo $q1->EMPLOYEE_NAME;
						      	?>	
						      	</td>
								<td>
						        <?php
						      		$q2 = $this->db->query("SELECT * FROM `kps_employee` WHERE KPS_EMPLOYEE_ID = '".$valueR->MADE_BY_OS."'")->first_row();
						      		echo $q2->EMPLOYEE_NAME;
						      	?>	
						      	</td>        
								<td>
									<?php
									$q3 = $this->db->query("SELECT * FROM `kps_order_sheet` WHERE KPS_OS_ID = '".$valueR->KPS_OS_STATUS_R_PENDING."'")->first_row();
						      		echo $q3->KPS_OS_NO;
									?>
								</td>
						        <td><a href="<?php echo site_url()."/order_sheet/detailReturnPending/". $valueR->KPS_OS_ID . "/" . $valueR->KPS_OS_STATUS_R_PENDING;?>" class="btn btn-primary btn-sm ">Detail</a></td>
					      <?php } ?>
							  </tr>
					    </tbody>
					</table>
					</div>
					<!--TABLE-->
				</div>
                  </div><!-- /.tab-pane -->
                </div><!-- /.tab-content -->
              </div><!-- nav-tabs-custom -->
		
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	   
	  </div>
	</div>
</div>
<!-- Modal ADD -->
<!-- Modal ADD Return Pending-->
<div class="modal fade" id="addReturnPending" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	   
	  </div>
	</div>
</div>
<!-- Modal ADD Return Pending-->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->