<section class="content-header">
	<h3>Outgoing Finished Good</h3>
	<small>Outgoing Finished Good</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
			<!-- Custom Tabs -->
              <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                  <li class="active"><a href="#tab_1" data-toggle="tab">Outgoing By Bukti Pesanan</a></li>
                  <li><a href="#tab_2" data-toggle="tab">Outgoing By Order Sheet</a></li>
                  
                </ul>
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                   <div class="box-body">
					<!--TABLE-->
					<h4>Out Going By Bukti Pesanan</h4>
					<table id="ogfg" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
					        <th>Status</th>
					        <th>Rev No</th>
					        <th>Bukti Pesanan Number</th>
					        <th>Outgoing Number</th>
					        <th>Vehicle</th>
					        <th>Total PO</th>	        
					        <th>Total Delivery Schedule</th>		        
					        <th>Total Delivery Execution</th>
					        <th>Update</th>		        
					        <th>Detail</th>
					        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
					        	?> 
					        	<th width="20px">Action</th>
					        	<?php
					        	}?>  
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($data as $value) { $no++; ?>
						      <tr>
						        <td><?php echo $no;?></td>
						         <td>
						        <?php 
						        	if($value->status_ogfg=="0"){
						        		?> 
						        		<center><span class="label label-info">Unlock</span></center>
						        		<?php
						        	}else{
						        	?> 
						        		<center><span class="label label-danger">lock</span></center>
						        	<?php	
						        	}
						        ?>
						        </td>
						        <td><?php echo $value->revisi_no_ogfg;?></td>
						        <td><?php echo $value->REV_NO_BP;?></td>
						        <td><?php echo $value->NO_OUTGOING;?></td>
						        <td><?php echo $value->VEHICLE_NAME;?></td>
						        <td><?php echo $value->TOTAL_PO;?></td>
						        <td><?php echo $value->TOTAL_DELIVERY_SHCEDULE;?></td>
						        <td><?php echo $value->TOTAL_DELIVERY_EXECUTION;?></td>
						        <td><a href="<?php echo site_url()."/outgoing_finished/edit/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" class="btn btn-warning btn-sm <?php if($value->status_ogfg==1){
						        	echo "disabled";
						        	}else{
						        		echo "";
						        		}?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
						        <td><a href="<?php echo site_url()."/outgoing_finished/detail/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>"class="btn btn-primary btn-sm <?php if($value->status_ogfg==1){
						        	echo "disabled";
						        	}else{
						        		echo "";
						        		}?>">Detail</a></td>
						         <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
					        	?> 
					        	<td><div class="btn-group"><a href="<?php echo site_url()."/outgoing_finished/lock/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a><a href="<?php echo site_url()."/outgoing_finished/unlock/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
					        	<?php
					        	}?>  
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE-->
				</div>
				<div class="box-body">
					<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Outgoing Finished Good</button>
				</div>
                  </div>
				  <!-- /.tab-pane -->
                  <div class="tab-pane" id="tab_2">
                    <div class="box-body">
					<!--TABLE-->
					
					<h4>Out Going By Order Sheet</h4>
					<div class="box-body">
					<table id="ogfg-os" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					    <thead>
					      <tr>
					        <th>No</th>
							<th>OS No</th>
					        <th>OS No From Customer</th>
					        <th>OS Date From Customer</th>
					        <th>Customer Name</th>
					        <th>Divisi</th>
					        <th>Outgoing Number</th>
					        <th>Vehicle</th>
					        <th>Total PO</th>	        
					        <th>Total Delivery Schedule</th>		        
					        <th>Total Delivery Execution</th>
					        <th>Update</th>		        
					        <th>Detail</th>
					      </tr>
					    </thead>
					    <tbody>
					    	<?php $no=0; foreach ($dataOs as $value) { $no++; ?>
						      <tr>
						        <td><?php echo $no;?></td>
						        <td><?php echo $value->KPS_OS_NO;?></td>
						        <td><?php echo $value->KPS_OS_DN_NO;?></td>
						        <td><?php echo $value->KPS_OS_DN_DATE;?></td>
						        <td><?php echo $value->COMPANY_NAME;?></td>
						        <td><?php echo $value->DIVISI;?></td>
						        <td><?php echo $value->NO_OUTGOING;?></td>
						        <td><?php echo $value->VEHICLE_NAME;?></td>
						        <td><?php echo $value->TOTAL_PO;?></td>
						        <td><?php echo $value->TOTAL_DELIVERY_SHCEDULE;?></td>
						        <td><?php echo $value->TOTAL_DELIVERY_EXECUTION;?></td>
						        <td><a href="" url="<?php echo site_url()."/outgoing_finished/edit_os/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
						        <td><a href="<?php echo site_url()."/outgoing_finished/detail_os/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>"class="btn btn-primary btn-sm">Detail</a></td>
						      </tr>
					      <?php } ?>
					    </tbody>
					</table>
					<!--TABLE-->
					</div>
				</div>
				
				<div class="box-body">
					<button type="button" href="" url="<?php echo site_url()."/outgoing_finished/addByOs/";?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#addByOS">Add New Outgoing Finished Good BY Order Sheet</button>
				</div>
                  </div><!-- /.tab-pane -->
                  
                </div><!-- /.tab-content -->
              </div><!-- nav-tabs-custom -->
	
		
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Outgoing Finished Good Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_finished/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
				  <label class="col-sm-3 control-label">Company Name</label>
				  <div class="col-sm-9">
					<select class="form-control select2" style="width: 100%;"  urlBPOut="<?php echo site_url()."/outgoing_finished/loadBpOut";?>" id="CustomerForBpOut">					  
						<option>-- Select Company --</option>
						<?php foreach ($dataCust as $value) { ?>
						<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
						<?php } ?>					  
					</select>
				  </div>
				</div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Bukti Pesanan</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="buktipesan" urldivisi="<?php echo site_url() ?>/outgoing_finished/loadDate" name="KPS_BUKTI_PESANAN_ID_OGFG">					  
					    <option>-- Select Bukti Pesanan --</option>			  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">KPS Vehicle</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_VEHICLE_ID">					  
					    <option>-- Select Vehicle --</option>
					    <?php foreach ($dataVeh as $value) { ?>
					    <option value="<?php echo $value->KPS_VEHICLE_ID;?>"><?php echo $value->VEHICLE_NO;?> - <?php echo $value->VEHICLE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Driver</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_driver_id">					  
					    <option>-- Select Driver --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Made By</label>
		          <div class="col-sm-9">
		             <input type="text" class="form-control" name="MADE_BYs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="MADE_BY" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Delivery Schedule</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%" id="deliveryschedule" name="DELIVERY_DATE" placeholder="Pick Date">
						<option value="0">-- Select Delivery Schedule --</option>

		            </select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		             <textarea type="text" class="form-control" name="NOTE_OGFG" placeholder="Enter Note.."></textarea>
		            
		          </div>
		        </div>	
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->
<!-- Modal ADD By OS -->
<div class="modal fade" id="addByOS" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal ADD By OS -->
<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->