<section class="content-header">
	<h3>Return Product</h3>
	<small>Retur Product</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="retur_product" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Status Delivery</th>
		        <th>No Retur</th>
		        <th>Rev No</th>
		        <th>No From Customer</th>
		        <th>Date</th>
		        <th>Customer Name</th>
		        <th>Date Retur Customer</th>
		        <th>PPIC DUE Date</th>
		        <th>Customer DUE Date</th>
		        <th>QTY Total Remaining</th>
		        <th>QTY Total Delivered</th>
		        <th>Made by</th>
		        <th>Checked Sales</th>
		        <th>Checked QC</th>
		        <th>Knowed</th>
		        <th>Approved</th>
		        <th>Action</th>		        
		        <th>Lock/Unlock</th>	
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_retur=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
					<?php 
					$query = $this->db->query("SELECT * , SUM(QTY_EXECUTION_OUT) AS TOTAL_QTY_EXE , SUM(QTY_REMAINIG_EXECUTION_OUT) AS TOTAL_QTY_REMAINING
							FROM `kps_outgoing_retur_product` 
							join kps_outgoing_retur_product_detail on(kps_outgoing_retur_product_detail.OUTGOING_RETUR_PRODUCT_ID_DETAIL=kps_outgoing_retur_product.OUTGOING_RETUR_PRODUCT_ID)
							WHERE KPS_RETUR_BARANG_ID_OUT ='". $value->KPS_RETUR_BARANG_ID  ."' GROUP BY KPS_RETUR_BARANG_ID_OUT");
					$datax = $query->first_row();
					?>
					<td><?php
						if($datax){
							if($datax->TOTAL_QTY_REMAINING){
								echo "ON GOING";
							}else{
								echo "CLOSE";
							}
						}else{
							echo "OPEN";
						}
						?></td>
			        <td><?php echo $value->NO_RETUR;?></td>
			        <td><?php echo $value->revisi_no_retur;?></td>
			        <td><?php echo $value->NO_RETUR_FROM_CUSTOMER;?></td>
			        <td><?php echo $value->DATE_RTR;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->DATE_RETUR_CUSTOMER;?></td>
			        <td><?php echo $value->DUE_DATE_PPIC;?></td>
			        <td><?php echo $value->DUE_DATE_CUSTOMER;?></td>
			        <td><?php 
						if($datax){
							echo $datax->TOTAL_QTY_REMAINING;
							}else{
							echo "0";
							}?>
					</td>
			        <td><?php
					if($datax){
								echo $datax->TOTAL_QTY_EXE;
							}else{
								echo "0";
							}?></td>
					<td><?php 
						$query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->MADE_BY_RB."'");
			        	$data1 = mysql_fetch_array($query1);
			        	echo $data1['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td><?php 
						$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHECKED_SALES."'");
			        	$data2 = mysql_fetch_array($query2);
			        	echo $data2['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td><?php 
						$query3 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHCEKED_QC."'");
			        	$data3 = mysql_fetch_array($query3);
			        	echo $data3['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td><?php 
						$query4 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->KNOWED."'");
			        	$data4 = mysql_fetch_array($query4);
			        	echo $data4['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td><?php 
						$query5 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->APPROVED."'");
			        	$data5 = mysql_fetch_array($query5);
			        	echo $data5['EMPLOYEE_NAME'];
			        	?>
					</td>
					<td>
					<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/retur_product/detail/".$value->KPS_RETUR_BARANG_ID;?>" <?php if($value->status_retur==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/retur_product/edit/".$value->KPS_RETUR_BARANG_ID;?>" <?php if($value->status_retur==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/retur_product/history/".$value->KPS_RETUR_BARANG_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/retur_product/del/".$value->KPS_RETUR_BARANG_ID;?>">Delete</a></li>
                        
                        <li class="divider"></li>
                       <li><a href="<?php echo site_url()."/retur_product/pre_print/".$value->KPS_RETUR_BARANG_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>      	
			       
			          <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular" ){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/retur_product/lock/".$value->KPS_RETUR_BARANG_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i>
		        		<?php
		        	}?>  
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	</a><a href="<?php echo site_url()."/retur_product/unlock/".$value->KPS_RETUR_BARANG_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			       
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Retur Product</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Retur Product</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/retur_product/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">No Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NO_RETUR_FROM_CUSTOMER" placeholder="No Retur From Customer">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Date Retur From Customer</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DATE_RETUR_CUSTOMER" placeholder="Pick Date">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Company Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" urldivisi="<?php echo site_url() ?>/pesanan/loadDivisi" id="divisiPesanan"  name="KPS_CUSTOMER_ID_RETUR">					  
					    <option>-- Select Company --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">PPIC DUE Date</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DUE_DATE_PPIC" placeholder="Pick Date">
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Customer DUE Date</label>
		          <div class="col-sm-9">
		            <input type="Date" class="form-control" name="DUE_DATE_CUSTOMER" placeholder="Pick Date">
		          </div>
		        </div>
				<div class="form-group">
				  <label class="col-sm-3 control-label">Made By</label>
				  <div class="col-sm-9">
					 <input type="text" class="form-control" name="MADE_BY_RBs" disabled value="<?php echo $this->session->userdata('name') ?>">
					<input type="hidden" class="form-control" name="MADE_BY_RB" value="<?php echo $this->session->userdata('id'); ?>">
				  </div>
				</div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Sales Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED_SALES">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">QC Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHCEKED_QC">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Knowed Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KNOWED">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">Approved Checked</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="APPROVED">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->


<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->