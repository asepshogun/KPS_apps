<section class="content-header">
	<h3>New Item (LOI) Data</h3>
	<small>Data Item Baru (LOI)</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		<!-- Show/Hide Column :
		<div class="box-body">				
			<div class="btn-group" role="group" aria-label="...">
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">LOI No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">LOI Date</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">REV No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Customer Name</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Part Number RFQ</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Part Name RFQ</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Model RFQ</a></button>		  
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Die Go No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">QTY Month</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Periode</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Discontinue Date</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="12">Min Stock</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="13">Max Stock</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="14">Made By</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="15">Code Product</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="16">Part Number</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="17">Part Name</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="18">Model</a></button>
			</div>
		</div> -->

		<!--TABLE-->
		<table id="loi" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>LOI No</th>
		        <th>LOI Date</th>
		        
		        <th>Customer Name</th>
		        <th>Part Number RFQ</th>
		        <th>Part Name  RFQ</th>
		        <th>Model  RFQ</th>
		        <th>Die Go No</th>
		        <th>QTY Month</th>
		        <th>Periode</th>
		        <th>Discontinue Date</th>
		        <th>Min Stock</th>
		        <th>Max Stock</th>
		        <th>Made By</th>
		        <th>Code Product</th>
		        <th>Part Number </th>
		        <th>Part Name  </th>
		        <th>Model  </th>
		        <th>Standard Packing</th>
		        <th>Action</th>		        
		        
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<th width="20px">Action</th>
		        	<?php
		        	}?> 
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_loi=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_loi;?></td>
			        <td><?php echo $value->NO_LOI;?></td>
			        <td><?php echo $value->DATE_LOI;?></td>
			        
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NO;?></td>
			        <td><?php echo $value->KPS_RFQ_PART_NAME;?></td>
			        <td><?php echo $value->MODEL;?></td>
			        <td><?php echo $value->LOI_DIE_GO_NO;?></td>
			        <td><?php echo $value->QTY_MONTH;?></td>
			        <td><?php echo $value->PERIODE;?></td>
			        <td><?php echo $value->DISCONTINUE_DATE;?></td>
			        <td><?php echo $value->MIN_STOK;?></td>
			        <td><?php echo $value->MAX_STOCK;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->LOI_CODE_ITEM;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->LOI_STRANDART_PACKING;?></td>
			        
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/item/detail/".$value->KPS_LOI_ID;?>" <?php if($value->status_loi==1){
			        	echo ".disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/item/edit/".$value->KPS_LOI_ID;?>" <?php if($value->status_loi==1){
			        	echo ".disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/item/history/".$value->KPS_LOI_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/item/del/".$value->KPS_LOI_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/item/pre_print/".$value->KPS_LOI_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>   
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/item/lock/".$value->KPS_LOI_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a><a href="<?php echo site_url()."/item/unlock/".$value->KPS_LOI_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button"  href="" url="<?php echo site_url()."/item/preAdd/";?>" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New LOI</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->