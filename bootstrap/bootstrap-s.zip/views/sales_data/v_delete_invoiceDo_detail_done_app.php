<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Approve to Delete No DO</h4>
</div>
<div class="modal-body">
	<h4>Mr/Mrs. <?php echo $this->session->userdata('name') ?> </h4><br/>
	<h4>this item is not locked</h4><br/>
</div>
