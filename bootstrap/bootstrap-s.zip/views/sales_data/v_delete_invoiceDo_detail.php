<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Are You Sure Delete This Item</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/invoice/deleteDetailSub/kps_invoice_detail";?>" method="POST" class="form-horizontal">
			<div class="form-group">
			  <label class="col-lg-3 control-label">Delivery Order Number</label>
			  <div class="col-lg-9">
				<input type="text" class="form-control" name="NOTE_detail_bsthp" id="NOTE_detail_bsthp" placeholder="Note" value="<?php echo $data->NO_DO; ?>" disabled>
				<input type="hidden" class="form-control" name="KPS_INVOICE_DETAIL_ID" id="KPS_INVOICE_DETAIL_ID"  value="<?php echo $data->KPS_INVOICE_DETAIL_ID; ?>" >
				<input type="hidden" class="form-control" name="INVOICE_INDUK_ID_DET" id="INVOICE_INDUK_ID_DET"  value="<?php echo $data->INVOICE_INDUK_ID_DET; ?>" >
				<input type="hidden" class="form-control" name="idCus" id="idCus"  value="<?php echo $idCus; ?>" >
				<input type="hidden" class="form-control" name="revisi_no_inv" id="revisi_no_inv"  value="<?php echo $data->revisi_no_inv; ?>" >
				<input type="hidden" class="form-control" name="INVOICE_INDUK_ID" id="INVOICE_INDUK_ID"  value="<?php echo $data->INVOICE_INDUK_ID_DET; ?>" >
				<input type="hidden" class="form-control" name="KPS_INVOICE_DETAIL_DELETE" value="<?php echo $this->session->userdata('employeeId'); ?>">
			 </div>
			</div>
			<div class="form-group">		          
				<div class="col-sm-12">
					<input type="submit" class="btn btn-danger btn-flat pull-right" value="YES" />
				</div>
			</div>
	</form>
</div>	
