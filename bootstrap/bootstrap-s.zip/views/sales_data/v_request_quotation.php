<section class="content-header">
	<h3>Request for Quotation</h3>
	<small>Permintaan untuk Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!-- Show/Hide Column :
		<div class="box-body">
			
		<div class="btn-group" role="group" aria-label="...">
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Company Name</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">RFQ Date</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">RFQ Number</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Receiving Date</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Customer Date</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Due Date</a></button>
		  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Estimation LOI</a></button>		  
		</div>
		</div> -->
		
		<!--TABLE-->
		<table id="rfq" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Company Name</th>
		        <th>RFQ Date</th>
		        <th>RFQ Number</th>
		        <th>Receiving Date</th>
		        <th>Customer Date</th>
		        <th>Due Date</th>
		        <th>Estimation LOI</th>
		      	<th>Action Button</th>
		      
		        
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		        	
		        	<th>Lock/Unlock</th>
		        	<?php
		        	}?>        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_rfq=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_rfq;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->DATE_RFQ;?></td>
			        <td><?php echo $value->NO_RFQ;?></td>
			        <td><?php echo $value->RECEIVING_RFQ_DATE;?></td>
			        <td><?php echo $value->RFQ_CUSTOMER_DATE;?></td>
			        <td><?php echo $value->DUE_DATE_QUOTATION;?></td>
			        <td><?php echo $value->ESTIMATION_LOI_DATE;?></td>

			        

			       
			        
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/request_quotation/detail/".$value->KPS_RFQ_ID;?>" <?php if($value->status_rfq==1){
			        	echo  'class="btn disabled pull-left"';
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/request_quotation/edit/".$value->KPS_RFQ_ID;?>" <?php if($value->status_rfq==1){
			        	echo "class='btn disabled pull-left'";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/request_quotation/history/".$value->KPS_RFQ_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/request_quotation/del/".$value->KPS_RFQ_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/request_quotation/pre_print/".$value->KPS_RFQ_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>      	
			        
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		       		<td><div class="btn-group">
		        	<a href="<?php echo site_url()."/request_quotation/lock/".$value->KPS_RFQ_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        	<?php
		        	}?>  
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<a href="<?php echo site_url()."/request_quotation/unlock/".$value->KPS_RFQ_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a>
		        	</div>
		        	</td>
		        	<?php
		        	}?>  

			      </tr>
		      <?php } ?>
		    </tbody>
		   
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New RFQ</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Request for Quotation Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/request_quotation/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_ID_RFQ">					  
					    <option>-- Select Customer --</option>
					    <?php foreach ($dataCustomer as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Receiving RFQ Date</label>
		          <div class="col-sm-9">
		            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="RECEIVING_RFQ_DATE" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">RFQ Customer Date</label>
		          <div class="col-sm-9">
		            <input type="date" class="form-control" name="RFQ_CUSTOMER_DATE" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">RFQ Customer No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="RFQ_CUSTOMER_NO" placeholder="customer no">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Due Date Quotation</label>
		          <div class="col-sm-9">
		            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DUE_DATE_QUOTATION" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Estimation LOI Date</label>
		          <div class="col-sm-9">
		            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="ESTIMATION_LOI_DATE" placeholder="Pick Date">
		          </div>
		        </div>
		        <div class="form-group">
					<label class="col-sm-3 control-label">Tooling Cost</label>
					<div class="col-sm-9">						
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="TOOLING_COST_RFQ" value="Depreciation">
	                      Depreciation
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="TOOLING_COST_RFQ" value="Not Depreciation">
	                      Not Depreciation
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="TOOLING_COST_RFQ" value="Others">
	                      Others
	                    </label>
	                  </div>		                
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Part Status</label>
					<div class="col-sm-9">						
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="New Project">
	                      New Project
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="Localization">
	                      Localization
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="Second Supplier">
	                      Second Supplier
	                    </label>
	                  </div>		                
					</div>
				</div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">RFQ Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY_RFQa" disabled value="<?php echo $this->session->userdata('name'); ?>">
		            <input type="hidden" class="form-control" name="MADE_BY_RFQ" value="">
		            <input type="hidden" class="form-control" name="user_made_by_id_rfq" value="<?php echo $this->session->userdata('employeeId'); ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">RFQ Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_checked_by">					  
					    <option>-- Select Checked --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">RFQ Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_approved_by">					  
					    <option>-- Select Approved --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
					<label class="col-sm-3 control-label">Customer Respond</label>
					<div class="col-sm-9">						
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="1">
	                      1 (Satu)
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="2">
	                      2 (Dua)
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="PART_STATUS" value="3">
	                      3 (Tiga)
	                    </label>
	                  </div>		                
					</div>
				</div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Target Price</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="TARGET_PRICE" placeholder="target price">
		          </div>
		        </div>		        		        		       
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->


<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->