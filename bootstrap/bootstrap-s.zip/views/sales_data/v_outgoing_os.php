<section class="content-header">
	<h3>Outgoing Finished Good (for Order Sheet)</h3>
	<small>Outgoing Finished Good (untuk Order Sheet)</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="ogos" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Order Sheet Number</th>
		        <th>Bukti Pesanan Number</th>
		        <th>Outgoing Number</th>
		        <th>Vehicle</th>	        
		        <th>Total PO</th>		        
		        <th>Total Delivery Schedule</th>
		        <th>Total Delivery Execution</th>
		        <th>Update</th>		        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->KPS_OS_NO;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->NO_OUTGOING;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
			        <td><?php echo $value->TOTAL_PO;?></td>
			        <td><?php echo $value->TOTAL_DELIVERY_SHCEDULE;?></td>
			        <td><?php echo $value->TOTAL_DELIVERY_EXECUTION;?></td>
			        <td><a href="" url="<?php echo site_url()."/outgoing_os/edit/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			        <td><a href="<?php echo site_url()."/outgoing_finished/detail/".$value->KPS_OUTGOING_FINISHED_GOOD_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Outgoing Finished Good</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Outgoing Finished Good (for Order Sheet) Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/outgoing_os/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Order Sheet</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="order_sheet_id">					  
					    <option>-- Select Order Sheet --</option>
					    <?php foreach ($dataOs as $value) { ?>
					    <option value="<?php echo $value->KPS_OS_ID;?>"><?php echo $value->KPS_OS_NO;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Outgoing Number</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_OUTGOING_FINISHED_GOOD_ID">					  
					    <option>-- Select Bukti Pesanan --</option>
					    <?php foreach ($dataOf as $value) { ?>
					    <option value="<?php echo $value->KPS_BUKTI_PESANAN_ID;?>"><?php echo $value->REV_NO_BP;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->