
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
			<?php if($this->session->flashdata('errorNOFAktur')) { ?>
		      <div class="alert alert-danger alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-ban"></i> Alert!</h4><h4><center>
		      <?php echo $this->session->flashdata('errorNOFAktur'); ?> 
		      </center></h4></div>
		<?php } ?>
		<!--TABLE-->
		<!--Di betulkan di revisiRetur.js-->
		<table id="invoice_detail_no"  class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Invoice Number KPS</th>
		        <th>Invoice Number Faktur</th>
		        <th>Invoice Date</th>
<!--		    <th>PO Number</th>
		        <th>PO Date</th>
				<th>Company Name</th>
		        <th>Adress</th> 
		        <th>Currency</th>
				<th>Delete</th>-->
				<?php if($data->KPS_INVOICE_INDUK_NO_URUT_TX){?>
		        <th>Delete Change Number</th>
				<?php } ?>
				<th>Print</th>
		        <th>Employee Prepared</th>	        
		        <th>Employee Checked</th>		        
		        <th>Employee Approved</th>
		        <th>Total Qty</th>
		        <th>Amount (Currency)</th>
		        <th>DP</th>
		        <th>VAT (10%)</th>
		        <th>Total (Curreny)</th>
		        <th>Term</th>
		        <th>Nomor Invoice Pengganti</th>
		        <th>Print Rekap</th>
		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($detail as $value) { $no++; ?>
			      <tr>
			       
			        <td><?php echo $no?></td>
			        <td><?php echo $value->NO_INVO;?></td>
			        <td><?php echo $value->KPS_NO_INVOICE_FAKTUR_PAJAK;?></td>
			        <td><?php echo $value->DATE_INVO;?></td>
			      	<!--  <td><?php// echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
			        <td><?php //echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
					<td><?php //echo $value->COMPANY_NAME;?></td>
			        <td><?php// echo $value->PLANT;?></td> 
			        <td><?php //echo $value->CURRENCY;?></td>
					<td><a href="" url="<?php // echo site_url()."/invoice/deleteInvoice/".$value->KPS_INVOICE_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>-->
					
						<?php if($data->KPS_INVOICE_INDUK_NO_URUT_TX){
								if($value->KPS_INVOICE_NOMOR_PENGGANTI){?>
								<td>-</td>
						<?php }else{ ?>
								<td><a href="" url="<?php echo site_url()."/invoice/deleteNomorFaktur/".$value->KPS_INVOICE_ID ."/". $this->session->userdata('role');?>" data-toggle="modal" data-target="#update" class="update-link">Delete</a></td>
						<?php  } 
							}?>
					<td><a href="<?php echo site_url()."/invoice/pre_print/".$value->KPS_INVOICE_ID;?>" target="_blank" class="btn btn-default btn-sm"><i class="fa fa-print"></i> Print</a></td>
					<td><?php 
			        	$query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->PREPARED_INVO."'");
			        	$dataEmp = mysql_fetch_array($query);
			        	echo $dataEmp['EMPLOYEE_NAME'];
			        ?></td>
			        <td><?php 
			      	$query1 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->CHECKED_INVO."'");
			        	$dataEmp1 = mysql_fetch_array($query1);
			        	echo $dataEmp1['EMPLOYEE_NAME'];
			        	
			        	?></td>
			        <td><?php 
			        			        	$query2 = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$value->APPROVED_INVO."'");
			        	$dataEmp2 = mysql_fetch_array($query2);
			        	echo $dataEmp2['EMPLOYEE_NAME'];
			        	?></td>
			        <td><?php echo $value->total_qty;?></td>
			        <td><?php echo $value->total_amount;?></td>
			        <td><?php echo $value->total_amount*($value->KPS_INVOICE_DP/100);?></td>
			        <td><?php echo 0.1*($value->total_amount*($value->KPS_INVOICE_DP/100));?></td>
			        <td><?php echo $value->total_amount*($value->KPS_INVOICE_DP/100)+(0.1*($value->total_amount*($value->KPS_INVOICE_DP/100)));?></td>
			        <td><?php echo $value->KPS_INVOICE_DP;?>%</td>
			        <td><?php if($value->KPS_INVOICE_NOMOR_PENGGANTI){ 
					echo $value->KPS_INVOICE_NOMOR_PENGGANTI;
					}else{
					echo "-";
					}?></td>
			        <td><a href="<?php echo site_url()."/invoice/pre_print_rekap/".$value->KPS_INVOICE_ID;?>" target="_blank" class="btn btn-default btn-sm"><i class="fa fa-print"></i> Print Rekap</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Invoice</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Get Invoice Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/invoice/add";?>" method="POST" class="form-horizontal">

		         <div class="form-group">
			      <label class="col-lg-3 control-label">Term</label>
			      <div class="col-lg-9">
			      	<?php 
			      		if($tot_term==0){
			      			?>
			      			<input type="radio" name="term" value="1"> 1 </input>
					        
			      			<?php
			      		}elseif($tot_term==1){
			      			?>
			      			
					        <input type="radio" name="term" value="2"> 2 </input>
					        
			      			<?php
			      		}elseif($tot_term==2) {
			      			?>
			      			
					        <input type="radio" name="term" value="3"> 3 </input>
					        
			      			<?php
			      		}else{
			      			?>
			      			
					        <input type="radio" name="term" value="4"> 4 </input>
			      			<?php
			      		}

			      	?>
			        
			      </div>
			    </div>    
		        <div class="form-group">
		          <label class="col-sm-3 control-label">DP (%)</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="KPS_INVOICE_DP" placeholder="DP (%)">
					<input type="hidden" class="form-control" name="INVOICE_INDUK_ID_inv" value="<?php echo $INVOICE_INDUK_ID;?>"/>
					 
		          </div>
		        </div>
				<div class="form-group">
		          <label class="col-sm-3 control-label">NO INVOICE FAKTUR PAJAK STRANDAR</label>
		          <div class="col-sm-9">
		            <input type="number" id="fakturPajaInvoice" url="<?php echo site_url()."/invoice/cekFaktur";?>" class="form-control" name="KPS_NO_INVOICE_FAKTUR_PAJAK" placeholder="NO INVOICE FAKTUR PAJAK STRANDAR" required>					 
		          </div>
		        </div>
		       
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Prepared By</label>
		          <div class="col-sm-9">
					<input type="text" class="form-control" name="PREPARED_INVOs" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="PREPARED_INVO" value="<?php echo $this->session->userdata('employeeId'); ?>">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED_INVO">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="APPROVED_INVO">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->
<!-- Modal UPDATE-->
<div class="modal fade" id="term" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->
