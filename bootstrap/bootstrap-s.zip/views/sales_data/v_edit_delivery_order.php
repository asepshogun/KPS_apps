<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Order Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/delivery_order/update";?>" method="POST" class="form-horizontal">
  
		<div class="form-group">
              <label class="col-sm-3 control-label">Outgoing Finished Good</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="KPS_OUTGOING_FINISHED_GOOD_ID_DO">            
              <option>-- Select Outgoing --</option>
              <?php foreach ($dataOut as $value) { ?>
              <option value="<?php echo $value->KPS_OUTGOING_FINISHED_GOOD_ID;?>" <?php
            if($value->KPS_OUTGOING_FINISHED_GOOD_ID==$data->KPS_OUTGOING_FINISHED_GOOD_ID_DO){
              echo "selected=''";
            }
            ?>><?php echo $value->NO_OUTGOING;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
         
          <div class="form-group">
              <label class="col-sm-3 control-label">Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_approved_id_DO">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_approved_id_DO){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Accepted By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_accepted_id">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_accepted_id){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
          <div class="form-group">
              <label class="col-sm-3 control-label">Known By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_known_id">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php
            if($value->KPS_EMPLOYEE_ID==$data->employee_known_id){
              echo "selected=''";
            }
            ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Address</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" value="<?php echo $data->ADDRESS ?>" name="ADDRESS" placeholder="address">
                <input type="hidden" class="form-control" value="<?php echo $data->KPS_DELIVERY_ORDER_ID ?>" name="id" placeholder="address">
                <input type="hidden" class="form-control" name="revisi_no_do" value="<?php echo $data->revisi_no_do ?>">
              </div>
            </div>
            <div class="form-group">              
              <div class="col-sm-12">
                <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
              </div>
            </div>  			      	
    </form>	        	    			      		        
</div>