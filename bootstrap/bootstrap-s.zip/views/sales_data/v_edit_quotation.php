<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Quotation Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/quotation/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
          <label class="col-sm-3 control-label">Request for Quotation</label>
          <div class="col-sm-9">
          <select class="form-control select2" style="width: 100%;" urlcurr="<?php echo site_url()."/quotation/loadCurr";?>" urlpic="<?php echo site_url()."/quotation/loadPic";?>" name="KPS_RFQ_ID_QUO" id="eqrfq_id">           
              <option>-- Select RFQ --</option>
              <?php foreach ($dataRfq as $value) { ?>
              <option value="<?php echo $value->KPS_RFQ_ID;?>" <?php 
              if($value->KPS_RFQ_ID==$data->KPS_RFQ_ID_QUO)
                echo "selected=''";
               ?>><?php echo $value->NO_RFQ;?></option>
              <?php } ?>           
            </select> 
          </div>
        </div>
         <div class="form-group">
              <label class="col-sm-3 control-label">RFQ Currency</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_CURENCY_ID_QUO" id="EQKPS_RFQ_CURENCY_ID_QUO"> 
                <option>-- Select Currency --</option>
              <?php foreach ($dataCurr as $value) { ?>
              <option value="<?php echo $value->KPS_RFQ_CURENCY_ID;?>" <?php 
              if($value->KPS_RFQ_CURENCY_ID==$data->KPS_RFQ_CURENCY_ID_QUO)
                echo "selected=''";
               ?>><?php echo $value->CURRENCY_NAME;?></option>
              <?php } ?>                      
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Valid From</label>
              <div class="col-sm-9">
                <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="VALID_DATE_FROM" value="<?php echo $data->VALID_DATE_FROM ?>" placeholder="Pick Date">
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Valid Until</label>
              <div class="col-sm-9">
                <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="VALID_DATE_UNTIL" value="<?php echo $data->VALID_DATE_UNTIL ?>" placeholder="Pick Date" >
                <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_QUOTATION_ID ?>">
                <input type="hidden" class="form-control" name="revisi_no_quo" value="<?php echo $data->revisi_no_quo ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Person in Charge</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="kps_customer_is_person_in_charge_quo" id="eqpic">           
              <option>-- Select PIC --</option>         
              <?php foreach ($dataPic as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID;?>" <?php 
              if($value->KPS_CUSTOMER_IS_PERSON_IN_CHARGE_ID==$data->kps_customer_is_person_in_charge_quo)
                echo "selected=''";
               ?>><?php echo $value->NAME;?></option>
              <?php } ?>   
          </select>
              </div>
            </div>
      
            <div class="form-group">
              <label class="col-sm-3 control-label">Made By</label>
              <div class="col-sm-9">
              <?php 
                $query = mysql_query("select * from kps_employee where KPS_EMPLOYEE_ID='".$data->MADE_BY_QUO."'");
                $datax = mysql_fetch_array($query);
                ?>
                <input type="text" class="form-control" name="MADE_BY_QUO" value="<?php echo $datax['EMPLOYEE_NAME'] ?>" disabled>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="CHECKED_QUO">           
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php 
              if($value->KPS_EMPLOYEE_ID==$data->CHECKED_QUO)
                echo "selected=''";
               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="APPROVED_QUO">            
              <option>-- Select Employee --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php 
              if($value->KPS_EMPLOYEE_ID==$data->APPROVED_QUO)
                echo "selected=''";
               ?>><?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Quotation Note</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="NOTE_QUO" value="<?php echo $data->NOTE_QUO; ?>">
          </div>
        </div>
        <div class="form-group">		          
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>			      	
    </form>	        	    			      		        
</div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>