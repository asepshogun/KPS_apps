<section class="content-header">
	<h3>Breakdown Cost</h3>
	<small>Perincian Harga</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">

		<!-- Show/Hide Column :
		<div class="box-body">				
			<div class="btn-group" role="group" aria-label="...">
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Breakdown No</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Total Material</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Total Part Cost</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Total Depreciation</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Cost</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Total Tools</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">Total Item</a></button>		  
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Total Manufacturing</a></button>
			  <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Note</a></button>
			</div>
		</div> -->

		<!--TABLE-->
		<table id="breakdown" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Breakdown No</th>
		        <th>Total Material</th>
		        <th>Total Part Cost</th>
		        <th>Total Depreciation</th>
		        <th>Tooling Cost</th>
		        <th>Total Tools</th>
		        <th>Total Item</th>
		        <th>Total Manufacturing</th>
		        <th>Total Breakdown</th>
		        <th>Action</th>		        
		        
		         <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		        	<th>Lock/Unlock</th>
		        	<?php
		        	}?>    
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			         <td>
			        <?php 
			        	if($value->status_break=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_break;?></td>
			        <td><?php echo $value->NO_BREAK;?></td>
			        <td><?php echo $value->TOTAL_MATERIAL;?></td>
			        <td><?php echo $value->TOTAL_PART_COST;?></td>
			        <td><?php echo $value->TOTAL_DEPRECIATION;?></td>
			        <td><?php echo $value->TOOLING_COST;?></td>
			        <td><?php echo $value->TOTAL_TOOLING;?></td>
			        <td><?php echo $value->TOTAL_ITEM;?></td>
			        <td><?php echo $value->TOTAL_MANUFACTURING;?></td>
			        <td><?php echo $value->total_breakdown;?></td>
			         
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/breakdown_cost/detail/".$value->KPS_BREAKDOWN_COST_ID;?>" <?php if($value->status_break==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/breakdown_cost/edit/".$value->KPS_BREAKDOWN_COST_ID;?>" <?php if($value->status_break==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/breakdown_cost/history/".$value->KPS_BREAKDOWN_COST_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/breakdown_cost/del/".$value->KPS_BREAKDOWN_COST_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/breakdown_cost/pre_print/".$value->KPS_BREAKDOWN_COST_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div>
		        	</td>      	
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales New Item"){
		        	?> 
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/breakdown_cost/lock/".$value->KPS_BREAKDOWN_COST_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        	<?php
		        	}?>  
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?> 
		        	<a href="<?php echo site_url()."/breakdown_cost/unlock/".$value->KPS_BREAKDOWN_COST_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  

			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Breakdown</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Breakdown Cost Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/breakdown_cost/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Request for Quotation</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_RFQ_ID_BREAK">					  
					    <option>-- Select RFQ --</option>
					    <?php foreach ($dataRfq as $value) { ?>
					    <option value="<?php echo $value->KPS_RFQ_ID;?>"><?php echo $value->NO_RFQ;?> - <?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
					<label class="col-sm-3 control-label">Customer Respond</label>
					<div class="col-sm-9">						
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_RESPOND" value="1">
	                      1 (Satu)
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_RESPOND" value="2">
	                      2 (Dua)
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_RESPOND" value="3">
	                      3 (Tiga)
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_RESPOND" value="4">
	                      4 (Empat)
	                    </label>
	                  </div>		                
					</div>
				</div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Prod Pred Lead Time</label>
		          <div class="col-sm-7">
		            <input type="text" class="form-control" name="PROD_PREP_LEAD_TIME" placeholder="lead time">
		          </div>
		          <label class="col-sm-2 control-label" style="text-align:left;">weeks</label>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Packing Charge</label>
		          <div class="col-sm-7">
		            <input type="text" class="form-control" name="packing_charge" placeholder="packing charge">
		          </div>
		          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Transportation Charge</label>
		          <div class="col-sm-7">
		            <input type="text" class="form-control" name="transportation_charge" placeholder="transportation charge">
		          </div>
		          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Overhead Profit</label>
		          <div class="col-sm-7">
		            <input type="text" class="form-control" name="overhead_profit" placeholder="overhead profit">
		          </div>
		          <label class="col-sm-2 control-label" style="text-align:left;">%</label>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Breakdown Made By</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="MADE_BY_BREAK_DIS" disabled value="<?php echo $this->session->userdata('name') ?>">
		            <input type="hidden" class="form-control" name="MADE_BY_BREAK" value="<?php echo $this->session->userdata('id'); ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Breakdown Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CHECKED_BREAK">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Breakdown Calculated By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="CALCULATED_BREAK">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Breakdown Approved By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="APPROVED_BREAK">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		         <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-7">
		            <input type="text" class="form-control" name="NOTE" placeholder="Note">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->