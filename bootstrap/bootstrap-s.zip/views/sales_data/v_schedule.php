<section class="content-header">
	<h3>Delivery Schedule</h3>
	<small>Jadwal Pengiriman</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="schedule" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Status</th>
		        <th>Rev No</th>
		        <th>Bukti Pesanan Number</th>
		        <th>Company Name</th>
		        <th>Delivery Number</th>
		        <th>Delivery Date</th>
		        <th>Employee Checked</th>		        
		        <th>Total</th>		        
		        <th>Action</th>		        
		        
		        <?php if($this->session->userdata('role')=="Sales Head" OR $this->session->userdata('role')=="Administrator"  OR $this->session->userdata('role')=="Sales Regular"){
		        	?> 
		        	<th width="20px">Lock/Unlock</th>
		        	<?php
		        	}?>  
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td>
			        <?php 
			        	if($value->status_ds=="0"){
			        		?> 
			        		<center><span class="label label-info">Unlock</span></center>
			        		<?php
			        	}else{
			        	?> 
			        		<center><span class="label label-danger">lock</span></center>
			        	<?php	
			        	}
			        ?>
			        </td>
			        <td><?php echo $value->revisi_no_ds;?></td>
			        <td><?php echo $value->REV_NO_BP;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->NO_REV_NO;?></td>
			        <td><?php echo $value->DELIVERY_DATE;?></td>
			        <td><?php echo $value->EMPLOYEE_NAME;?></td>
			        <td><?php echo $value->TOTAL;?></td>

			         
		        	<td>
		        	<div class="btn-group btn-block">
		        	 <button type="button" class="btn btn-block btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="glyphicon glyphicon-cog"></span> Manage <span class="caret"></span>
                        
                      </button>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                        <a href="<?php echo site_url()."/schedule/detail/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" <?php if($value->status_ds==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?>>Detail</a></li>
                        <li><a href="" url="<?php echo site_url()."/schedule/edit/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" <?php if($value->status_ds==1){
			        	echo "disabled";
			        	}else{
			        		echo "";
			        		}?> data-toggle="modal" data-target="#update" class="update-link">Update</a></li>
                        <li><a href="<?php echo site_url()."/schedule/history/".$value->KPS_DELIVERY_SCHEDULE_ID;?>">History</a></li>
                        <li><a href="<?php echo site_url()."/schedule/del/".$value->KPS_DELIVERY_SCHEDULE_ID;?>">Delete</a></li>
                        <li class="divider"></li>
                        <li><a href="<?php echo site_url()."/schedule/pre_print/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" target="_blank">Print</a></li>
                      </ul>
		        	</div></td>      	
			        <?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator" OR $this->session->userdata('role')=="Sales Regular"){
		        	?>
		        	<td><div class="btn-group"><a href="<?php echo site_url()."/schedule/lock/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" class="btn btn-danger btn-sm"><i class="fa fa-lock"></i></a>
		        	<?php
		        	}?> 
		        	<?php if($this->session->userdata('role')=="Sales Head"  OR $this->session->userdata('role')=="Administrator"){
		        	?>
		        	<a href="<?php echo site_url()."/schedule/unlock/".$value->KPS_DELIVERY_SCHEDULE_ID;?>" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i></a></div></td>
		        	<?php
		        	}?>  
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Delivery Schedule</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Schedule Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/schedule/add";?>" method="POST" class="form-horizontal">
	    	
	    			<div class="form-group">
		          <label class="col-sm-3 control-label">Company Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;"  url="<?php echo site_url()."/schedule/loadBuktiPesanan";?>" id="comschedule" name="KPS_CUSTOMER_ID_BK">					  
					    <option>-- Select Company --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Bukti Pesanan</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="bpbp" name="KPS_BUKTI_PESANAN_ID_DS">					  
					    <option>-- Select Bukti Pesanan --</option>
					    				  
					</select>
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Checked By</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="employee_checked_id">					  
					    <option>-- Select Employee --</option>
					    <?php foreach ($dataEmployee as $value) { ?>
					    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"><?php echo $value->EMPLOYEE_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		       
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->