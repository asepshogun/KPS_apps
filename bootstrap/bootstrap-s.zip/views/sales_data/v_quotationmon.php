<section class="content-header">
  <h3>Quotation Monitoring</h3>
  <small>Data Quotation</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
  <div class="box-body">
    <!-- Show/Hide Column :
    <div class="box-body">
      
    <div class="btn-group" role="group" aria-label="..."><center>

      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="0">No</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="1">Quotation No</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="2">Quotation Date</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="3">Revisi Number</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="4">Valid From</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="5">Valid Until</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="6">Currency</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="7">RFQ Number </a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="8">Customer Name</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="9">Address</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="10">Phone</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="11">Fax</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="12">PIC </a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="13">Email</a></button>
      <button type="button" class="btn btn-default"><a class="toggle-vis" data-column="14">Marketing Name</a></button>
      </center>
    </div>
    </div> -->
    
    <!--TABLE-->
    <table id="quotation_mon" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>Date</th>
            <th>Quotation No</th>
            <th>Rev No</th>
            <th>Part Name</th>
            <th>Part No</th>
            <th>Model</th>
            <th>Customer Name</th>
            <th>Price</th>
            <th>Unit</th>
            <th>Valid From</th>
            <th>Valid Until</th>
            <th>Status</th>
             
          </tr>

        </thead>
        <tfoot>
          <tr>
            <th>Date</th>
            <th>Quotation No</th>
            <th>Rev No</th>
            <th>Part Name</th>
            <th>Part No</th>
            <th>Model</th>
            <th>Customer Name</th>
            <th>Price</th>
            <th>Unit</th>
            <th>Valid From</th>
            <th>Valid Until</th>
            <th>Status</th>
             
          </tr>
          
        </tfoot>

        <tbody>
          <?php $no=0; foreach ($data as $value) { $no++; ?>
            <tr>
              <td><?php echo $value->DATE_QUO;?></td>
              <td><?php echo $value->NO_QUO;?></td>
              <td><?php echo $value->revisi_no_quo;?></td>
              <td><?php echo $value->part_name;?></td>
              <td><?php echo $value->part_no;?></td>
              <td><?php echo $value->model;?></td>
              <td><?php echo $value->COMPANY_NAME;?></td>
              <td><?php echo $value->price;?></td>
              <td><?php echo $value->unit;?></td>
              <td><?php echo $value->VALID_DATE_FROM;?></td>
              <td><?php echo $value->VALID_DATE_UNTIL;?></td>
              <td></td>
             </tr>
          <?php } ?>
        </tbody>
    </table>
    <!--TABLE-->


<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
  <div class="modal-dialog">

    <div class="modal-content">
      
    </div>
    
  </div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->