<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Order Sheet Data</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/order_sheet/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-lg-3 control-label">Customer Name</label>
		  <div class="col-lg-9">			
				<select name="KPS_OS_CUSTOMER_ID"  class="form-control select2" style="width:100%" urlDpOs="<?php echo site_url()."/order_Sheet/loadDpOs";?>"	urldivisiOs="<?php echo site_url()."/order_Sheet/loadDivisiOs";?>"  id="divisiOs">
					<option>-- Select Customer Name --</option>
					<?php foreach ($dataCust as $valueCus) { ?>
					<option value="<?php echo $valueCus->KPS_CUSTOMER_ID;?>"  <?php if($valueCus->KPS_CUSTOMER_ID==$data->KPS_OS_CUSTOMER_ID){ echo "selected=''";	} ?>>
					<?php echo $valueCus->COMPANY_NAME;?>
					</option>
				<?php } ?>
				</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Divisi</label>
		  <div class="col-lg-9">
				<select name="KPS_OS_CUSTOMER_DIVISI_ID"  class="form-control select2" style="width:100%" id="divisiOsGet">
				<option value="0">-- Select Divisi Name --</option>
				<?php foreach ($dataDivisi as $valueDiv) { ?>
				<option value="<?php echo $valueDiv->KPS_CUSTOMER_DIVISI_ID; ?>"  <?php if($valueDiv->KPS_CUSTOMER_ID==$data->KPS_OS_CUSTOMER_DIVISI_ID){ echo "selected=''";	} ?>>
					<?php echo $valueDiv->DIVISI; ?>
				</option>
				<?php } ?>
				</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">NO OS / DN From Customer</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_OS_DN_NO" placeholder="DN / OS NO" value="<?php echo $data->KPS_OS_DN_NO;?>">
			<input type="hidden" class="form-control" name="KPS_OS_REV_NO" placeholder="DN / OS NO" value="<?php echo $data->KPS_OS_REV_NO;?>">
			<input type="hidden" class="form-control" name="KPS_OS_ID" placeholder="DN / OS NO" value="<?php echo $data->KPS_OS_ID;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">OS / DN Date</label>
		  <div class="col-sm-9">
			<input type="text"  class="form-control" name="KPS_OS_DN_DATE" value="<?php echo $data->KPS_OS_DN_DATE;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Printed Date</label>
		  <div class="col-sm-9">
			<input type="date" class="form-control" name="KPS_OS_PRINTED_DATE" value="<?php echo $data->KPS_OS_PRINTED_DATE;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Schedule Delivery Date</label>
		  <div class="col-sm-9">
			<input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_DATE" placeholder="Pick Date" value="<?php echo $data->KPS_OS_SCHEDULE_DELIVERY_DATE;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Schedule Delivery Time</label>
		  <div class="col-sm-9">
			<input type="time" class="form-control" name="KPS_OS_SCHEDULE_DELIVERY_TIME" placeholder="Pick Date" value="<?php echo $data->KPS_OS_SCHEDULE_DELIVERY_TIME;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Delivery Place</label>
		  <div class="col-lg-9">
				<select name="KPS_CUSTOMER_DELIVERY_SETUP_ID"  class="form-control select2" style="width:100%"	id="cusDelSetUpOs">
				<option>-- Select Delivery Place --</option>
				<?php foreach ($deliv as $valueDeliv) { ?>
				<option value="<?php echo $valueDeliv->KPS_CUSTOMER_DELIVERY_SETUP; ?>"  <?php if($valueDeliv->KPS_CUSTOMER_DELIVERY_SETUP==$data->KPS_CUSTOMER_DELIVERY_SETUP_ID){ echo "selected=''";	} ?>>
					<?php echo $valueDeliv->PLANT1_CITY; ?>
				</option>
				<?php } ?>
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Total Kanban</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="KPS_OS_TOTAL_KANBAN" value="0" placeholder="note" value="<?php echo $data->KPS_OS_TOTAL_KANBAN;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Print Count</label>
		  <div class="col-sm-9">
			<input type="number" class="form-control" name="KPS_OS_PRINT_COUNT" value="0" placeholder="note" value="<?php echo $data->KPS_OS_PRINT_COUNT;?>">
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Approved By</label>
		  <div class="col-sm-9">
			<select class="form-control select2" style="width: 100%;" name="employee_approved_id" >					  
				<option>-- Select Employee --</option>
				<?php foreach ($dataEmployee as $value) { ?>
				<option value="<?php echo $value->KPS_EMPLOYEE_ID; ?>" <?php if($value->KPS_EMPLOYEE_ID==$data->employee_approved_id){ echo "selected=''";	} ?>><?php echo $value->EMPLOYEE_NAME; ?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		  <div class="form-group">
		  <label class="col-sm-3 control-label">Made By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="MADE_BY_OSs" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="MADE_BY_OS" value="<?php echo $this->session->userdata('id'); ?>">
		  </div>
		</div>	
		<div class="form-group">
		  <label class="col-sm-3 control-label">Note</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="NOTE_OS" placeholder="note" value="<?php  echo $data->NOTE_OS; ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		  </div>
		</div>			      	
	</form>	        	    			      		        
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>