<div class="modal-header">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
      <h4 class="modal-title">Customer Information Data Detail</h4>
    </div>
    <div class="modal-body">
    	<form action="<?php echo site_url()."/customer_information/update";?>" method="POST" class="form-horizontal">
    		<div class="form-group">
	          <label class="col-sm-3 control-label">Marketing</label>
	          <div class="col-sm-9">
	            <select class="form-control select2" style="width: 100%;" name="marketing_id">					  
				    <option>-- Select Marketing --</option>		
				    <?php foreach ($dataMarketing as $value) { ?>
				    <option value="<?php echo $value->KPS_MARKETING_ID;?>"
				    <?php
				    if($value->KPS_MARKETING_ID==$data->marketing_id){
				    	echo "selected=''";
				    }
				    ?>
				    ><?php echo $value->MARKETING_NAME;?></option>
				    <?php } ?>		    					 
				</select>
	          </div>
	        </div>
    		<div class="form-group">
	          <label class="col-sm-3 control-label">Company Name</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="COMPANY_NAME" value="<?php echo $data->COMPANY_NAME ?>">
	            <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_CUSTOMER_ID ?>">
	             <input type="hidden" class="form-control" name="revisi_no" value="<?php echo $data->revisi_no ?>">

	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">Customer Code</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="CUSTOMER_CODE" value="<?php echo $data->CUSTOMER_CODE ?>">
	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">KPS Made By</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="MADE_BY" disabled value="<?php echo $this->session->userdata('name'); ?>">
	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">KPS Checked</label>
	          <div class="col-sm-9">
	            <select class="form-control select2" style="width: 100%;" name="CHECKED">					  
				    <option>-- Select Checked --</option>
				    <?php foreach ($dataEmployee as $value) { ?>
				    <option value="<?php echo $value->KPS_EMPLOYEE_ID; ?>"
				    <?php
				    if($value->KPS_EMPLOYEE_ID==$data->CHECKED){
				    	echo "selected=''";
				    }
				    ?>><?php echo $value->EMPLOYEE_NAME;?></option>
				    <?php } ?>					  
				</select>
	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">KPS Approved</label>
	          <div class="col-sm-9">
	            <select class="form-control select2" style="width: 100%;" name="APPROVED">					  
				    <option>-- Select Approved --</option>
				    <?php foreach ($dataEmployee as $value) { ?>
				    <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>"
				    <?php
				    if($value->KPS_EMPLOYEE_ID==$data->APPROVED){
				    	echo "selected=''";
				    }
				    ?>><?php echo $value->EMPLOYEE_NAME;?></option>
				    <?php } ?>					  
				</select>
	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">Customer Made By</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="CUSTOMER_MADE_BY" value="<?php echo $data->CUSTOMER_MADE_BY ?>">
	          </div>
	        </div>		        
	        <div class="form-group">
	          <label class="col-sm-3 control-label">Customer Checked</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="CUSTOMER_CHECKED" value="<?php echo $data->CUSTOMER_CHECKED ?>">
	          </div>
	        </div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">Customer Approved</label>
	          <div class="col-sm-9">
	            <input type="text" class="form-control" name="CUSTOMER_APPROVED" value="<?php echo $data->CUSTOMER_APPROVED ?>">
	          </div>
	        </div>
	        <div class="form-group">
				<label class="col-sm-3 control-label">Customer Industry</label>
				<div class="col-sm-9">
					<div class="form-group">
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_INDUSTRY" value="Automotive"
				    <?php
				    if($data->CUSTOMER_INDUSTRY=="Automotive"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Automotive
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="CUSTOMER_INDUSTRY" value="Non Automotive"
				    <?php
				    if($data->CUSTOMER_INDUSTRY=="Non Automotive"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Non Automotive
	                    </label>
	                  </div>
	                </div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Automotive Type</label>
				<div class="col-sm-9">
					<div class="form-group">
	                  <div class="radio">
	                    <label>
	                      <input type="radio" id="auto" name="AUTOMOTIVE_TYPE" value="OEM"
				    <?php
				    if($data->AUTOMOTIVE_TYPE=="OEM"){
				    	echo "checked=''";
				    }
				    ?>>
	                      OEM
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" id="nonautuo" name="AUTOMOTIVE_TYPE" value="Non OEM"
				    <?php
				    if($data->AUTOMOTIVE_TYPE=="Non OEM"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Non OEM
	                    </label>
	                  </div>
	                </div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Sales Type</label>
				<div class="col-sm-9">
					<div class="form-group">
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="SALES_TYPE" value="Local"
				    <?php
				    if($data->SALES_TYPE=="Local"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Local
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="SALES_TYPE" value="Export"
				    <?php
				    if($data->SALES_TYPE=="Export"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Export
	                    </label>
	                  </div>
	                </div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Sales Tax</label>
				<div class="col-sm-9">
					<div class="form-group">
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="SALES_TAX" value="Tax"
				    <?php
				    if($data->SALES_TAX=="Tax"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Tax
	                    </label>
	                  </div>
	                  <div class="radio">
	                    <label>
	                      <input type="radio" name="SALES_TAX" value="Non Tax"
				    <?php
				    if($data->SALES_TAX=="Non Tax"){
				    	echo "checked=''";
				    }
				    ?>>
	                      Non Tax
	                    </label>
	                  </div>
	                </div>
				</div>
			</div>
	        <div class="form-group">
	          <label class="col-sm-3 control-label">Payment</label>
	          <div class="col-sm-9">
	            <select class="form-control select2" style="width: 100%;" name="PAYMENT">					  
				    <option>-- Select Payment --</option>
				     <option value="50% DP, 50% Before Delivery" <?php
				    if($data->PAYMENT=="50% DP, 50% Before Delivery"){
				    	echo "selected=''";
				    }
				    ?>>50% DP, 50% Before Delivery</option>
                      <option value="1 Week After Invoice" <?php
				    if($data->PAYMENT=="1 Week After Invoice"){
				    	echo "selected=''";
				    }
				    ?>>1 Week After Invoice</option>
                      <option value="2 Week After Invoice" <?php
				    if($data->PAYMENT=="2 Week After Invoice"){
				    	echo "selected=''";
				    }
				    ?>>2 Week After Invoice</option>
                      <option value="1 Month After Invoice" <?php
				    if($data->PAYMENT=="1 Month After Invoice"){
				    	echo "selected=''";
				    }
				    ?>>1 Month After Invoice</option>
                      <option value="2 Month After Invoice" <?php
				    if($data->PAYMENT=="2 Month After Invoice"){
				    	echo "selected=''";
				    }
				    ?>>2 Month After Invoice</option>
                      <option value="3 Month After Invoice" <?php
				    if($data->PAYMENT=="3 Month After Invoice"){
				    	echo "selected=''";
				    }
				    ?>>3 Month After Invoice</option>				    					 
				</select>
	          </div>
	        </div>		        
	        <div class="form-group">		          
	          <div class="col-sm-12">
	            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
	          </div>
	        </div>			      	
        </form>	        	    			      		        
    </div>
    <script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>