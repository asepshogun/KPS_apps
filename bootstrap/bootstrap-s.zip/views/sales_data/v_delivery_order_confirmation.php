<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Delivery Order Confirmation</h4>
</div>
<?php if($data){ ?>
<div class="modal-body">
	<form action="<?php echo site_url()."/delivery_order/updateConfirmCustomer/";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">No Delivery Order</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="RECEIVED_DATE" disabled value="<?php echo $dataOnly->NO_DO;?>" >
			<input type="hidden" class="form-control" name="KPS_DELIVERY_ORDER_CONFIRM_ID" value="<?php echo $data->KPS_DELIVERY_ORDER_CONFIRM_ID;?>" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Receive by Customer Date</label>
		  <div class="col-sm-9">
			<input type="date" class="form-control" name="RECEIVED_DATE" placeholder="Pick Date" value="<?php echo $data->RECEIVED_DATE; ?>">
		  </div>
		</div>
	   <div class="form-group">
		  <label class="col-sm-3 control-label">Receive by Customer Desicion</label>
		  <div class="col-sm-9">
			<input type="radio" name="RECEIVED_DECISION" class="cdsss" value="NG"   
					<?php
				    if($data->RECEIVED_DECISION=="NG"){
				    	echo "checked=''";
				    }
				    ?>> Not Good</input>
			<input type="radio" name="RECEIVED_DECISION" class="cdsss" value="OK"
					<?php
				    if($data->RECEIVED_DECISION=="OK"){
				    	echo "checked=''";
				    }
				    ?>> OK</input>
		  </div>
		</div>

		<div class="form-group ifng" style="display: none">
		  <label class="col-lg-3 control-label">Problem</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="PROBLEM" placeholder="Problem" value="<?php echo $data->PROBLEM; ?>">
		  </div>
		</div>    
	   <div class="form-group ifng" style="display: none">
		  <label class="col-lg-3 control-label">Note</label>
		  <div class="col-lg-9">
			<textarea type="text" class="form-control" name="NOTE_IF_NG" placeholder="note"><?php echo $data->NOTE_IF_NG; ?></textarea>
		  </div>
		</div>    
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Confirm By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="KPS_DO_CONFIRM_MADE_BYS" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="KPS_DO_CONFIRM_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	  
</div>
<?php }else{  ?>	
<div class="modal-body">
	<form action="<?php echo site_url()."/delivery_order/addSubConfirmation/kps_delivery_order_confirm";?>" method="POST" class="form-horizontal">
		<div class="form-group">
		  <label class="col-sm-3 control-label">No Delivery Order</label>
		  <div class="col-sm-9">
			<input type="text" class="form-control" name="RECEIVED_DATE" disabled value="<?php echo $dataOnly->NO_DO;?>" >
			<input type="hidden" class="form-control" name="KPS_DO_ID_CONFIRM"  value="<?php echo $dataOnly->KPS_DELIVERY_ORDER_ID;?>" >
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-sm-3 control-label">Receive by Customer Date</label>
		  <div class="col-sm-9">
			<input type="date" class="form-control" name="RECEIVED_DATE" placeholder="Pick Date">
		  </div>
		</div>
	   <div class="form-group">
		  <label class="col-sm-3 control-label">Receive by Customer Desicion</label>
		  <div class="col-sm-9">
			<input type="radio" name="RECEIVED_DECISION" class="cdsss" value="NG"> Not Good</input>
			<input type="radio" name="RECEIVED_DECISION" class="cdsss" value="OK"> OK</input>
		  </div>
		</div>

		<div class="form-group ifng" style="display: none">
		  <label class="col-lg-3 control-label">Problem</label>
		  <div class="col-lg-9">
			<input type="text" class="form-control" name="PROBLEM" placeholder="Problem">
		  </div>
		</div>    
	   <div class="form-group ifng" style="display: none">
		  <label class="col-lg-3 control-label">Note</label>
		  <div class="col-lg-9">
			<textarea type="text" class="form-control" name="NOTE_IF_NG" placeholder="note"></textarea>
		  </div>
		</div>    
		 <div class="form-group">
		  <label class="col-sm-3 control-label">Confirm By</label>
		  <div class="col-sm-9">
			 <input type="text" class="form-control" name="KPS_DO_CONFIRM_MADE_BYS" disabled value="<?php echo $this->session->userdata('name') ?>">
			<input type="hidden" class="form-control" name="KPS_DO_CONFIRM_MADE_BY" value="<?php echo $this->session->userdata('employeeId'); ?>">
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	  
</div>
<?php  } ?>