
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">Request for Quotation Data Detail</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/request_quotation/update";?>" method="POST" class="form-horizontal">
		<div class="form-group">
          <label class="col-sm-3 control-label">Customer</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="KPS_CUSTOMER_ID_RFQ">					  
			      <option>-- Select Customer --</option>
              <?php foreach ($dataCustomer as $value) { ?>
              <option value="<?php echo $value->KPS_CUSTOMER_ID;?>" <?php if($value->KPS_CUSTOMER_ID==$data->KPS_CUSTOMER_ID_RFQ){
              echo "selected=''";
            } ?>><?php echo $value->COMPANY_NAME;?></option>
              <?php } ?>    		  
			</select>
          </div>
        </div>
		<div class="form-group">
          <label class="col-sm-3 control-label">Receiving RFQ Date</label>
          <div class="col-sm-9">
            <input type="date"  class="form-control" name="RECEIVING_RFQ_DATE" value="<?php echo $data->RECEIVING_RFQ_DATE ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">RFQ Customer Date</label>
          <div class="col-sm-9">
            <input type="date"  class="form-control" name="RFQ_CUSTOMER_DATE" value="<?php echo $data->RFQ_CUSTOMER_DATE ?>" >
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">RFQ Customer No</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="RFQ_CUSTOMER_NO" value="<?php echo $data->RFQ_CUSTOMER_NO ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Due Date Quotation</label>
          <div class="col-sm-9">
            <input type="date" class="form-control" name="DUE_DATE_QUOTATION" value="<?php echo $data->DUE_DATE_QUOTATION ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Estimation LOI Date</label>
          <div class="col-sm-9">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $data->KPS_RFQ_ID ?>">
                        <input type="hidden" class="form-control" name="revisi_no_rfq" value="<?php echo $data->revisi_no_rfq ?>">

            <input type="date"  class="form-control" name="ESTIMATION_LOI_DATE" value="<?php echo $data->ESTIMATION_LOI_DATE ?>">
          </div>
        </div>
        <div class="form-group">
			<label class="col-sm-3 control-label">Tooling Cost</label>
			<div class="col-sm-9">						
              <div class="radio">
                <label>
                  <input type="radio" name="TOOLING_COST_RFQ" value="Depreciation">
                  Depreciation
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="TOOLING_COST_RFQ" value="Not Depreciation">
                  Not Depreciation
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="TOOLING_COST_RFQ" value="Others">
                  Others
                </label>
              </div>		                
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">Part Status</label>
			<div class="col-sm-9">						
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="New Project">
                  New Project
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="Localization">
                  Localization
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="Second Supplier">
                  Second Supplier
                </label>
              </div>		                
			</div>
		</div>
        <div class="form-group">
          <label class="col-sm-3 control-label">RFQ Made By</label>
          <div class="col-sm-9">
          <input type="hidden" class="form-control" name="user_made_by_id_rfq" value="<?php echo $this->session->userdata('employeeId'); ?>">
            <input type="text" class="form-control" name="MADE_BY_RFQ" disabled value="<?php echo $this->session->userdata('username') ?>">
          </div>
        </div>
        <div class="form-group">
              <label class="col-sm-3 control-label">RFQ Checked By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_checked_by">           
              <option>-- Select Checked --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->employee_checked_by){
              echo "selected=''";
            } ?>><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">RFQ Approved By</label>
              <div class="col-sm-9">
                <select class="form-control select2" style="width: 100%;" name="employee_approved_by">            
              <option>-- Select Approved --</option>
              <?php foreach ($dataEmployee as $value) { ?>
              <option value="<?php echo $value->KPS_EMPLOYEE_ID;?>" <?php if($value->KPS_EMPLOYEE_ID==$data->employee_approved_by){
              echo "selected=''";
            } ?>><?php echo $value->NIK;?> - <?php echo $value->EMPLOYEE_NAME;?></option>
              <?php } ?>            
          </select>
              </div>
            </div>
        <div class="form-group">
			<label class="col-sm-3 control-label">Customer Respond</label>
			<div class="col-sm-9">						
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="1">
                  1 (Satu)
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="2">
                  2 (Dua)
                </label>
              </div>
              <div class="radio">
                <label>
                  <input type="radio" name="PART_STATUS" value="3">
                  3 (Tiga)
                </label>
              </div>		                
			</div>
		</div>
        <div class="form-group">
          <label class="col-sm-3 control-label">Target Price</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="TARGET_PRICE"  value="<?php echo $data->TARGET_PRICE ?>">
          </div>
        </div>		        		        		       
        <div class="form-group">		          
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>			      	
    </form>	        	    			      		        
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>