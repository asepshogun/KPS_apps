<section class="content-header">
	<h3>Delivery Schedule</h3>
	<small>Jadwal Pengiriman</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<?php
		print_r($databp);
		echo "id bp  <br/>";
		echo "id bp  <br/>";
		print_r($dataBpPendingBpDetail);
		echo "Pending by id bp <br/>";
		print_r($dataBpPendingNotExeBpDetail);
		echo "Pending by id bp not exe <br/><br/><br/><br/>";
		print_r($dataBpRetunrPending);
		echo "Return Pending by  bp <br/><br/><br/><br/>";
		print_r($dataBpRetunrPendingDetail);
		echo "Return Pending by  bp dETAIL <br/><br/><br/><br/>";
		print_r($dataBpRetunrPendingDetail[0]->TOTAL_RETURN_PENDING_BP);
		echo "Return Pending by  bp dETAIL <br/><br/><br/><br/>";
		foreach($dataDS as $value){
			foreach($dataBpPending as $values){
					$Totalpending=0;
				if($value->KPS_DELIVERY_SCHEDULE_ID==$values->KPS_DELIVERY_SCHEDULE_ID){
					$Totalpending=$Totalpending+$values->TOTAL_PENDING_BP;
					foreach($dataBpPendingNotExe as $valuess){
						if($value->KPS_DELIVERY_SCHEDULE_ID == $valuess->KPS_DELIVERY_SCHEDULE_ID){
						$Totalpending=$Totalpending+$valuess->TOTAL_PENDING_BP_DSD;
						}
					}
					echo $Totalpending . $value->KPS_DELIVERY_SCHEDULE_ID . "</br>"	;
				}
			}
		}
	?>
	<br/><br/><br/>
	<span>ini adalah pending by bp detail</span>
	<?php
	foreach($dataDS as $value){
			if($dataBpPendingBpDetail){
				foreach($dataBpPendingBpDetail as $valuesBpPending){
						$TotalpendingBp=0;
					if($value->KPS_DELIVERY_SCHEDULE_ID==$valuesBpPending->KPS_DELIVERY_SCHEDULE_ID){
						$TotalpendingBp=$TotalpendingBp+$valuesBpPending->TOTAL_PENDING_BP;
						if($dataBpPendingNotExeBpDetail){
							foreach($dataBpPendingNotExeBpDetail as $valuessBpPending){
								if($value->KPS_DELIVERY_SCHEDULE_ID == $valuessBpPending->KPS_DELIVERY_SCHEDULE_ID){
									$TotalpendingBp=$TotalpendingBp+$valuessBpPending->TOTAL_PENDING_BP_DSD;
									if($dataBpRetunrPendingDetail){
										foreach($dataBpRetunrPendingDetail as $valuesReturn){
											if($value->KPS_DELIVERY_SCHEDULE_ID == $valuesReturn->KPS_DELIVERY_SCHEDULE_ID){
												$TotalpendingBp=$TotalpendingBp-$valuesReturn->TOTAL_RETURN_PENDING_BP;
												print_r($TotalpendingBp . "hallo");
											}
										}
									}
								}
							}
						}else{
						if($dataBpRetunrPendingDetail){
								foreach($dataBpRetunrPendingDetail as $valuesReturn){
									if($value->KPS_DELIVERY_SCHEDULE_ID == $valuesReturn->KPS_DELIVERY_SCHEDULE_ID){
										$TotalpendingBp=$TotalpendingBp-$valuesReturn->TOTAL_RETURN_PENDING_BP;
									}
								}
							}
						}
						echo $TotalpendingBp . $value->KPS_DELIVERY_SCHEDULE_ID . "</br>ff"	;
					}
				}
			}else if($dataBpPendingNotExeBpDetail){
				foreach($dataBpPendingNotExeBpDetail as $valuessBpPending){
						$TotalpendingBp=0;
						if($value->KPS_DELIVERY_SCHEDULE_ID == $valuessBpPending->KPS_DELIVERY_SCHEDULE_ID){
							$TotalpendingBp=$TotalpendingBp+$valuessBpPending->TOTAL_PENDING_BP_DSD;
							if($dataBpRetunrPendingDetail){
									foreach($dataBpRetunrPendingDetail as $valuesReturn){
										if($value->KPS_DELIVERY_SCHEDULE_ID == $valuesReturn->KPS_DELIVERY_SCHEDULE_ID){
											$TotalpendingBp=$TotalpendingBp-$valuesReturn->TOTAL_RETURN_PENDING_BP;
											print_r($TotalpendingBp . "hallo");
										}
									}
								}
							echo $TotalpendingBp . $value->KPS_DELIVERY_SCHEDULE_ID . "</br>dd"	;
						}
				}
			}else{
			$TotalpendingBp=0;
			}
		}
	?>
</div>