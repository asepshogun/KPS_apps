<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <title>PT KPS</title>    

    <link href="<?php echo base_url("bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/plugins/ionicons/css/ionicons.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/plugins/select2/select2.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/plugins/datatables/dataTables.bootstrap.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/plugins/datepicker/css/bootstrap-datepicker3.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url("bootstrap/dist/css/skins/_all-skins.css"); ?>">
    <link href="<?php echo base_url("bootstrap/css/style.css"); ?>" rel="stylesheet">

  </head>
  
 
  <body class="hold-transition skin-blue skin-black sidebar-collapse sidebar-mini">
  <!-- Site wrapper -->
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo site_url() ?>/dashboard" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>KPS</b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg">PT. <b>KPS </b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">   
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
       <p role="button" class="label label-primary navbar-text navbar-left" onclick=self.history.back()><span class="glyphicon glyphicon-hand-left"></span> BACK</a></p>
        
        
        <!-- Navbar Right Menu -->
         <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">  
          <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">
              <?php echo $this->session->userdata('name'); ?>
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" data-toggle="modal" data-target="#changepassword"><i class="fa fa-lock"></i>Change Password</a></li>
                <li class="divider"></li>
                <li><a href="<?php echo site_url() ?>/login/logout"><i class="fa fa-sign-out"></i>Log Out</a></li> 
              </ul>
            </li>                        
          </ul>
        </div>
      </nav>
    </header>

    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">

      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
       <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url("bootstrap/image/avatar5.png"); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $this->session->userdata('name'); ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
         
        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">  
          <li class="header">MAIN NAVIGATION</li>
          <li class="active"><a href="<?php echo site_url('dashboard');?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
          <?php
          if($this->session->userdata('role')=="Administrator"){ //hapus SALES HEAD dibaris ini
          ?>  
          <li class="treeview">
            <a href="#"><i class="fa fa-database"></i> <span>Master Data</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('department');?>"><i class="fa fa-chevron-circle-right"></i> <span>Department</span></a></li>
              <li><a href="<?php echo site_url('section');?>"><i class="fa fa-chevron-circle-right"></i> <span>Section</span></a></li>
              <li><a href="<?php echo site_url('position');?>"><i class="fa fa-chevron-circle-right"></i> <span>Position</span></a></li>
              <li><a href="<?php echo site_url('group');?>"><i class="fa fa-chevron-circle-right"></i> <span>Group</span></a></li>
              <li><a href="<?php echo site_url('bank_reference');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bank Reference</span></a></li>
              
            </ul>
          </li>
          <li class="treeview">
            <a href="#"><i class="fa fa-user"></i> <span>Employee Management</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('employee');?>"><i class="fa fa-chevron-circle-right"></i> <span>Employee</span></a></li>
              <li><a href="<?php echo site_url('user_data');?>"><i class="fa fa-chevron-circle-right"></i> <span>User Data</span></a></li>
              <li><a href="<?php echo site_url('marketing_data');?>"><i class="fa fa-chevron-circle-right"></i> <span>Marketing Data</span></a></li>
            </ul>
          </li>
         <li class="treeview">
            <a href="#"><i class="fa fa-book"></i> <span>New Item</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('customer_information');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer Information</span></a></li>
              <li><a href="<?php echo site_url('customer_list');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer List</span></a></li>
			        <li><a href="<?php echo site_url('new_item_master');?>"><i class="fa fa-chevron-circle-right"></i> <span>Item Master</span></a></li>
              
              <li><a href="<?php echo site_url('request_quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Request for Quotation</span></a></li>
              <li><a href="<?php echo site_url('rfqmonitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>RFQ Monitoring</span></a></li>
              <li><a href="<?php echo site_url('breakdown_cost');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Cost</span></a></li>
              <li><a href="<?php echo site_url('breakrep');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Report</span></a></li>
              <li><a href="<?php echo site_url('quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation</span></a></li>
              <li><a href="<?php echo site_url('historyupdate');?>"><i class="fa fa-chevron-circle-right"></i> <span>History Update</span></a></li>
              <li><a href="<?php echo site_url('historyprice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Price Update</span></a></li>
               <li><a href="<?php echo site_url('quotationmon');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation Monitoring</span></a></li>
              <li><a href="<?php echo site_url('item');?>"><i class="fa fa-chevron-circle-right"></i> <span>New Item (LOI)</span></a></li>
              <li><a href="<?php echo site_url('project');?>"><i class="fa fa-chevron-circle-right"></i> <span>Failed Project</span></a></li>
              <li><a href="<?php echo site_url('cost_of_delivery_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Cost Of Delivery Product</span></a></li>

            </ul>
          </li>
          
           <li class="treeview">
            <a href="#"><i class="fa fa-file"></i> <span>Regular</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('pesanan');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan</span></a></li>
              <li><a href="<?php echo site_url('pesanan/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan NT</span></a></li>
              <li><a href="<?php echo site_url('retur_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur Product</span></a></li>
              <li><a href="<?php echo site_url('schedule');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Schedule</span></a></li>
              <li><a href="<?php echo site_url('order_sheet');?>"><i class="fa fa-chevron-circle-right"></i> <span>Order Sheet</span></a></li>
              <li><a href="<?php echo site_url('order_sheet/monitoringSales');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monitoring Order Sheet Group</span></a></li>
              <li><a href="<?php echo site_url('order_sheet/monitoringSalesPerItem');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monitoring Order Sheet All</span></a></li>
             <li><a href="<?php echo site_url('delivery_order');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order</span></a></li>
              <li><a href="<?php echo site_url('delivery_order_retur');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order Retur</span></a></li>
              <li><a href="<?php echo site_url('delivery_order/monitoringDo');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monitor Delivery Order Confirm</span></a></li>
              <li><a href="<?php echo site_url('invoice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice</span></a></li>
              <li><a href="<?php echo site_url('invoice/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice NT</span></a></li>
              <li><a href="<?php echo site_url('invoice/monitoringDeleteInvoice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monitoring Delete Invoice</span></a></li>
              <li><a href="<?php echo site_url('invoice/monitoringDeleteInvoiceDetailDO');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monitoring Delete Invoice DO</span></a></li>
            </ul>
          </li>
            <li class="treeview">
            <a href="#"><i class="fa fa-bar-chart"></i> <span>Sales Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Sales Report</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Report</span></a></li>
              <li><a href="<?php echo site_url('total_sales_monthly_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Sales Monthly Analize</span></a></li>
              <li><a href="<?php echo site_url('total_marketing_sales_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Marketing Sales Analize</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_growth_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Growth Report</span></a></li>
            </ul>
          </li>
          <li class="treeview">
            <a href="#"><i class="fa fa-file-archive-o"></i> <span>Marketing Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('quantity');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quantity & Tooling</span></a></li>
              <li><a href="<?php echo site_url('tooling');?>"><i class="fa fa-chevron-circle-right"></i> <span>Tooling Monitoring</span></a></li>
              <li><a href="<?php echo site_url('report_monthly');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Report</span></a></li>
            </ul>
          </li>
          
            <li class="treeview">
            <a href="#"><i class="fa fa-gears"></i> <span>Production</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              
              <li><a href="<?php echo site_url('label');?>"><i class="fa fa-chevron-circle-right"></i> <span>Label</span></a></li>
              <li><a href="<?php echo site_url('bsthp');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP</span></a></li>
              <li><a href="<?php echo site_url('bsthp_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP Verification</span></a></li>
              
              <li><a href="<?php echo site_url('label_information');?>"><i class="fa fa-chevron-circle-right"></i> <span>Label Information</span></a></li>
              
              <li><a href="<?php echo site_url('bsthp_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP Verification</span></a></li>
              <li><a href="<?php echo site_url('retur');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur</span></a></li>
			  <li><a href="<?php echo site_url('label/barcodeSetting');?>"><i class="fa fa-chevron-circle-right"></i> <span>Setting Print Barcode</span></a></li>
			</ul>
          </li>
          <li class="treeview">
            <a href="#"><i class="fa fa-tv"></i> <span>Production Monitoring</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              
              <li><a href="<?php echo site_url('retur/monitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur Production Monitoring</span></a></li>
               <li><a href="<?php echo site_url('Inventory');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
        <li><a href="<?php echo site_url('Inventory/indexCodeItem');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory By Code Item</span></a></li>
             
            </ul>
          </li>
          
          <li class="treeview">
            <a href="#"><i class="fa fa-tachometer"></i> <span>PPIC</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('delivery_status');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Status</span></a></li>
              <li><a href="<?php echo site_url('vehicle');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Quota Setup</span></a></li>
              <li><a href="<?php echo site_url('delivery_quota');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Quota</span></a></li>
              <li><a href="<?php echo site_url('mutation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Mutation Item</span></a></li>              
              <li><a href="<?php echo site_url('mutation_item/monitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>Mutation Item Monitoring</span></a></li>
              <li><a href="<?php echo site_url('Inventory');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
			  <li><a href="<?php echo site_url('Inventory/indexCodeItem');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory By Code Item</span></a></li>
		   </ul>
          </li> 
          <li class="treeview">
            <a href="#"><i class="fa fa-building"></i> <span>Warehouse</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('receiving_good');?>"><i class ="fa fa-chevron-circle-right"></i> <span>Receiving Goods</span></a></li>            
              <li><a href="<?php echo site_url('inventory_warehouse');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
              <li><a href="<?php echo site_url('stock_card_delivery');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Card for Delivery</span></a></li>
              <li><a href="<?php echo site_url('stock_card_in_out');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Card by In Out</span></a></li>
              <li><a href="<?php echo site_url('stock_opname');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Opname</span></a></li>              
              <li><a href="<?php echo site_url('outgoing_finished_good_other');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Others</span></a></li>
              <li><a href="<?php echo site_url('delivery_execution_other');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Execution to Other</span></a></li>
              <li><a href="<?php echo site_url('outgoing_finished_good_other/report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Report</span></a></li>
               <li><a href="<?php echo site_url('outgoing_retur_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Retur</span></a></li>
              <li><a href="<?php echo site_url('outgoing_finished');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good</span></a></li>
              <li><a href="<?php echo site_url('outgoing_os');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing for Order Sheet</span></a></li>
               <li><a href="<?php echo site_url('outgoing_finished_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Verification</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
           <?php
          if($this->session->userdata('role')=="Sales Head"){
          ?>  
           <li class="treeview">
            <a href="#"><i class="fa fa-book"></i> <span>New Item</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('customer_information');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer Information</span></a></li>
              <li><a href="<?php echo site_url('customer_list');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer List</span></a></li>
              <li><a href="<?php echo site_url('new_item_master');?>"><i class="fa fa-chevron-circle-right"></i> <span>Item Master</span></a></li>
              
              <li><a href="<?php echo site_url('request_quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Request for Quotation</span></a></li>
              <li><a href="<?php echo site_url('rfqmonitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>RFQ Monitoring</span></a></li>
              <li><a href="<?php echo site_url('breakdown_cost');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Cost</span></a></li>
              <li><a href="<?php echo site_url('breakrep');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Report</span></a></li>
              <li><a href="<?php echo site_url('quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation</span></a></li>
              <li><a href="<?php echo site_url('historyupdate');?>"><i class="fa fa-chevron-circle-right"></i> <span>History Update</span></a></li>
              <li><a href="<?php echo site_url('historyprice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Price Update</span></a></li>
               <li><a href="<?php echo site_url('quotationmon');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation Monitoring</span></a></li>
              <li><a href="<?php echo site_url('item');?>"><i class="fa fa-chevron-circle-right"></i> <span>New Item (LOI)</span></a></li>
              <li><a href="<?php echo site_url('project');?>"><i class="fa fa-chevron-circle-right"></i> <span>Failed Project</span></a></li>
              <li><a href="<?php echo site_url('cost_of_delivery_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Cost Of Delivery Product</span></a></li>
            </ul>
          </li>
          
          <li class="treeview">
            <a href="#"><i class="fa fa-file"></i> <span>Regular</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('pesanan');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan</span></a></li>
              <li><a href="<?php echo site_url('pesanan/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan NT</span></a></li>
              <li><a href="<?php echo site_url('retur_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur Product</span></a></li>
              <li><a href="<?php echo site_url('schedule');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Schedule</span></a></li>
              <li><a href="<?php echo site_url('order_sheet');?>"><i class="fa fa-chevron-circle-right"></i> <span>Order Sheet</span></a></li>
             <li><a href="<?php echo site_url('delivery_order');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order</span></a></li>
              <li><a href="<?php echo site_url('delivery_order_retur');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order Retur</span></a></li>
              <li><a href="<?php echo site_url('invoice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice</span></a></li>
              <li><a href="<?php echo site_url('invoice/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice NT</span></a></li>
            </ul>
          </li>
           <li class="treeview">
            <a href="#"><i class="fa fa-bar-chart"></i> <span>Sales Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Sales Report</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Report</span></a></li>
              <li><a href="<?php echo site_url('total_sales_monthly_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Sales Monthly Analize</span></a></li>
              <li><a href="<?php echo site_url('total_marketing_sales_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Marketing Sales Analize</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_growth_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Growth Report</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
          <?php
          if($this->session->userdata('role')=="Sales New Item"){
          ?>  
         <li class="treeview">
            <a href="#"><i class="fa fa-book"></i> <span>New Item</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('customer_information');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer Information</span></a></li>
              <li><a href="<?php echo site_url('customer_list');?>"><i class="fa fa-chevron-circle-right"></i> <span>Customer List</span></a></li>
              <li><a href="<?php echo site_url('new_item_master');?>"><i class="fa fa-chevron-circle-right"></i> <span>Item Master</span></a></li>
              
              <li><a href="<?php echo site_url('request_quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Request for Quotation</span></a></li>
              <li><a href="<?php echo site_url('rfqmonitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>RFQ Monitoring</span></a></li>
              <li><a href="<?php echo site_url('breakdown_cost');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Cost</span></a></li>
              <li><a href="<?php echo site_url('breakrep');?>"><i class="fa fa-chevron-circle-right"></i> <span>Breakdown Report</span></a></li>
              <li><a href="<?php echo site_url('quotation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation</span></a></li>
              <li><a href="<?php echo site_url('historyupdate');?>"><i class="fa fa-chevron-circle-right"></i> <span>History Update</span></a></li>
              <li><a href="<?php echo site_url('historyprice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Price Update</span></a></li>
               <li><a href="<?php echo site_url('quotationmon');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quotation Monitoring</span></a></li>
              <li><a href="<?php echo site_url('item');?>"><i class="fa fa-chevron-circle-right"></i> <span>New Item (LOI)</span></a></li>
              <li><a href="<?php echo site_url('project');?>"><i class="fa fa-chevron-circle-right"></i> <span>Failed Project</span></a></li>
              <li><a href="<?php echo site_url('cost_of_delivery_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Cost Of Delivery Product</span></a></li>
            </ul>
          </li>
           <li class="treeview">
            <a href="#"><i class="fa fa-bar-chart"></i> <span>Sales Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Sales Report</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Report</span></a></li>
              <li><a href="<?php echo site_url('total_sales_monthly_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Sales Monthly Analize</span></a></li>
              <li><a href="<?php echo site_url('total_marketing_sales_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Marketing Sales Analize</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_growth_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Growth Report</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
          <?php
          if($this->session->userdata('role')=="Sales Regular"){
          ?>  
         <li class="treeview">
            <a href="#"><i class="fa fa-file"></i> <span>Regular</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('pesanan');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan</span></a></li>
              <li><a href="<?php echo site_url('pesanan/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Bukti Pesanan NT</span></a></li>
              <li><a href="<?php echo site_url('retur_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur Product</span></a></li>
              <li><a href="<?php echo site_url('schedule');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Schedule</span></a></li>
              <li><a href="<?php echo site_url('order_sheet');?>"><i class="fa fa-chevron-circle-right"></i> <span>Order Sheet</span></a></li>
             <li><a href="<?php echo site_url('delivery_order');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order</span></a></li>
              <li><a href="<?php echo site_url('delivery_order_retur');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Order Retur</span></a></li>
              <li><a href="<?php echo site_url('invoice');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice</span></a></li>
              <li><a href="<?php echo site_url('invoice/indexNt');?>"><i class="fa fa-chevron-circle-right"></i> <span>Invoice NT</span></a></li>
            </ul>
          </li>
           <li class="treeview">
            <a href="#"><i class="fa fa-bar-chart"></i> <span>Sales Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Sales Report</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Report</span></a></li>
              <li><a href="<?php echo site_url('total_sales_monthly_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Sales Monthly Analize</span></a></li>
              <li><a href="<?php echo site_url('total_marketing_sales_analize');?>"><i class="fa fa-chevron-circle-right"></i> <span>Total Marketing Sales Analize</span></a></li>
              <li><a href="<?php echo site_url('monthly_marketing_sales_growth_report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Marketing Sales Growth Report</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
          <?php
          if($this->session->userdata('role')=="Marketing"){
          ?>
          <li class="treeview">
            <a href="#"><i class="fa fa-file-archive-o"></i> <span>Marketing Report</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('quantity');?>"><i class="fa fa-chevron-circle-right"></i> <span>Quantity & Tooling</span></a></li>
              <li><a href="<?php echo site_url('tooling');?>"><i class="fa fa-chevron-circle-right"></i> <span>Tooling Monitoring</span></a></li>
              <li><a href="<?php echo site_url('report_monthly');?>"><i class="fa fa-chevron-circle-right"></i> <span>Monthly Report</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
           <?php
          if($this->session->userdata('role')=="Production"){
          ?>
            <li class="treeview">
            <a href="#"><i class="fa fa-gears"></i> <span>Production</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              
              <li><a href="<?php echo site_url('label');?>"><i class="fa fa-chevron-circle-right"></i> <span>Label</span></a></li>
              <li><a href="<?php echo site_url('bsthp');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP</span></a></li>
              <li><a href="<?php echo site_url('bsthp_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP Verification</span></a></li>
              
              <li><a href="<?php echo site_url('label_information');?>"><i class="fa fa-chevron-circle-right"></i> <span>Label Information</span></a></li>
              
              <li><a href="<?php echo site_url('bsthp_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>BSTHP Verification</span></a></li>
              <li><a href="<?php echo site_url('retur');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur</span></a></li>
               <li><a href="<?php echo site_url('label/barcodeSetting');?>"><i class="fa fa-chevron-circle-right"></i> <span>Setting Print Barcode</span></a></li>
            </ul>
          </li>
          <li class="treeview">
            <a href="#"><i class="fa fa-tv"></i> <span>Production Monitoring</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              
              <li><a href="<?php echo site_url('retur/monitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>Retur Production Monitoring</span></a></li>
              <li><a href="<?php echo site_url('Inventory');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
        <li><a href="<?php echo site_url('Inventory/indexCodeItem');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory By Code Item</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>

          <?php
          if($this->session->userdata('role')=="PPIC Delivery"){
          ?>
            <li class="treeview">
            <a href="#"><i class="fa fa-tachometer"></i> <span>PPIC</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('delivery_status');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Status</span></a></li>
              <li><a href="<?php echo site_url('vehicle');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Quota Setup</span></a></li>
              <li><a href="<?php echo site_url('delivery_quota');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Quota</span></a></li>
              <li><a href="<?php echo site_url('mutation');?>"><i class="fa fa-chevron-circle-right"></i> <span>Mutation Item</span></a></li>              
              <li><a href="<?php echo site_url('mutation_item/monitoring');?>"><i class="fa fa-chevron-circle-right"></i> <span>Mutation Item Monitoring</span></a></li>
              <li><a href="<?php echo site_url('Inventory');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
            </ul>
          </li> 
          
          <?php 
          }
          ?>

          <?php
          if($this->session->userdata('role')=="Warehouse" OR $this->session->userdata('role')=="PPIC Delivery"){
          ?>
         <li class="treeview">
            <a href="#"><i class="fa fa-building"></i> <span>Warehouse</span> <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="treeview-menu">
              <li><a href="<?php echo site_url('receiving_good');?>"><i class ="fa fa-chevron-circle-right"></i> <span>Receiving Goods</span></a></li>            
              <li><a href="<?php echo site_url('inventory_warehouse');?>"><i class="fa fa-chevron-circle-right"></i> <span>Inventory</span></a></li>
              <li><a href="<?php echo site_url('stock_card_delivery');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Card for Delivery</span></a></li>
              <li><a href="<?php echo site_url('stock_card_in_out');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Card by In Out</span></a></li>
              <li><a href="<?php echo site_url('stock_opname');?>"><i class="fa fa-chevron-circle-right"></i> <span>Stock Opname</span></a></li>              
              <li><a href="<?php echo site_url('outgoing_finished_good_other');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Others</span></a></li>
              <li><a href="<?php echo site_url('delivery_execution_other');?>"><i class="fa fa-chevron-circle-right"></i> <span>Delivery Execution to Other</span></a></li>
              <li><a href="<?php echo site_url('outgoing_finished_good_other/report');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Report</span></a></li>
               <li><a href="<?php echo site_url('outgoing_retur_product');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Retur</span></a></li>
              <li><a href="<?php echo site_url('outgoing_finished');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good</span></a></li>
              <li><a href="<?php echo site_url('outgoing_os');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing for Order Sheet</span></a></li>
               <li><a href="<?php echo site_url('outgoing_finished_verification');?>"><i class="fa fa-chevron-circle-right"></i> <span>Outgoing Finished Good Verification</span></a></li>
            </ul>
          </li>
          <?php 
          }
          ?>
        </ul>
        <!--sidebar-menu -->
      </section>
      <!--sidebar -->
    </aside>
    
    <div class="content-wrapper">                               
    <!--MODAL-->
    <!-- Modal CHANGE PASSWORD-->
    <div class="modal fade" id="changepassword" role="dialog">
      <div class="modal-dialog">

        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Form Change Password</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo site_url()."/login/changes";?>" method="POST" class="form-horizontal">
            <input type="hidden" name="id" value="<?php echo $this->session->userdata('id') ?>">
              <div class="form-group">
                  <label for="departName" class="col-sm-3 control-label">Current Password</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" name="password" placeholder="Ex. HRD" value="<?php echo $this->session->userdata('password') ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="departName" class="col-sm-3 control-label">New Password</label>
                  <div class="col-sm-9">
                    <input type="password" class="form-control" name="PASSWORD" placeholder="New Password" value="">
                  </div>
                </div>
                <div class="form-group">              
                  <div class="col-sm-12">
                    <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
                  </div>
                </div>              
              </form>                                       
          </div>
        </div>
        
      </div>
    </div>
    <!-- Modal CHANGE PASSWORD -->
  </body>
</html>