<section class="content-header">
	<h3>Dashboard Page</h3>
	<small>Halam Dashboard</small>
</section>
<?php //	var_dump($this->session->userdata)?>