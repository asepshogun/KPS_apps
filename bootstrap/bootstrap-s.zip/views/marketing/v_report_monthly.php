<section class="content-header">
	<h3>Marketing Report Monthly</h3>
	<small>Data Report Monthly</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="report_monthly" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Marketing Report</th>
		        <th>Month</th>
		        <th>Marketing Name</th>        
		        <th>Detail</th>
		        <th>Print</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) $no++;{ ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->MONTH;?></td>
			        <td><?php echo $value->MARKETING_NAME;?></td>			        
			        <td><a href="<?php echo site_url()."/report_monthly/detail/".$value->KPS_MARKETING_REPORT_MONTHLY_ID;?>">Detail</a></td>
			        <td><a href="" url="<?php echo site_url()."/report_monthly/print/".$value->KPS_MARKETING_REPORT_MONTHLY_ID;?>">Print</a></td>
			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Report Monthly</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Report Monthly Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/report_monthly/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="date" min="<?php echo date('Y-m-d') ?>" class="form-control" name="DATE" placeholder="Pick Date" value="<?php echo date('Y-m-d') ?>">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Month</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="MONTH">	
		            					    <option>-- Select Year --</option>

						<?php
						$bulan = array("", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
						for($y=1;$y<=12;$y++){
						echo("<option value=\"$y\" $pilih>$bulan[$y]</option>"."\n");
						}
						?>
						</select>

		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Marketing Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="KPS_MARKETING_ID">					  
					    <option>-- Select Marketing Name --</option>
					    <?php foreach ($dataMarketing as $value) { ?>
					    <option value="<?php echo $value->KPS_MARKETING_ID;?>"><?php echo $value->MARKETING_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->