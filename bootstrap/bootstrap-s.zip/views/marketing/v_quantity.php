<section class="content-header">
	<h3>Quantity & Tooling</h3>
	<small>Data Quantity</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="quantity" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Quantity</th>
		        <th>Customer Name</th>
		        <th>LOI Date</th>
		        <th>Part No</th>
		        <th>Part Name</th>
		        <th>Model</th>	        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php 

		    	$no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO_MQ;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->LOI_DATE;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><a href="<?php echo site_url()."/quantity/detail/".$value->KPS_MARKETING_QUANTITY_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Quantity</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Quantity Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/quantity/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Customer Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" url="<?php echo site_url()."/quantity/loadLoi"; ?>" name="customer" id="customers">					  
					    <option>-- Select Customer Name --</option>
					    <?php foreach ($dataCust as $value) { ?>
					    <option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Part No - Nama - Model</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" id="lois" name="loi">					  
					    <option>-- Select Part No - Nama - Model --</option>
					   			  
					</select>
		          </div>
		        </div>
		       <div class="form-group">
		          <label class="col-sm-3 control-label">Tooling price base on puchased</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" style="width: 100%;" name="TOOLINGS_PRICE_BASED_ON_PURCHASE">					  
		          </div>
		        </div>
		       
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->