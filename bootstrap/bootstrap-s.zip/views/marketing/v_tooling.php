<section class="content-header">
	<h3>Monitoring Tooling</h3>
	<small>Data Tooling</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="tooling" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No Tooling</th>
		        <th>Month</th>
		        <th>Year</th>	        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) $no++;{ ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->MONTH;?></td>
			        <td><?php echo $value->YEAR;?></td>
			        <td><a href="<?php echo site_url()."/tooling/detail/".$value->KPS_MARKETING_TOOLINGS_ID;?>">Detail</a></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Tooling</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Tooling Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/tooling/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" 
		            value="<?php echo date('Y-m-d'); ?>" 
		            name="DATE" placeholder="Pick Date">
		          </div>
		        </div>
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Month</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="MONTH">	
		            					    <option>-- Select Year --</option>

						<?php
						$bulan = array("", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
						for($y=1;$y<=12;$y++){
						echo("<option value=\"$y\" $pilih>$bulan[$y]</option>"."\n");
						}
						?>
						</select>

		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Year</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="YEAR">					  
					    <option>-- Select Year --</option>
					    <?php for ($i=2016;$i<2020;$i++) { ?>
					    <option value="<?php echo $i;?>"><?php echo $i;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->