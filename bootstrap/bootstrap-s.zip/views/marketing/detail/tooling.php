<section class="content-header">
	<h3>Tooling Data Detail</h3>
	<small>Detail Data Tooling</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled value="<?php echo $data->NO ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $data->DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Month</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH" disabled value="<?php echo $data->MONTH ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Year</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="YEAR" disabled value="<?php echo $data->YEAR ?>">
			          </div>
			        </div>
				</form>
			</div>
			<?php 
				$statusvg = 0;
		    	$statusg = 0;
		    	$statusn = 0;
		    	$statusc = 0;
		    	$statusd = 0;
			?>
			<div class="col-lg-6">
				<form class="form-horizontal">
					
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Very Good</label>
			          <div class="col-sm-7">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $statusvg; ?>">
			          </div>
			          <label class="col-sm-2 control-label">PCS</label>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Good</label>
			           <div class="col-sm-7">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $statusg; ?>">
			          </div>
			          <label class="col-sm-2 control-label">PCS</label>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Normal</label>
			           <div class="col-sm-7">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $statusn; ?>">
			          </div>
			          <label class="col-sm-2 control-label">PCS</label>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Carefully</label>
			           <div class="col-sm-7">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $statusc; ?>">
			          </div>
			          <label class="col-sm-2 control-label">PCS</label>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Danger</label>
			           <div class="col-sm-7">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $statusd; ?>">
			          </div>
			          <label class="col-sm-2 control-label">PCS</label>
			        </div>
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="marketing-tooling-satu" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th colspan="2"><center>LOI</center></th>
		        <th rowspan="2">First PO Date</th>
		        <th rowspan="2">Part Name</th>
		        <th rowspan="2">Part No</th>
		        <th rowspan="2">Model</th>
		        <th rowspan="2">Customer Name</th>
		        <th rowspan="2">Tooling Cost Based on Breakdown</th>	        
		        <th rowspan="2">Tooling Cost Based on Purchase</th>	 
		        <th rowspan="2">Mould Depreciation (Yes/No)</th>	
		        <th colspan="4"><center>Payment if Not Depreciated</center></th>    
		        <th colspan="2"><center>Cumulative</center></th>   
		        <th colspan="2"><center>Amortized Based on Breakdown</center></th>
		        <th colspan="2"><center>Amortized Based on Purchased</center></th>
		        <th colspan="2">Balance</th>
		        <th rowspan="2">Loss</th>
		      </tr>
		      <tr>
		      	<th>Date</th>
		      	<th>No LOI</th>
		      	<th>Invoice Date</th>
		      	<th>Invoice No</th>
		      	<th>Amount</th>
		      	<th>Status</th>
		      	<th>QTY</th>
		      	<th>Units</th>
		      	<th>RP</th>
		      	<th>Status</th>
		      	<th>RP</th>
		      	<th>QTY</th>
		      	<th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	
		    	<?php 
		    	$no=0;
		    	$valuecom=0;
		    	$valueam=0;
		    	$valuepur=0;
		    	$valuebal=0;
		    	$loss=0;
		    	

		    	$no=0; 
		    	foreach ($datas as $value) {$no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE_LOI;?></td>
			        <td><?php echo $value->NO_LOI;?></td>
			        <td><?php echo $value->FIRST_PO_DATE;?></td>
			        <td><?php echo $value->LOI_PART_NAME;?></td>
			        <td><?php echo $value->LOI_PART_NO;?></td>
			        <td><?php echo $value->LOI_MODEL;?></td>
			        <td><?php echo $value->COMPANY_NAME;?></td>
			        <td><?php echo $value->TOOLINGS_PRICE_BASED_ON_BREAKDOWN;?></td>
			        <td><?php echo $value->TOOLINGS_PRICE_BASED_ON_PURCHASE;?></td>
			        <td>
			        	<?php
			        		if($value->TOOLING_COST_RFQ="Depreciation"){
			        			echo "YES";
			        		}else{
			        			echo "NO";
			        		}
			       		 ?>
			        </td>
			        <td><?php echo $value->INVOICE_INDUK_DATE;?></td>
			        <td><?php echo $value->INVOICE_INDUK_NO;?></td>
			        <td><?php echo $value->TOTAL_TERBAYAR;?></td>
			        <td><?php echo "status"; ?></td>
			        <td><?php echo $value->QUANTITY;?></td>
			        <td><?php echo $value->CUMULATIVE;?></td>
			        <td><?php echo $value->STATUS;?></td>
			        <td><?php echo $value->AMORTIZE_BASED_ON_BREAKDOWN_RP;?></td>
			        <td><?php echo $value->AMORTIZE_BASED_ON_BREAKDOWN_STATUS;?></td>
			        <td><?php echo $value->AMORTIZE_BASED_ON_PURCHASE_RP;?></td>
			        <td><?php echo $value->AMORTIZE_BASED_ON_PURCHASE_STATUS;?></td>
			        <td><?php echo $value->BALANCE_RP;?></td>
			        <td><?php echo $value->BALANCE_STATUS;?></td>
			        <td><?php echo $value->LOSS;?></td>
		    	</tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
