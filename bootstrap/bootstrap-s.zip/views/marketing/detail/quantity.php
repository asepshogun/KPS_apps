<?php
ini_set('display_errors', 1);

?>
<section class="content-header">
	<h3>Quantity Data Detail</h3>
	<small>Detail Data Quantity</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled value="<?php echo $dataOnly->NO_MQ; ?>">
			          </div>
			        </div>
					<div class="form-group">
			          <label class="col-sm-3 control-label">LOI Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="LOI_DATE" disabled value="<?php echo $dataOnly->LOI_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">First PO Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="FIRST_PO_DATE" disabled value="<?php echo $dataOnly->FIRST_PO_DATE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Tooling Price Based on Breakdown</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOOLING_PRICE_BASED_ON_BREAKDOWN" disabled value="<?php echo $dataOnly->TOOLINGS_PRICE_BASED_ON_BREAKDOWN; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Tooling Price Based on Purchase</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOOLING_PRICE_BASED_ON_PURCHASE" disabled value="<?php echo $dataOnly->TOOLINGS_PRICE_BASED_ON_PURCHASE; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $dataOnly->DATE; ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="COMPANY_NAME" disabled value="<?php echo $dataOnlys->COMPANY_NAME; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled value="<?php echo $dataOnlys->LOI_PART_NAME; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NO" disabled value="<?php echo $dataOnlys->LOI_PART_NO; ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled value="<?php echo $dataOnlys->LOI_MODEL; ?>">
			          </div>
			        </div>
			        <div class="form-group">
					          <label class="col-sm-3 control-label">QTY Based on Breakdown</label>
					          <div class="col-sm-9">
					            <input type="text" class="form-control" name="QTY_BASED_ON_BREAKDOWN" disabled value="<?php echo $dataOnly->QTY_BASED_ON_BREAKDOWN; ?>">
					          </div>
					        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Amortize Cost Purchased</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="AMORTIZE_COST_BREAKDOWN" disabled value="<?php echo $dataOnly->AMORTIZE_COST_PURCHASE; ?>">
			          </div>
			        </div>	
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Amortize Cost Breakdown</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="AMORTIZE_COST_BREAKDOWN" disabled value="<?php echo $dataOnly->AMORTIZE_COST_BREAKDOWN; ?>">
			          </div>
			        </div>			        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="quantity_detail" class="table table-bordered table-hover table-striped dataTable">
		    <thead>
		      <tr>
		        <th rowspan="2">No</th>
		        <th rowspan="2">Month - Year</th>
		        <th colspan="3"><center>Based on Invoice</center></th>
		        <th colspan="2"><center>Amortized Based on Breakdown</center></th>
		        <th colspan="2"><center>Amortized Based on Purchased</center></th>
		        <th colspan="2">Balance</th>
		        <th rowspan="2">Loss</th>
		      </tr>
		      <tr>
		      	<th>QTY</th>
		      	<th>Cummulative</th>
		      	<th>Status</th>
		      	<th>RP</th>
		      	<th>Status</th>
		      	<th>RP</th>
		      	<th>Status</th>
		      	<th>QTY</th>
		      	<th>Status</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php 
		    	$no=1;
		    	$valuecom=0;
		    	$valueam=0;
		    	$valuepur=0;
		    	$valuebal=0;
		    	$loss=0;

		    	$lastkey = array_pop(array_keys($data));
				$lastvalue = $data[$lastkey];
		    	
		    	foreach ($data as $value){ 
		    		
		    		if(!is_null($value->yearmonth)){
		    			
		    			?>
		    		<tr>
		    		<td><?php echo $no++; ?></td>
		    		<td><?php echo $value->yearmonth;?></td>
		    		<td><?php echo $value->delivery_exe;?></td>
		    		<td><?php 	
		    				$valuecom += $value->delivery_exe;
		    				echo $valuecom;
		    			?>
		    		</td>
		    		<td><?php 	
		    				$statusV = (($valuecom/$dataOnly->QTY_BASED_ON_BREAKDOWN)-1)*100;
					        if($statusV>50){
					        	echo $status = "Very Good";
					        }else if($statusV>25){
					        	echo $status = "GOOD";
					        }else if($statusV>0){
					        	echo $status = "NORMAL";
					        }else if($statusV>-25){
					        	echo $status = "CAREFULLY";
					        }else{
					        	echo $status = "DANGER";
					        }
		    			?>
		    		</td>
		    		<td><?php 	
		    				$valueam += $valueam-($dataOnly->AMORTIZE_COST_BREAKDOWN*$valuecom);
		    				echo $valueam;
		    			?>
		    		</td>
		    		<td><?php 	
		    				if($valuecom < ($dataOnly->QTY_BASED_ON_BREAKDOWN*$dataOnly->AMORTIZE_COST_PURCHASE_PERIODE)){
					        	echo "OPEN";
					        	$statusam = "OPEN";
					        }else{
					        	echo "CLOSE";
					        	$statusam = "CLOSE";
					        }
		    			?>
		    		</td>
		    		<td><?php 	
		    				$valuepur += $valuepur-($dataOnly->AMORTIZE_COST_PURCHASE*$valuecom);
		    				echo $valuepur;
		    			?>
		    		</td>
		    		<td><?php 	
		    				if($valuecom <= 0){
					        	echo "OPEN";
					        	$statuspur = "OPEN";
					        }else{
					        	echo "CLOSE";
					        	$statuspur = "CLOSE";
					        }
		    			?>
		    		</td>
		    		<td><?php 	
		    				$valuebal = $dataOnly->QTY_BASED_ON_BREAKDOWN - $value->delivery_exe;
		    				echo $valuebal;
		    			?>
		    		</td>
		    		<td><?php 	
		    				if($valuebal > 0){
					        	echo "SURPLUS";
					        	$statusbal = "SURPLUS";
					        }elseif($valuebal = 0){
					        	echo "EQUIVALEN";
					        	$statusbal = "EQUIVALEN";
					        }else{
					        	echo "LOSS";
					        	$statusbal = "LOSS";
					        }
		    			?>
		    		</td>
		    		<td><?php 	
		    				$loss = $valuebal - $dataOnly->AMORTIZE_COST_BREAKDOWN;
		    				echo $loss;
		    			?>
		    		</td>
		    		</tr>
		    	<?php 
		    	//$testing = end($value);
		    	
		    	if($lastvalue->yearmonth==$value->yearmonth){
		    			$datas['KPS_MARKETING_QUANTITY_ID'] = $dataOnlys->KPS_MARKETING_QUANTITY_ID;
						$datas['MONTH_YEAR'] = $value->yearmonth;
						$datas['QUANTITY'] = $value->delivery_exe;
						$datas['CUMULATIVE'] = $valuecom;
						$datas['STATUS'] = $status;
						$datas['AMORTIZE_BASED_ON_BREAKDOWN_RP'] = $valueam;
						$datas['AMORTIZE_BASED_ON_BREAKDOWN_STATUS'] = $statusam;
						$datas['AMORTIZE_BASED_ON_PURCHASE_RP'] = $valuepur;
						$datas['AMORTIZE_BASED_ON_PURCHASE_STATUS'] = $statuspur;
						$datas['BALANCE_RP'] = $valuebal;
						$datas['BALANCE_STATUS'] = $statusbal;
						$datas['LOSS'] = $loss;

						$dataid = $this->m_quantity->cekID($dataOnlys->KPS_MARKETING_QUANTITY_ID);
						//var_dump($dataid->KPS_MARKETING_QUANTITY_ID);
						if(is_null($dataid->KPS_MARKETING_QUANTITY_ID)){
							$this->m_quantity->insertDet($datas);	
						}else{
							$this->m_quantity->updatedet($datas,$dataOnlys->KPS_MARKETING_QUANTITY_ID);
						}
						
		    			}
		    	}
		    }
		    	?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>