<section class="content-header">
	<h3>Report Monthly Data Detail</h3>
	<small>Detail Data Report Monthly</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled value="<?php echo $data->NO ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled value="<?php echo $data->DATE ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Month</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MONTH_YEAR" disabled value="<?php echo $data->MONTH ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Marketing Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MARKETING_NAME" disabled value="<?php echo $data->MARKETING_NAME ?>">
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
								        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="report_monthly_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Subject</th>
		        <th>QTY</th>
		        <th>NOTE</th>
		      </tr>
		    </thead>
		    <tbody>
		    	
			      <tr>
			      	<td>
			      		1
			      	</td>
			      	<td>
			      		Jumlah Quotation
			      	</td>
			      	<td>
			      		<?php
			      		
			      		echo $dataQuo;
			      		?>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		2
			      	</td>
			      	<td>
					Jumlah Revisi Quotation
			      	</td>
			      	<td>
			      		<?php
			      		
			      		echo $dataQuoRev;
			      		?>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		3
			      	</td>
			      	<td>
					Jumlah RFQ
			      	</td>
			      	<td>
			      		<?php
			      		
			      		echo $dataRfq;
			      		?>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		4
			      	</td>
			      	<td>
					Jumlah LOI
			      	</td>
			      	<td>
			      		<?php
			      		
			      		echo $dataLoi;
			      		?>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		5
			      	</td>
			      	<td>
			Jumlah Gagal LOI
			      	<td>
			      		<?php
			      		
			      		echo $dataFP;
			      		?>			      	</td>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		6
			      	</td>
			      	<td>
					Jumlah Kewajaran Quantity 
					<br/>
					a. Very Good
					<br/>
					b. Good
					<br/>
					c. Normal
					<br/>
					d. Carefully
					<br/>
					e. Danger

			      	</td>
			      	<td>
			      		<br/>
			      			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_marketing_quantity_detail` join kps_marketing_quantity using(KPS_MARKETING_QUANTITY_ID) WHERE STATUS='Very Good' AND MONTH(`DATE`) = '".$data->MONTH."'")->result();
			      		echo count($q1);
			      		?>
<br/>
			      			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_marketing_quantity_detail` join kps_marketing_quantity using(KPS_MARKETING_QUANTITY_ID) WHERE STATUS='GOOD' AND MONTH(`DATE`) = '".$data->MONTH."'")->result();
			      		echo count($q1);
			      		?>
<br/>
			      			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_marketing_quantity_detail` join kps_marketing_quantity using(KPS_MARKETING_QUANTITY_ID) WHERE STATUS='NORMAL' AND MONTH(`DATE`) = '".$data->MONTH."'")->result();
			      		echo count($q1);
			      		?>
<br/>
			      			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_marketing_quantity_detail` join kps_marketing_quantity using(KPS_MARKETING_QUANTITY_ID) WHERE STATUS='CAREFULLY' AND MONTH(`DATE`) = '".$data->MONTH."'")->result();
			      		echo count($q1);
			      		?>
<br/>
			      			<?php
			      		$q1 = $this->db->query("SELECT * FROM `kps_marketing_quantity_detail` join kps_marketing_quantity using(KPS_MARKETING_QUANTITY_ID) WHERE STATUS='Very Good' AND MONTH(`DATE`) = '".$data->MONTH."'")->result();
			      		echo count($q1);
			      		?>

			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			     
			      <tr>
			      	<td>
			      	7
			      	</td>
			      	<td>
			      		Jumlah produk mould yang running dan sudah terdepresiasi sempurna
					
			      	</td>
			      	<td>
			      		0
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		8
			      	</td>
			      	<td>
			      		Jumlah produk mould yang running dan belum discontinue
					
			      	</td>
			      	<td>
			      		0
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		9
			      	</td>
			      	<td>
			      		Inventasi tooling setelah dikurangi depresiasi
					
			      	</td>
			      	<td>
			      		0
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>
			      <tr>
			      	<td>
			      		10
			      	</td>
			      	<td>
				Jumlah konsumen							
			      	</td>
			      	<td>
			      		<?php 
			      		echo $dataCust;
			      		?>
			      	</td>
			      	<td>
			      		
			      	</td>
			      </tr>

		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>