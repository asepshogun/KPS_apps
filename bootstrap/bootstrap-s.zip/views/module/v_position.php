<section class="content-header">
	<h3>Employee Position Module</h3>
	<small>Modul Posisi Karyawan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="position" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Position Name</th>
		        <th>Section Name</th>
		        <th>Update</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->POS_NAME;?></td>
			        <td><?php echo $value->SEC_NAME;?></td>
			        <td><a href="<?php echo site_url()."/position/edit/".$value->POSITION_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Position</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Employee Position</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/position/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label for="posName" class="col-sm-3 control-label">Position Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="POS_NAME" placeholder="Ex. Merketing">
		          </div>
		        </div>
		        <div class="form-group">
		          <label for="sectionName" class="col-sm-3 control-label">Section Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SEC_EMPLOYEE_ID_POS">					  
					    <option>-- Select Section --</option>
					    <?php foreach ($dataSection as $value) { ?>
					    <option value="<?php echo $value->SEC_EMPLOYEE_ID;?>"><?php echo $value->SEC_NAME;?></option>					  
					    <?php } ?>
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->