<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
      <h4 class="modal-title">Employee Section Data Detail</h4>
</div>
<div class="modal-body">	    	
	<form action="<?php echo site_url()."/section/update";?>" method="POST" class="form-horizontal">
		<input type="hidden" name="id" value="<?php echo $data->SEC_EMPLOYEE_ID ?>">	    		
		<div class="form-group">
          <label for="sectionName" class="col-sm-3 control-label">Section Name</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" name="SEC_NAME" value="<?php echo $data->SEC_NAME ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="departName" class="col-sm-3 control-label">Department Name</label>
          <div class="col-sm-9">
            <select class="form-control select2" style="width: 100%;" name="DEPT_EMPLOYEE_ID_SEC">					  
			    <option>-- Select Department --</option>
			    <?php foreach ($dataDepartment as $value) { 

			    	?>
			    <option value="<?php echo $value->DEPT_EMPLOYEE_ID;?>" <?php if($value->DEPT_EMPLOYEE_ID==$data->DEPT_EMPLOYEE_ID_SEC){
			    		echo "selected=''";
			    	} ?>><?php echo $value->DEPT_NAME;?></option>
			    <?php } ?>					  
			</select>
          </div>
        </div>		        
        <div class="form-group">		          
          <div class="col-sm-12">
            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
          </div>
        </div>			      	
    </form>	        	        	    			      		       
</div>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>