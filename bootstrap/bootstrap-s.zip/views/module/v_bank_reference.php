<section class="content-header">
	<h3>Bank Reference Module</h3>
	<small>Modul Referensi Bank</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="bankref" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Bank Name</th>
		        <th>Update</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ;?>
			      <tr>		      	
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->BANK_NAME;?></td>
			        <td><a href="<?php echo site_url()."/bank_reference/edit/".$value->KPS_BANK_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Bank Reference</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Bank Reference</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/bank_reference/add";?>" method="post" class="form-horizontal">
	    		<div class="form-group">
		          <label for="bankName" class="col-sm-3 control-label">Bank Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BANK_NAME" placeholder="Ex. Bank Indonesia">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->