<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">KPS Group Data Detail</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/group/update";?>" method="post" class="form-horizontal">
	    		<input type="hidden" name="id" value="<?php echo $data->id; ?>">
	    		<div class="form-group">
		          <label for="groupName" class="col-sm-3 control-label">Group Name</label>
		          <div class="col-sm-9">		          	
		            <input type="text" class="form-control" name="group_name" value="<?php echo $data->group_name ?>">		            
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>