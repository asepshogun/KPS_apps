<section class="content-header">
	<h3>Employee Section Module</h3>
	<small>Modul Golongan Karyawan</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="section" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Section Name</th>
		        <th>Department Name</th>
		        <th>Update</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->SEC_NAME;?></td>
			        <td><?php echo $value->DEPT_NAME;?></td>
			        <td><a href="<?php echo site_url()."/section/edit/".$value->SEC_EMPLOYEE_ID;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Section</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Employee Section</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/section/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label for="sectionName" class="col-sm-3 control-label">Section Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SEC_NAME" placeholder="Ex. Marketing">
		          </div>
		        </div>
		        <div class="form-group">
		          <label for="departName" class="col-sm-3 control-label">Department Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="DEPT_EMPLOYEE_ID_SEC">					  
					    <option>-- Select Department --</option>
					    <?php foreach ($dataDepartment as $value) { ?>
					    <option value="<?php echo $value->DEPT_EMPLOYEE_ID;?>"><?php echo $value->DEPT_NAME;?></option>
					    <?php } ?>					  
					</select>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">
	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->