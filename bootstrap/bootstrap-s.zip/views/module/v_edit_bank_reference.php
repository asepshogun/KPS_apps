<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Bank Reference Data Detail</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/bank_reference/update";?>" method="POST" class="form-horizontal">
	    		<input type="hidden" name="id" value="<?php echo $data->KPS_BANK_ID; ?>">
	    		<div class="form-group">
		          <label for="bankName" class="col-sm-3 control-label">Bank Name</label>
		          <div class="col-sm-9">		          	
		            <input type="text" class="form-control" name="BANK_NAME" value="<?php echo $data->BANK_NAME; ?>">		            
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>