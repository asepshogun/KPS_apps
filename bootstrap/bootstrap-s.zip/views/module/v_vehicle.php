<section class="content-header">
	<h3>KPS Vehicle Module</h3>
	<small>Modul Kendaraan KPS</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
<div class="box-body">
	<div class="box-body">
		<!--TABLE-->
		<table id="vehicle" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>NO</th>
		        <th>Rev No</th>
		        <th>Vehicle Number</th>
		        <th>Vehicle Name</th>
		        <th>Supplier Name</th>
		        <th>Purchase Date</th>
		        <th>Cost Of delivery(Rp) Local</th>
		        <th>Cost Of delivery(Rp) JABODETABEK</th>
		        <th>Volume Box</th>
		        <th>Photo Of Truck</th>
		        <th>Note</th>
		        <th>Update</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no; ?></td>
			        <td><?php echo $value->VEHICLE_DATE; ?></td>
			        <td><?php echo $value->VEHICLE_NO; ?></td>
			        <td><?php echo $value->REV_NO; ?></td>
			        <td><?php echo $value->VEHICLE_NO; ?></td>
			        <td><?php echo $value->VEHICLE_NAME; ?></td>
			        <td><?php echo $value->SUPPLIER_NAME; ?></td>
			        <td><?php echo $value->PURCHASE_DATE; ?></td>
			        <td><?php echo $value->COD_LOCAL; ?></td>
			        <td><?php echo $value->COD_JABODETABEK; ?></td>
			        <td><?php echo $value->VOLUME_BOX; ?></td>
			        <td><img alt="" width="100px" heaight="100px" src="<?php echo base_url(); ?>/uploads/vehicle/<?php echo $value->PHOTO_OF_TRUCK; ?>" /></td>
			        <td><?php echo $value->VEHICLE_NOTE; ?></td>
					<td><a href="#" url="<?php echo site_url()."/vehicle/edit/".$value->KPS_VEHICLE_ID;?>" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>
	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New KPS Vehicle</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New KPS Vehicle</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/vehicle/add";?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label for="vehicleNumber" class="col-sm-3 control-label">Vehicle Number</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NO" placeholder="Ex. 123-456">
		          </div>
		        </div>
		        <div class="form-group">
		          <label for="vehicleName" class="col-sm-3 control-label">Vehicle Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NAME" placeholder="Ex. Mitshubisi">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="SUPPLIER_NAME" class="col-sm-3 control-label">Supplier Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SUPPLIER_NAME" placeholder="Supplier Name">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="PURCHASE_DATE" class="col-sm-3 control-label">Purchase Date</label>
		          <div class="col-sm-9">
		            <input type="date" class="form-control" name="PURCHASE_DATE" placeholder="Pick Date">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="COD_LOCAL" class="col-sm-3 control-label">Cost of Delivery (Rp) Local</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="COD_LOCAL" placeholder="Cost Of Delivery Local">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="COD_JABODETABEK" class="col-sm-3 control-label">Cost of Delivery (Rp) JABODETABEK</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="COD_JABODETABEK" placeholder="Cost Of Delivery JABODETABEK">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="VOLUME_BOX" class="col-sm-3 control-label">VOLUME BOX (mm3)</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="VOLUME_BOX" placeholder="VOLUME BOX (mm3)">
		          </div>
		        </div>
				<div class="form-group">
					<?php echo form_error('photo_truck'); ?>
		          <label for="FILENAME" class="col-sm-3 control-label">Photos of Truck</label>
		          <div class="col-sm-9">
		            <input type="file" class="form-control" name="FILENAME" id="photo_truck">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="VEHICLE_NOTE" class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <textarea type="number" class="form-control" name="VEHICLE_NOTE" placeholder="Note"></textarea>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">
	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->