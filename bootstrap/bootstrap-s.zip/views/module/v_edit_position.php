<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Employee Position Data Detail</h4>
	    </div>
	    <div class="modal-body">	    	
	    	<form action="<?php echo site_url()."/position/update";?>" method="POST" class="form-horizontal">
	    		<input type="hidden" name="id" value="<?php echo $data->POSITION_ID; ?>">	    		
	    		<div class="form-group">
		          <label for="posName" class="col-sm-3 control-label">Positon Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="POS_NAME" value="<?php echo $data->POS_NAME; ?>">
		          </div>
		        </div>
		        <div class="form-group">
		          <label for="sectionName" class="col-sm-3 control-label">Section Name</label>
		          <div class="col-sm-9">
		            <select class="form-control select2" style="width: 100%;" name="SEC_EMPLOYEE_ID_POS">
					    <option>-- Select Department --</option> <option>-- Select Department --</option>
					    <?php foreach ($dataSection as $value) { ?>
					    <option value="<?php echo $value->SEC_EMPLOYEE_ID;?>" <?php if($value->SEC_EMPLOYEE_ID==$data->SEC_EMPLOYEE_ID_POS){
			    		echo "selected=''";
			    	} ?>><?php echo $value->SEC_NAME;?></option>
					    <?php } ?>				  
					</select>
		          </div>
		        </div>		        
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			        	      		        
	    </div>

<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>