<div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">KPS Vehicle Data Detail</h4>
	    </div>
	    <div class="modal-body">
	    	
	        <form action="<?php echo site_url()."/vehicle/update";?>" enctype="multipart/form-data" method="POST" class="form-horizontal">
	        <input type="hidden" name="id" value="<?php echo $data->KPS_VEHICLE_ID; ?>">
	    		<div class="form-group">
		          <label for="vehicleNumber" class="col-sm-3 control-label">Vehicle Number</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NO" value="<?php echo $data->VEHICLE_NO; ?>" placeholder="Ex. 123-456">
		          </div>
		        </div>
		        <div class="form-group">
		          <label for="vehicleName" class="col-sm-3 control-label">Vehicle Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NAME" value="<?php echo $data->VEHICLE_NAME; ?>" placeholder="Ex. Mitshubisi">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="SUPPLIER_NAME" class="col-sm-3 control-label">Supplier Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SUPPLIER_NAME" value="<?php echo $data->SUPPLIER_NAME; ?>" placeholder="Supplier Name">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="PURCHASE_DATE" class="col-sm-3 control-label">Purchase Date</label>
		          <div class="col-sm-9">
		            <input type="date" class="form-control" name="PURCHASE_DATE" value="<?php echo $data->PURCHASE_DATE; ?>"placeholder="Pick Date">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="COD_LOCAL" class="col-sm-3 control-label">Cost of Delivery (Rp) Local</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="COD_LOCAL" value="<?php echo $data->COD_LOCAL; ?>" placeholder="Cost Of Delivery Local">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="COD_JABODETABEK" class="col-sm-3 control-label">Cost of Delivery (Rp) JABODETABEK</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="COD_JABODETABEK" value="<?php echo $data->COD_JABODETABEK; ?>" placeholder="Cost Of Delivery JABODETABEK">
		          </div>
		        </div>
				<div class="form-group">
		          <label for="VOLUME_BOX" class="col-sm-3 control-label">VOLUME BOX (mm3)</label>
		          <div class="col-sm-9">
		            <input type="number" class="form-control" name="VOLUME_BOX" value="<?php echo $data->VOLUME_BOX; ?>" placeholder="VOLUME BOX (mm3)">
		          </div>
		        </div>
				<!--
				<div class="form-group">
					<?php echo form_error('photo_truck'); ?>
		          <label for="FILENAME" class="col-sm-3 control-label">Photos of Truck</label>
		          <div class="col-sm-9">
		            <input type="file" class="form-control" name="FILENAME" value="<?php echo $data->PHOTO_OF_TRUCK; ?>" id="photo_truck">
		          </div>
		        </div>
				-->
				<?php //print_r($data);?>
				<div class="form-group">
		          <label for="VEHICLE_NOTE" class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <textarea type="number" class="form-control" name="VEHICLE_NOTE" value="<?php echo $data->VEHICLE_NOTE;?>" placeholder="Note"></textarea>
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Update Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>