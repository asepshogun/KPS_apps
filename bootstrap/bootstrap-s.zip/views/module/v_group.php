<section class="content-header">
	<h3>KPS Group Module</h3>
	<small>Modul Group KPS</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="group" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Group Name</th>
		        <th>Update</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->group_name;?></td>
			        <td><a href="<?php echo site_url()."/group/edit/".$value->id;?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#update" class="update-link">Update</a></td>		        
			      </tr>
		      	<?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New KPS Group</button>
	</div>
</div>

<!--MODAL-->
<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New KPS Group</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/group/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label for="groupName" class="col-sm-3 control-label">Group Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="group_name" placeholder="Ex. Group 1">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD -->

<!-- Modal UPDATE-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    
	  </div>
	  
	</div>
</div>
<!-- Modal UPDATE -->
<!--MODAL-->