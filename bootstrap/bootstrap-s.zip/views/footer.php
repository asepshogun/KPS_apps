</section>      
    </div>    

    <!-- Main Footer -->
    <footer class="main-footer">
      2015 © PT. KPS (Karya Putra Sangkuriang)
    </footer>
  </div>
  <!--wrapper -->

  <script src="<?php echo base_url("bootstrap/plugins/jQuery/jQuery.min.js"); ?>"></script>  
  <script src="<?php echo base_url("bootstrap/js/bootstrap.min.js"); ?>"></script>  
  <script src="<?php echo base_url("bootstrap/dist/js/app.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/slimScroll/jquery.slimscroll.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/datatables/jquery.dataTables.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/datatables/dataTables.bootstrap.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/select2/select2.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/plugins/datepicker/js/bootstrap-datepicker.min.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/js/script.js"); ?>"></script>
  <script src="<?php echo base_url("bootstrap/js/revisiScript.js"); ?>"></script>
   <!-- revisi lable Start-->
  <script src="<?php echo base_url("bootstrap/js/revisiLabelScript.js"); ?>"></script>
 <!-- revisi lable end-->
 <!-- revisi retur 22-15-2016 start-->
  <script src="<?php echo base_url("bootstrap/js/revisiRetur.js"); ?>"></script>
 <!-- revisi retur 22-15-2016 end-->

  
  <script type="text/javascript">
  $(document).ready(function() {
      $('#employees').DataTable();
      $('#customer_cp').DataTable();
      $('#customer_plant').DataTable();
      $('#customer_divisi').DataTable();
      $('#customer_pic').DataTable();
      $('#customer_mc').DataTable();
      $('#customer_supplier').DataTable();
      $('#customer_finance').DataTable();
      $('#customer_account').DataTable();
      $('#customer_ds').DataTable();
      $('#customer_iso').DataTable();      
      $('#departement').DataTable();
      $('#position').DataTable();
      $('#group').DataTable();
      $('#section').DataTable();
      //$('#vehicle').DataTable();
      $('#bankref').DataTable();
      $('#marketing').DataTable();
      $('#user_data').DataTable();
	    $('#BSTHP_RECORD_history').DataTable();
      $('#BSTHP_detail').DataTable();
      $('#BSTHPdetailSub').DataTable();
      //$('#rfq_detail_pp').DataTable();
      //$('#breakdown').DataTable();
      //$('#quotation').DataTable();
      //$('#loi').DataTable();
      //$('#bukti_pesanan').DataTable();
      //$('#marketing_tooling').DataTable();
      $('#ogfg').DataTable();
      $('#ogfg-os').DataTable();
      $('#codp').DataTable();
	  //REVISI LABLE START
   
	  //REVISI LABLE END 
	  //REVISI BSTHP START
      
	  //REVISI BSTHP END
      $('#item-master').DataTable();
      $('#invoice-print').DataTable();
      $('#invoice_detail_no').DataTable();
      $('#history-price').DataTable();
      //$('#dod-confirmation').DataTable();
    
	
	//revisi retur start
		$('#retur_detail_data').DataTable();
	//revisi retur end
	
	//revisi retur 22-15-2016 start
		$('#retur_product_history_induk').DataTable();
		$('#retur_detail_data_history').DataTable();
	//revisi retur 22-15-2016 end
	//revisi sales 23-05-2016
	 	$('#os_pending_return_monitoring').DataTable();
		$('#os_pending_monitoring').DataTable();
		$('#os_monitoring').DataTable();
	
  } );
  </script>
<script type="text/javascript">
$(document).ready(function() {
  $(".select2").select2();
});
</script>

<script>
$(document).ready(function() {
  $(".datepicker").datepicker({
    autoclose: true
  });
});
</script>