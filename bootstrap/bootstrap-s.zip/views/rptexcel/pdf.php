 <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <title>PT KPS</title>    

        <link href="<?php echo base_url("bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/css/style.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/ionicons/css/ionicons.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/select2/select2.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/datatables/dataTables.bootstrap.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/datepicker/css/bootstrap-datepicker3.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url("bootstrap/dist/css/skins/_all-skins.css"); ?>">

    </head>
    <?php 
    if(count($data) < 1){
        echo "data kosong bos";
    }else{
         foreach ($data as $item) {
       
    ?>
        <table font size="10" width="100%" class="table table-bordered" >
                <colgroup>
                <col style="width: 143px">
                <col style="width: 193px">
                <col style="width: 129px">
                <col style="width: 127px">
                <col style="width: 115px">
                <col style="width: 141px">
                <col style="width: 107px">
                <col style="width: 94px">
                <col style="width: 79px">
                </colgroup>
                  <tr>
                    <th colspan="3">PT. Karya Putra Sangkuriang</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                  <tr>
                    <th colspan="3">Sales Departement</th>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td colspan="7"><h3><center><b>REQUEST FOR QUOTATION</b></center></h3></td>
                  </tr>
                  <tr>
                    <td><b>Date</b></td>
                    <td><?=$item->DATE_RFQ;?></td>
                    <td colspan="7"><h5><center>Review &amp; Estimation New Item (Engineering) Click</center></h5></td>
                  </tr>
                  <tr>
                    <td><b>No</b></td>
                    <td><?=$item->NO_RFQ;?></td>
                    <td colspan="7"><h5><center>Breakdown Price Click</center></h5></td>
                  </tr>
                  <tr>
                    <td><b>Rev No</b></td>
                    <td>0</td>
                    <td></td>
                    <td></td>
                    <td><b>Customer Respond</b></td>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Customer Name</b></td>
                    <td><?=$item->COMPANY_NAME;?></td>
                    <td colspan="7"><h5><center>PT. Karya Putra Sangkuriang</center></h5></td>
                  </tr>
                  <tr>
                    <td><b></b>Receiving RFQ Date</td>
                    <td><?=$item->RECEIVING_RFQ_DATE;?></td>
                    <td><b>Made By</b></td>
                    <td></td>
                    <td><b>Checked</b></td>
                    <td></td>
                    <td colspan="3"><b>Approved</b></td>
                  </tr>
                  <tr>
                    <td><b>RFQ Customer Date</b></td>
                    <td><?=$item->RFQ_CUSTOMER_DATE;?></td>
                    <td><?=$item->user_made;?></td>
                    <td></td>
                    <td><?=$item->employee_checked;?></td>
                    <td></td>
                    <td colspan="3"><?=$item->employee_approved;?></td>
                  </tr>
                  <tr>
                    <td><b>RFQ Customer No</b></td>
                    <td><?=$item->RFQ_CUSTOMER_NO;?></td>
                    <td><b>Sales Staff</b></td>
                    <td></td>
                    <td><b>Sales Head</b></td>
                    <td></td>
                    <td colspan="3"><b>Sales &amp; Purchased Manager</b></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>1</b></td>
                    <td><b>Drawing Reff</b></td>
                    <td><b>As per enclosed here in</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td><b>No</b></td>
                    <td><b>Part No</b></td>
                    <td><b>Part Name</b></td>
                    <td><b>QTY</b></td>
                    <td><b>Units</b></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td><?=$item->KPS_RFQ_PART_NO;?></td>
                    <td><?=$item->KPS_RFQ_PART_NAME;?></td>
                    <td><?=$item->KPS_RFQ_PART_QTY;?></td>
                    <td><?=$item->KPS_RFQ_PART_UNIT;?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>2</b></td>
                    <td><b>Production Plan</b></td>
                    <td><b>No</b></td>
                    <td><b>Model</b></td>
                    <td><b>QTY/Unit</b></td>
                    <td><b>QTY/Month</b></td>
                    <td><b>Periode</b></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td><?=$item->MODEL;?></td>
                    <td><?=$item->QTY_UNIT;?></td>
                    <td><?=$item->QTY_MONTH;?></td>
                    <td><?=$item->PERIODE;?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>3</b></td>
                    <td><b>Schedule</b></td>
                    <td><b>No</b></td>
                    <td><b>Model</b></td>
                    <td><b>Sample</b></td>
                    <td><b>PP1</b></td>
                    <td><b>Masspro</b></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td><?=$item->MODEL;?></td>
                    <td><?=$item->SAMPLE_MASSPRO;?></td>
                    <td><?=$item->PP1;?></td>
                    <td><?=$item->MASSPRO;?></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>4</b></td>
                    <td><b>Target Price</b></td>
                    <td rowspan="2"><b>Target Price (Rp)</b></td>
                    <td colspan="2"><center><b>Competitor 1</b></center></td>
                    <td colspan="2"><center><b>Competitor 2</b></center></td>
                    <td colspan="2"><center><b>Competitor 3</b></center></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td><b>Name</b></td>
                    <td><b>Price</b></td>
                    <td><b>Name</b></td>
                    <td><b>Price</b></td>
                    <td><b>Name</b></td>
                    <td><b>Price</b></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td><?=$item->TARGET_PRICE;?></td>
                    <td><?=$item->COMPETITIOR_NAME;?></td>
                    <td><?=$item->COMPETITIOR_PRICE;?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>5</b></td>
                    <td><b>Currency</b></td>
                    <td><b>No</b></td>
                    <td colspan="4"><center><b>Currency</b></center></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td><?=$item->CURRENCY_NAME;?></td>
                    <td>Rp</td>
                    <td><?=$item->TO_IDR;?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>6</b></td>
                    <td><b>Tooling Cost</b></td>
                    <td><?=$item->TOOLING_COST_RFQ;?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>7</b></td>
                    <td><b>Part Status</b></td>
                    <td>
                        <?php 
                        $no = $item->TOOLING_COST_RFQ;
                        if( $no = 1){
                            echo "New Project";
                        }elseif ($no = 2) {
                            echo "Localization";
                        }else{
                            echo "Second Supplier";
                        }?>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>8</b></td>
                    <td><b>RFQ Letters</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>9</b></td>
                    <td><b>Drawing</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>10</b></td>
                    <td><b>Others</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </table>
                <?php 
                    }
                }
                ?>
</html>