 <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <title>PT KPS</title>    

        <link href="<?php echo base_url("bootstrap/css/bootstrap.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/css/style.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/fontawesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/ionicons/css/ionicons.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/select2/select2.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/datatables/dataTables.bootstrap.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/plugins/datepicker/css/bootstrap-datepicker3.min.css"); ?>" rel="stylesheet">
        <link href="<?php echo base_url("bootstrap/dist/css/AdminLTE.min.css"); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url("bootstrap/dist/css/skins/_all-skins.css"); ?>">

    </head>
    <?php 
    if(count($data) < 1){
        echo "data kosong bos";
    }else{
         foreach ($data as $item) {
       
    ?>
        <table font size="10" width="100%" class="table table-bordered" >
                
                  <tr>
                    <th colspan="7"><h2><center>QUOTATION</center></h2></th>
                  </tr>
                  <tr>
                    <td><b>Date</b></td>
                    <td><?=$item->DATE_QUO;?></td>
                    <td><b>Customer Name</b></td>
                    <td><?=$item->COMPANY_NAME;?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>No/Rev no</b></td>
                    <td><?=$item->NO_QUO;?>/1</td>
                    <td rowspan="2"><b>Address</b></td>
                    <td rowspan="2"></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Valid Date From</b></td>
                    <td><?=$item->VALID_DATE_FROM;?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Valid Date Until</b></td>
                    <td><?=$item->VALID_DATE_UNTIL;?></td>
                    <td><b>Attention</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Currency</b></td>
                    <td><?=$item->CURRENCY_NAME;?></td>
                    <td><b>Phone/Fax</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Breakdown No</b></td>
                    <td><?=$item->NO_BREAK;?></td>
                    <td><b>Mail</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td colspan="2"><b>Dear Sirs/Madam</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td colspan="3"><b>We hereby wish to submit our offers as follows :</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>No</b></td>
                    <td><b>Part Name</b></td>
                    <td><b>Part No</b></td>
                    <td><b>Model</b></td>
                    <td><b>Price</b></td>
                    <td><b>Unit</b></td>
                    <td><b>Note</b></td>
                  </tr>
                  <tr>
                    <td>1</td>
                    <td><?=$item->KPS_RFQ_PART_NAME;?></td>
                    <td><?=$item->KPS_RFQ_PART_NO;?></td>
                    <td><?=$item->MODEL;?></td>
                    <td><?=$item->TOTAL_BREAKDOWN;?></td>
                    <td><?=$item->QTY_UNIT;?></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Note :</b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>1</td>
                    <td>Price Exclude Tax 10%</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>Tooling Depreciation</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>Tooling Payment</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>Delivery Place</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td colspan="7"><b>We hope the above quotation will meet your requirement and we are looking forward to hearing from you very soon. Thank you for your kind attention and good cooperation.</b></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Customer</b></td>
                    <td></td>
                    <td></td>
                    <td><center><b>Your Sincerely</b></center></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td><b>Approved</b></td>
                    <td></td>
                    <td colspan="3"><center><b>PT. Karya Putra Sangkuriang</b></center></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td><b>Made By</b></td>
                    <td><b>Checked</b></td>
                    <td><b>Approved</b></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <tr>
                    <td></td>
                    <td></td>
                    <td>Sales Staff</td>
                    <td>Sales Head</td>
                    <td>Sales &amp; Purchased Manager</td>
                    <td></td>
                    <td></td>
                  </tr>
                </table>
                <?php 
                    }
                }
                ?>
</html>