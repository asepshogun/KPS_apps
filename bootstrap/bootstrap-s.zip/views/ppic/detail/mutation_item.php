<section class="content-header">
	<h3>Mutation Item Data Detail</h3>
	<small>Detail Data Mutation Item</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="QTY" disabled>
			          </div>
			        </div>
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Mutation New Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_NEW_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Item</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_CODE_ITEM" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_PART_NAME" disabled>
			          </div>
			        </div>	
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_PART_NO" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_MODEL" disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MUTATION_CUSTOMER_NAME" disabled>
			          </div>
			        </div>		        
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Barcode Date</th>
		        <th>Barcode No</th>
		        <th>Barcode QTY</th>
		        <th>Barcode Units</th>        
		        <th>Remaining QTY</th>
		        <th>Remaining Units</th>		        
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->BARCODE_DATE;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_QTY;?></td>
			        <td><?php echo $value->BARCODE_UNIT;?></td>			        
			        <td><?php echo $value->REMAINING_QTY;?></td>
			        <td><?php echo $value->REMAINING_UNITS;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Mutation Item Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/mutation_item/add";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Barcode Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="BARCODE_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_NO" placeholder="barcode no">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_QTY" placeholder="barcode qty">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode Units</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_UNIT" placeholder="barcode units">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Remaining QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REMAINING_QTY" placeholder="remaining qty">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Remaining Units</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REMAINING_UNITS" placeholder="remaining units">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Mutation Item Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/mutation_item/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Barcode Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="BARCODE_DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_NO">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_QTY">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Barcode Units</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="BARCODE_UNIT">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Remaining QTY</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REMAINING_QTY">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Remaining Units</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REMAINING_UNITS">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->