<section class="content-header">
	<h3>Mutation Item Detail Data</h3>
	<small>Mutasi Item Detail</small>
</section>
				<?php
				$query2 = mysql_query("select * from kps_loi 
						JOIN `kps_rfq` ON `kps_loi`.`KPS_RFQ_ID_LOI`=`kps_rfq`.`KPS_RFQ_ID` 
						JOIN `kps_customer` ON `kps_rfq`.`KPS_CUSTOMER_ID_RFQ`=`kps_customer`.`KPS_CUSTOMER_ID` 
						where KPS_LOI_ID='".$dataOnly->KPS_LOI_ID_MUTATION."'");
			        	$data2 = mysql_fetch_array($query2);
				?>
				<form method="POST" class="form-horizontal">
				<div class="col-lg-6">
				<h4>From</h4>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Date</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->DATE?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->NO?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Code Item</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data2['LOI_CODE_ITEM'];?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Part Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data2['LOI_PART_NAME'];?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Part No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data2['LOI_PART_NO'];?>" placeholder="barcode">
				  </div>
				</div>	
				<div class="form-group">
				  <label class="col-lg-3 control-label">Model</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data2['LOI_MODEL'];?>" placeholder="barcode">
				  </div>
				</div>	
				<div class="form-group">
				  <label class="col-lg-3 control-label">Customer Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data2['COMPANY_NAME'];?>" placeholder="barcode">
				  </div>
				</div>	
				<div class="form-group">
				  <label class="col-lg-3 control-label">QTY</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $dataOnly->QTY;?>" placeholder="barcode">
				  </div>
				</div>
				</div>
				<div class="col-lg-6">
				<h4>To</h4>
				<?php 
				$query3 = mysql_query("select * from kps_loi 
						JOIN `kps_rfq` ON `kps_loi`.`KPS_RFQ_ID_LOI`=`kps_rfq`.`KPS_RFQ_ID` 
						JOIN `kps_customer` ON `kps_rfq`.`KPS_CUSTOMER_ID_RFQ`=`kps_customer`.`KPS_CUSTOMER_ID` 
						where KPS_LOI_ID='".$dataOnly->MUTATION_NEW_ITEM_LOI_ID."'");
			        	$data3 = mysql_fetch_array($query3);
				?>
				<?php
				// print_r($data3['KPS_LOI_ID']);
				?>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Code Item</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data3['LOI_CODE_ITEM'];?>" placeholder="barcode">
				  </div>
				</div><div class="form-group">
				  <label class="col-lg-3 control-label">Part Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data3['LOI_PART_NAME'];?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">Part No</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data3['LOI_PART_NO'];?>" placeholder="barcode">
				  </div>
				</div>	<div class="form-group">
				  <label class="col-lg-3 control-label">Model</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data3['LOI_MODEL'];?>" placeholder="barcode">
				  </div>
				</div>	
				<div class="form-group">
				  <label class="col-lg-3 control-label">Customer Name</label>
				  <div class="col-lg-9">
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $data3['COMPANY_NAME'];?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				  <label class="col-lg-3 control-label">QTY Remaining</label>
				  <div class="col-lg-9">
					<?php
						$dataVer=count($detail_ver);
						$totalVer=$dataVer*$detail_ver[0]->QUANTITY;
					?>
					<input type="text" class="form-control" name="bsthp_barcode_code" disabled id="bsthp_barcode_code" value="<?php echo $totalVer;?>" placeholder="barcode">
				  </div>
				</div>
				<div class="form-group">
				<a href="<?php echo site_url()."/mutation/generateOut/".$dataOnly->KPS_MUTATION_ITEM_ID ."/". $dataOnly->DATE;?>" class="btn btn-primary btn-sm <?php if($dataOnly->STATUS_MT_OFG==1){
					echo "disabled";
					}else{
						echo "";
					}?>">Generate Out Going</a>
					<a href="<?php echo site_url()."/mutation/generateOutDet/".$dataOnly->KPS_MUTATION_ITEM_ID;?>" class="btn btn-primary btn-sm <?php if($dataOnly->STATUS_MT_OFG==0 || $dataOnly->STATUS_MT_OFGDET==1){
					echo "disabled";
					}else{
						echo "";
					}?>">Generate Out Going Detail</a>
					<a href="<?php echo site_url()."/mutation/generateBarcode/".$dataOnly->KPS_MUTATION_ITEM_ID ."/". $data3['KPS_LOI_ID'] ."/".$totalVer;?>" class="btn btn-primary btn-sm <?php if($dataOnly->STATUS_MT_OFG==0 || $dataOnly->STATUS_MT_OFGDET==0 || $dataOnly->STATUS_MT_OFG_VER==1 || $dataOnly->QTY>$totalVer){
					echo "disabled";
					}else{
						echo "";
					}?>">Generate Barcode</a>	
					<a target="_blank" href="<?php echo site_url() ?>/mutation/prints/<?php echo $dataOnly->KPS_MUTATION_ITEM_ID; ?>" class="btn btn-primary btn-sm <?php if($dataOnly->STATUS_MT_OFG==0 || $dataOnly->STATUS_MT_OFGDET==0 || $dataOnly->STATUS_MT_OFG_VER==0 || $dataOnly->QTY>$totalVer){
					echo "disabled";
					}else{
						echo "";
					}?>">Print Barcode</a>
				</div>
				</div>	      	
			</form>	       
<div class="box-body">
<?php if($dataOnly->STATUS_MT_OFG==1 && $dataOnly->STATUS_MT_OFGDET==1 && $dataOnly->STATUS_MT_OFG_VER==0 && $dataOnly->OUTGOING_DETAIL_QTY_VERIFICATION<$dataOnly->QTY && $dataOnly->QTY>$totalVer){?>			
    <div class="col-lg-12">
    	<div class="box box-success box-solid">
            <div class="box-header with-border" id="panel-head">
              <h4 class="box-title" id="titleDetail">Scan Barcode Mutasi Item</h4>			             
              <button type="button" class="btn btn-box-tool pull-right" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div>
			 <div class="box-body">
				<?php if($pesan){
					echo "<label> <font color=red >". $pesan ." </font></label>";				
				}?>
				<form action="<?php echo site_url()."/mutation/addVerification/". $dataOnly->KPS_OUTGOING_FINISHED_GOOD_ID;?>" method="POST" class="form-horizontal">
						<div class="form-group">
						  <label class="col-lg-3 control-label">Barcode</label>
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="no_barcode_item" id="no_barcode_item" placeholder="Barcode">
						  </div>
						</div>
						<div class="form-group" style="display:none"> 
						  <div class="col-lg-9">
							<input type="text" class="form-control" name="KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER" id="KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID_VER" value="<?php echo $dataOnly->KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID ?>" placeholder="ID OGFG D">
							<input type="text" class="form-control" name="LOI_idByVER" id="LOI_idByVER" value="<?php echo $dataOnly->KPS_LOI_ID_MUTATION ?>" placeholder="LOI ID">
							<input type="text" class="form-control" name="ID_Mutation" value="<?php echo $dataOnly->KPS_MUTATION_ITEM_ID ?>" placeholder="LOI ID">
						  </div>
						</div>
						<div class="form-group">
							<input type="submit" class="btn bg-olive btn-flat pull-left" value="Save Data" />
							<input type="reset" class="btn btn-danger btn-flat pull-right" value="Clear Form " />
						</div>
				</form>
			</div>
		</div>
	</div>
	<?php } ?>
</div>
<?php 
	// $hallo="CODEDARICLIENT20160302332";
	// $hallo2 = substr($hallo, 0, -3);
	// $hallo3 = substr($hallo,-3);
	// echo $hallo2 . "</br>";
	// echo abs($hallo3);
?>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body overflow">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		         <th>No</th>
				<th>Code Product</th>
				<th>Part No</th>
				<th>Part Name</th>
				<th>Model</th>
				<th>Code Barcode</th>
				<th>Barcode Pic</th>
				<th>QTY ITem</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=1; foreach ($detail_ver as $value) { ?>
		      <tr>
		        <td><?php echo $no++;?></td>
		        <td><?php echo $value->LOI_CODE_ITEM;?></td>
		        <td><?php echo $value->LOI_PART_NO;?></td>
		        <td><?php echo $value->LOI_PART_NAME;?></td> 
		        <td><?php echo $value->LOI_MODEL;?></td>
		        <td><?php echo $value->BARCODE_NO;?></td>
				<td>	
				 <img alt="" src="<?php echo site_url(); ?>/label_information/generateBarcode/code39?text=<?php echo $value->BARCODE_NO; ?>" />
				</td>
				<td><?php echo $value->LOI_STRANDART_PACKING;?></td>
		      </tr>
	      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

</div>
</section>

<!--MODAL-->
<!-- Modal ADD-->

<!-- Modal ADD -->

<!-- Modal UPDATE-->

<!-- Modal UPDATE -->
<!--MODAL-->	