<section class="content-header">
	<h3>Delivery Quota Data Detail</h3>
	<small>Detail Data Delivery Quota</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VEHICLE_NAME" value='<?php echo $data->VEHICLE_NAME?>' disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Vehicle No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="VEHICLE_NO" value='<?php echo $data->VEHICLE_NO?>' disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Standart</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_STANDARD" value='<?php echo $data->TOTAL_STANDARD?>' disabled>
			          </div>
			        </div>
			        	        
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Total Actual</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_ACTUAL" value='<?php echo $data->TOTAL_ACTUAL?>' disabled>
			          </div>
			        </div>		
					<div class="form-group">
			          <label class="col-sm-3 control-label">Total Profit / (loss)</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_PROFIT" value='<?php echo $data->TOTAL_PROFIT?>' disabled>
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Total Volume (%)</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="TOTAL_VOLUME" value='<?php echo $data->TOTAL_VOLUME?>' disabled>
			          </div>
			        </div>
			               
				</form>
			</div>

		</div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="delivery_quota_det" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>Standart</th>
		        <th>Actual</th>
		        <th>Profit / (loss)</th>        
		        <th>Volume (%)</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($datax as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DELIVERY_DATE;?></td>
			        <?php 
			        	if($value->PLANT1_LOCAL_JABOTABEK == "Jabotabek"){
			        		?> 
			        		<td><?php echo $value->COD_JABODETABEK;?></td>			        
			       		
			        		<?php
			        	}else{?>
			        		<td><?php echo $value->COD_LOCAL;?></td>			        
			        		
			        		<?php
			        	}
			        ?>
			        <td><?php echo $value->TOTALS;?></td>
			        <?php 
			        	if($value->PLANT1_LOCAL_JABOTABEK == "Jabotabek"){
			        		?> 
			        		<td><?php echo $value->COD_JABODETABEK-$value->TOTALS;?></td>			        
			       		
			        		<?php
			        	}else{?>
			        		<td><?php echo $value->COD_LOCAL-$value->TOTALS;?></td>			        
			        		
			        		<?php
			        	}
			        ?>
			        <td></td>
			        
			        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>