<section class="content-header">
	<h3>Delivery Status Data Detail</h3>
	<small>Detail Data Delivery Status</small>
</section>
<?php //$totalx=0; var_dump($pending);?>
<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="panel-body">

			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Bukti Pesanan Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="DATE_BP" disabled value="<?php echo $data->DATE_BP ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Bukti Pesanan No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="REV_NO_BP" disabled value="<?php echo $data->REV_NO_BP ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">PO Date</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PO_OS_DATE" disabled value="<?php echo $data->PO_OS_DATE_FROM_CUSTOMER ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">PO No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PO_OS_NO" disabled  value="<?php echo $data->PO_OS_NO_FROM_CUSTOMER ?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Customer Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CUSTOMER_NAME" disabled value="<?php echo $data->COMPANY_NAME?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Code Product</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="CODE_PRODUCT" disabled value="<?php echo $data->LOI_CODE_ITEM?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part Name</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NAME" disabled value="<?php echo $data->LOI_PART_NAME?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Part No</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PART_NO" disabled value="<?php echo $data->LOI_PART_NO?>">
			          </div>
			        </div>	
				</form>
			</div>
			<div class="col-lg-6">
				<form class="form-horizontal">
					<div class="form-group">
			          <label class="col-sm-3 control-label">Model</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="MODEL" disabled value="<?php echo $data->LOI_MODEL?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY PO</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="QUANTITY_PO" disabled value="<?php echo $data->QUANTITY?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY Actual Delivery</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="QUANTITY_ACTUAL_DELIVERY" disabled value="<?php echo $data->QTY_DELIVERY_EXECUTION?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY Remaining</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="QUANTITY_REMAINING" disabled value="<?php echo $data->QTY_OUTSTANDING_PO_OS - $data->QTY_DELIVERY_EXECUTION?>">
			          </div>
			        </div>		
			        <div class="form-group">
			          <label class="col-sm-3 control-label">QTY Pending</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="PENDING_QUANTITY" disabled value="<?php echo $pending->pending;?>">
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Status</label>
			          <div class="col-sm-9">
			          	<?php 
			          		if($pending->pending != 0){
			          			?><input type="text" class="form-control" name="STATUS" disabled value="OPEN"><?php
			          		}else{
			          			?><input type="text" class="form-control" name="STATUS" disabled value="CLOSED"><?php
			          		}
			          	?>
			            
			          </div>
			        </div>
			        <div class="form-group">
			          <label class="col-sm-3 control-label">Unit</label>
			          <div class="col-sm-9">
			            <input type="text" class="form-control" name="UNIT" disabled value="<?php echo $data->unit?>">
			          </div>
			        </div>		        
				</form>
			</div>
			
		</div>
	</div>
<section class="content"> 
	<div class="box">
		<div class="box-body">
			<div class="box-body">
				<!--TABLE-->
				<table id="delivery_status_detail" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
					<thead>
					  <tr>
						<th>No</th>
						<th>Delivery Date</th>
						<th>Plan</th>
						<th>DN</th>
						<th>On The Way</th>        
						<th>Actual</th>
						<th>SJ No</th>		        
						<th>Balance</th>
						<th>Pending</th>
						<th>Retur</th>
						<th>Status</th>
					  </tr>
					</thead>
					<tbody>
						<?php $totalin=0;$retur=0;$totalx=0; $no=0; foreach ($detail as $value) { $no++; ?>
						  <tr>
							<td><?php echo $no;?></td>
							<td><?php echo $value->DELIVERY_PLAN;?></td>
							<td><?php echo $value->QUANTITY_DELIVERY;?></td>
							<td><?php echo $value->KPS_OS_NO;?></td>
							<td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>	
							<td>
								<?php 
								if($value->RECEIVED_DECISION == 'OK'){
									echo $value->QTY_DELIVERY_EXECUTION;		
								}else{
									echo "";
								}
								?>
							</td>	
							<td><?php echo $value->NO_DO;?></td>
							<td><?php 
								$total = $value->QTY_DELIVERY_EXECUTION - $value->QUANTITY_DELIVERY;
								echo $total;
								?></td>
							<td><?php 
								//echo $total;
								$totalx+=$total;	
								echo $totalx;						
								?>
							</td>
							<td>
								<?php 
								if($value->RECEIVED_DECISION == 'NG' OR NULL){
									echo $value->QTY_DELIVERY_EXECUTION;		
								}else{
									echo "";
								}
								?>
							</td>
							<td>
								<?php 
								if($value->RECEIVED_DECISION == 'NG' OR NULL){
									$retur += $value->QTY_DELIVERY_EXECUTION;		
								}
								$totalin = $totalx + $retur;
								if($totalin !=0){
									echo "OPEN";
								}else{
									echo "CLOSED";
								}
								?>
							</td>
						  </tr>
					  <?php } ?>
					</tbody>
				</table>
				<!--TABLE-->
			</div>
		</div>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delvery Status Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_status/add";?>" method="POST" class="form-horizontal">	    		
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">DN</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_DELIVERY_STATUS_DETAIL_DN" placeholder="dn">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Delivery Status Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/stock_opname/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">DN</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="KPS_DELIVERY_STATUS_DETAIL_DN">
		          </div>
		        </div>
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->