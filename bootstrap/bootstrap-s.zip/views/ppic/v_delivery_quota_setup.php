<section class="content-header">
	<h3>Delivery Quota Setup Data</h3>
	<small>Data Delivery Quota Setup</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
	    <div class="row">
	    	<div class="col-lg-12">
	    		<div class="form-group">
		          <label class="col-sm-2 control-label">Filter By Date</label>
		          <div class="col-sm-3">
		            <input type="text" class="form-control datepicker" name="SETUP_DATE" value="Default by Today" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
	    	</div>
	    </div>
	</div>

	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Rev No</th>        
		        <th>Vehicle Name</th>
		        <th>Vehicle No</th>		        
		        <th>Supplier Name</th>
		        <th>Purchase Date</th>
		        <th>Cost of Delivery Local</th>
		        <th>Cost of Delivery Jabotabek</th>
		        <th>Volume Box</th>
		        <th>Photos of Truck</th>
		        <th>NOTE</th>
		        <th>Update</th>
		        <th>Delete</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
			        <td><?php echo $value->REV_NO;?></td>			        
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>		        
			        <td><?php echo $value->SUPPLIER_NAME;?></td>
			        <td><?php echo $value->PURCHASE_DATE;?></td>
			        <td><?php echo $value->COST_DELIVERY_LOCAL;?></td>
			        <td><?php echo $value->COST_DELIVERY_JABOTABEK;?></td>
			        <td><?php echo $value->VOLUME_BOX;?></td>
			        <td><?php echo $value->PHOTOS_OF_TRUCK;?></td>
			        <td><?php echo $value->NOTE;?></td>
			        <td><a href="" url="<?php echo site_url()."/delivery_quota_setup/update/".$value->KPS_DELIVERY_QUOTA_SETUP_ID;?>">Update</a></td>	        
			        <td><a href="" url="<?php echo site_url()."/delivery_quota_setup/delete/".$value->KPS_DELIVERY_QUOTA_SETUP_ID;?>">Delete</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button type="button" class="btn btn-danger pull-right btn-flat" data-toggle="modal" data-target="#add">Add New Delivery Quota Setup Data</button>
	</div>
</div>


<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Form New Delivery Quota Setup Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_quota_setup/add";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="NO" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REV_NO" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Vehicle Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NAME" placeholder="delivery area">
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Vehicle No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NO" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Supplier Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SUPPLIER_NAME" placeholder="delivery area">
		          </div>
		        </div> 
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Purchase Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PURCHASE_DATE" placeholder="Pick Date" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Cost of Delivery Local</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="COST_DELIVERY_LOCAL" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Cost of Delivery Jabotabek</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="COST_DELIVERY_JABOTABEK" placeholder="delivery area">
		          </div>
		        </div> 
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Volume Box</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VOLUME_BOX" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Photos of Truck</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="PHOTOS_OF_TRUCK" placeholder="delivery area">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NOTE" placeholder="delivery area">
		          </div>
		        </div>  		
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Delivery Quota Setup Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/delivery_quota_setup/edit";?>" method="POST" class="form-horizontal">
	    		<div class="form-group">
		          <label class="col-sm-3 control-label">Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="NO">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Rev No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="REV_NO">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Vehicle Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NAME">
		          </div>
		        </div>	
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Vehicle No</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VEHICLE_NO">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Supplier Name</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="SUPPLIER_NAME">
		          </div>
		        </div> 
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Purchase Date</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control datepicker" name="PURCHASE_DATE" readonly="readonly">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Cost of Delivery Local</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="COST_DELIVERY_LOCAL">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Cost of Delivery Jabotabek</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="COST_DELIVERY_JABOTABEK">
		          </div>
		        </div> 
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Volume Box</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="VOLUME_BOX">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Photos of Truck</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="PHOTOS_OF_TRUCK">
		          </div>
		        </div>
		        <div class="form-group">
		          <label class="col-sm-3 control-label">Note</label>
		          <div class="col-sm-9">
		            <input type="text" class="form-control" name="NOTE">
		          </div>
		        </div>	    		
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->
