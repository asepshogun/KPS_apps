
<section class="content-header">
	<h3>Delivery Status Data</h3>
	<small>Data Delivery Status</small>
</section>
<?php  // var_dump($session);?>
<!-- Main content -->

<section class="content"> 
<div class="box">
	<div class="box-body">
		<div class="box-body">
			<!--TABLE-->
			<table id="delivery_status" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
				<thead>
				  <tr>
					<th rowspan="2">No</th>
					<th colspan="2"><center>Bukti Pesanan</center></th>
					<th colspan="2"><center>PO</center> </th>
					<th rowspan="2">Customer Name</th>
					<th rowspan="2">Code Product</th>
					<th rowspan="2">Part Name</th>        
					<th rowspan="2">Part No</th>
					<th rowspan="2">Model</th>		        
					<th colspan="3"><center>Quantity</center> </th>
					<th rowspan="2">Unit</th>
					<th rowspan="2">Detail</th>
				  </tr>
				  <tr>
				  	<th>Date</th>
				  	<th>No</th>
				  	<th>Date</th>
				  	<th>No</th>
				  	<th>PO</th>
				  	<th>Actual Delivery</th>
				  	<th>Remaining</th>
				  </tr>
				</thead>
				<tbody>
					<?php $no=0; foreach ($data as $value) { $no++; ?>
					  <tr>
						<td><?php echo $no;?></td>
						<td><?php echo $value->DATE_BP;?></td>
						<td><?php echo $value->REV_NO_BP;?></td>
						<td><?php echo $value->PO_OS_DATE_FROM_CUSTOMER;?></td>
						<td><?php echo $value->PO_OS_NO_FROM_CUSTOMER;?></td>
						<td><?php echo $value->COMPANY_NAME;?></td>
						<td><?php echo $value->LOI_CODE_ITEM;?></td>
						<td><?php echo $value->LOI_PART_NAME;?></td>			        
						<td><?php echo $value->LOI_PART_NO;?></td>
						<td><?php echo $value->LOI_MODEL;?></td>	
						<td><?php echo $value->QTY_OUTSTANDING_PO_OS;?></td>
						<td><?php echo $value->QTY_DELIVERY_EXECUTION;?></td>
						<td><?php echo $value->QTY_OUTSTANDING_PO_OS - $value->QTY_DELIVERY_EXECUTION;?></td>	        
						
						<?php 
						//print_r($dat);
						//print_r($data);
						//echo $value->KPS_OUTGOING_FINISHED_GOOD_ID;
						//$getBP = $this->db->query("SELECT * FROM kps_outgoing_finished_good_detail JOIN kps_delivery_order_confirm ON kps_delivery_order_confirm.OUTGOING_DETAIL=kps_outgoing_finished_good_detail.KPS_OUTGOING_FINISHED_GOOD_DETAIL_ID	WHERE kps_delivery_order_confirm.RECEIVED_DECISION = 'OK' and KPS_OUTGOING_FINISHED_GOOD_ID_D = '".$value->KPS_OUTGOING_FINISHED_GOOD_ID."'")->result();
							//echo var_dump($getBP);
						//	foreach ($getBP as $valuex) {
						//		$x = 0;
						//		if($valuex->KPS_OUTGOING_FINISHED_GOOD_ID_D == $value->KPS_OUTGOING_FINISHED_GOOD_ID){
									?>
									
									<?php
						//		}
									
						//	}
						?>
						<td><?php echo $value->unit;?></td>
						<td><a href="<?php echo site_url()."/delivery_status/detail/".$value->KPS_BUKTI_PESANAN_DETAIL_ID;?>">Detail</a></td>	        
					  </tr>
				  <?php } ?>
				</tbody>
			</table>
			<!--TABLE-->
			</div>
		</div>
	</div>
	</div>
