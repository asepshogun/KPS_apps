<section class="content-header">
	<h3>Mutation Item Data</h3>
	<small>Data Mutation Item</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
	<div class="box-body overflow">
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Date</th>
		        <th>No</th>
		        <th>Code Item</th>
		        <th>Part Name</th>        
		        <th>Part No</th>
		        <th>Model</th>
		        <th>Customer Name</th>
		        <th>QTY</th>
		        <th>></th>
		        <th>Code Item</th>
		        <th>Part Name</th>
		        <th>Part No</th>
		        <th>Model</th>
		        <th>Customer Name</th>
		        <th>Total QTY Barcode</th>
		        <th>Total QTY Remaining</th>
		        <th>Status</th>
		        <th>Update</th>
		        <th>Delete</th>
		        <th>Lock</th>
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->DATE;?></td>
			        <td><?php echo $value->NO;?></td>
					<td><?php 
			        	$query2 = mysql_query("select * from kps_loi 
						JOIN `kps_rfq` ON `kps_loi`.`KPS_RFQ_ID_LOI`=`kps_rfq`.`KPS_RFQ_ID` 
						JOIN `kps_customer` ON `kps_rfq`.`KPS_CUSTOMER_ID_RFQ`=`kps_customer`.`KPS_CUSTOMER_ID` 
						where KPS_LOI_ID='".$value->KPS_LOI_ID_MUTATION."'");
			        	$data2 = mysql_fetch_array($query2);
			        	echo $data2['LOI_CODE_ITEM'];
			        ?></td>
					<td><?php echo $data2['LOI_PART_NAME'];?></td>
					<td><?php echo $data2['LOI_PART_NO'];?></td>
					<td><?php echo $data2['LOI_MODEL'];?></td>
					<td><?php echo $data2['COMPANY_NAME'];?></td>
			        <td><?php echo $value->QTY;?></td>
			        <td>></td>
					<td><?php 
			        	$query3 = mysql_query("select * from kps_loi 
						JOIN `kps_rfq` ON `kps_loi`.`KPS_RFQ_ID_LOI`=`kps_rfq`.`KPS_RFQ_ID` 
						JOIN `kps_customer` ON `kps_rfq`.`KPS_CUSTOMER_ID_RFQ`=`kps_customer`.`KPS_CUSTOMER_ID` 
						where KPS_LOI_ID='".$value->MUTATION_NEW_ITEM_LOI_ID."'");
			        	$data3 = mysql_fetch_array($query3);
			        	echo $data3['LOI_CODE_ITEM'];
			        ?></td>
			       <td><?php echo $data3['LOI_PART_NAME'];?></td>
					<td><?php echo $data3['LOI_PART_NO'];?></td>
					<td><?php echo $data3['LOI_MODEL'];?></td>
					<td><?php echo $data3['COMPANY_NAME'];?></td>
					<td>0</td>
					<td>0</td>
					<td>0</td>
					<?php 
					if(empty($value->KPS_STATUS_LOCK)){
					?>
					<style>
						.mutation_detail{
						   pointer-events: none;
						   cursor: default;
						   color: grey;
						}
					</style>	
					<?php
					}else{
					?>
					<style>
						.mutation_change{
						   pointer-events: none;
						   cursor: default;
						   color: grey;
						}
					</style>	
					<?php
					}
					?>
			        <td><a class="mutation_change" href="" url="<?php echo site_url()."/mutation/update/".$value->KPS_MUTATION_ITEM_ID;?>">Update</a></td>
			        <td><a class="mutation_change" href="" url="<?php echo site_url()."/mutation/delete/".$value->KPS_MUTATION_ITEM_ID;?>">Delete</a></td>
			        <td><a class="mutation_change" href="<?php echo site_url()."/mutation/lock/".$value->KPS_MUTATION_ITEM_ID;?>">LOCK</a></td>
			        <td><a  class="mutation_detail" href="<?php echo site_url()."/mutation/detail/".$value->KPS_MUTATION_ITEM_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
	</div>
		<!--TABLE-->
	</div>

	<div class="box-body">
		<button href="" url="<?php echo site_url()."/mutation/add"?>" type="button" class="btn btn-danger pull-right btn-flat update-link" data-toggle="modal" data-target="#add">Add New Mutation Item Data</button>
	</div>
</div>

<!-- Modal ADD-->
<div class="modal fade" id="add" role="dialog">
	<div class="modal-dialog">
	  <div class="modal-content">
	    
	  </div>
	</div>
</div>
<!-- Modal ADD-->

<!-- Modal Update-->
<div class="modal fade" id="update" role="dialog">
	<div class="modal-dialog">

	  <div class="modal-content">
	    <div class="modal-header">
	      <button type="button" class="close" data-dismiss="modal">&times;</button>
	      <h4 class="modal-title">Mutation Item Data</h4>
	    </div>
	    <div class="modal-body">
	    	<form action="<?php echo site_url()."/mutation_item/edit";?>" method="POST" class="form-horizontal">	    		
		        <div class="form-group">		          
		          <div class="col-sm-12">
		            <button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		          </div>
		        </div>			      	
	        </form>	        	    			      		        
	    </div>
	  </div>
	  
	</div>
</div>
<!-- Modal Update-->