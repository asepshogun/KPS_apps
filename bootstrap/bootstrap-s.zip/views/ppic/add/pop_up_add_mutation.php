<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal">&times;</button>
  <h4 class="modal-title">New Mutation</h4>
</div>
<div class="modal-body">
	<form action="<?php echo site_url()."/mutation/add";?>"  enctype="multipart/form-data" method="POST" class="form-horizontal">	    		
		<div class="form-group">
		  <label class="col-lg-3 control-label">Customer</label>
		  <div class="col-lg-9">
			<select class="form-control select2" style="width: 100%;" id="mutationcustomer" url="<?php echo site_url() ?>/mutation/loadloi" name="KPS_CUSTOMER_LIST_ID">					  
				<option>-- Select Customer --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Code Item</label>
		  <div class="col-lg-9">
			<select class="form-control select2" id="mutationloi" name="KPS_LOI_ID_MUTATION">					  
				<option>-- Select Code Item --</option>
							  
			</select>
		  </div>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Qty</label>
		  <div class="col-lg-9">
			<input type="number" class="form-control" name="QTY" id="QTY" placeholder="Qty">
		  </div>
		</div>
		<div>
			<h4>Akan Di Mutasikan Ke :</h4>
		</div>
		<div class="form-group">
		  <label class="col-lg-3 control-label">Customer</label>
		  <div class="col-lg-9">
			<select class="form-control select2" style="width: 100%;" id="mutationcustomer2" url="<?php echo site_url() ?>/mutation/loadProduct" name="KPS_CUSTOMER_LIST_ID2">					  
				<option>-- Select Customer --</option>
				<?php foreach ($dataCust as $value) { ?>
				<option value="<?php echo $value->KPS_CUSTOMER_ID;?>"><?php echo $value->COMPANY_NAME;?></option>
				<?php } ?>					  
			</select>
		  </div>
		</div>
		<div class="form-group">
			<?php echo form_error('KPS_LOI_ID_label'); ?>
		  <label class="col-lg-3 control-label">Code Item</label>
		  <div class="col-lg-9">
			<select class="form-control select2"  id="mutationloi2" name="MUTATION_NEW_ITEM_LOI_ID">					  
				<option>-- Select Code Item --</option>
							  
			</select>
		  </div>
		</div>
		<div class="form-group">		          
		  <div class="col-sm-12">
			<button type="submit" class="btn btn-danger btn-flat pull-right">Save Data</button>
		  </div>
		</div>			      	
	</form>	        	    			      		        
</div>