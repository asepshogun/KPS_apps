<section class="content-header">
	<h3>Mutation Item Monitoring</h3>
	<small>Mutation Item Monitoring</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	<div class="box-body">
		<!--TABLE-->
		<table id="data" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Mutation Date</th>
		        <th>Mutation No</th>
		        <th>Mutation Code Item</th>
		        <th>Mutation Part Name</th>
		        <th>Mutation Part No</th>
		        <th>Mutation Model</th>
		        <th>Mutation Customer Name</th>
		        <th>Barcode Date</th>
		        <th>Barcode No</th>
		        <th>Barcode QTY</th>
		        <th>Barcode Units</th>
		        <th>Mutation New Item Code Item</th>
		        <th>Mutation New Item Part Name</th>
		        <th>Mutation New Item Part No</th>
		        <th>Mutation New Item Model</th>
		        <th>Mutation New Item Customer Name</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->MUTATION_DATE;?></td>
			        <td><?php echo $value->MUTATION_NO;?></td>
			        <td><?php echo $value->MUTATION_CODE_ITEM;?></td>
			        <td><?php echo $value->MUTATION_PART_NAME;?></td>
			        <td><?php echo $value->MUTATION_PART_NO;?></td>
			        <td><?php echo $value->MUTATION_MODEL;?></td>
			        <td><?php echo $value->MUTATION_CUSTOMER_NAME;?></td>
			        <td><?php echo $value->BARCODE_DATE;?></td>
			        <td><?php echo $value->BARCODE_NO;?></td>
			        <td><?php echo $value->BARCODE_QTY;?></td>
			        <td><?php echo $value->BARCODE_UNITS;?></td>
			        <td><?php echo $value->MUTATION_NEW_CODE_ITEM;?></td>
			        <td><?php echo $value->MUTATION_NEW_PART_NAME;?></td>
			        <td><?php echo $value->MUTATION_NEW_PART_NO;?></td>
			        <td><?php echo $value->MUTATION_NEW_MODEL;?></td>
			        <td><?php echo $value->MUTATION_NEW_CUSTOMER_NAME;?></td>
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
	
</div>