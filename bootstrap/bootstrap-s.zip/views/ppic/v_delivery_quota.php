<section class="content-header">
	<h3>Delivery Quota Data</h3>
	<small>Data Delivery Quota</small>
</section>

<!-- Main content -->
<section class="content"> 
<div class="box">
	

	<div class="box-body">
		<!--TABLE-->
		<table id="delivery_quota" class="table table-bordered table-hover table-striped dataTable"  cellspacing="0" width="100%">
		    <thead>
		      <tr>
		        <th>No</th>
		        <th>Vehicle Name</th>
		        <th>Vehicle No</th>
		        <th>Total Standart</th>        
		        <th>Total Actual</th>
		        <th>Total Profit / (loss)</th>		        
		        <th>Volume (%)</th>
		        
		        <th>Detail</th>
		      </tr>
		    </thead>
		    <tbody>
		    	<?php $no=0; foreach ($data as $value) { $no++; ?>
			      <tr>
			        <td><?php echo $no;?></td>
			        <td><?php echo $value->VEHICLE_NAME;?></td>
			        <td><?php echo $value->VEHICLE_NO;?></td>
			        <td><?php echo $value->TOTAL_STANDARD;?></td>			        
			        <td><?php echo $value->TOTAL_ACTUAL;?></td>
			        <td><?php echo $value->TOTAL_PROFIT;?></td>		        
			        <td><?php echo $value->TOTAL_VOLUME;?></td>		        
			        	        
			        <td><a href="<?php echo site_url()."/delivery_quota/detail/".$value->KPS_VEHICLE_ID;?>">Detail</a></td>	        
			      </tr>
		      <?php } ?>
		    </tbody>
		</table>
		<!--TABLE-->
	</div>
</div>

